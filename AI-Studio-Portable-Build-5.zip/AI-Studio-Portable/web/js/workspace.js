/* Presentation enhancement only: move existing controls without cloning them,
   changing their form owner, or touching authentication, storage or requests. */
(() => {
    const form = document.getElementById('studio-form');
    if (!form) return;
    const get = selector => form.querySelector(selector);
    const bar = document.createElement('div');
    bar.className = 'studio-settings-bar';
    const groups = [];
    function group(label, nodes, name) {
        const details = document.createElement('details');
        details.className = `studio-setting-group studio-setting-${name}`;
        const summary = document.createElement('summary');
        summary.textContent = label;
        const content = document.createElement('div');
        content.className = 'studio-setting-content';
        nodes.filter(Boolean).forEach(node => content.append(node));
        details.append(summary, content);
        bar.append(details);
        groups.push(details);
        details.addEventListener('toggle', () => {
            if (details.open) groups.forEach(other => { if (other !== details) other.open = false; });
        });
        return summary;
    }
    const prompt = document.createElement('div');
    prompt.className = 'studio-prompt-block';
    [get('.prompt-header'), get('#prompt'), get('#prompt-count')?.closest('.field-caption')].filter(Boolean).forEach(node => prompt.append(node));
    const promptPair = document.createElement('div');
    promptPair.className = 'studio-prompt-pair';
    promptPair.append(prompt);
    const negative = get('#negative-settings');
    if (negative) {
        negative.open = true;
        const summary = negative.querySelector('summary');
        const label = document.createElement('strong');
        label.textContent = 'Negative prompt';
        const optional = document.createElement('small');
        optional.textContent = 'Optional';
        const chevron = document.createElement('span');
        chevron.textContent = '⌄';
        chevron.setAttribute('aria-hidden', 'true');
        summary.replaceChildren(label, optional, chevron);
        promptPair.append(negative);
    }
    const modelSummary = group('Model', [get('label[for="architecture"]'),get('#architecture'),get('label[for="model"]'),get('#model'),get('#model-note'),get('#prompt-enhance-wrapper')], 'model');
    const styleSummary = group('Style & LoRAs', [get('.lora-fieldset')], 'style');
    const canvasSummary = group('Canvas', [...form.querySelectorAll('.ratio-fieldset')], 'canvas');
    group('Presets', [get('.preset-launcher-bar')], 'presets');
    group('Advanced', [get('#advanced-settings')], 'advanced');
    const advanced = bar.querySelector('#advanced-settings');
    if (advanced) advanced.open = true;
    const sliders = get('#composer-mode-sliders');
    const generate = get('.generate-bar');
    form.prepend(promptPair, bar);
    if (sliders) bar.after(sliders);
    if (generate) form.append(generate);
    const heading = document.getElementById('compose-title');
    if (heading) heading.textContent = 'What do you want to create?';
    function updateSummary() {
        const model = get('#model');
        modelSummary.textContent = model?.selectedOptions[0]?.textContent || 'Model';
        const ratio = get('input[name="ratio"]:checked');
        const resolution = get('input[name="resolution"]:checked');
        canvasSummary.textContent = `${ratio?.closest('label')?.querySelector('strong')?.textContent || 'Canvas'} · ${resolution?.closest('label')?.querySelector('strong')?.textContent || 'Resolution'}`;
        const count = get('#lora-count');
        styleSummary.textContent = `Style & LoRAs${count?.textContent ? ' · ' + count.textContent : ''}`;
    }
    form.addEventListener('change', updateSummary);
    new MutationObserver(updateSummary).observe(get('#model'), { childList: true, subtree: true, characterData: true });
    new MutationObserver(updateSummary).observe(get('#lora-count'), { childList: true, subtree: true, characterData: true });
    // Native validation must be able to reveal a control inside a closed group.
    form.addEventListener('invalid', event => {
        const parent = event.target.closest('.studio-setting-group');
        if (parent) parent.open = true;
    }, true);
    document.addEventListener('pointerdown', event => {
        if (!bar.contains(event.target)) groups.forEach(group => { group.open = false; });
    });
    document.addEventListener('keydown', event => {
        if (event.key !== 'Escape') return;
        const open = groups.find(group => group.open);
        if (open) { open.open = false; open.querySelector('summary').focus(); }
    });
    window.addEventListener('studio-mode-change', () => {
        groups.forEach(group => { group.open = false; });
        updateSummary();
    });
    // Keep the existing mode buttons and handlers, now in a persistent app rail.
    const icons = {
        txt2img:'M12 3l2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5Z',
        img2img:'M4 4h16v16H4Z M4 16l5-5 4 4 3-3 4 4 M15 8h.01',
        inpaint:'M14 5l5 5 M5 19l4-1 11-11-4-4L5 14Z M4 21h16',
        chat:'M21 11a9 9 0 0 1-9 9H4l-2 2V11a9 9 0 0 1 19 0Z'
    };
    const names = {txt2img:'Create',img2img:'Transform',inpaint:'Inpaint',chat:'Chat'};
    document.querySelectorAll('.generator-mode-tabs .mode-tab').forEach(tab => {
        const icon = document.createElement('span');
        icon.className = 'studio-nav-icon';
        icon.setAttribute('aria-hidden','true');
        const svg = document.createElementNS('http://www.w3.org/2000/svg','svg');
        svg.setAttribute('viewBox','0 0 24 24');
        svg.setAttribute('fill','none');
        svg.setAttribute('stroke','currentColor');
        svg.setAttribute('stroke-width','1.6');
        svg.setAttribute('stroke-linejoin','round');
        const path = document.createElementNS('http://www.w3.org/2000/svg','path');
        path.setAttribute('d',icons[tab.dataset.mode]);
        svg.append(path);
        icon.append(svg);
        tab.prepend(icon);
        tab.querySelector('strong').textContent = names[tab.dataset.mode];
        tab.title = {txt2img:'Text to image',img2img:'Image to image',inpaint:'Paint selected areas',chat:'AI chat'}[tab.dataset.mode];
    });
    document.body.classList.add('studio-workspace-v2');
    updateSummary();
})();

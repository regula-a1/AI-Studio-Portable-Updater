(function () {
    'use strict';

    // Report a problem.
    //
    // The preview is not a convenience, it is the whole design. Everything in a
    // report is collected from the machine rather than typed by the user, so the
    // only way for them to know what is in it is to read it - which is why it
    // loads as soon as the dialog opens rather than waiting behind a button, and
    // why it shows the finished file rather than a summary of it.
    //
    // Nothing is transmitted. Saving writes a file they send wherever they like.

    const dialog = document.querySelector('#report-dialog');
    if (!dialog) return;

    const openBtn = document.querySelector('#report-problem');
    const closeBtn = document.querySelector('#report-close');
    const noteField = document.querySelector('#report-note');
    const previewEl = document.querySelector('#report-preview');
    const statusEl = document.querySelector('#report-status');
    const saveBtn = document.querySelector('#report-save');
    const openBtnFolder = document.querySelector('#report-open-folder');
    const refreshBtn = document.querySelector('#report-refresh');

    let savedPath = '';

    async function post(action, body) {
        const response = await fetch('/api/studio?action=' + action, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body || {})
        });
        const result = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(result.error || 'The studio could not build the report.');
        return result;
    }

    async function loadPreview() {
        previewEl.textContent = 'Building the report…';
        try {
            const result = await post('report-preview', { note: noteField.value });
            previewEl.textContent = result.text || '(empty)';
        } catch (error) {
            previewEl.textContent = 'Could not build the report: ' + error.message;
        }
    }

    openBtn?.addEventListener('click', () => {
        savedPath = '';
        statusEl.textContent = '';
        if (openBtnFolder) openBtnFolder.hidden = true;
        dialog.showModal();
        loadPreview();
    });

    closeBtn?.addEventListener('click', () => dialog.close());
    dialog.addEventListener('click', event => { if (event.target === dialog) dialog.close(); });

    refreshBtn?.addEventListener('click', loadPreview);
    // Retyping the note without refreshing would show a preview that is not what
    // gets saved, which is the one thing this dialog must not do.
    noteField?.addEventListener('blur', loadPreview);

    saveBtn?.addEventListener('click', async () => {
        saveBtn.disabled = true;
        statusEl.textContent = 'Saving…';
        try {
            const result = await post('report-save', { note: noteField.value });
            savedPath = result.path || '';
            // The folder opens with the file selected, so say that rather than
            // printing a path and leaving them to go looking for it.
            statusEl.textContent = result.revealed
                ? 'Saved. The folder is open with ' + (result.name || 'the report')
                  + ' selected — drag it wherever you need to send it.'
                : 'Saved to ' + savedPath;
            if (openBtnFolder) openBtnFolder.hidden = false;
        } catch (error) {
            statusEl.textContent = error.message;
        } finally {
            saveBtn.disabled = false;
        }
    });

    openBtnFolder?.addEventListener('click', async () => {
        try {
            const result = await post('report-reveal', {});
            statusEl.textContent = result.ok
                ? 'Opened the folder.'
                : 'Could not open the folder. The file is at ' + (result.path || savedPath);
        } catch (error) {
            statusEl.textContent = error.message;
        }
    });
}());

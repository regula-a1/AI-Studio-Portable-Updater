(function () {
    "use strict";
    // Reaching a page behind the Studio gate means the unlock worked, so clear
    // the gate's loop marker. If the gate sees it again it knows the browser
    // came back locked instead of failing silently.
    try { sessionStorage.removeItem('studio-gate-unlocking'); } catch (error) { /* private window */ }
    const resolutions = {
        "draft": {
            label: "Draft",
            sizes: {
                square: { width: 512, height: 512 },
                portrait: { width: 432, height: 576 },
                landscape: { width: 576, height: 432 },
                wide: { width: 672, height: 384 }
            }
        },
        "1mp": {
            label: "1MP",
            sizes: {
                square: { width: 1024, height: 1024 },
                portrait: { width: 864, height: 1152 },
                landscape: { width: 1152, height: 864 },
                wide: { width: 1280, height: 720 }
            }
        },
        "2mp": {
            label: "2MP",
            sizes: {
                square: { width: 1408, height: 1408 },
                portrait: { width: 1248, height: 1664 },
                landscape: { width: 1664, height: 1248 },
                wide: { width: 1920, height: 1080 }
            }
        },
        "3mp": {
            label: "3MP",
            sizes: {
                square: { width: 1728, height: 1728 },
                portrait: { width: 1536, height: 2048 },
                landscape: { width: 2048, height: 1536 },
                wide: { width: 2304, height: 1296 }
            }
        },
        "4mp": {
            label: "4MP",
            sizes: {
                square: { width: 2048, height: 2048 },
                portrait: { width: 1728, height: 2304 },
                landscape: { width: 2304, height: 1728 },
                wide: { width: 2560, height: 1440 }
            }
        },
        "8mp_ultra": {
            label: "8MP Ultra",
            sizes: {
                square: { width: 2880, height: 2880 },
                portrait: { width: 2496, height: 3328 },
                landscape: { width: 3328, height: 2496 },
                wide: { width: 3840, height: 2160 }
            }
        }
    };
    const ratioLabels = {
        square: "Square · 1:1",
        portrait: "Portrait · 3:4",
        landscape: "Landscape · 4:3",
        wide: "Wide · 16:9"
    };
    const architectures = {
        krea2: {
            label: "Krea 2 (DiT)",
            models: ["krea2_turbo"],
            defaultModel: "krea2_turbo"
        },
        sdxl: {
            label: "SDXL (Photorealistic)",
            models: ["sdxl_cyberrealistic"],
            defaultModel: "sdxl_cyberrealistic"
        },
        anima: {
            label: "Anima (Anime DiT)",
            models: ["anima_base"],
            defaultModel: "anima_base"
        },
        illustrious: {
            label: "Illustrious (Anime)",
            models: ["illustrious_base"],
            defaultModel: "illustrious_base"
        }
    };
    // Shipped defaults only. Anything the user installs themselves is merged in
    // at runtime from the local model registry, which the server builds by
    // scanning the model folders.
    const modelDetails = {
        krea2_turbo: { label: "Krea 2 Turbo", note: "Krea 2 Turbo distilled base checkpoint; best for perspective LoRAs, clean angles, and LanPaint inpainting. 16 steps, Euler.", canvas: "Krea 2 Turbo", sampler: "Euler", steps: "16", guidance: "1.0", architecture: "krea2", samplerKey: "euler", loras: {} },
        sdxl_cyberrealistic: { label: "CyberRealistic XL v1.0", note: "CyberRealistic XL v1.0 photorealistic SDXL checkpoint. 30 steps, DPM++ 2M SDE Karras.", canvas: "CyberRealistic XL", sampler: "DPM++ 2M SDE", steps: "30", guidance: "4.5", architecture: "sdxl", samplerKey: "dpmpp_2m_sde_gpu" },
        anima_base: { label: "Anima Base 1.0", note: "Anima 2B DiT anime base checkpoint. 30 steps, ER-SDE.", canvas: "Anima Base", sampler: "ER-SDE", steps: "30", guidance: "4.5", architecture: "anima", samplerKey: "er_sde" },
        illustrious_base: { label: "Illustrious XL Base v0.1", note: "Illustrious-XL v0.1 anime checkpoint. 28 steps, Euler Ancestral.", canvas: "Illustrious Base", sampler: "Euler Ancestral", steps: "28", guidance: "6.0", architecture: "illustrious", samplerKey: "euler_ancestral" }
    };
    // No saved state predates this build, so there is nothing to migrate.
    const legacyModelMap = {};
    // Checkpoints with their own LanPaint masked-edit path. Mirrors INPAINT_CHECKPOINTS
    // in app/orchestrator.py. Anything else is switched to Turbo here, because the
    // orchestrator now refuses a masked job whose graph has no mask node rather than
    // building one that ignores it.
    const inpaintModels = ["krea2_turbo"];
    const inpaintSteps = model => String(Math.max(16, Number(modelDetails[model]?.steps) || 16));
    // Ships empty by design. The portable build discovers LoRAs from the user's own
    // models/loras folder; shipping a curated list is what phase 4 replaces this with.
    const loraDetails = {};
    // The one preset that ships, filed under "Starter Prompts": a character
    // prompt written out in full.
    //
    // It is an example, not a sampler. Ten assorted presets shipped before this
    // and a bracketed template briefly sat beside it; both are gone. A worked
    // example shows the shape of a good prompt on its own, and the library is
    // meant to fill up with the user's own saved settings rather than ours.
    //
    // Krea 2 Turbo only, because it is the only checkpoint this build ships. A preset
    // naming a model that is not installed would offer itself, load, and then fail at
    // generation time - worse than not being offered.
    //
    // No negative prompts, and no steps, guidance or sampler. Krea 2 feeds its negative
    // branch through ConditioningZeroOut, so negative text is silently discarded there;
    // and useStarter treats any spelled-out advanced value as deliberate, which would
    // pin Turbo's 16 steps at CFG 1.0 onto whatever checkpoint the user switched to
    // next. Leaving them out lets each model keep its own defaults.
    const presetCatalog = [
        {
            id: "starter-character-example",
            title: "Sample Character Prompt",
            category: "Starter Prompts",
            architecture: "krea2",
            model: "krea2_turbo",
            loras: {},
            ratio: "portrait",
            resolution: "1mp",
            tags: ["example", "character", "selfie", "filled in"],
            prompt: `24 years old, tan, straightened sleek blonde hair that falls just past her shoulders. Simple Caucasian American suburban style—minimal makeup, soft freckles across her nose, bright blue eyes, and a friendly, approachable smile.  Energetic volleyball player with a sunny, optimistic personality.

Wearing simple tees, denim shorts, and simple stud earrings.

The year is 2023, Selfie taken on her iPhone in bedroom mirror standing at a slight angle.`
        }
    ];
    const form = document.querySelector("#studio-form");
    const privatePromptKey = "aistudio-private-preset-prompt:v1";
    const prompt = document.querySelector("#prompt");
    const negativePrompt = document.querySelector("#negative-prompt");
    const negativeSettings = document.querySelector("#negative-settings");
    const seed = document.querySelector("#seed");
    const stepsInput = document.querySelector("#steps");
    const guidanceInput = document.querySelector("#guidance");
    const samplerSelect = document.querySelector("#sampler");
    const resetAdvancedBtn = document.querySelector("#reset-advanced");
    const loraList = document.querySelector("#lora-list");
    const feedback = document.querySelector("#connection-note");
    let storageKey;
    let privatePromptActive = false;
    let activeLoras = [];
    let activeLoraCategory = "All";
    let currentMode = "txt2img";

    function normalizeLoras(value, architecture, fallback = {}) {
        const source = Array.isArray(value) ? value : Object.entries(fallback).map(([id, strength]) => ({ id, strength }));
        const seen = new Set();
        return source.slice(0, 8).flatMap(item => {
            const detail = loraDetails[item?.id];
            if (!detail || detail.architecture !== architecture || seen.has(item.id)) return [];
            seen.add(item.id);
            const numeric = Number(item.strength);
            const strength = Number.isFinite(numeric) ? Math.min(1.5, Math.max(0.1, Math.round(numeric * 20) / 20)) : detail.defaultStrength;
            return [{ id: item.id, strength }];
        });
    }

    const loraGuideDialog = document.querySelector("#lora-guide-dialog");
    const loraGuideTitle = document.querySelector("#lora-guide-title");
    const loraGuideSubtitle = document.querySelector("#lora-guide-subtitle");
    const loraGuideBody = document.querySelector("#lora-guide-body");
    const loraGuideClose = document.querySelector("#lora-guide-close");
    const loraGuideDone = document.querySelector("#lora-guide-done");
    const loraGuideEnable = document.querySelector("#lora-guide-enable");
    const loraGuideStatus = document.querySelector("#lora-guide-status");

    function insertTagToPrompt(tag) {
        const text = tag.trim();
        if (!text) return false;
        const current = prompt.value.trim();
        const lower = current.toLowerCase();
        if (lower.includes(text.toLowerCase())) {
            return false;
        }
        prompt.value = current ? `${current}, ${text}`.slice(0, 4000) : text.slice(0, 4000);
        update();
        persist();
        prompt.focus();
        return true;
    }

    function showLoraGuide(id) {
        const detail = loraDetails[id];
        if (!detail || !loraGuideDialog) return;
        if (loraGuideTitle) loraGuideTitle.textContent = `${detail.label} — Keywords Key`;
        if (loraGuideSubtitle) {
            loraGuideSubtitle.textContent = `${detail.architecture.toUpperCase()} · Recommended Strength: ${detail.defaultStrength.toFixed(2)} · ${detail.description}`;
        }
        if (loraGuideStatus) loraGuideStatus.textContent = "";
        if (loraGuideBody) {
            loraGuideBody.replaceChildren();
            if (detail.authorNote) {
                const noteBox = document.createElement("div");
                noteBox.className = "lora-guide-note";
                noteBox.innerHTML = `<strong>Creator Tips:</strong> <span>${detail.authorNote}</span>`;
                loraGuideBody.appendChild(noteBox);
            }
            const sections = detail.keywordSections || [];
            if (!sections.length && detail.trigger) {
                sections.push({
                    title: "Trigger Words",
                    tags: detail.trigger.split(",").map(t => t.trim()).filter(Boolean)
                });
            }
            for (const section of sections) {
                const secEl = document.createElement("div");
                secEl.className = "lora-guide-section";
                const headEl = document.createElement("div");
                headEl.className = "lora-guide-section-head";
                const heading = document.createElement("h3");
                heading.textContent = section.title;
                const addAllBtn = document.createElement("button");
                addAllBtn.type = "button";
                addAllBtn.className = "text-button lora-guide-add-all";
                addAllBtn.textContent = "Insert all in category";
                addAllBtn.addEventListener("click", () => {
                    let addedCount = 0;
                    for (const tag of section.tags) {
                        if (insertTagToPrompt(tag)) addedCount++;
                    }
                    if (loraGuideStatus) {
                        loraGuideStatus.textContent = addedCount > 0 ? `Added ${addedCount} tags to prompt.` : "Tags are already in prompt.";
                    }
                });
                headEl.append(heading, addAllBtn);
                secEl.appendChild(headEl);

                const tagsEl = document.createElement("div");
                tagsEl.className = "lora-guide-tags";
                for (const tag of section.tags) {
                    const tagBtn = document.createElement("button");
                    tagBtn.type = "button";
                    tagBtn.className = "lora-tag-chip";
                    tagBtn.textContent = tag;
                    tagBtn.title = `Click to insert "${tag}" into prompt`;
                    tagBtn.addEventListener("click", () => {
                        const added = insertTagToPrompt(tag);
                        if (loraGuideStatus) {
                            loraGuideStatus.textContent = added ? `Added "${tag}" to prompt.` : `"${tag}" is already in prompt.`;
                        }
                    });
                    tagsEl.appendChild(tagBtn);
                }
                secEl.appendChild(tagsEl);
                loraGuideBody.appendChild(secEl);
            }
        }
        if (loraGuideEnable) {
            const isActive = activeLoras.some(l => l.id === id);
            loraGuideEnable.textContent = isActive ? "Active in current stack" : `Enable ${detail.label} (${detail.defaultStrength.toFixed(2)})`;
            loraGuideEnable.disabled = isActive;
            loraGuideEnable.onclick = () => {
                if (!activeLoras.some(l => l.id === id)) {
                    activeLoras.push({ id, strength: detail.defaultStrength });
                    renderLoras();
                    update();
                    persist();
                    loraGuideEnable.textContent = "Active in current stack";
                    loraGuideEnable.disabled = true;
                    if (loraGuideStatus) loraGuideStatus.textContent = `${detail.label} layer enabled!`;
                }
            };
        }
        loraGuideDialog.showModal();
    }

    function addTrigger(trigger) {
        const tokens = trigger.split(",").map(token => token.trim()).filter(Boolean);
        const current = prompt.value.trim();
        const lower = current.toLowerCase();
        const missing = tokens.filter(token => !lower.includes(token.toLowerCase()));
        if (!missing.length) {
            feedback.textContent = "Trigger words are already in the prompt.";
            return;
        }
        prompt.value = `${missing.join(", ")}${current ? `, ${current}` : ""}`.slice(0, 4000);
        update(); persist(); prompt.focus();
        feedback.textContent = "Trigger words added to the prompt.";
    }

    function renderLoras() {
        if (!loraList) return;
        const arch = form.elements.architecture?.value || "krea2";
        const active = new Map(activeLoras.map(item => [item.id, item.strength]));
        const compatible = Object.entries(loraDetails).filter(([, detail]) => detail.architecture === arch);

        // 1. Render Active Stack Tray
        const activeTray = document.querySelector("#lora-active-tray");
        if (activeTray) {
            if (activeLoras.length > 0) {
                activeTray.hidden = false;
                activeTray.replaceChildren();

                const trayHead = document.createElement("div");
                trayHead.className = "lora-active-tray-head";

                const trayTitle = document.createElement("span");
                trayTitle.className = "lora-active-tray-title";
                trayTitle.textContent = `Active Stack (${activeLoras.length}):`;
                trayHead.appendChild(trayTitle);

                if (activeLoras.length >= 2) {
                    const clearBtn = document.createElement("button");
                    clearBtn.type = "button";
                    clearBtn.className = "lora-active-clear-btn text-button";
                    clearBtn.textContent = "Clear all";
                    clearBtn.addEventListener("click", () => {
                        activeLoras = [];
                        renderLoras();
                        update();
                        persist();
                    });
                    trayHead.appendChild(clearBtn);
                }
                activeTray.appendChild(trayHead);

                const pillsWrap = document.createElement("div");
                pillsWrap.className = "lora-active-pills";
                for (const item of activeLoras) {
                    const detail = loraDetails[item.id];
                    const pill = document.createElement("div");
                    pill.className = "lora-active-pill";

                    const pillLabel = document.createElement("span");
                    pillLabel.className = "lora-active-pill-label";
                    pillLabel.dataset.loraPill = item.id;
                    pillLabel.textContent = `${detail?.label || item.id} (${Number(item.strength).toFixed(2)})`;

                    const removeBtn = document.createElement("button");
                    removeBtn.type = "button";
                    removeBtn.className = "lora-active-pill-remove";
                    removeBtn.setAttribute("aria-label", `Remove ${detail?.label || item.id}`);
                    removeBtn.innerHTML = "&times;";
                    removeBtn.addEventListener("click", (e) => {
                        e.stopPropagation();
                        activeLoras = activeLoras.filter(l => l.id !== item.id);
                        renderLoras();
                        update();
                        persist();
                    });

                    pill.append(pillLabel, removeBtn);
                    pillsWrap.appendChild(pill);
                }
                activeTray.appendChild(pillsWrap);
            } else {
                activeTray.hidden = true;
                activeTray.replaceChildren();
            }
        }

        // 2. Render LoRA Role Filter Bar
        const filterBar = document.querySelector("#lora-filter-bar");
        if (filterBar) {
            const rolesInArch = Array.from(new Set(compatible.map(([, d]) => d.role || "General"))).filter(Boolean);
            if (rolesInArch.length > 1) {
                filterBar.hidden = false;
                filterBar.replaceChildren();
                const filterCategories = ["All", ...rolesInArch];
                for (const cat of filterCategories) {
                    const chip = document.createElement("button");
                    chip.type = "button";
                    chip.className = "lora-filter-chip";
                    chip.dataset.active = String(activeLoraCategory === cat);
                    chip.textContent = cat;
                    chip.addEventListener("click", () => {
                        activeLoraCategory = cat;
                        renderLoras();
                    });
                    filterBar.appendChild(chip);
                }
            } else {
                filterBar.hidden = true;
                filterBar.replaceChildren();
            }
        }

        // 3. Render Cards
        const displayedLoras = compatible.filter(([, detail]) => {
            if (activeLoraCategory === "All") return true;
            return (detail.role || "General") === activeLoraCategory;
        });

        loraList.replaceChildren();
        for (const [id, detail] of displayedLoras) {
            const isItemActive = active.has(id);
            const card = document.createElement("div"); 
            card.className = "lora-layer"; 
            card.dataset.active = String(isItemActive); 
            card.dataset.loraId = id;

            const main = document.createElement("div"); 
            main.className = "lora-layer-main";

            const toggleLabel = document.createElement("label"); 
            toggleLabel.className = "lora-toggle";
            const toggle = document.createElement("input"); 
            toggle.type = "checkbox"; 
            toggle.checked = isItemActive; 
            toggle.dataset.loraToggle = id; 
            toggle.setAttribute("aria-label", `Use ${detail.label}`);
            const track = document.createElement("span"); 
            track.setAttribute("aria-hidden", "true"); 
            toggleLabel.append(toggle, track);

            const name = document.createElement("span"); 
            name.className = "lora-name";
            const strong = document.createElement("strong"); 
            strong.textContent = detail.label;
            const description = document.createElement("small"); 
            description.textContent = detail.description; 
            name.append(strong, description);

            const meta = document.createElement("div"); 
            meta.className = "lora-meta";
            
            if (detail.keywordSections || detail.trigger) {
                const keyBtn = document.createElement("button");
                keyBtn.type = "button";
                keyBtn.className = "lora-key-btn";
                keyBtn.title = `View keywords and prompt key for ${detail.label}`;
                keyBtn.setAttribute("aria-label", `View keywords and prompt key for ${detail.label}`);
                keyBtn.innerHTML = `<span aria-hidden="true">🔑</span> <span class="lora-key-text">Key</span>`;
                keyBtn.addEventListener("click", (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    showLoraGuide(id);
                });
                meta.append(keyBtn);
            }
            if (detail.role) {
                const role = document.createElement("span"); 
                role.className = "lora-role"; 
                role.textContent = detail.role;
                meta.append(role);
            }
            main.append(toggleLabel, name, meta);

            const controls = document.createElement("div"); 
            controls.className = "lora-controls";
            controls.hidden = !isItemActive;

            const range = document.createElement("input"); 
            range.type = "range"; 
            range.min = "0.1"; 
            range.max = "1.5"; 
            range.step = "0.05"; 
            range.value = String(active.get(id) ?? detail.defaultStrength); 
            range.dataset.loraStrength = id; 
            range.setAttribute("aria-label", `${detail.label} strength`);
            
            const output = document.createElement("output"); 
            output.className = "lora-strength"; 
            output.value = Number(range.value).toFixed(2); 
            output.textContent = output.value;
            controls.append(range, output);

            if (detail.trigger) {
                const trigger = document.createElement("button"); 
                trigger.type = "button"; 
                trigger.className = "text-button lora-trigger"; 
                trigger.textContent = `Add trigger: ${detail.trigger}`; 
                trigger.addEventListener("click", () => addTrigger(detail.trigger)); 
                controls.append(trigger);
            }
            if (detail.keywordSections) {
                const guideLink = document.createElement("button");
                guideLink.type = "button";
                guideLink.className = "text-button lora-guide-link";
                guideLink.textContent = "🔑 View keywords & trigger words";
                guideLink.addEventListener("click", () => showLoraGuide(id));
                controls.append(guideLink);
            }

            toggle.addEventListener("change", () => {
                // Work off activeLoras, not the `active` map snapshot taken at render
                // time: slider changes mutate activeLoras without re-rendering, so the
                // map goes stale and rebuilding from it would reset every weight.
                if (toggle.checked) {
                    if (!activeLoras.some(layer => layer.id === id)) {
                        activeLoras.push({ id, strength: Number(range.value) });
                    }
                } else {
                    activeLoras = activeLoras.filter(layer => layer.id !== id);
                }
                renderLoras(); 
                update(); 
                persist();
            });

            range.addEventListener("input", () => {
                const item = activeLoras.find(layer => layer.id === id);
                if (item) item.strength = Number(range.value);
                output.value = Number(range.value).toFixed(2); 
                output.textContent = output.value;
                const pillLabel = document.querySelector(`[data-lora-pill="${id}"]`);
                if (pillLabel) pillLabel.textContent = `${detail.label} (${output.value})`;
                update(); 
                persist();
            });

            card.append(main, controls); 
            loraList.append(card);
        }
        if (!displayedLoras.length) {
            const empty = document.createElement("p"); 
            empty.className = "lora-empty"; 
            empty.textContent = compatible.length ? "No LoRAs in this category." : "No compatible LoRA layers are configured for this architecture."; 
            loraList.append(empty);
        }
        const count = document.querySelector("#lora-count");
        if (count) count.textContent = `${activeLoras.length} active`;
    }
    function syncModelDropdown(arch, preferredModel) {
        const modelSelect = form.elements.model;
        if (!modelSelect) return;
        const archConfig = architectures[arch] || architectures.krea2;
        modelSelect.replaceChildren();
        for (const modelKey of archConfig.models) {
            const opt = document.createElement("option");
            opt.value = modelKey;
            opt.textContent = modelDetails[modelKey]?.label || modelKey;
            modelSelect.appendChild(opt);
        }
        if (archConfig.models.includes(preferredModel)) {
            modelSelect.value = preferredModel;
        } else {
            modelSelect.value = archConfig.defaultModel;
        }
        markUnavailableModels();
    }
    // Which advanced fields the user has typed into by hand. Switching base
    // checkpoint re-follows the new checkpoint's defaults only for the fields
    // still untouched, so hand-tuned values survive the switch.
    const advancedTouched = new Set();
    function syncAdvancedForModel() {
        const model = form.elements.model?.value || "krea2_turbo";
        const detail = modelDetails[model] || modelDetails.krea2_turbo;
        const defaultSteps = currentMode === "inpaint" ? inpaintSteps(model) : detail.steps;
        if (stepsInput) {
            stepsInput.placeholder = defaultSteps;
            if (!advancedTouched.has("steps")) stepsInput.value = defaultSteps;
        }
        if (guidanceInput) {
            guidanceInput.placeholder = detail.guidance;
            if (!advancedTouched.has("guidance")) guidanceInput.value = detail.guidance;
        }
        if (samplerSelect && !advancedTouched.has("sampler")) {
            samplerSelect.value = detail.samplerKey || "euler";
        }
    }
    function resetAdvancedDefaults() {
        advancedTouched.clear();
        const model = form.elements.model?.value || "krea2_turbo";
        const detail = modelDetails[model] || modelDetails.krea2_turbo;
        if (seed) seed.value = "";
        if (stepsInput) {
            const defaultSteps = currentMode === "inpaint" ? inpaintSteps(model) : detail.steps;
            stepsInput.value = defaultSteps;
            stepsInput.placeholder = defaultSteps;
        }
        if (guidanceInput) {
            guidanceInput.value = detail.guidance;
            guidanceInput.placeholder = detail.guidance;
        }
        if (samplerSelect) {
            samplerSelect.value = detail.samplerKey || "euler";
        }
    }
    function settings() {
        // Ephemeral user settings (seed, steps, guidance, sampler) are intentionally
        // excluded so they are never saved in browser storage or break the local generator.
        return {
            prompt: privatePromptActive ? "" : prompt.value,
            negativePrompt: negativePrompt?.value || "",
            ratio: form.elements.ratio?.value || "square",
            resolution: form.elements.resolution?.value || "1mp",
            architecture: form.elements.architecture?.value || "krea2",
            model: form.elements.model?.value || "krea2_turbo",
            loras: activeLoras.map(item => ({ ...item })),
            upscale: Boolean(form.elements.upscale?.checked),
            promptEnhance: Boolean(form.elements['prompt-enhance']?.checked)
        };
    }
    function clean(value) {
        let res = value?.resolution;
        if (res === "fast") res = "1mp";
        if (res === "hd") res = "2mp";
        if (res === "8mp") res = "8mp_ultra";
        if (res === "preview") res = "draft";
        if (!Object.hasOwn(resolutions, res)) res = "1mp";

        const rawModel = value?.model;
        const legacy = legacyModelMap[rawModel];

        let arch = value?.architecture || legacy?.architecture;
        if (!Object.hasOwn(architectures, arch)) {
            if (typeof rawModel === "string" && rawModel.startsWith("illustrious_")) {
                arch = "illustrious";
            } else if (typeof rawModel === "string" && rawModel.startsWith("anima_")) {
                arch = "anima";
            } else if (typeof rawModel === "string" && rawModel.startsWith("sdxl_")) {
                arch = "sdxl";
            } else {
                arch = "krea2";
            }
        }
        const archConfig = architectures[arch] || architectures.krea2;
        let model = legacy?.model || rawModel;
        if (!archConfig.models.includes(model)) {
            model = archConfig.defaultModel;
        }

        let lorasInput = value?.loras;
        if (legacy?.loras && (!Array.isArray(lorasInput) || lorasInput.length === 0)) {
            lorasInput = legacy.loras;
        }

        return {
            prompt: typeof value?.prompt === "string" ? value.prompt.slice(0, 4000) : "",
            negativePrompt: typeof value?.negativePrompt === "string" ? value.negativePrompt.slice(0, 4000) : "",
            seed: /^\d{1,15}$/.test(String(value?.seed || "")) ? String(value.seed) : "",
            ratio: Object.hasOwn(ratioLabels, value?.ratio) ? value.ratio : "square",
            resolution: res,
            architecture: arch,
            model: model,
            loras: normalizeLoras(lorasInput, arch, {}),
            upscale: value?.upscale !== false,
            promptEnhance: Boolean(value?.promptEnhance)
        };
    }
    function persist() {
        try { localStorage.setItem(storageKey, JSON.stringify({ current: settings() })); return true; }
        catch { feedback.textContent = "Browser storage is unavailable. Changes will last only for this visit."; return false; }
    }
    function update() {
        const ratioKey = form.elements.ratio?.value || "square";
        const resolutionKey = form.elements.resolution?.value || "1mp";
        const resObj = resolutions[resolutionKey] || resolutions["1mp"];
        const size = resObj.sizes[ratioKey] || resolutions["1mp"].sizes.square;
        const ratioLabel = ratioLabels[ratioKey] || ratioLabels.square;
        const model = form.elements.model?.value || "krea2_turbo";
        const supportsNegativePrompt = !model.startsWith("krea2_");
        const upscale = Boolean(form.elements.upscale?.checked);
        const isStudio2 = model.startsWith("krea2_");
        const promptEnhanceToggle = document.querySelector("#prompt-enhance-wrapper");
        const promptEnhanceInput = form.elements['prompt-enhance'];
        if (!isStudio2) {
            if (promptEnhanceInput) {
                promptEnhanceInput.checked = false;
                promptEnhanceInput.disabled = true;
            }
            if (promptEnhanceToggle) {
                promptEnhanceToggle.title = "Prompt Enhancer is only available for Krea 2 models";
                promptEnhanceToggle.style.opacity = "0.5";
            }
        } else {
            if (promptEnhanceInput) promptEnhanceInput.disabled = false;
            if (promptEnhanceToggle) {
                promptEnhanceToggle.title = "";
                promptEnhanceToggle.style.opacity = "";
            }
        }
        document.querySelector("#prompt-count").textContent = `${prompt.value.length.toLocaleString()} / 4,000`;
        if (negativeSettings) negativeSettings.hidden = !supportsNegativePrompt;
        const negativeCount = document.querySelector("#negative-prompt-count");
        if (negativeCount) negativeCount.textContent = `${(negativePrompt?.value.length || 0).toLocaleString()} / 4,000`;
        document.querySelector("#canvas-size").textContent = `${size.width} × ${size.height} (${resObj.label})`;
        document.querySelector("#canvas-ratio").textContent = `${ratioLabel} · ${resObj.label}`;
        document.querySelector("#canvas-frame").dataset.ratio = ratioKey;
        const modelNote = document.querySelector("#model-note");
        const stepsDefaultHint = document.querySelector("#steps-default-hint");
        const guidanceDefaultHint = document.querySelector("#guidance-default-hint");
        const samplerDefaultHint = document.querySelector("#sampler-default-hint");
        const canvasModel = document.querySelector("#canvas-model");
        const resolutionNote = document.querySelector("#resolution-note");
        const detail = modelDetails[model] || modelDetails.krea2_turbo;
        if (modelNote) {
            if (currentMode === "inpaint") {
                modelNote.textContent = `${detail.canvas} with the LanPaint inpainting engine. ${inpaintSteps(model)} steps, Euler, masked region only.`;
            } else {
                modelNote.textContent = detail.note;
            }
        }
        if (stepsDefaultHint) {
            stepsDefaultHint.textContent = resolutionKey === "8mp_ultra" && !upscale ? `Default: ${detail.steps} (+8 detail)` : `Default: ${detail.steps}`;
        }
        if (guidanceDefaultHint) {
            guidanceDefaultHint.textContent = `Default: ${detail.guidance || "1.0"}`;
        }
        if (samplerDefaultHint) {
            samplerDefaultHint.textContent = `Default: ${detail.sampler}`;
        }
        const baseCanvas = currentMode === "inpaint" ? `${detail.canvas} (LanPaint)` : detail.canvas;
        if (canvasModel) canvasModel.textContent = baseCanvas;
        const activeLabels = activeLoras.map(item => loraDetails[item.id]?.label).filter(Boolean);
        if (canvasModel && activeLabels.length) canvasModel.textContent = `${baseCanvas} · ${activeLabels.join(" + ")}`;
        if (stepsInput && !stepsInput.value) {
            stepsInput.placeholder = detail.steps;
        }
        if (guidanceInput && !guidanceInput.value) {
            guidanceInput.placeholder = detail.guidance || "1.0";
        }
        if (resolutionNote) {
            if (resolutionKey === "draft") {
                resolutionNote.textContent = "Draft renders directly at minimum size for ultra-fast prompt testing.";
            } else if (resolutionKey === "1mp") {
                resolutionNote.textContent = "1MP renders directly at native size.";
            } else if (upscale) {
                resolutionNote.textContent = `Generates 1MP composition base, then finishes at ${resObj.label} using SeedVR2 AI upscaler.`;
            } else if (resolutionKey === "8mp_ultra") {
                resolutionNote.textContent = "Generates at 4MP, then adds new fine detail with a second overlapping tiled Krea pass. Takes longer.";
            } else {
                resolutionNote.textContent = `Renders directly at native ${resObj.label} resolution.`;
            }
        }
    }
    function apply(value, isIdea = false) {
        privatePromptActive = false;
        const next = clean(value);
        prompt.value = next.prompt;
        if (negativePrompt) negativePrompt.value = next.negativePrompt;
        if (form.elements.ratio) form.elements.ratio.value = next.ratio;
        if (form.elements.resolution) form.elements.resolution.value = next.resolution;
        if (form.elements.architecture) form.elements.architecture.value = next.architecture;
        syncModelDropdown(next.architecture, next.model);
        activeLoras = next.loras;
        renderLoras();
        if (form.elements.upscale) form.elements.upscale.checked = next.upscale;
        if (form.elements['prompt-enhance']) form.elements['prompt-enhance'].checked = Boolean(next.promptEnhance);
        if (isIdea && next.seed) {
            seed.value = next.seed;
        } else {
            seed.value = "";
        }
        resetAdvancedDefaults();
        update();
    }
    // What this machine can actually run, from action=registry. Until it arrives
    // every checkpoint is assumed present, which is the right way round: a slow
    // or failed scan should not empty the dropdowns of models that do work.
    let installed = null;

    async function loadRegistry() {
        try {
            const response = await fetch("/api/studio?action=registry", { cache: "no-store" });
            if (!response.ok) return;
            const registry = await response.json();
            if (!registry.ready) return;
            installed = registry;
            markUnavailableModels();
            markUnavailableSamplers();
            applyLoraRegistry();
        } catch (error) {
            // Offline or mid-restart. Leaving `installed` null keeps every option
            // enabled rather than hiding models the user has.
        }
    }

    // Fill the picker's catalog from what the registry found. Only configured,
    // enabled, loadable layers: renderLoras filters by detail.architecture, which
    // an unconfigured LoRA does not have, and offering one would queue a job the
    // orchestrator rejects on the way in.
    function applyLoraRegistry() {
        for (const key of Object.keys(loraDetails)) delete loraDetails[key];
        for (const entry of Object.values(installed?.loras || {})) {
            if (!entry.configured || !entry.enabled || !entry.loadable) continue;
            loraDetails[entry.id] = {
                label: entry.label || entry.id,
                architecture: entry.architecture,
                defaultStrength: entry.defaultStrength ?? 0.8,
                trigger: entry.triggers || "",
                role: "General",
                note: entry.triggers
                    ? `Trigger words: ${entry.triggers}`
                    : "No trigger words set."
            };
        }
        renderLoras();
    }

    // A checkpoint whose weights are absent used to be offered anyway, and
    // choosing it failed inside ComfyUI with a message the user never saw.
    //
    // It was then listed as "not installed" instead, which was worse than it
    // sounds: a fresh install ships one checkpoint, so the picker was mostly a
    // list of things the user does not have and cannot use. Now they are
    // hidden, and the Models panel is where you go to see what exists and what
    // is missing - a list, not a dropdown you are trying to choose from.
    //
    // Never hidden when that would empty the picker. Somebody whose weights
    // have not downloaded yet should see a disabled list saying why, not an
    // empty box that looks broken.
    function markUnavailableModels() {
        if (!installed) return;
        const modelSelect = form.elements.model;
        if (modelSelect) {
            const options = [...modelSelect.options];
            const absent = (option) => {
                const entry = installed.checkpoints?.[option.value];
                return Boolean(entry && !entry.available);
            };
            const anyPresent = options.some(option => !absent(option));
            for (const option of options) {
                const entry = installed.checkpoints?.[option.value];
                const missing = absent(option);
                const label = modelDetails[option.value]?.label || option.value;
                option.disabled = missing;
                option.hidden = missing && anyPresent;
                option.textContent = missing ? `${label} — not installed` : label;
                if (missing) option.title = `Missing: ${(entry.missing || []).join(", ")}`;
            }
            // A hidden option can still be the selected one, and then the
            // closed picker shows a model the user cannot generate with.
            if (modelSelect.selectedOptions[0]?.hidden) {
                const usable = options.find(option => !option.hidden && !option.disabled);
                if (usable) modelSelect.value = usable.value;
            }
        }
        const archSelect = form.elements.architecture;
        if (archSelect) {
            const options = [...archSelect.options];
            const usableArch = (option) => (architectures[option.value]?.models || [])
                .some(key => installed.checkpoints?.[key]?.available !== false);
            const anyUsable = options.some(usableArch);
            for (const option of options) {
                const ok = usableArch(option);
                option.disabled = !ok;
                option.hidden = !ok && anyUsable;
            }
            if (archSelect.selectedOptions[0]?.hidden) {
                const usable = options.find(option => !option.hidden);
                if (usable) {
                    archSelect.value = usable.value;
                    archSelect.dispatchEvent(new Event("change", { bubbles: true }));
                }
            }
        }
    }

    // RES4LYF is optional and user-installed, never bundled (see NOTICE.md).
    // Offering its two sampler entries when the node isn't there let a pick
    // reach ComfyUI as an unrecognised name and fail the job; the orchestrator
    // now falls back to Euler for those too, but hiding them here is what stops
    // someone from picking a sampler that quietly isn't the one they chose.
    function markUnavailableSamplers() {
        if (!installed || !samplerSelect) return;
        const available = Boolean(installed.res4lyfAvailable);
        for (const option of samplerSelect.options) {
            if (option.dataset.requires !== "res4lyf") continue;
            option.disabled = !available;
            const label = option.dataset.label || option.textContent;
            option.dataset.label = label;
            option.textContent = available ? label : `${label} — RES4LYF not installed`;
        }
    }


    // ----------------------------------------------------------- Models panel ---
    //
    // Where a LoRA found on disk is told what it is. A filename cannot say which
    // architecture a layer was trained for, what its trigger words are, or how
    // strongly it wants to be applied, and every one of those guessed wrong gives
    // a layer that silently does nothing or wrecks an image. So a LoRA stays out
    // of the picker until it has been set up here, and the panel is honest about
    // which ones are waiting.

    const modelsDialog = document.querySelector("#models-dialog");
    const modelsBody = document.querySelector("#models-body");
    const modelsSubtitle = document.querySelector("#models-subtitle");
    const modelsStatus = document.querySelector("#models-status");
    const modelsSearch = document.querySelector("#models-search");
    const modelsOnlyUnconfigured = document.querySelector("#models-only-unconfigured");
    const ARCHITECTURE_CHOICES = [
        ["", "Not set — pick one"],
        ["krea2", "Krea 2 (DiT)"],
        ["sdxl", "SDXL"],
        ["anima", "Anima"],
        ["illustrious", "Illustrious"]
    ];

    function modelsNote(text, isError = false) {
        if (!modelsStatus) return;
        modelsStatus.textContent = text;
        modelsStatus.dataset.error = String(Boolean(isError));
    }

    async function saveLoraMeta(entry, patch) {
        const body = {
            id: entry.id,
            label: patch.label ?? entry.label,
            architecture: patch.architecture ?? entry.architecture ?? "",
            triggers: patch.triggers ?? entry.triggers,
            implied: patch.implied ?? entry.implied,
            defaultStrength: patch.defaultStrength ?? entry.defaultStrength,
            enabled: patch.enabled ?? entry.enabled
        };
        const response = await fetch("/api/studio?action=save-lora", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body)
        });
        const result = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(result.error || "Could not save this LoRA.");
        Object.assign(entry, body, { configured: Boolean(body.architecture) });
        return result;
    }

    function renderModelsPanel() {
        if (!modelsBody) return;
        modelsBody.replaceChildren();
        if (!installed) {
            modelsBody.textContent = "Still checking what is installed…";
            return;
        }

        // Checkpoints first: short, and the thing a user checks when a model is
        // missing from the picker.
        const checkSection = document.createElement("div");
        checkSection.className = "models-section";
        const checkHead = document.createElement("h3");
        checkHead.textContent = "Checkpoints";
        checkSection.append(checkHead);
        // Only what is actually here. This panel used to list every checkpoint
        // the studio can drive, three of them permanently red and "Missing",
        // naming files the build never ships and the user was never asked to
        // fetch. That is not a to-do list, it is an install reporting three
        // faults it does not have.
        //
        // Anything dropped into the model folders shows up here on the next
        // rescan, which is the case this panel is actually for.
        const checkpoints = Object.entries(installed.checkpoints || {});
        const present = checkpoints.filter(([, entry]) => entry.available);
        // Unless nothing is here at all - then the missing list is the whole
        // diagnosis, and hiding it would leave an empty panel during a download
        // or after a half-finished install.
        for (const [key, entry] of (present.length ? present : checkpoints)) {
            const row = document.createElement("div");
            row.className = "models-row";
            row.dataset.ok = String(entry.available);
            const name = document.createElement("span");
            name.className = "models-row-name";
            name.textContent = modelDetails[key]?.label || key;
            const state = document.createElement("span");
            state.className = "models-row-state";
            state.textContent = entry.available
                ? "Installed"
                : `Missing: ${(entry.missing || []).join(", ")}`;
            row.append(name, state);
            checkSection.append(row);
        }
        modelsBody.append(checkSection);

        // LoRAs.
        const loras = Object.values(installed.loras || {});
        const term = (modelsSearch?.value || "").trim().toLowerCase();
        const onlyUnconfigured = Boolean(modelsOnlyUnconfigured?.checked);
        const shown = loras
            .filter(item => !onlyUnconfigured || !item.configured)
            .filter(item => !term || item.id.toLowerCase().includes(term)
                || (item.label || "").toLowerCase().includes(term))
            .sort((a, b) => Number(a.configured) - Number(b.configured)
                || a.id.localeCompare(b.id));

        const loraSection = document.createElement("div");
        loraSection.className = "models-section";
        const loraHead = document.createElement("h3");
        const waiting = loras.filter(item => !item.configured).length;
        loraHead.textContent = `LoRAs — ${loras.length} found`
            + (waiting ? `, ${waiting} need setting up` : "");
        loraSection.append(loraHead);

        if (!loras.length) {
            const empty = document.createElement("p");
            empty.className = "setting-note";
            empty.textContent = "No LoRA files found. Drop .safetensors files into "
                + "models/loras inside the studio folder, or add a folder you already "
                + "have to lora_paths in config.json, then press Rescan.";
            loraSection.append(empty);
        }

        for (const entry of shown) {
            loraSection.append(loraCard(entry));
        }
        modelsBody.append(loraSection);
    }

    function loraCard(entry) {
        const card = document.createElement("div");
        card.className = "models-lora";
        card.dataset.configured = String(entry.configured);

        const head = document.createElement("div");
        head.className = "models-lora-head";
        const title = document.createElement("strong");
        title.textContent = entry.label || entry.id;
        const tags = document.createElement("span");
        tags.className = "models-lora-tags";
        // Where a file came from is worth showing: one folder is the studio's own
        // and writable, the others are the user's and only ever read.
        tags.textContent = `${entry.source === "studio" ? "in studio folder" : entry.source} · ${entry.sizeMb} MB`;
        head.append(title, tags);
        card.append(head);

        if (!entry.loadable) {
            const warn = document.createElement("p");
            warn.className = "setting-note models-lora-warn";
            warn.textContent = "ComfyUI cannot load this file from where it is. It has to "
                + "sit in the ComfyUI loras folder, or that folder has to be registered "
                + "with ComfyUI, before this layer can be used.";
            card.append(warn);
        }

        const grid = document.createElement("div");
        grid.className = "models-lora-grid";

        const archLabel = document.createElement("label");
        archLabel.textContent = "Architecture";
        const arch = document.createElement("select");
        for (const [value, text] of ARCHITECTURE_CHOICES) {
            const option = document.createElement("option");
            option.value = value;
            option.textContent = text;
            arch.append(option);
        }
        arch.value = entry.architecture || "";
        archLabel.append(arch);

        const triggerLabel = document.createElement("label");
        triggerLabel.textContent = "Trigger words";
        const triggers = document.createElement("input");
        triggers.type = "text";
        triggers.placeholder = "comma, separated";
        triggers.value = entry.triggers || "";
        triggerLabel.append(triggers);

        const impliedLabel = document.createElement("label");
        impliedLabel.textContent = "Already implied by";
        const implied = document.createElement("input");
        implied.type = "text";
        implied.placeholder = "terms that make the triggers redundant";
        implied.value = entry.implied || "";
        impliedLabel.append(implied);

        const strengthLabel = document.createElement("label");
        strengthLabel.textContent = "Default strength";
        const strength = document.createElement("input");
        strength.type = "number";
        strength.min = "0.1";
        strength.max = "1.5";
        strength.step = "0.05";
        strength.value = String(entry.defaultStrength ?? 0.8);
        strengthLabel.append(strength);

        grid.append(archLabel, triggerLabel, impliedLabel, strengthLabel);
        card.append(grid);

        const actions = document.createElement("div");
        actions.className = "models-lora-actions";
        const save = document.createElement("button");
        save.type = "button";
        save.className = "button primary";
        save.textContent = "Save";
        save.addEventListener("click", async () => {
            save.disabled = true;
            try {
                await saveLoraMeta(entry, {
                    architecture: arch.value,
                    triggers: triggers.value,
                    implied: implied.value,
                    defaultStrength: Number(strength.value)
                });
                card.dataset.configured = String(entry.configured);
                modelsNote(`Saved ${entry.label || entry.id}.`);
                // Rebuild the catalog, not just the list. renderLoras draws from
                // loraDetails, which only applyLoraRegistry fills - re-rendering
                // alone redraws the same empty catalog and the layer never shows up.
                applyLoraRegistry();
                renderModelsPanel();
            } catch (error) {
                modelsNote(error.message, true);
            } finally {
                save.disabled = false;
            }
        });
        actions.append(save);
        card.append(actions);
        return card;
    }

    async function openModelsPanel() {
        if (!modelsDialog) return;
        modelsDialog.showModal();
        modelsNote("");
        renderModelsPanel();
        await loadRegistry();
        if (installed) {
            const count = Object.keys(installed.loras || {}).length;
            if (modelsSubtitle) {
                modelsSubtitle.textContent = `${count} LoRA${count === 1 ? "" : "s"} found · `
                    + `models from ${installed.comfyDir}`;
            }
        }
        renderModelsPanel();
    }

    document.querySelector("#open-models-panel")?.addEventListener("click", openModelsPanel);
    document.querySelector("#models-close")?.addEventListener("click", () => modelsDialog?.close());
    document.querySelector("#models-done")?.addEventListener("click", () => modelsDialog?.close());
    modelsSearch?.addEventListener("input", renderModelsPanel);
    modelsOnlyUnconfigured?.addEventListener("change", renderModelsPanel);
    document.querySelector("#models-rescan")?.addEventListener("click", async () => {
        modelsNote("Rescanning…");
        await loadRegistry();
        renderModelsPanel();
        renderLoras();
        modelsNote("Rescanned.");
    });

    async function init() {
        try {
            // Single local user: there is no account system in the portable build.
            const user = { id: "local" };
            storageKey = `aistudio-studio-v2:${user.id}`;
            const legacyKey = `aistudio-studio-v1:${user.id}`;
            try {
                let saved = JSON.parse(localStorage.getItem(storageKey) || "null");
                if (!saved) {
                    const legacy = JSON.parse(localStorage.getItem(legacyKey) || "null");
                    if (legacy) {
                        saved = { current: { ...legacy.current, model: "krea2_turbo" } };
                    }
                }
                apply(saved?.current, false);
            } catch { apply({}, false); feedback.textContent = "Saved settings could not be restored in this browser."; }
            form.elements.architecture?.addEventListener("change", event => {
                syncModelDropdown(event.target.value);
                activeLoras = [];
                renderLoras();
                resetAdvancedDefaults();
                update();
                persist();
            });
            // A base-checkpoint swap stays inside the same architecture, so the
            // active LoRAs remain compatible - keep them, along with the seed and
            // any hand-tuned advanced values. Only an architecture change clears
            // the stack.
            form.elements.model?.addEventListener("change", () => {
                syncAdvancedForModel();
                renderLoras();
                update();
                persist();
            });
            stepsInput?.addEventListener("input", () => advancedTouched.add("steps"));
            guidanceInput?.addEventListener("input", () => advancedTouched.add("guidance"));
            samplerSelect?.addEventListener("change", () => advancedTouched.add("sampler"));
            resetAdvancedBtn?.addEventListener("click", () => {
                resetAdvancedDefaults();
                update();
                feedback.textContent = "Advanced settings reset to defaults.";
            });
            form.addEventListener("input", () => { update(); persist(); });
            form.addEventListener("change", () => { update(); persist(); });
            // Prevent a document navigation; the remote module handles job submission.
            form.addEventListener("submit", event => event.preventDefault());
            function useStarter(starter, isPrivate = false) {
                if (!starter) return;
                privatePromptActive = isPrivate;
                if (typeof starter === "string") {
                    prompt.value = starter;
                } else {
                    const resolvedPrompt = (starter.text !== undefined && starter.text !== null) ? starter.text : (starter.prompt ?? "");
                    prompt.value = resolvedPrompt;
                    if (negativePrompt) {
                        const resolvedNegative = (starter.negativeText !== undefined && starter.negativeText !== null) ? starter.negativeText : (starter.negativePrompt ?? "");
                        negativePrompt.value = resolvedNegative;
                    }
                    const rawModel = starter.model;
                    const legacy = legacyModelMap[rawModel];
                    const arch = starter.architecture || legacy?.architecture || modelDetails[rawModel]?.architecture || "krea2";
                    if (form.elements.architecture) form.elements.architecture.value = arch;
                    const targetModel = legacy?.model || starter.model || (architectures[arch] || architectures.krea2).defaultModel;
                    syncModelDropdown(arch, targetModel);

                    let lorasConfig = starter.loras;
                    if (typeof lorasConfig === "string") {
                        try { lorasConfig = JSON.parse(lorasConfig); } catch (_) {}
                    }
                    if (!lorasConfig && legacy?.loras) {
                        lorasConfig = legacy.loras;
                    }
                    if (!lorasConfig) {
                        lorasConfig = {};
                    }
                    activeLoras = normalizeLoras(lorasConfig, arch, Array.isArray(lorasConfig) ? {} : lorasConfig);
                    renderLoras();
                    if (starter.ratio) {
                        const r = form.querySelector(`input[name="ratio"][value="${starter.ratio}"]`);
                        if (r) { r.checked = true; }
                    }
                    if (starter.resolution) {
                        const res = form.querySelector(`input[name="resolution"][value="${starter.resolution}"]`);
                        if (res) { res.checked = true; }
                    }
                    if (starter.upscale !== undefined && form.elements.upscale) {
                        form.elements.upscale.checked = Boolean(starter.upscale);
                    }
                    if (starter.promptEnhance !== undefined && form.elements['prompt-enhance']) {
                        form.elements['prompt-enhance'].checked = Boolean(starter.promptEnhance);
                    }
                    resetAdvancedDefaults();
                    // Values the starter spells out count as deliberate, so a later
                    // checkpoint swap keeps them instead of reverting to its defaults.
                    if (starter.steps !== undefined && starter.steps !== "" && stepsInput) { stepsInput.value = String(starter.steps); advancedTouched.add("steps"); }
                    else if (legacy?.steps !== undefined && stepsInput) { stepsInput.value = String(legacy.steps); advancedTouched.add("steps"); }

                    if (starter.guidance !== undefined && starter.guidance !== "" && guidanceInput) { guidanceInput.value = String(starter.guidance); advancedTouched.add("guidance"); }
                    else if (legacy?.guidance !== undefined && guidanceInput) { guidanceInput.value = String(legacy.guidance); advancedTouched.add("guidance"); }

                    if (starter.sampler && samplerSelect) { samplerSelect.value = starter.sampler; advancedTouched.add("sampler"); }
                    else if (legacy?.samplerKey && samplerSelect) { samplerSelect.value = legacy.samplerKey; advancedTouched.add("sampler"); }

                    if (starter.seed !== undefined && starter.seed !== "" && seed) seed.value = String(starter.seed);
                    if (starter.denoise !== undefined && starter.denoise !== "") {
                        const denoiseInput = document.querySelector("#denoise");
                        if (denoiseInput) {
                            denoiseInput.value = String(starter.denoise);
                            const denoiseVal = document.querySelector("#denoise-value");
                            if (denoiseVal) denoiseVal.textContent = String(starter.denoise);
                        }
                    }
                    const growMaskValInput = starter.growMask !== undefined && starter.growMask !== "" ? starter.growMask : starter.grow_mask;
                    if (growMaskValInput !== undefined && growMaskValInput !== "") {
                        const growMaskInput = document.querySelector("#grow-mask");
                        if (growMaskInput) {
                            growMaskInput.value = String(growMaskValInput);
                            const growMaskVal = document.querySelector("#grow-mask-value");
                            if (growMaskVal) growMaskVal.textContent = `${growMaskValInput} px`;
                        }
                    }
                }
                update();
                persist();
                form.dispatchEvent(new Event("input", { bubbles: true }));
                prompt.focus();
            }
            // Scalable Prompt Preset Library System (stored locally)
            function getCurrentUserId() {
                try {
                    return (localStorage.getItem("aistudio-current-user") || "default").trim().toLowerCase();
                } catch {
                    return "default";
                }
            }
            function getCustomPresetsStorageKey() {
                return "aistudio-studio-custom-presets:" + getCurrentUserId() + ":v1";
            }
            function loadCustomPresets() {
                try {
                    const userKey = getCustomPresetsStorageKey();
                    let raw = localStorage.getItem(userKey);
                    if (!raw) {
                        const legacy = localStorage.getItem("aistudio-studio-custom-presets:v1");
                        if (legacy) {
                            raw = legacy;
                            try { localStorage.setItem(userKey, legacy); } catch (_) {}
                        }
                    }
                    return raw ? JSON.parse(raw) : [];
                } catch {
                    return [];
                }
            }
            function saveCustomPresets(list) {
                try {
                    localStorage.setItem(getCustomPresetsStorageKey(), JSON.stringify(list));
                    return true;
                } catch {
                    feedback.textContent = "Browser storage is unavailable to save custom preset.";
                    return false;
                }
            }
            function getAllPresets() {
                const custom = loadCustomPresets().filter(item => !item.deleted).map(item => ({
                    ...item,
                    isCustom: true,
                    category: item.category || "General"
                }));
                // The user's own first. The quick chips show only the first eight of
                // this list, and ten shipped presets would otherwise push everything
                // somebody saved themselves off the bar they saved it for.
                return [...custom, ...presetCatalog];
            }

            async function pushCustomPresetsToCloud(list) {
                if (window.StudioCrypto?.isUnlocked()) {
                    try {
                        const normalized = (list || []).map(p => ({
                            ...p,
                            updatedAt: p.updatedAt || 0
                        }));
                        const remote = await window.StudioCrypto.fetchCloudPresets();
                        const merged = window.StudioState.mergePresets(remote || [], normalized);
                        await window.StudioCrypto.saveCloudPresets(merged);
                        saveCustomPresets(merged);
                    } catch (e) {
                        console.error("Failed to sync presets to cloud", e);
                    }
                }
            }

            async function pullCloudPresets() {
                if (!window.StudioCrypto?.isUnlocked()) return;
                try {
                    const cloudList = await window.StudioCrypto.fetchCloudPresets();
                    if (Array.isArray(cloudList)) {
                        const localList = loadCustomPresets();
                        const merged = window.StudioState.mergePresets(cloudList, localList);
                        const localHasNew = JSON.stringify(merged) !== JSON.stringify(cloudList);
                        saveCustomPresets(merged);
                        renderQuickSelect();
                        renderQuickChips();
                        renderPresetLibrary();
                        syncPresetUI();
                        if (localHasNew) {
                            await pushCustomPresetsToCloud(merged);
                        }
                    } else if (cloudList === null) {
                        const localList = loadCustomPresets();
                        if (localList.length) {
                            await pushCustomPresetsToCloud(localList);
                        }
                    }
                } catch (e) {
                    console.error("Failed to pull presets from cloud", e);
                }
            }

            window.addEventListener("studio-unlocked", () => {
                pullCloudPresets();
            });

            const presetLibraryDialog = document.querySelector("#preset-library-dialog");
            const presetLibraryClose = document.querySelector("#preset-library-close");
            const presetLibraryDone = document.querySelector("#preset-library-done");
            const presetSearch = document.querySelector("#preset-search");
            const presetCategoryTabs = document.querySelector("#preset-category-tabs");
            const presetLibraryGrid = document.querySelector("#preset-library-grid");
            const presetLibraryStatus = document.querySelector("#preset-library-status");
            const saveCurrentAsPresetBtn = document.querySelector("#save-current-as-preset");
            const savePresetQuickBtn = document.querySelector("#save-preset-quick");
            const openPresetLibraryBtn = document.querySelector("#open-preset-library");
            const presetQuickSelect = document.querySelector("#preset-quick-select");
            const presetQuickChips = document.querySelector("#preset-quick-chips");
            const presetCountBadge = document.querySelector("#preset-count-badge");

            let activePresetCategory = "All";
            let activePresetId = null;

            function activatePreset(preset) {
                if (!preset) return;
                activePresetId = preset.id;
                if (preset.isPrivate) {
                    let value = "";
                    try { value = localStorage.getItem(privatePromptKey) || ""; }
                    catch { feedback.textContent = "Browser storage is unavailable, so the private prompt cannot be loaded."; return; }
                    if (!value) {
                        value = window.prompt("Paste the prompt for this private preset. It is stored only in this browser profile.") || "";
                        if (!value) return;
                        if (value.length > 4000) {
                            feedback.textContent = "The private prompt must be 4,000 characters or fewer.";
                            return;
                        }
                        try { localStorage.setItem(privatePromptKey, value); }
                        catch { feedback.textContent = "Browser storage is unavailable, so the private prompt was not saved."; return; }
                    }
                    useStarter({ ...preset, prompt: value }, true);
                } else {
                    useStarter(preset, false);
                }
                syncPresetUI();
            }

            function syncPresetUI() {
                const all = getAllPresets();
                if (presetCountBadge) presetCountBadge.textContent = String(all.length);
                if (presetQuickSelect) {
                    presetQuickSelect.value = activePresetId && all.some(p => p.id === activePresetId) ? activePresetId : "";
                }
                document.querySelectorAll(".preset-quick-chip").forEach(chip => {
                    chip.dataset.active = String(chip.dataset.presetId === activePresetId);
                });
                document.querySelectorAll(".preset-card").forEach(card => {
                    card.dataset.active = String(card.dataset.presetId === activePresetId);
                });
            }

            function renderQuickSelect() {
                if (!presetQuickSelect) return;
                const all = getAllPresets();
                presetQuickSelect.replaceChildren();
                const placeholder = document.createElement("option");
                placeholder.value = "";
                placeholder.textContent = "Choose a preset...";
                presetQuickSelect.appendChild(placeholder);

                const groups = {};
                for (const p of all) {
                    const cat = p.category || "General";
                    if (!groups[cat]) groups[cat] = [];
                    groups[cat].push(p);
                }

                for (const [groupName, items] of Object.entries(groups)) {
                    const optgroup = document.createElement("optgroup");
                    optgroup.label = groupName;
                    for (const item of items) {
                        const opt = document.createElement("option");
                        opt.value = item.id;
                        opt.textContent = item.title;
                        optgroup.appendChild(opt);
                    }
                    presetQuickSelect.appendChild(optgroup);
                }
                if (activePresetId) presetQuickSelect.value = activePresetId;
            }

            function renderQuickChips() {
                if (!presetQuickChips) return;
                presetQuickChips.replaceChildren();
                const all = getAllPresets();
                const chips = all.slice(0, 8);
                for (const p of chips) {
                    const chip = document.createElement("button");
                    chip.type = "button";
                    chip.className = "preset-quick-chip";
                    chip.dataset.presetId = p.id;
                    chip.dataset.active = String(p.id === activePresetId);
                    chip.textContent = p.title;
                    chip.addEventListener("click", () => activatePreset(p));
                    presetQuickChips.appendChild(chip);
                }
            }

            function renderPresetLibrary() {
                const all = getAllPresets();
                if (presetCountBadge) presetCountBadge.textContent = String(all.length);
                const query = (presetSearch?.value || "").trim().toLowerCase();

                // Build category tabs
                const categoryCounts = { All: all.length };
                for (const p of all) {
                    categoryCounts[p.category] = (categoryCounts[p.category] || 0) + 1;
                }
                if (!categoryCounts[activePresetCategory]) {
                    activePresetCategory = "All";
                }
                if (presetCategoryTabs) {
                    presetCategoryTabs.replaceChildren();
                    for (const [catName, count] of Object.entries(categoryCounts)) {
                        const tab = document.createElement("button");
                        tab.type = "button";
                        tab.className = "preset-tab-btn";
                        tab.dataset.active = String(activePresetCategory === catName);
                        tab.innerHTML = `${catName} <span class="preset-tab-count">(${count})</span>`;
                        tab.addEventListener("click", () => {
                            activePresetCategory = catName;
                            renderPresetLibrary();
                        });
                        presetCategoryTabs.appendChild(tab);
                    }
                }

                if (!presetLibraryGrid) return;
                presetLibraryGrid.replaceChildren();

                const filtered = all.filter(p => {
                    if (activePresetCategory !== "All" && p.category !== activePresetCategory) {
                        return false;
                    }
                    if (query) {
                        const matchTitle = p.title.toLowerCase().includes(query);
                        const matchPrompt = (p.prompt || "").toLowerCase().includes(query);
                        const matchTags = (p.tags || []).some(t => t.toLowerCase().includes(query));
                        const matchArch = (p.architecture || "").toLowerCase().includes(query);
                        const matchModel = (p.model || "").toLowerCase().includes(query);
                        return matchTitle || matchPrompt || matchTags || matchArch || matchModel;
                    }
                    return true;
                });

                if (!filtered.length) {
                    const empty = document.createElement("div");
                    empty.className = "preset-library-empty";
                    empty.textContent = all.length === 0
                        ? "No presets saved yet. Configure your architecture, model and prompt, then click 'Save Current' to save your own custom preset."
                        : (query ? `No presets found matching "${query}".` : "No presets in this category.");
                    presetLibraryGrid.appendChild(empty);
                    return;
                }

                for (const p of filtered) {
                    const card = document.createElement("div");
                    card.className = "preset-card";
                    card.dataset.presetId = p.id;
                    card.dataset.active = String(p.id === activePresetId);

                    const head = document.createElement("div");
                    head.className = "preset-card-head";
                    const title = document.createElement("h3");
                    title.className = "preset-card-title";
                    title.textContent = p.title;

                    const badges = document.createElement("div");
                    badges.className = "preset-card-badges";
                    const archBadge = document.createElement("span");
                    archBadge.className = `preset-arch-badge ${p.architecture || "krea2"}`;
                    archBadge.textContent = p.isCustom ? "Custom" : (architectures[p.architecture]?.label || p.architecture || "Preset");
                    badges.appendChild(archBadge);
                    head.append(title, badges);

                    const paramsBox = document.createElement("div");
                    paramsBox.className = "preset-card-params";

                    const modelLabel = modelDetails[p.model]?.label || p.model;
                    if (modelLabel) {
                        const mBadge = document.createElement("span");
                        mBadge.className = "preset-param-badge model";
                        mBadge.textContent = modelLabel;
                        paramsBox.appendChild(mBadge);
                    }

                    if (p.ratio || p.resolution) {
                        const rBadge = document.createElement("span");
                        rBadge.className = "preset-param-badge";
                        const parts = [];
                        if (p.ratio) parts.push(p.ratio);
                        if (p.resolution) parts.push(p.resolution.toUpperCase());
                        rBadge.textContent = parts.join(" · ");
                        paramsBox.appendChild(rBadge);
                    }

                    if (p.sampler || p.steps) {
                        const sBadge = document.createElement("span");
                        sBadge.className = "preset-param-badge";
                        const parts = [];
                        if (p.sampler) parts.push(p.sampler);
                        if (p.steps) parts.push(`${p.steps} steps`);
                        sBadge.textContent = parts.join(" · ");
                        paramsBox.appendChild(sBadge);
                    }

                    if (p.guidance) {
                        const gBadge = document.createElement("span");
                        gBadge.className = "preset-param-badge";
                        gBadge.textContent = `CFG ${p.guidance}`;
                        paramsBox.appendChild(gBadge);
                    }

                    if (p.denoise) {
                        const dBadge = document.createElement("span");
                        dBadge.className = "preset-param-badge";
                        dBadge.textContent = `Denoise ${p.denoise}`;
                        paramsBox.appendChild(dBadge);
                    }

                    const lorasBox = document.createElement("div");
                    lorasBox.className = "preset-card-loras";
                    const rawLoras = p.loras;
                    const loraList = Array.isArray(rawLoras)
                        ? rawLoras
                        : Object.entries(rawLoras || {}).map(([id, strength]) => ({ id, strength }));
                    if (loraList.length) {
                        for (const item of loraList) {
                            if (!item || !item.id) continue;
                            const loraSpan = document.createElement("span");
                            loraSpan.className = "preset-lora-chip";
                            loraSpan.textContent = `${loraDetails[item.id]?.label || item.id} (${Number(item.strength).toFixed(2)})`;
                            lorasBox.appendChild(loraSpan);
                        }
                    }

                    const snippet = document.createElement("p");
                    snippet.className = "preset-card-snippet";
                    snippet.textContent = p.prompt || "No prompt text.";

                    let negEl = null;
                    if (p.negativePrompt && p.negativePrompt.trim()) {
                        negEl = document.createElement("p");
                        negEl.className = "preset-card-negative";
                        const strong = document.createElement("strong");
                        strong.textContent = "Negative: ";
                        negEl.appendChild(strong);
                        negEl.appendChild(document.createTextNode(p.negativePrompt));
                    }

                    const foot = document.createElement("div");
                    foot.className = "preset-card-foot";
                    const applyBtn = document.createElement("button");
                    applyBtn.type = "button";
                    applyBtn.className = "button primary preset-apply-btn";
                    applyBtn.textContent = p.id === activePresetId ? "Active in Studio" : "Load Preset";
                    applyBtn.addEventListener("click", () => {
                        activatePreset(p);
                        if (presetLibraryStatus) presetLibraryStatus.textContent = `Loaded "${p.title}"!`;
                    });

                    const actions = document.createElement("div");
                    actions.className = "preset-card-actions";

                    if (!p.isPrivate && p.prompt) {
                        const copyBtn = document.createElement("button");
                        copyBtn.type = "button";
                        copyBtn.className = "preset-copy-btn";
                        copyBtn.title = "Copy prompt to clipboard";
                        copyBtn.textContent = "📋 Copy";
                        copyBtn.addEventListener("click", async () => {
                            try {
                                await navigator.clipboard.writeText(p.prompt);
                                if (presetLibraryStatus) presetLibraryStatus.textContent = `Copied "${p.title}" prompt!`;
                            } catch {
                                if (presetLibraryStatus) presetLibraryStatus.textContent = "Could not copy automatically.";
                            }
                        });
                        actions.appendChild(copyBtn);
                    }

                    const editBtn = document.createElement("button");
                    editBtn.type = "button";
                    editBtn.className = "preset-edit-btn";
                    // A shipped preset cannot be edited in place - it is rebuilt from
                    // the catalogue on every load - so editing one saves a copy instead.
                    editBtn.title = p.isCustom ? "Edit this preset" : "Save your own version of this preset";
                    editBtn.textContent = "✏️";
                    editBtn.addEventListener("click", () => openEditPresetDialog(p));
                    actions.appendChild(editBtn);

                    // Only the user's own presets get a delete button. The shipped ones
                    // live in the catalogue above, not in stored state, so deleting one
                    // marked nothing and the preset came straight back on the next render
                    // - after a confirmation box had said it was gone.
                    if (p.isCustom) {
                        const delBtn = document.createElement("button");
                        delBtn.type = "button";
                        delBtn.className = "preset-del-btn";
                        delBtn.title = "Delete this preset";
                        delBtn.textContent = "🗑";
                        delBtn.addEventListener("click", async () => {
                            if (window.confirm(`Delete preset "${p.title}"?`)) {
                                const customList = loadCustomPresets().map(item => item.id === p.id ? { id: item.id, deleted: true, updatedAt: Date.now() } : item);
                                saveCustomPresets(customList);
                                await pushCustomPresetsToCloud(customList);
                                if (activePresetId === p.id) activePresetId = null;
                                renderQuickSelect();
                                renderQuickChips();
                                renderPresetLibrary();
                                syncPresetUI();
                                if (presetLibraryStatus) presetLibraryStatus.textContent = `Deleted "${p.title}".`;
                            }
                        });
                        actions.appendChild(delBtn);
                    }

                    foot.append(applyBtn, actions);
                    card.append(head, paramsBox, lorasBox, snippet);
                    if (negEl) card.appendChild(negEl);
                    card.appendChild(foot);
                    presetLibraryGrid.appendChild(card);
                }
            }

            const presetEditDialog = document.querySelector("#preset-edit-dialog");
            const presetEditForm = document.querySelector("#preset-edit-form");
            const presetEditClose = document.querySelector("#preset-edit-close");
            const presetEditCancel = document.querySelector("#preset-edit-cancel");
            const presetEditId = document.querySelector("#preset-edit-id");
            const presetEditTitleInput = document.querySelector("#preset-edit-title-input");
            const presetEditCategoryInput = document.querySelector("#preset-edit-category-input");
            const presetEditPromptInput = document.querySelector("#preset-edit-prompt-input");
            const presetEditNegativeInput = document.querySelector("#preset-edit-negative-input");
            const presetEditTagsInput = document.querySelector("#preset-edit-tags-input");
            const presetEditSnapshot = document.querySelector("#preset-edit-snapshot");
            const presetEditHeading = document.querySelector("#preset-edit-title");
            const presetEditSubtitle = document.querySelector("#preset-edit-subtitle");
            const presetEditSubmit = presetEditForm?.querySelector('button[type="submit"]');
            // The preset the dialog was opened on. Held because a shipped preset is not
            // in the stored list, so the submit handler has nothing to look it up by.
            let presetEditSource = null;

            function openEditPresetDialog(preset) {
                if (!preset || !presetEditDialog) return;
                presetEditSource = preset;
                // Editing a shipped preset makes a copy rather than changing it. The
                // catalogue is rebuilt from source on every load, so an in-place edit
                // would be discarded the next time the page opened.
                const copying = !preset.isCustom;
                if (presetEditHeading) presetEditHeading.textContent = copying ? "Save your own version" : "Edit Preset";
                if (presetEditSubtitle) {
                    presetEditSubtitle.textContent = copying
                        ? `"${preset.title}" is one of the presets that came with the studio, so it stays as it is. This saves a copy you own and can change.`
                        : "Modify preset details, prompt text, and settings.";
                }
                if (presetEditSubmit) presetEditSubmit.textContent = copying ? "Save My Copy" : "Save Changes";
                if (presetEditId) presetEditId.value = preset.id;
                if (presetEditTitleInput) presetEditTitleInput.value = copying ? `${preset.title} (my version)` : (preset.title || "");
                if (presetEditCategoryInput) presetEditCategoryInput.value = copying ? "Custom / Saved" : (preset.category || "General");
                if (presetEditPromptInput) presetEditPromptInput.value = preset.prompt || "";
                if (presetEditNegativeInput) presetEditNegativeInput.value = preset.negativePrompt || "";
                if (presetEditTagsInput) presetEditTagsInput.value = (preset.tags || []).join(", ");
                if (presetEditSnapshot) presetEditSnapshot.checked = false;
                presetEditDialog.showModal();
            }

            presetEditClose?.addEventListener("click", () => presetEditDialog?.close());
            presetEditCancel?.addEventListener("click", () => presetEditDialog?.close());
            presetEditDialog?.addEventListener("click", (e) => {
                if (e.target === presetEditDialog) {
                    const rect = presetEditDialog.getBoundingClientRect();
                    if (rect.top > e.clientY || e.clientY > rect.top + rect.height || rect.left > e.clientX || e.clientX > rect.left + rect.width) {
                        presetEditDialog.close();
                    }
                }
            });

            presetEditForm?.addEventListener("submit", async (e) => {
                e.preventDefault();
                const id = presetEditId?.value;
                const title = presetEditTitleInput?.value.trim();
                if (!title) return;
                const list = loadCustomPresets();
                let idx = list.findIndex(p => p.id === id);
                if (idx === -1) {
                    // A preset the stored list has never heard of: one of the shipped
                    // ones. Start a copy from it instead of silently doing nothing,
                    // which is what a dialog offering a Save button used to do.
                    const source = presetEditSource;
                    if (!source) return;
                    list.unshift({
                        ...source,
                        id: "custom_" + Date.now(),
                        isCustom: true,
                        updatedAt: Date.now()
                    });
                    idx = 0;
                }

                const existing = list[idx];
                existing.title = title;
                existing.category = presetEditCategoryInput?.value.trim() || "General";
                existing.prompt = presetEditPromptInput?.value.trim() || "";
                existing.negativePrompt = presetEditNegativeInput?.value.trim() || "";
                existing.tags = (presetEditTagsInput?.value || "").split(",").map(t => t.trim()).filter(Boolean);
                existing.updatedAt = Date.now();

                if (presetEditSnapshot?.checked) {
                    existing.architecture = form.elements.architecture?.value || existing.architecture || "krea2";
                    existing.model = form.elements.model?.value || existing.model || "krea2_turbo";
                    existing.loras = Object.fromEntries(activeLoras.map(item => [item.id, item.strength]));
                    existing.ratio = form.querySelector('input[name="ratio"]:checked')?.value || existing.ratio || "square";
                    existing.resolution = form.querySelector('input[name="resolution"]:checked')?.value || existing.resolution || "1mp";
                    if (stepsInput?.value?.trim()) existing.steps = stepsInput.value.trim();
                    if (guidanceInput?.value?.trim()) existing.guidance = guidanceInput.value.trim();
                    if (samplerSelect?.value) existing.sampler = samplerSelect.value;
                    if (seed?.value?.trim()) existing.seed = seed.value.trim();
                    const denoiseEl = document.querySelector("#denoise");
                    if (denoiseEl?.value) existing.denoise = denoiseEl.value;
                    const growMaskEl = document.querySelector("#grow-mask");
                    if (growMaskEl?.value) existing.growMask = growMaskEl.value;
                }

                saveCustomPresets(list);
                await pushCustomPresetsToCloud(list);
                presetEditDialog.close();
                renderQuickSelect();
                renderQuickChips();
                renderPresetLibrary();
                syncPresetUI();
                if (presetLibraryStatus) presetLibraryStatus.textContent = `Preset "${title}" updated!`;
            });

            async function saveCustomPresetFromConfig(config = {}) {
                const resolvedPrompt = (config.text !== undefined && config.text !== null) ? config.text : config.prompt;
                const promptText = (resolvedPrompt ?? prompt.value ?? "").trim();
                if (!promptText && !privatePromptActive) {
                    window.alert("Please enter a prompt first before saving as a preset.");
                    return false;
                }
                const defaultName = promptText.length > 30 ? promptText.slice(0, 30).trim() + "…" : promptText;
                const name = window.prompt("Enter a name for this custom preset:", config.title || defaultName);
                if (!name || !name.trim()) return false;

                const customPresets = loadCustomPresets();
                const rawModel = config.model || form.elements.model?.value || "krea2_turbo";
                const legacy = legacyModelMap[rawModel];
                const arch = config.architecture || legacy?.architecture || modelDetails[rawModel]?.architecture || form.elements.architecture?.value || "krea2";

                let loras = config.loras;
                if (typeof loras === "string") {
                    try { loras = JSON.parse(loras); } catch (_) {}
                }
                let lorasObj = {};
                if (Array.isArray(loras)) {
                    lorasObj = Object.fromEntries(loras.map(item => [item.id, item.strength]));
                } else if (loras && typeof loras === "object") {
                    lorasObj = loras;
                } else {
                    lorasObj = Object.fromEntries(activeLoras.map(item => [item.id, item.strength]));
                }

                const ratioVal = config.ratio || form.querySelector('input[name="ratio"]:checked')?.value || "square";
                const resVal = config.resolution || form.querySelector('input[name="resolution"]:checked')?.value || "1mp";

                const resolvedNegative = (config.negativeText !== undefined && config.negativeText !== null)
                    ? config.negativeText
                    : (config.negativePrompt !== undefined ? config.negativePrompt : (negativePrompt?.value || ""));

                const newPreset = {
                    id: "custom_" + Date.now(),
                    title: name.trim(),
                    category: config.category || "Custom / Saved",
                    architecture: arch,
                    model: rawModel,
                    loras: lorasObj,
                    ratio: ratioVal,
                    resolution: resVal,
                    prompt: promptText,
                    negativePrompt: resolvedNegative,
                    tags: ["custom", "saved"],
                    isCustom: true,
                    updatedAt: Date.now()
                };

                newPreset.upscale = Boolean(config.upscale ?? form.elements.upscale?.checked);
                newPreset.promptEnhance = Boolean(config.promptEnhance ?? form.elements['prompt-enhance']?.checked);

                const stepsVal = config.steps !== undefined && config.steps !== "" ? config.steps : stepsInput?.value?.trim();
                if (stepsVal) newPreset.steps = String(stepsVal);

                const guidanceVal = config.guidance !== undefined && config.guidance !== "" ? config.guidance : guidanceInput?.value?.trim();
                if (guidanceVal) newPreset.guidance = String(guidanceVal);

                const samplerVal = config.sampler || samplerSelect?.value;
                if (samplerVal) newPreset.sampler = samplerVal;

                const seedVal = config.seed !== undefined && config.seed !== "" ? config.seed : seed?.value?.trim();
                if (seedVal) newPreset.seed = String(seedVal);

                const denoiseVal = config.denoise !== undefined && config.denoise !== "" ? config.denoise : document.querySelector("#denoise")?.value;
                if (denoiseVal !== undefined && denoiseVal !== "") newPreset.denoise = denoiseVal;

                const growMaskVal = (config.growMask !== undefined && config.growMask !== "") ? config.growMask : ((config.grow_mask !== undefined && config.grow_mask !== "") ? config.grow_mask : document.querySelector("#grow-mask")?.value);
                if (growMaskVal !== undefined && growMaskVal !== "") newPreset.growMask = growMaskVal;

                customPresets.unshift(newPreset);
                saveCustomPresets(customPresets);
                await pushCustomPresetsToCloud(customPresets);
                activePresetId = newPreset.id;
                renderQuickSelect();
                renderQuickChips();
                renderPresetLibrary();
                syncPresetUI();
                if (presetLibraryStatus) presetLibraryStatus.textContent = `Custom preset "${newPreset.title}" saved!`;
                feedback.textContent = `Custom preset "${newPreset.title}" saved.`;
                return true;
            }

            function handleSaveCustomPreset() {
                saveCustomPresetFromConfig();
            }

            presetQuickSelect?.addEventListener("change", (e) => {
                const id = e.target.value;
                if (!id) return;
                const match = getAllPresets().find(p => p.id === id);
                if (match) activatePreset(match);
            });

            openPresetLibraryBtn?.addEventListener("click", () => {
                if (window.StudioCrypto?.isUnlocked()) {
                    pullCloudPresets();
                }
                renderPresetLibrary();
                if (presetLibraryStatus) presetLibraryStatus.textContent = "";
                presetLibraryDialog?.showModal();
            });

            presetLibraryClose?.addEventListener("click", () => presetLibraryDialog?.close());
            presetLibraryDone?.addEventListener("click", () => presetLibraryDialog?.close());
            presetLibraryDialog?.addEventListener("click", (e) => {
                if (e.target === presetLibraryDialog) presetLibraryDialog.close();
            });

            presetSearch?.addEventListener("input", () => renderPresetLibrary());
            saveCurrentAsPresetBtn?.addEventListener("click", handleSaveCustomPreset);
            savePresetQuickBtn?.addEventListener("click", handleSaveCustomPreset);

            document.querySelectorAll("[data-starter]").forEach(button => button.addEventListener("click", () => {
                const starterName = button.dataset.starter;
                const match = getAllPresets().find(p => p.id === starterName);
                if (match) activatePreset(match);
            }));

            // Initial render of preset components
            renderQuickSelect();
            renderQuickChips();
            renderPresetLibrary();
            syncPresetUI();
            if (window.StudioCrypto?.isUnlocked()) {
                pullCloudPresets();
            }

            document.querySelector("#surprise")?.addEventListener("click", () => {
                const uniqueStarters = getAllPresets().filter(item => !item.isPrivate);
                const choices = uniqueStarters.filter(item => item.prompt !== prompt.value);
                const pick = choices.length ? choices[Math.floor(Math.random() * choices.length)] : uniqueStarters[0];
                if (pick) activatePreset(pick);
            });
            document.querySelector("#reset").addEventListener("click", () => {
                apply({}, false);
                form.querySelectorAll("details").forEach(details => { details.open = false; });
                persist();
                prompt.focus();
            });
            loraGuideClose?.addEventListener("click", () => loraGuideDialog?.close());
            loraGuideDone?.addEventListener("click", () => loraGuideDialog?.close());
            loraGuideDialog?.addEventListener("click", event => {
                if (event.target === loraGuideDialog) loraGuideDialog.close();
            });
            function initModesAndInpainting() {
                currentMode = 'txt2img';
                let inputImage = null;
                let inputBlob = null;
                let imageLoadVersion = 0;
                const imageWorkspaces = new Map();
                // Durable drafts + cross-device sync. Wired up once the Studio
                // key is available, so the editor works unchanged while locked.
                let drafts = null;
                const draftsChanged = () => drafts?.noteChange(currentMode);
                let hasMask = false;
                let activeTool = 'brush';
                // A fingertip is far blunter than a cursor, so touch devices
                // start with a brush that is visible at fit-to-screen zoom.
                let brushSize = window.matchMedia?.('(pointer: coarse)').matches ? 90 : 40;
                // The one place the mask's paint colour is written down.
                const MASK_PAINT = 'rgba(236, 72, 153, 0.65)';
                let isDrawing = false;
                let lastPoint = null;
                // Where the last stroke ended, so Shift+click can run a
                // straight edge on from it the way a Photoshop brush does.
                let lastStrokeEnd = null;
                const undoStack = [];
                const redoStack = [];

                // UI Elements
                const modeTabs = document.querySelectorAll('.mode-tab');
                const composerImageSection = document.querySelector('#composer-image-section');
                const composerDropzone = document.querySelector('#composer-dropzone');
                const composerFileInput = document.querySelector('#composer-file-input');
                const composerDropzonePrompt = document.querySelector('#composer-dropzone-prompt');
                const composerImagePreview = document.querySelector('#composer-image-preview');
                const composerPreviewImg = document.querySelector('#composer-preview-img');
                const composerImageDims = document.querySelector('#composer-image-dims');
                const composerMatchRatioBtn = document.querySelector('#composer-match-ratio-btn');
                const composerClearImgBtn = document.querySelector('#composer-clear-img-btn');

                // Unified Img2Img Elements
                const img2imgEditorPanel = document.querySelector('#img2img-editor-panel');
                const img2imgDropzone = document.querySelector('#img2img-dropzone');
                const img2imgFileInput = document.querySelector('#img2img-file-input');
                const img2imgViewport = document.querySelector('#img2img-viewport');
                const img2imgPreviewImg = document.querySelector('#img2img-preview-img');
                const img2imgImageDims = document.querySelector('#img2img-image-dims');
                const img2imgMatchRatioBtn = document.querySelector('#img2img-match-ratio-btn');
                const img2imgChangeBtn = document.querySelector('#img2img-change-btn');
                const img2imgClearBtn = document.querySelector('#img2img-clear-btn');
                const img2imgInfo = document.querySelector('#img2img-info');

                // Mobile Zone Navigation
                const studioLayout = document.querySelector('#studio-layout');
                const mobileZoneTabs = document.querySelectorAll('.mobile-zone-tab');
                function setMobileZone(zone) {
                    if (!studioLayout) return;
                    studioLayout.dataset.mobileZone = zone;
                    mobileZoneTabs.forEach(tab => {
                        const active = tab.dataset.targetZone === zone;
                        tab.classList.toggle('active', active);
                        tab.setAttribute('aria-selected', String(active));
                    });
                }
                mobileZoneTabs.forEach(tab => {
                    tab.addEventListener('click', () => setMobileZone(tab.dataset.targetZone));
                });
                window.setMobileStudioZone = setMobileZone;

                const composerModeSliders = document.querySelector('#composer-mode-sliders');
                const denoiseContainer = document.querySelector('#denoise-container');
                const denoiseInput = document.querySelector('#denoise');
                const denoiseValue = document.querySelector('#denoise-value');
                const denoiseHint = document.querySelector('#denoise-hint');
                const growMaskContainer = document.querySelector('#grow-mask-container');
                const growMaskInput = document.querySelector('#grow-mask');
                const growMaskValue = document.querySelector('#grow-mask-value');

                const workspaceViewTabs = document.querySelector('#workspace-view-tabs');
                const viewTabEditor = document.querySelector('#view-tab-editor');
                const viewTabOutput = document.querySelector('#view-tab-output');
                const inpaintEditorPanel = document.querySelector('#inpaint-editor-panel');
                const inpaintToolbar = document.querySelector('#inpaint-toolbar');
                const workspaceOutputStage = document.querySelector('#workspace-output-stage');
                const workspaceOutputFooter = document.querySelector('#workspace-output-footer');
                const outputStageActions = document.querySelector('#output-stage-actions');
                const outputToInpaint = document.querySelector('#output-to-inpaint');
                const outputToImg2img = document.querySelector('#output-to-img2img');

                const toolBrush = document.querySelector('#tool-brush');
                const toolEraser = document.querySelector('#tool-eraser');
                const brushSizeInput = document.querySelector('#brush-size');
                const brushSizeDisplay = document.querySelector('#brush-size-display');
                const toolUndo = document.querySelector('#tool-undo');
                const toolRedo = document.querySelector('#tool-redo');
                const toolInvert = document.querySelector('#tool-invert');
                const toolClear = document.querySelector('#tool-clear');
                const toolMatchRatio = document.querySelector('#tool-match-ratio');
                const toolNewImage = document.querySelector('#tool-new-image');
                const toolRemoveImage = document.querySelector('#tool-remove-image');

                const inpaintStage = document.querySelector('#inpaint-stage');
                const inpaintDropzoneLarge = document.querySelector('#inpaint-dropzone-large');
                const inpaintFileInput = document.querySelector('#inpaint-file-input');
                const inpaintViewport = document.querySelector('#inpaint-viewport');
                const baseCanvas = document.querySelector('#inpaint-base-canvas');
                const maskCanvas = document.querySelector('#inpaint-mask-canvas');
                const brushCursor = document.querySelector('#inpaint-brush-cursor');
                const inpaintInfo = document.querySelector('#inpaint-info');

                const toolZoomOut = document.querySelector('#tool-zoom-out');
                const toolZoomReset = document.querySelector('#tool-zoom-reset');
                const toolZoomIn = document.querySelector('#tool-zoom-in');
                const toolZoomFit = document.querySelector('#tool-zoom-fit');

                // Pan & Zoom State for Inpainting
                let zoom = 1.0;
                let panX = 0;
                let panY = 0;
                let isSpacePressed = false;
                let isPanning = false;
                let lastMousePos = null;
                let gestures = null;
                const isCoarsePointer = window.matchMedia?.('(pointer: coarse)').matches === true;

                // Slider listeners
                denoiseInput?.addEventListener('input', () => {
                    if (denoiseValue) denoiseValue.textContent = parseFloat(denoiseInput.value).toFixed(2);
                });
                growMaskInput?.addEventListener('input', () => {
                    if (growMaskValue) growMaskValue.textContent = `${growMaskInput.value} px`;
                });

                function setWorkspaceView(view) {
                    const isEditor = view === 'editor';
                    if (viewTabEditor) viewTabEditor.classList.toggle('active', isEditor);
                    if (viewTabOutput) viewTabOutput.classList.toggle('active', !isEditor);
                    if (currentMode === 'inpaint') {
                        if (inpaintEditorPanel) inpaintEditorPanel.hidden = !isEditor;
                        if (img2imgEditorPanel) img2imgEditorPanel.hidden = true;
                        if (isEditor && inputImage) {
                            requestAnimationFrame(() => fitToStage());
                        }
                    } else if (currentMode === 'img2img') {
                        if (img2imgEditorPanel) img2imgEditorPanel.hidden = !isEditor;
                        if (inpaintEditorPanel) inpaintEditorPanel.hidden = true;
                    } else {
                        if (inpaintEditorPanel) inpaintEditorPanel.hidden = true;
                        if (img2imgEditorPanel) img2imgEditorPanel.hidden = true;
                    }
                    if (workspaceOutputStage) workspaceOutputStage.hidden = isEditor;
                    if (workspaceOutputFooter) workspaceOutputFooter.hidden = isEditor;
                }

                viewTabEditor?.addEventListener('click', () => setWorkspaceView('editor'));
                viewTabOutput?.addEventListener('click', () => setWorkspaceView('output'));

                function autoMatchRatio(w, h) {
                    const ar = w / h;
                    const ratios = [
                        { id: 'square', val: 1.0 },
                        { id: 'portrait', val: 0.75 },
                        { id: 'landscape', val: 4/3 },
                        { id: 'wide', val: 16/9 }
                    ];
                    let closest = 'square';
                    let minDiff = Infinity;
                    for (const r of ratios) {
                        const diff = Math.abs(ar - r.val);
                        if (diff < minDiff) {
                            minDiff = diff;
                            closest = r.id;
                        }
                    }
                    if (form.elements.ratio) {
                        form.elements.ratio.value = closest;
                        update();
                        persist();
                    }
                }

                composerMatchRatioBtn?.addEventListener('click', () => {
                    if (inputImage) autoMatchRatio(inputImage.naturalWidth || inputImage.width, inputImage.naturalHeight || inputImage.height);
                });
                img2imgMatchRatioBtn?.addEventListener('click', () => {
                    if (inputImage) autoMatchRatio(inputImage.naturalWidth || inputImage.width, inputImage.naturalHeight || inputImage.height);
                });
                toolMatchRatio?.addEventListener('click', () => {
                    if (inputImage) autoMatchRatio(inputImage.naturalWidth || inputImage.width, inputImage.naturalHeight || inputImage.height);
                });

                // `explicit` is the user asking for the image to go away, which
                // is the only thing that discards a saved draft. Mode switches
                // pass false: they blank the stage but keep the workspace.
                function clearImage(explicit = true) {
                    imageLoadVersion++;
                    if (explicit) {
                        imageWorkspaces.delete(currentMode);
                        drafts?.noteCleared(currentMode);
                    }
                    inputImage = null;
                    inputBlob = null;
                    hasMask = false;
                    undoStack.length = 0;
                    redoStack.length = 0;
                    lastStrokeEnd = null;
                    zoom = 1.0;
                    panX = 0;
                    panY = 0;
                    isSpacePressed = false;
                    isPanning = false;
                    updateCursorState();
                    if (inpaintViewport) {
                        inpaintViewport.style.transform = '';
                        inpaintViewport.classList.remove('is-zoomed-in', 'has-brush-cursor');
                    }
                    if (toolZoomReset) toolZoomReset.textContent = '100%';
                    if (brushCursor) brushCursor.style.display = 'none';
                    if (composerPreviewImg) composerPreviewImg.src = '';
                    if (composerImagePreview) composerImagePreview.hidden = true;
                    if (composerDropzonePrompt) composerDropzonePrompt.hidden = false;
                    if (img2imgPreviewImg) img2imgPreviewImg.src = '';
                    if (img2imgViewport) img2imgViewport.hidden = true;
                    if (img2imgDropzone) img2imgDropzone.hidden = false;
                    if (img2imgInfo) img2imgInfo.textContent = 'No image loaded';
                    if (inpaintViewport) inpaintViewport.hidden = true;
                    if (inpaintDropzoneLarge) inpaintDropzoneLarge.hidden = false;
                    if (inpaintInfo) inpaintInfo.textContent = 'No image loaded';
                    updateHistoryButtons();
                    window.dispatchEvent(new CustomEvent('studio-input-change'));
                }

                composerClearImgBtn?.addEventListener('click', (e) => {
                    e.stopPropagation();
                    clearImage();
                });
                img2imgClearBtn?.addEventListener('click', (e) => {
                    e.stopPropagation();
                    clearImage();
                });
                img2imgChangeBtn?.addEventListener('click', () => {
                    img2imgFileInput?.click();
                });

                toolNewImage?.addEventListener('click', () => {
                    inpaintFileInput?.click();
                });

                // Everything the two stages need once `inputImage` holds a
                // decoded image. A fresh load and a restored workspace both
                // land here so the previews, the canvas sizes and the
                // fit-to-stage pass cannot drift apart between the two paths.
                function showInputImage({ status, mask = null, matchRatio = false, keepView = false }) {
                    if (!inputImage) return;
                    const img = inputImage;
                    const width = img.naturalWidth || img.width;
                    const height = img.naturalHeight || img.height;

                    // Update composer preview (legacy compatibility)
                    if (composerPreviewImg) composerPreviewImg.src = img.src;
                    if (composerImageDims) composerImageDims.textContent = `${width} × ${height} px`;
                    if (composerDropzonePrompt) composerDropzonePrompt.hidden = true;
                    if (composerImagePreview) composerImagePreview.hidden = false;

                    // Update unified img2img stage
                    if (img2imgPreviewImg) img2imgPreviewImg.src = img.src;
                    if (img2imgImageDims) img2imgImageDims.textContent = `${width} × ${height} px`;
                    if (img2imgDropzone) img2imgDropzone.hidden = true;
                    if (img2imgViewport) img2imgViewport.hidden = false;
                    if (img2imgInfo) img2imgInfo.textContent = `${width} × ${height} px · Ready for Image-to-Image`;

                    // Update inpaint canvas
                    if (baseCanvas && maskCanvas) {
                        baseCanvas.width = width;
                        baseCanvas.height = height;
                        const bctx = baseCanvas.getContext('2d');
                        bctx.clearRect(0, 0, width, height);
                        bctx.drawImage(img, 0, 0, width, height);

                        maskCanvas.width = width;
                        maskCanvas.height = height;
                        const mctx = maskCanvas.getContext('2d');
                        mctx.clearRect(0, 0, width, height);
                        if (mask) {
                            if (mask instanceof ImageData) mctx.putImageData(mask, 0, 0);
                            else mctx.drawImage(mask, 0, 0, width, height);
                        }
                        checkHasMask();

                        if (inpaintViewport) {
                            inpaintViewport.style.width = `${width}px`;
                            inpaintViewport.style.height = `${height}px`;
                        }
                    }

                    if (inpaintDropzoneLarge) inpaintDropzoneLarge.hidden = true;
                    if (inpaintViewport) inpaintViewport.hidden = false;
                    if (inpaintInfo) inpaintInfo.textContent = `${width} × ${height} px · ${status}`;
                    updateHistoryButtons();

                    // A draft arriving from the other device must not throw
                    // away where the user has zoomed to: the image is the same
                    // size, so the current transform still means the same thing.
                    if (keepView) {
                        applyTransform();
                    } else {
                        requestAnimationFrame(() => {
                            fitToStage();
                        });
                    }

                    if (matchRatio) autoMatchRatio(width, height);
                    window.dispatchEvent(new CustomEvent('studio-input-change'));
                }

                async function loadImageSource(source) {
                    const version = ++imageLoadVersion;
                    const prepared = await window.InpaintUI.prepareImage(source);
                    // A newer load, a mode switch or an explicit Clear happened
                    // while this one was decoding. Leave the newer state alone.
                    if (version !== imageLoadVersion) return;
                    inputBlob = prepared.blob;
                    inputImage = prepared.image;
                    undoStack.length = 0;
                    redoStack.length = 0;
                    showInputImage({ status: 'Ready to paint mask', matchRatio: true });
                    draftsChanged();
                }

                // The mask and undo history travel with the image so that
                // leaving inpaint for another tab and coming back does not
                // throw away work. Kept as pixels, not as a canvas, so the
                // snapshot is unaffected by later drawing.
                function captureWorkspace() {
                    if (!inputImage || !maskCanvas) return { image: null, blob: null, mask: null, history: [] };
                    return {
                        image: inputImage,
                        blob: inputBlob,
                        history: undoStack.slice(),
                        mask: maskCanvas.getContext('2d').getImageData(0, 0, maskCanvas.width, maskCanvas.height)
                    };
                }

                // Expects clearImage() to have run first, so a failed restore
                // leaves an empty stage rather than a half-updated one.
                function restoreWorkspace(saved) {
                    if (!saved?.image) return false;
                    inputImage = saved.image;
                    inputBlob = saved.blob;
                    undoStack.length = 0;
                    redoStack.length = 0;
                    for (const entry of saved.history || []) undoStack.push(entry);
                    showInputImage({ status: 'Edit restored', mask: saved.mask });
                    return true;
                }

                function handleFileSelect(file) {
                    if (!file || !file.type.startsWith('image/')) return;
                    loadImageSource(file).catch(error => { if (inpaintInfo) inpaintInfo.textContent = error.message; });
                    if (window.innerWidth <= 760 && typeof window.setMobileStudioZone === 'function') {
                        window.setMobileStudioZone('stage');
                    }
                }

                composerFileInput?.addEventListener('change', (e) => {
                    if (e.target.files?.[0]) handleFileSelect(e.target.files[0]);
                });
                composerDropzone?.addEventListener('click', (e) => {
                    if (e.target.closest('#composer-image-preview')) return;
                    composerFileInput?.click();
                });

                img2imgFileInput?.addEventListener('change', (e) => {
                    if (e.target.files?.[0]) handleFileSelect(e.target.files[0]);
                });
                img2imgDropzone?.addEventListener('click', () => {
                    img2imgFileInput?.click();
                });

                inpaintFileInput?.addEventListener('change', (e) => {
                    if (e.target.files?.[0]) handleFileSelect(e.target.files[0]);
                });
                inpaintDropzoneLarge?.addEventListener('click', () => {
                    inpaintFileInput?.click();
                });

                // Drag and drop handlers
                [composerDropzone, inpaintDropzoneLarge, img2imgDropzone].forEach(zone => {
                    if (!zone) return;
                    zone.addEventListener('dragover', (e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        zone.classList.add('drag-over');
                    });
                    zone.addEventListener('dragleave', (e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        zone.classList.remove('drag-over');
                    });
                    zone.addEventListener('drop', (e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        zone.classList.remove('drag-over');
                        const file = e.dataTransfer?.files?.[0];
                        if (file) handleFileSelect(file);
                    });
                });

                // Global paste listener
                window.addEventListener('paste', (e) => {
                    if (currentMode === 'txt2img') return;
                    if (e.target.tagName === 'TEXTAREA' || e.target.tagName === 'INPUT') return;
                    const items = e.clipboardData?.items;
                    if (!items) return;
                    for (const item of items) {
                        if (item.type.startsWith('image/')) {
                            const file = item.getAsFile();
                            if (file) {
                                handleFileSelect(file);
                                break;
                            }
                        }
                    }
                });

                // Mask Drawing & Tools
                function clearMask(resetHistory = true) {
                    if (!maskCanvas) return;
                    const mctx = maskCanvas.getContext('2d');
                    mctx.clearRect(0, 0, maskCanvas.width, maskCanvas.height);
                    hasMask = false;
                    if (resetHistory) {
                        undoStack.length = 0;
                        redoStack.length = 0;
                    }
                    lastStrokeEnd = null;
                    updateHistoryButtons();
                    window.dispatchEvent(new CustomEvent('studio-input-change'));
                    draftsChanged();
                }

                function updateHistoryButtons() {
                    if (toolUndo) toolUndo.disabled = undoStack.length === 0;
                    if (toolRedo) toolRedo.disabled = redoStack.length === 0;
                }

                function snapshotMask() {
                    if (!maskCanvas) return null;
                    return maskCanvas.getContext('2d').getImageData(0, 0, maskCanvas.width, maskCanvas.height);
                }

                function pushUndo() {
                    if (!maskCanvas) return;
                    if (undoStack.length >= 20) undoStack.shift();
                    undoStack.push(snapshotMask());
                    // Painting again abandons the branch that redo would have
                    // walked back into, exactly as Photoshop's history does.
                    redoStack.length = 0;
                    updateHistoryButtons();
                }

                function undoMask() {
                    if (!maskCanvas || undoStack.length === 0) return;
                    redoStack.push(snapshotMask());
                    maskCanvas.getContext('2d').putImageData(undoStack.pop(), 0, 0);
                    lastStrokeEnd = null;
                    updateHistoryButtons();
                    checkHasMask();
                    window.dispatchEvent(new CustomEvent('studio-input-change'));
                    draftsChanged();
                }

                function redoMask() {
                    if (!maskCanvas || redoStack.length === 0) return;
                    undoStack.push(snapshotMask());
                    maskCanvas.getContext('2d').putImageData(redoStack.pop(), 0, 0);
                    lastStrokeEnd = null;
                    updateHistoryButtons();
                    checkHasMask();
                    window.dispatchEvent(new CustomEvent('studio-input-change'));
                    draftsChanged();
                }

                toolUndo?.addEventListener('click', undoMask);
                toolRedo?.addEventListener('click', redoMask);

                toolClear?.addEventListener('click', () => {
                    if (!maskCanvas) return;
                    pushUndo();
                    clearMask(false);
                });

                toolInvert?.addEventListener('click', () => {
                    if (!maskCanvas) return;
                    pushUndo();
                    const mctx = maskCanvas.getContext('2d');
                    const imgData = mctx.getImageData(0, 0, maskCanvas.width, maskCanvas.height);
                    const data = imgData.data;
                    for (let i = 0; i < data.length; i += 4) {
                        if (data[i + 3] > 10) {
                            data[i] = 0;
                            data[i + 1] = 0;
                            data[i + 2] = 0;
                            data[i + 3] = 0;
                        } else {
                            data[i] = 236;
                            data[i + 1] = 72;
                            data[i + 2] = 153;
                            data[i + 3] = 165;
                        }
                    }
                    mctx.putImageData(imgData, 0, 0);
                    checkHasMask();
                    window.dispatchEvent(new CustomEvent('studio-input-change'));
                    draftsChanged();
                });

                toolRemoveImage?.addEventListener('click', () => {
                    clearImage();
                });

                // Tool selection
                toolBrush?.addEventListener('click', () => {
                    activeTool = 'brush';
                    toolBrush.classList.add('active');
                    toolEraser?.classList.remove('active');
                    updateBrushCursor();
                });

                toolEraser?.addEventListener('click', () => {
                    activeTool = 'eraser';
                    toolEraser.classList.add('active');
                    toolBrush?.classList.remove('active');
                    updateBrushCursor();
                });

                function setBrushSize(newSize) {
                    const min = parseInt(brushSizeInput?.min || '5', 10);
                    const max = parseInt(brushSizeInput?.max || '160', 10);
                    brushSize = Math.max(min, Math.min(max, Math.round(newSize)));
                    if (brushSizeInput) brushSizeInput.value = brushSize;
                    if (brushSizeDisplay) brushSizeDisplay.textContent = brushSize;
                }

                brushSizeInput?.addEventListener('input', () => {
                    setBrushSize(parseInt(brushSizeInput.value, 10));
                    updateBrushCursor();
                });

                setBrushSize(brushSize);

                // Pan & Zoom Transform and Helpers
                function applyTransform() {
                    if (!inpaintViewport) return;
                    inpaintViewport.style.transform = `translate(${panX}px, ${panY}px) scale(${zoom})`;
                    if (toolZoomReset) {
                        toolZoomReset.textContent = `${Math.round(zoom * 100)}%`;
                    }
                    inpaintViewport.classList.toggle('is-zoomed-in', zoom >= 2.0);
                }

                function zoomAtPoint(clientX, clientY, factor) {
                    if (!inpaintStage || !maskCanvas || inpaintViewport.hidden) return;
                    const stageRect = inpaintStage.getBoundingClientRect();
                    const stageX = clientX - stageRect.left;
                    const stageY = clientY - stageRect.top;

                    const imgX = (stageX - panX) / zoom;
                    const imgY = (stageY - panY) / zoom;

                    const minZoom = 0.05;
                    const maxZoom = 25.0;
                    const newZoom = Math.max(minZoom, Math.min(maxZoom, zoom * factor));
                    if (Math.abs(newZoom - zoom) < 0.0001) return;

                    zoom = newZoom;
                    const next = gestures
                        ? gestures.clampPan(stageX - imgX * newZoom, stageY - imgY * newZoom)
                        : { x: stageX - imgX * newZoom, y: stageY - imgY * newZoom };
                    panX = next.x;
                    panY = next.y;
                    applyTransform();
                }

                function fitToStage() {
                    if (!inpaintStage || !maskCanvas || !inputImage || inpaintViewport.hidden) return;
                    const stageWidth = inpaintStage.clientWidth;
                    const stageHeight = inpaintStage.clientHeight;
                    if (stageWidth <= 0 || stageHeight <= 0) return;

                    const imgWidth = maskCanvas.width || inputImage.naturalWidth || inputImage.width;
                    const imgHeight = maskCanvas.height || inputImage.naturalHeight || inputImage.height;
                    if (imgWidth <= 0 || imgHeight <= 0) return;

                    const pad = 36;
                    const availW = Math.max(80, stageWidth - pad);
                    const availH = Math.max(80, stageHeight - pad);

                    const fitZoom = Math.min(availW / imgWidth, availH / imgHeight, 1.0);
                    zoom = Math.max(0.05, fitZoom);
                    panX = (stageWidth - imgWidth * zoom) / 2;
                    panY = (stageHeight - imgHeight * zoom) / 2;
                    applyTransform();
                }

                function zoomTo100() {
                    if (!inpaintStage || !maskCanvas || !inputImage) return;
                    const stageWidth = inpaintStage.clientWidth;
                    const stageHeight = inpaintStage.clientHeight;
                    const imgWidth = maskCanvas.width || inputImage.naturalWidth || inputImage.width;
                    const imgHeight = maskCanvas.height || inputImage.naturalHeight || inputImage.height;

                    zoom = 1.0;
                    panX = (stageWidth - imgWidth * zoom) / 2;
                    panY = (stageHeight - imgHeight * zoom) / 2;
                    applyTransform();
                }

                function updateCursorState() {
                    if (!inpaintStage) return;
                    if (isPanning) {
                        inpaintStage.classList.add('is-dragging-pan');
                        inpaintStage.classList.remove('is-space-down');
                        if (brushCursor) brushCursor.style.display = 'none';
                    } else if (isSpacePressed) {
                        inpaintStage.classList.add('is-space-down');
                        inpaintStage.classList.remove('is-dragging-pan');
                        if (brushCursor) brushCursor.style.display = 'none';
                    } else {
                        inpaintStage.classList.remove('is-space-down');
                        inpaintStage.classList.remove('is-dragging-pan');
                    }
                }

                function updateBrushCursor(e) {
                    if (e && e.clientX != null && e.clientY != null) {
                        lastMousePos = { clientX: e.clientX, clientY: e.clientY };
                    }
                    if (!brushCursor || !inpaintStage || !maskCanvas || inpaintViewport.hidden) {
                        if (brushCursor) brushCursor.style.display = 'none';
                        if (inpaintViewport) inpaintViewport.classList.remove('has-brush-cursor');
                        return;
                    }
                    // A finger already covers the spot it paints, so the ring
                    // is a pointer affordance only.
                    if (isSpacePressed || isPanning || isCoarsePointer) {
                        brushCursor.style.display = 'none';
                        if (inpaintViewport) inpaintViewport.classList.remove('has-brush-cursor');
                        return;
                    }

                    const stageRect = inpaintStage.getBoundingClientRect();
                    const maskRect = maskCanvas.getBoundingClientRect();
                    const screenScale = maskRect.width / maskCanvas.width;
                    const displayDiameter = Math.max(4, Math.round(brushSize * screenScale));

                    brushCursor.style.width = `${displayDiameter}px`;
                    brushCursor.style.height = `${displayDiameter}px`;
                    brushCursor.classList.toggle('is-eraser', activeTool === 'eraser');

                    const pos = e || lastMousePos;
                    if (pos) {
                        const x = pos.clientX - stageRect.left;
                        const y = pos.clientY - stageRect.top;
                        brushCursor.style.left = `${x}px`;
                        brushCursor.style.top = `${y}px`;

                        const isOverStage = pos.clientX >= stageRect.left && pos.clientX <= stageRect.right &&
                                            pos.clientY >= stageRect.top && pos.clientY <= stageRect.bottom;
                        const isOverCanvas = pos.clientX >= maskRect.left && pos.clientX <= maskRect.right &&
                                             pos.clientY >= maskRect.top && pos.clientY <= maskRect.bottom;

                        if (isOverStage && !isSpacePressed && !isPanning) {
                            brushCursor.style.display = 'block';
                        } else {
                            brushCursor.style.display = 'none';
                        }

                        if (inpaintViewport) {
                            inpaintViewport.classList.toggle('has-brush-cursor', isOverCanvas && !isSpacePressed && !isPanning);
                        }
                    }
                }

                function checkHasMask() {
                    if (!maskCanvas) return false;
                    const mctx = maskCanvas.getContext('2d');
                    const imgData = mctx.getImageData(0, 0, maskCanvas.width, maskCanvas.height);
                    const data = imgData.data;
                    let count = 0;
                    for (let i = 3; i < data.length; i += 16) {
                        if (data[i] > 10) {
                            count++;
                            if (count > 5) break;
                        }
                    }
                    hasMask = count > 5;
                    return hasMask;
                }

                function getCanvasCoordinates(e) {
                    const rect = maskCanvas.getBoundingClientRect();
                    const scaleX = maskCanvas.width / rect.width;
                    const scaleY = maskCanvas.height / rect.height;
                    const clientX = e.clientX ?? (e.touches && e.touches[0]?.clientX) ?? 0;
                    const clientY = e.clientY ?? (e.touches && e.touches[0]?.clientY) ?? 0;
                    return {
                        x: (clientX - rect.left) * scaleX,
                        y: (clientY - rect.top) * scaleY
                    };
                }

                function drawSegment(p1, p2) {
                    if (!maskCanvas) return;
                    const mctx = maskCanvas.getContext('2d');
                    mctx.save();
                    mctx.lineCap = 'round';
                    mctx.lineJoin = 'round';
                    mctx.lineWidth = brushSize;
                    if (activeTool === 'brush') {
                        mctx.globalCompositeOperation = 'source-over';
                        mctx.strokeStyle = MASK_PAINT;
                        mctx.fillStyle = MASK_PAINT;
                    } else {
                        mctx.globalCompositeOperation = 'destination-out';
                        mctx.strokeStyle = 'rgba(0, 0, 0, 1)';
                        mctx.fillStyle = 'rgba(0, 0, 0, 1)';
                    }
                    mctx.beginPath();
                    mctx.moveTo(p1.x, p1.y);
                    mctx.lineTo(p2.x, p2.y);
                    mctx.stroke();
                    mctx.restore();
                }

                function drawDot(p) {
                    if (!maskCanvas) return;
                    const mctx = maskCanvas.getContext('2d');
                    mctx.save();
                    if (activeTool === 'brush') {
                        mctx.globalCompositeOperation = 'source-over';
                        mctx.fillStyle = MASK_PAINT;
                    } else {
                        mctx.globalCompositeOperation = 'destination-out';
                        mctx.fillStyle = 'rgba(0, 0, 0, 1)';
                    }
                    mctx.beginPath();
                    mctx.arc(p.x, p.y, brushSize / 2, 0, Math.PI * 2);
                    mctx.fill();
                    mctx.restore();
                }

                // Discards the snapshot taken at the start of a stroke that was
                // abandoned (a second finger landed and turned it into a pinch).
                function popUndo() {
                    if (!maskCanvas || undoStack.length === 0) return;
                    const mctx = maskCanvas.getContext('2d');
                    mctx.putImageData(undoStack.pop(), 0, 0);
                    updateHistoryButtons();
                }

                // Stage Input: touch, pen and mouse all run through the shared
                // gesture layer, which adds pinch-to-zoom and two-finger pan.
                if (inpaintStage && maskCanvas) {
                    gestures = window.InpaintUI?.attachGestures({
                        stage: inpaintStage,
                        isReady: () => Boolean(inputImage) && !inpaintViewport.hidden,
                        getMaskRect: () => maskCanvas.getBoundingClientRect(),
                        getContentSize: () => ({
                            width: maskCanvas.width || inputImage?.naturalWidth || 0,
                            height: maskCanvas.height || inputImage?.naturalHeight || 0
                        }),
                        getZoom: () => zoom,
                        setZoom: value => { zoom = value; },
                        getPan: () => ({ x: panX, y: panY }),
                        setPan: (x, y) => { panX = x; panY = y; },
                        applyTransform,
                        isPanModifier: () => isSpacePressed,
                        getBrushSize: () => brushSize,
                        setBrushSize: (value) => setBrushSize(value),
                        onStageFocus: () => inpaintStage.focus({ preventScroll: true }),
                        onStrokeStart: (e) => {
                            pushUndo();
                            isDrawing = true;
                            const point = getCanvasCoordinates(e);
                            // Shift+click runs a straight edge on from wherever
                            // the last stroke stopped, the Photoshop way of
                            // masking a hard line without a steady hand.
                            if (e.shiftKey && lastStrokeEnd) {
                                drawSegment(lastStrokeEnd, point);
                            } else {
                                drawDot(point);
                            }
                            lastPoint = point;
                        },
                        onStrokeMove: (e) => {
                            if (!lastPoint) return;
                            const currentPoint = getCanvasCoordinates(e);
                            drawSegment(lastPoint, currentPoint);
                            lastPoint = currentPoint;
                        },
                        onStrokeEnd: () => {
                            isDrawing = false;
                            lastStrokeEnd = lastPoint;
                            lastPoint = null;
                            checkHasMask();
                            window.dispatchEvent(new CustomEvent('studio-input-change'));
                            draftsChanged();
                        },
                        onStrokeCancel: () => {
                            isDrawing = false;
                            lastPoint = null;
                            popUndo();
                        },
                        onPanStateChange: (active) => {
                            isPanning = active;
                            updateCursorState();
                        },
                        onCursor: (e) => updateBrushCursor(e)
                    });

                    inpaintStage.addEventListener('pointerenter', (e) => {
                        if (document.activeElement && !['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName)) {
                            inpaintStage.focus({ preventScroll: true });
                        }
                        updateBrushCursor(e);
                    });
                    inpaintStage.addEventListener('pointerleave', () => {
                        if (!isDrawing && !isPanning && brushCursor) {
                            brushCursor.style.display = 'none';
                            if (inpaintViewport) inpaintViewport.classList.remove('has-brush-cursor');
                        }
                    });

                    inpaintToolbar?.addEventListener('click', (e) => {
                        const btn = e.target.closest('button');
                        if (btn && btn.id !== 'tool-more-btn') {
                            btn.blur();
                            inpaintStage?.focus({ preventScroll: true });
                        }
                    });

                    window.InpaintUI?.attachToolbarMenu(
                        document.querySelector('#tool-more-btn'),
                        document.querySelector('#tool-more-panel')
                    );

                    // Wheel Controls:
                    // Alt + Scroll (or trackpad pinch): Zoom in/out at pointer
                    // Ctrl + Scroll: Resize brush
                    // Plain Scroll: Pan canvas
                    inpaintStage.addEventListener('wheel', (e) => {
                        if (inpaintViewport.hidden || !inputImage) return;

                        if (e.altKey) {
                            e.preventDefault();
                            const factor = e.deltaY < 0 ? 1.15 : (1 / 1.15);
                            zoomAtPoint(e.clientX, e.clientY, factor);
                            updateBrushCursor(e);
                            return;
                        }

                        if (e.ctrlKey || e.metaKey) {
                            e.preventDefault();
                            e.stopPropagation();
                            const step = e.deltaY < 0 ? 5 : -5;
                            setBrushSize(brushSize + step);
                            updateBrushCursor(e);
                            return;
                        }

                        e.preventDefault();
                        if (gestures) {
                            gestures.setPan(panX - e.deltaX, panY - e.deltaY);
                        } else {
                            panX -= e.deltaX;
                            panY -= e.deltaY;
                            applyTransform();
                        }
                        updateBrushCursor(e);
                    }, { passive: false });
                }

                // Toolbar Zoom Buttons
                toolZoomIn?.addEventListener('click', () => {
                    if (!inpaintStage) return;
                    const rect = inpaintStage.getBoundingClientRect();
                    zoomAtPoint(rect.left + rect.width / 2, rect.top + rect.height / 2, 1.25);
                    updateBrushCursor();
                });

                toolZoomOut?.addEventListener('click', () => {
                    if (!inpaintStage) return;
                    const rect = inpaintStage.getBoundingClientRect();
                    zoomAtPoint(rect.left + rect.width / 2, rect.top + rect.height / 2, 0.8);
                    updateBrushCursor();
                });

                toolZoomFit?.addEventListener('click', () => {
                    fitToStage();
                    updateBrushCursor();
                });

                toolZoomReset?.addEventListener('click', () => {
                    if (Math.abs(zoom - 1.0) < 0.05) {
                        fitToStage();
                    } else {
                        zoomTo100();
                    }
                    updateBrushCursor();
                });

                // Photoshop-style keyboard map. The bindings themselves live
                // in the shared module so Lite and the chat dialog answer to
                // the same keys this page does.
                function zoomByFactor(factor) {
                    if (!inpaintStage) return;
                    const rect = inpaintStage.getBoundingClientRect();
                    zoomAtPoint(rect.left + rect.width / 2, rect.top + rect.height / 2, factor);
                    updateBrushCursor();
                }

                const chatInpaintDialog = document.querySelector('#chat-inpaint-dialog');

                window.InpaintUI?.attachShortcuts({
                    // The chat's own inpaint dialog floats over this editor and
                    // binds the same keys, so it takes them while it is open.
                    isActive: () => currentMode === 'inpaint' && Boolean(inpaintViewport) &&
                        !inpaintViewport.hidden && !chatInpaintDialog?.open,
                    onSpaceChange: (down) => {
                        isSpacePressed = down;
                        updateCursorState();
                        if (!down) updateBrushCursor();
                    },
                    brush: () => toolBrush?.click(),
                    eraser: () => toolEraser?.click(),
                    toggleTool: () => (activeTool === 'brush' ? toolEraser : toolBrush)?.click(),
                    adjustBrush: (delta) => {
                        setBrushSize(brushSize + delta);
                        updateBrushCursor();
                    },
                    undo: undoMask,
                    redo: redoMask,
                    invert: () => toolInvert?.click(),
                    clear: () => toolClear?.click(),
                    fit: () => {
                        fitToStage();
                        updateBrushCursor();
                    },
                    zoom100: () => {
                        zoomTo100();
                        updateBrushCursor();
                    },
                    zoomBy: zoomByFactor,
                    onWindowBlur: () => {
                        isPanning = false;
                        updateCursorState();
                    }
                });

                window.addEventListener('resize', () => {
                    if (currentMode === 'inpaint' && inputImage && inpaintViewport && !inpaintViewport.hidden) {
                        updateBrushCursor();
                    }
                });

                // Mode switching
                function setMode(mode) {
                    if (!['txt2img', 'img2img', 'inpaint', 'chat'].includes(mode)) return;
                    // Each editing mode keeps its own image, mask and undo
                    // history, so loading a reference for Image-to-Image never
                    // costs the user the mask they painted in Inpaint.
                    const switching = mode !== currentMode;
                    let restoring = null;
                    if (switching) {
                        if (currentMode === 'inpaint' || currentMode === 'img2img') {
                            imageWorkspaces.set(currentMode, captureWorkspace());
                        }
                        restoring = imageWorkspaces.get(mode) || null;
                        // Also cancels any load still decoding for the old mode.
                        clearImage(false);
                    }
                    currentMode = mode;
                    document.body.dataset.studioMode = mode;
                    document.body.classList.toggle('studio-chat-active', mode === 'chat');
                    modeTabs.forEach(tab => {
                        const active = tab.dataset.mode === mode;
                        tab.classList.toggle('active', active);
                        tab.setAttribute('aria-selected', String(active));
                    });
                    const studioChatLayout = document.querySelector('#studio-chat-layout');
                    const studioHistory = document.querySelector('#studio-history');
                    if (mode === 'chat') {
                        if (studioLayout) studioLayout.hidden = true;
                        if (studioHistory) studioHistory.hidden = true;
                        if (studioChatLayout) studioChatLayout.hidden = false;
                        window.dispatchEvent(new CustomEvent('studio-mode-change', { detail: { mode } }));
                        return;
                    } else {
                        if (studioLayout) studioLayout.hidden = false;
                        if (studioHistory) studioHistory.hidden = false;
                        if (studioChatLayout) studioChatLayout.hidden = true;
                    }
                    if (mode === 'txt2img') {
                        if (composerImageSection) composerImageSection.hidden = true;
                        if (composerModeSliders) composerModeSliders.hidden = true;
                        if (workspaceViewTabs) workspaceViewTabs.hidden = true;
                        if (img2imgEditorPanel) img2imgEditorPanel.hidden = true;
                        if (inpaintEditorPanel) inpaintEditorPanel.hidden = true;
                        if (workspaceOutputStage) workspaceOutputStage.hidden = false;
                        if (workspaceOutputFooter) workspaceOutputFooter.hidden = false;
                        const cTitle = document.querySelector('#canvas-title');
                        if (cTitle) cTitle.textContent = 'Output';
                    } else if (mode === 'img2img') {
                        if (composerImageSection) composerImageSection.hidden = true;
                        if (composerModeSliders) composerModeSliders.hidden = false;
                        if (denoiseContainer) denoiseContainer.hidden = false;
                        if (growMaskContainer) growMaskContainer.hidden = true;
                        if (denoiseHint) denoiseHint.textContent = "0.3 = subtle modifications, 0.7 = heavy variation.";
                        if (workspaceViewTabs) workspaceViewTabs.hidden = false;
                        if (viewTabEditor) viewTabEditor.textContent = "Reference";
                        if (viewTabOutput) viewTabOutput.textContent = "Output";
                        if (inpaintEditorPanel) inpaintEditorPanel.hidden = true;
                        setWorkspaceView('editor');
                        const cTitle = document.querySelector('#canvas-title');
                        if (cTitle) cTitle.textContent = 'Input Reference';
                        if (denoiseInput && denoiseValue && denoiseInput.value === '0.75') {
                            denoiseInput.value = '0.65';
                            denoiseValue.textContent = '0.65';
                        }
                        if (stepsInput?.value === '20') stepsInput.value = modelDetails[form.elements.model?.value]?.steps || '16';
                        // Only Krea 2 wires an uploaded image into its graph. The other
                        // architectures build a text-to-image graph and would silently
                        // discard the upload, so the orchestrator refuses those jobs.
                        // Switch here rather than let the user reach that error.
                        if (form.elements.architecture?.value !== 'krea2') {
                            form.elements.architecture.value = 'krea2';
                            syncModelDropdown('krea2', 'krea2_turbo');
                            activeLoras = [];
                            renderLoras();
                            resetAdvancedDefaults();
                            update();
                            persist();
                        }
                    } else if (mode === 'inpaint') {
                        if (composerImageSection) composerImageSection.hidden = true;
                        if (composerModeSliders) composerModeSliders.hidden = false;
                        if (denoiseContainer) denoiseContainer.hidden = false;
                        if (growMaskContainer) growMaskContainer.hidden = false;
                        if (denoiseHint) denoiseHint.textContent = "0.75 balances prompt adherence with preserving the original proportions.";
                        if (workspaceViewTabs) workspaceViewTabs.hidden = false;
                        if (viewTabEditor) viewTabEditor.textContent = "Mask editor";
                        if (viewTabOutput) viewTabOutput.textContent = "Output";
                        if (img2imgEditorPanel) img2imgEditorPanel.hidden = true;
                        setWorkspaceView('editor');
                        const cTitle = document.querySelector('#canvas-title');
                        if (cTitle) cTitle.textContent = 'Inpaint Mask';

                        if (denoiseInput && denoiseValue && denoiseInput.value === '0.65') {
                            denoiseInput.value = '0.75';
                            denoiseValue.textContent = '0.75';
                        }
                        // Masked edits are Krea 2 only, but any checkpoint with its own
                        // LanPaint path keeps its place - only the others fall back to Turbo.
                        const currentArch = form.elements.architecture?.value;
                        const currentModel = form.elements.model?.value;
                        if (currentArch !== 'krea2') {
                            form.elements.architecture.value = 'krea2';
                            syncModelDropdown('krea2', 'krea2_turbo');
                            activeLoras = [];
                            renderLoras();
                            resetAdvancedDefaults();
                            update();
                            persist();
                        } else if (!inpaintModels.includes(currentModel)) {
                            // Same architecture, so the LoRA stack still applies.
                            form.elements.model.value = 'krea2_turbo';
                            renderLoras();
                            resetAdvancedDefaults();
                            update();
                            persist();
                        } else {
                            resetAdvancedDefaults();
                            update();
                        }
                    }
                    // Restored last, once the panel for the new mode is on
                    // screen, so the fit-to-stage pass can measure the stage.
                    if (switching) {
                        restoreWorkspace(restoring);
                        drafts?.noteModeShown(mode);
                    }
                    window.dispatchEvent(new CustomEvent('studio-mode-change', { detail: { mode } }));
                }

                modeTabs.forEach(tab => {
                    tab.addEventListener('click', () => setMode(tab.dataset.mode));
                    tab.addEventListener('keydown', event => {
                        if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
                        event.preventDefault();
                        const tabs = [...modeTabs];
                        const current = tabs.indexOf(tab);
                        const next = event.key === 'Home' ? 0
                            : event.key === 'End' ? tabs.length - 1
                            : (current + (event.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length;
                        tabs[next].focus();
                        setMode(tabs[next].dataset.mode);
                    });
                });

                // Quick action buttons in output stage
                outputToInpaint?.addEventListener('click', () => {
                    const img = workspaceOutputStage?.querySelector('.canvas-frame img');
                    if (img?.src) {
                        setMode('inpaint');
                        loadImageSource(img.src);
                        if (window.innerWidth <= 760 && typeof window.setMobileStudioZone === 'function') {
                            window.setMobileStudioZone('stage');
                        }
                    }
                });
                outputToImg2img?.addEventListener('click', () => {
                    const img = workspaceOutputStage?.querySelector('.canvas-frame img');
                    if (img?.src) {
                        setMode('img2img');
                        loadImageSource(img.src);
                        if (window.innerWidth <= 760 && typeof window.setMobileStudioZone === 'function') {
                            window.setMobileStudioZone('stage');
                        }
                    }
                });

                // Export Mask as black/white PNG Blob
                async function getMaskBlob() {
                    if (!maskCanvas) return null;
                    const off = document.createElement('canvas');
                    off.width = maskCanvas.width;
                    off.height = maskCanvas.height;
                    const octx = off.getContext('2d');
                    octx.fillStyle = '#000000';
                    octx.fillRect(0, 0, off.width, off.height);
                    const mctx = maskCanvas.getContext('2d');
                    const srcData = mctx.getImageData(0, 0, off.width, off.height);
                    const dstData = octx.getImageData(0, 0, off.width, off.height);
                    for (let i = 0; i < srcData.data.length; i += 4) {
                        if (srcData.data[i + 3] > 127) {
                            dstData.data[i] = 255;
                            dstData.data[i + 1] = 255;
                            dstData.data[i + 2] = 255;
                            dstData.data[i + 3] = 255;
                        }
                    }
                    octx.putImageData(dstData, 0, 0);
                    return new Promise((resolve) => off.toBlob(resolve, 'image/png'));
                }

                // Export Input Image as PNG/JPEG Blob
                async function getInputBlob() {
                    if (inputBlob) return inputBlob;
                    if (!inputImage) return null;
                    const off = document.createElement('canvas');
                    off.width = inputImage.naturalWidth || inputImage.width;
                    off.height = inputImage.naturalHeight || inputImage.height;
                    const octx = off.getContext('2d');
                    octx.drawImage(inputImage, 0, 0, off.width, off.height);
                    return new Promise((resolve) => off.toBlob(resolve, 'image/png'));
                }

                // ---- Durable drafts -------------------------------------
                // The editor keeps owning its own state; the draft controller
                // only asks for a snapshot and hands payloads back.
                const draftStatus = document.querySelector('#draft-status');
                const draftConflict = document.querySelector('#draft-conflict');
                const draftUseRemote = document.querySelector('#draft-use-remote');
                const draftKeepLocal = document.querySelector('#draft-keep-local');
                let draftStatusTimer = null;

                function showDraftStatus(state, text) {
                    if (!draftStatus) return;
                    draftStatus.textContent = text;
                    draftStatus.dataset.state = state;
                    draftStatus.hidden = false;
                    clearTimeout(draftStatusTimer);
                    // An error stays until something better happens; the rest
                    // are reassurance, not information to act on.
                    if (state !== 'error') {
                        draftStatusTimer = setTimeout(() => { draftStatus.hidden = true; }, 4000);
                    }
                }

                function rawMaskBlob() {
                    if (!maskCanvas?.width) return Promise.resolve(null);
                    // The submission mask is flattened to black and white; a
                    // draft keeps the painted overlay exactly as it looks.
                    return new Promise(resolve => maskCanvas.toBlob(resolve, 'image/png'));
                }

                function maskBlobFrom(mask) {
                    if (!mask) return Promise.resolve(null);
                    const off = document.createElement('canvas');
                    off.width = mask.width || mask.naturalWidth;
                    off.height = mask.height || mask.naturalHeight;
                    if (!off.width || !off.height) return Promise.resolve(null);
                    const octx = off.getContext('2d');
                    if (mask instanceof ImageData) octx.putImageData(mask, 0, 0);
                    else octx.drawImage(mask, 0, 0);
                    return new Promise(resolve => off.toBlob(resolve, 'image/png'));
                }

                async function snapshotDraft(mode) {
                    if (mode === currentMode) {
                        if (!inputImage) return null;
                        return {
                            imageBlob: await getInputBlob(),
                            maskBlob: await rawMaskBlob(),
                            meta: { width: maskCanvas?.width || 0, height: maskCanvas?.height || 0, savedAt: Date.now() }
                        };
                    }
                    const saved = imageWorkspaces.get(mode);
                    if (!saved?.image) return null;
                    return {
                        imageBlob: saved.blob,
                        maskBlob: await maskBlobFrom(saved.mask),
                        meta: {
                            width: saved.image.naturalWidth || 0,
                            height: saved.image.naturalHeight || 0,
                            savedAt: Date.now()
                        }
                    };
                }

                async function applyDraft(mode, payload) {
                    if (!payload) {
                        imageWorkspaces.delete(mode);
                        if (mode === currentMode) clearImage(false);
                        return;
                    }
                    const prepared = await window.InpaintUI.prepareImage(payload.imageBlob);
                    const mask = payload.maskBlob ? (await window.InpaintUI.prepareImage(payload.maskBlob)).image : null;
                    if (mode === currentMode) {
                        // Supersede anything still decoding, exactly as a fresh
                        // load would.
                        imageLoadVersion++;
                        const sameImage = Boolean(inputImage) && maskCanvas
                            && maskCanvas.width === (prepared.image.naturalWidth || prepared.image.width)
                            && maskCanvas.height === (prepared.image.naturalHeight || prepared.image.height);
                        inputImage = prepared.image;
                        inputBlob = prepared.blob;
                        undoStack.length = 0;
                        redoStack.length = 0;
                        showInputImage({ status: 'Draft restored', mask, keepView: sameImage });
                    } else {
                        imageWorkspaces.set(mode, { image: prepared.image, blob: prepared.blob, mask, history: [] });
                    }
                }

                function startDrafts() {
                    if (drafts || !window.InpaintDrafts || !window.StudioCrypto?.isUnlocked()) return;
                    drafts = window.InpaintDrafts.create({
                        app: 'studio',
                        owner: user.id,
                        seal: bytes => window.StudioCrypto.sealBinary(bytes),
                        unseal: bytes => window.StudioCrypto.unsealBinary(bytes),
                        snapshot: snapshotDraft,
                        apply: applyDraft,
                        isBusy: () => isDrawing,
                        onStatus: showDraftStatus,
                        onConflict: (mode, resolver) => {
                            if (!draftConflict) return;
                            if (!resolver) { draftConflict.hidden = true; return; }
                            draftConflict.hidden = false;
                            draftUseRemote.onclick = () => resolver.useRemote();
                            draftKeepLocal.onclick = () => resolver.keepLocal();
                        }
                    });
                    // Same idea as window.StudioInpaint: a named handle for
                    // the console and the regression tests.
                    window.StudioDrafts = drafts;
                    drafts.start().catch(() => showDraftStatus('error', 'Drafts are unavailable in this browser'));
                }

                if (window.StudioCrypto?.isUnlocked()) startDrafts();
                else window.addEventListener('studio-unlocked', startDrafts, { once: true });

                window.StudioInpaint = {
                    getMode: () => currentMode,
                    setMode: setMode,
                    hasInputImage: () => Boolean(inputImage),
                    hasMask: () => checkHasMask(),
                    getDenoise: () => parseFloat(denoiseInput?.value || '0.65'),
                    getGrowMask: () => parseInt(growMaskInput?.value || '6', 10),
                    loadImage: loadImageSource,
                    getInputBlob: getInputBlob,
                    getMaskBlob: getMaskBlob,
                    showOutputView: () => {
                        if (currentMode === 'inpaint' || currentMode === 'img2img') setWorkspaceView('output');
                    }
                };
            }

            window.addEventListener("aistudio-auth-change", () => window.location.reload());
            window.StudioComposer = {
                getLoras: () => activeLoras.map(item => ({ ...item })),
                getLoraLabel: id => loraDetails[id]?.label || null,
                applyConfig: config => useStarter(config),
                saveCustomPresetFromConfig
            };
            initModesAndInpainting();
            // Not awaited: the studio is usable while the scan runs, and the
            // dropdowns are corrected when it answers.
            loadRegistry();
            window.StudioReady = true;
            window.dispatchEvent(new CustomEvent("studio-ready", { detail: { userId: user.id } }));
        } catch { feedback.textContent = "Could not verify your session. Reload the page to try again."; }
    }
    init();
}());

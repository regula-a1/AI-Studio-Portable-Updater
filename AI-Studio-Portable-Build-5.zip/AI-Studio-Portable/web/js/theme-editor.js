(function () {
    'use strict';

    // The scheme picker.
    //
    // theme.js already carried all of this - sixteen named schemes with their
    // descriptions and swatches, setScheme, resetSchemes - and nothing in the
    // build could reach any of it. This is the missing half: a grid of cards per
    // mode, so the schemes that were always there can be chosen.
    //
    // Cards are built as DOM nodes rather than an HTML string. The scheme data is
    // ours rather than the user's, so escaping is not strictly at issue, but the
    // rest of this interface builds nodes and a lone innerHTML template is how
    // that stops being true later.

    const dialog = document.querySelector('#theme-dialog');
    if (!dialog) return;

    const openBtn = document.querySelector('#theme-editor-open');
    const closeBtn = document.querySelector('#theme-dialog-close');
    const resetBtn = document.querySelector('#theme-reset');
    const statusEl = document.querySelector('#theme-status');
    const groups = {
        light: document.querySelector('#theme-options-light'),
        dark: document.querySelector('#theme-options-dark')
    };

    const api = () => window.StudioTheme;

    function schemesFor(mode) {
        const theme = api();
        if (!theme) return [];
        if (typeof theme.getSchemes === 'function') return theme.getSchemes(mode);
        return Array.isArray(theme.schemes?.[mode]) ? theme.schemes[mode] : [];
    }

    function checkMark() {
        const span = document.createElement('span');
        span.className = 'theme-check';
        span.setAttribute('aria-hidden', 'true');
        const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.setAttribute('viewBox', '0 0 24 24');
        svg.setAttribute('fill', 'none');
        svg.setAttribute('stroke', 'currentColor');
        const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        path.setAttribute('d', 'm20 6-11 11-5-5');
        svg.appendChild(path);
        span.appendChild(svg);
        return span;
    }

    function card(mode, scheme) {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'theme-card';
        button.setAttribute('role', 'radio');
        button.setAttribute('aria-checked', 'false');
        button.dataset.mode = mode;
        button.dataset.scheme = scheme.id;

        const head = document.createElement('span');
        head.className = 'theme-card-head';
        const name = document.createElement('span');
        name.className = 'theme-name';
        name.textContent = scheme.name || scheme.id;
        head.append(name, checkMark());

        const description = document.createElement('span');
        description.className = 'theme-description';
        description.textContent = scheme.description || '';

        const swatches = document.createElement('span');
        swatches.className = 'theme-swatches';
        swatches.setAttribute('aria-hidden', 'true');
        for (const colour of scheme.swatches || []) {
            const swatch = document.createElement('span');
            swatch.className = 'theme-swatch';
            // A style property, not an interpolated attribute string.
            swatch.style.setProperty('--swatch-color', colour);
            swatches.appendChild(swatch);
        }

        button.append(head, description, swatches);
        return button;
    }

    function render() {
        for (const [mode, group] of Object.entries(groups)) {
            if (!group) continue;
            group.replaceChildren();
            for (const scheme of schemesFor(mode)) group.appendChild(card(mode, scheme));
        }
        syncSelection();
    }

    function syncSelection() {
        const theme = api();
        if (!theme) return;
        const preferences = theme.getPreferences();
        for (const button of document.querySelectorAll('.theme-card')) {
            const selected = button.dataset.scheme === preferences[button.dataset.mode + 'Scheme'];
            button.classList.toggle('selected', selected);
            button.setAttribute('aria-checked', String(selected));
        }
        if (!statusEl) return;
        const active = schemesFor(preferences.mode)
            .find(scheme => scheme.id === preferences.activeScheme);
        statusEl.textContent = active
            ? 'Using ' + active.name + ' for ' + preferences.mode + ' mode.'
            : '';
    }

    function choose(button) {
        const theme = api();
        if (!button || !theme) return;
        const mode = button.dataset.mode;
        theme.setScheme(mode, button.dataset.scheme);
        // Switch to the mode that was edited, so the choice is visible at once
        // rather than the next time they happen to flip the toggle.
        theme.setTheme(mode);
        syncSelection();
    }

    for (const group of Object.values(groups)) {
        if (!group) continue;
        group.addEventListener('click', event => choose(event.target.closest('.theme-card')));
        group.addEventListener('keydown', event => {
            if (event.key !== 'Enter' && event.key !== ' ') return;
            const button = event.target.closest('.theme-card');
            if (!button) return;
            event.preventDefault();
            choose(button);
        });
    }

    openBtn?.addEventListener('click', () => {
        render();
        dialog.showModal();
    });
    closeBtn?.addEventListener('click', () => dialog.close());
    dialog.addEventListener('click', event => { if (event.target === dialog) dialog.close(); });
    resetBtn?.addEventListener('click', () => {
        api()?.resetSchemes();
        syncSelection();
    });

    // The sun/moon button and this dialog both change the theme, so whichever
    // was not used has to catch up.
    window.addEventListener('aistudio-theme-change', syncSelection);
}());

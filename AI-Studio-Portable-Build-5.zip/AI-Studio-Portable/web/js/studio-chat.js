/**
 * AI Studio Portable - Chat Tab Controller
 * Local LLM integration. The model is chosen per turn from the picker; see
 * CHAT_MODELS in functions/api/_studio_agent.py for the installed tiers.
 *
 * E2EE via the Studio content key: plaintext exists only in this file and in the
 * worker on the PC. Everything the API sees is a sealed envelope.
 *
 * Message lifecycle: a message is `pending` while it only exists in the browser
 * and gains an `id` once the API has stored it. Sync reconciles on that id, so a
 * message must never be rendered from two sources at once.
 */

(function () {
    'use strict';

    // ---------------------------------------------------------------- DOM ---
    const chatSidebar = document.querySelector('#chat-sidebar');
    const chatSidebarHeader = document.querySelector('#chat-sidebar-header');
    const chatLayout = document.querySelector('#studio-chat-layout');
    const chatSessionsList = document.querySelector('#chat-sessions-list');
    const chatSearch = document.querySelector('#chat-search');
    const newChatBtn = document.querySelector('#new-chat-btn');
    const sidebarCollapseBtn = document.querySelector('#chat-sidebar-collapse');
    const activeChatTitle = document.querySelector('#active-chat-title');
    const chatTitleEditBtn = document.querySelector('#chat-title-edit-btn');
    const chatDeleteBtn = document.querySelector('#chat-delete-btn');
    const chatCopyAllBtn = document.querySelector('#chat-copy-all-btn');
    const chatExportBtn = document.querySelector('#chat-export-btn');
    const chatMessagesContainer = document.querySelector('#chat-messages-container');
    const chatJumpLatest = document.querySelector('#chat-jump-latest');
    const chatStatusBar = document.querySelector('#chat-status-bar');
    const chatStatusText = document.querySelector('#chat-status-text');
    const chatComposerWrap = document.querySelector('#chat-composer-wrap');
    const chatAttachmentTray = document.querySelector('#chat-attachment-tray');
    const chatAttachBtn = document.querySelector('#chat-attach-btn');
    const chatFileInput = document.querySelector('#chat-file-input');
    const chatComposerForm = document.querySelector('#chat-composer-form');
    const chatInput = document.querySelector('#chat-input');
    const chatSendBtn = document.querySelector('#chat-send-btn');
    const chatQueueChip = document.querySelector('#chat-queue-chip');
    const chatQueueCount = document.querySelector('#chat-queue-count');
    const chatModelSelect = document.querySelector('#chat-model');

    // Offer only models this card can actually hold, and correct the context
    // figures from the same source the engine uses.
    //
    // The option elements carry data-ctx and data-image-tokens, and those numbers
    // have to agree with CHAT_MODELS or the context meter misreports how full a
    // conversation is. They were a second hand-maintained copy of the engine's
    // own values; now the registry publishes them and this overwrites the markup.
    // Picking a model too large for the card used to fail inside llama.cpp, well
    // out of sight of whoever chose it.
    async function applyHardwareProfile() {
        if (!chatModelSelect) return;
        let registry;
        try {
            const response = await fetch('/api/studio?action=registry', { cache: 'no-store' });
            if (!response.ok) return;
            registry = await response.json();
        } catch (_) {
            return;                       // Leave every option as-is if unreachable.
        }
        const tiers = registry?.profile?.tiers || {};
        const installedTiers = registry?.chatModels || {};
        // A tier whose weights were never downloaded is hidden, not listed as
        // unavailable. A fresh install downloads one of these, so the picker
        // was four things the user does not have and one they do.
        //
        // "Needs a larger GPU" stays visible on purpose: that model IS on the
        // disk, and being told why it cannot be chosen is useful. Only the
        // absent ones go.
        //
        // Never hidden when that would empty the picker - a studio whose chat
        // model has not finished downloading should say so, not show nothing.
        const options = [...chatModelSelect.options];
        const downloaded = (option) => {
            const present = installedTiers[option.value];
            return !(present && !present.available);
        };
        const anyDownloaded = options.some(downloaded);
        let firstUsable = null;
        for (const option of options) {
            const tier = tiers[option.value];
            const present = installedTiers[option.value];
            const missing = present && !present.available;
            const tooBig = tier && !tier.fits;
            option.disabled = Boolean(missing || tooBig);
            option.hidden = Boolean(missing && anyDownloaded);
            if (tier?.fits && tier.ctx) option.dataset.ctx = String(tier.ctx);
            if (present?.image_tokens) option.dataset.imageTokens = String(present.image_tokens);
            const base = option.textContent.replace(/ — .*$/, '');
            if (missing) option.textContent = base + ' — not downloaded';
            else if (tooBig) option.textContent = base + ' — needs a larger GPU';
            else if (tier?.reduced) option.textContent = base + ' — shorter memory on this GPU';
            else option.textContent = base;
            if (!option.disabled && firstUsable === null) firstUsable = option.value;
        }
        // Never leave a disabled model selected: the composer would send a turn
        // that cannot run.
        const chosen = chatModelSelect.selectedOptions[0];
        if (chosen?.disabled || chosen?.hidden) {
            const preferred = registry?.profile?.defaultChatModel;
            const fallback = (preferred && !chatModelSelect.querySelector(
                `option[value="${preferred}"]`)?.disabled) ? preferred : firstUsable;
            if (fallback) {
                chatModelSelect.value = fallback;
                chatModelSelect.dispatchEvent(new Event('change', { bubbles: true }));
            }
        }
    }

    const chatModelBadge = document.querySelector('#chat-model-badge');
    const chatContextBtn = document.querySelector('#chat-context-btn');
    const chatContextPct = document.querySelector('#chat-context-pct');
    const chatContextDialog = document.querySelector('#chat-context-dialog');
    const chatContextBody = document.querySelector('#chat-context-body');
    const chatContextClose = document.querySelector('#chat-context-close');
    const enableThinkingCheckbox = document.querySelector('#enable-thinking');
    const enableSearchCheckbox = document.querySelector('#enable-search');
    const chatCharCount = document.querySelector('#chat-char-count');
    let chatMemoryBtn = document.querySelector('#chat-memory-btn');
    let chatMemoryBadge = document.querySelector('#chat-memory-badge');
    let chatMemoryDialog = document.querySelector('#chat-memory-dialog');
    let chatMemoryClose = document.querySelector('#chat-memory-close');
    let chatMemorySearch = document.querySelector('#chat-memory-search');
    let chatMemoryClearBtn = document.querySelector('#chat-memory-clear-btn');
    let chatMemoryAddForm = document.querySelector('#chat-memory-add-form');
    let chatMemoryInput = document.querySelector('#chat-memory-input');
    let chatMemoryList = document.querySelector('#chat-memory-list');
    let chatMemoryEmpty = document.querySelector('#chat-memory-empty');

    function resolveMemoryElements() {
        if (!chatMemoryBtn) chatMemoryBtn = document.querySelector('#chat-memory-btn');
        if (!chatMemoryBadge) chatMemoryBadge = document.querySelector('#chat-memory-badge');
        if (!chatMemoryDialog) chatMemoryDialog = document.querySelector('#chat-memory-dialog');
        if (!chatMemoryClose) chatMemoryClose = document.querySelector('#chat-memory-close');
        if (!chatMemorySearch) chatMemorySearch = document.querySelector('#chat-memory-search');
        if (!chatMemoryClearBtn) chatMemoryClearBtn = document.querySelector('#chat-memory-clear-btn');
        if (!chatMemoryAddForm) chatMemoryAddForm = document.querySelector('#chat-memory-add-form');
        if (!chatMemoryInput) chatMemoryInput = document.querySelector('#chat-memory-input');
        if (!chatMemoryList) chatMemoryList = document.querySelector('#chat-memory-list');
        if (!chatMemoryEmpty) chatMemoryEmpty = document.querySelector('#chat-memory-empty');
    }

    /*
     * Every chat surface shares this controller. Everything that
     * differs between them is resolved once, here, and nothing below this block
     * knows which studio it is running in.
     *
     * The two studios hold different keys and must not be able to read each
     * other: Plus derives one symmetric key from the passphrase you type, while
     * Lite uses an RSA keypair generated in the browser and kept in IndexedDB,
     * per user account. Lite's chat therefore seals to the account that is
     * signed in, and its images are sealed by the PC to that same public key.
     */
    const IS_LITE = document.body.dataset.studio === 'lite';

    function liteUserId() {
        try {
            return (localStorage.getItem('aistudio-current-user') || 'default').trim().toLowerCase();
        } catch (_) {
            return 'default';
        }
    }

    const STUDIO = IS_LITE
        ? { id: 'lite', endpoint: '/api/lite-chat', imageApp: 'lite' }
        : { id: 'plus', endpoint: '/api/chat', imageApp: 'studio' };

    let liteKeypair = null;
    const liteImageUrls = new Map();

    async function liteKeys() {
        if (!liteKeypair && window.StudioLiteCrypto) {
            liteKeypair = await window.StudioLiteCrypto.getOrCreateKeyPair(liteUserId());
        }
        return liteKeypair;
    }

    // Same shape as window.StudioCrypto, backed by the Lite per-user keypair.
    const LITE_CRYPTO = {
        isUnlocked: () => Boolean(window.StudioLiteCrypto),
        sealText: text => window.StudioLiteCrypto.sealForUser(text, liteUserId()),
        unsealText: base64 => window.StudioLiteCrypto.unsealForUser(base64, liteUserId()),
        sealBinary: async bytes => {
            if (window.StudioLiteCrypto?.sealBinaryForWorker) {
                return window.StudioLiteCrypto.sealBinaryForWorker(bytes);
            }
            const encoder = new TextEncoder();
            const digest = await crypto.subtle.digest("SHA-256", encoder.encode("studio-content-v1|studio-lite-v1-secret"));
            const key = await crypto.subtle.importKey("raw", new Uint8Array(digest), "AES-GCM", false, ["encrypt"]);
            const iv = crypto.getRandomValues(new Uint8Array(12));
            const body = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, bytes));
            const sealed = new Uint8Array(17 + body.length);
            sealed.set(encoder.encode("ASP1"), 0);
            sealed.set(iv, 5);
            sealed.set(body, 17);
            return sealed;
        },
        unsealBinary: bytes => window.StudioLiteCrypto.unsealPayload(bytes, liteUserId()),
        // In-chat images are Lite jobs sealed by the PC to this browser's key,
        // so they cannot be an <img src> until they are opened here.
        imageFor: job => {
            const id = job.id || job.job_id;
            if (!liteImageUrls.has(id)) {
                const pending = (async () => {
                    const res = await fetch(`/api/studio?action=image&app=lite&id=${encodeURIComponent(id)}`, { cache: 'no-store' });
                    if (!res.ok) throw new Error('Image not ready');
                    const bytes = await window.StudioLiteCrypto.unsealPayload(new Uint8Array(await res.arrayBuffer()), liteUserId());
                    return URL.createObjectURL(new Blob([bytes], { type: 'image/png' }));
                })();
                liteImageUrls.set(id, pending);
                // A just-finished image can take a moment to become readable.
                pending.catch(() => liteImageUrls.delete(id));
            }
            return liteImageUrls.get(id);
        }
    };

    const CRYPTO = IS_LITE ? LITE_CRYPTO : null;
    // Plus's StudioCrypto is installed by studio-remote.js after this file runs, so
    // it has to be looked up lazily rather than captured now.
    const crypt = () => CRYPTO || window.StudioCrypto;

    const DEFAULT_MODEL = 'qwen3-vl-4b-abliterated';

    function selectedModelOption() {
        if (!chatModelSelect) return null;
        return chatModelSelect.selectedOptions[0] || chatModelSelect.options[chatModelSelect.selectedIndex] || null;
    }

    function selectedModel() {
        return chatModelSelect?.value || DEFAULT_MODEL;
    }

    function modelOptionFor(key) {
        if (!chatModelSelect || !key) return null;
        return Array.from(chatModelSelect.options).find(option => option.value === key) || null;
    }

    // The <option> list is the single source of truth for model names, so the
    // message author label, the header badge and the composer placeholder
    // cannot drift apart as tiers are added.
    //
    // Returns null when the model is unknown (e.g. historical messages created
    // before the schema stored one). In that case, authorNameFor falls back
    // to 'Assistant' rather than misattributing older replies.
    function modelBadgeFor(key) {
        const option = modelOptionFor(key);
        if (!option) return null;
        return option.dataset.badge || option.textContent.split('·')[0].trim();
    }

    function authorNameFor(msg) {
        if (msg.role === 'user') return 'You';
        if (msg.role === 'checkpoint') return 'Context Briefing';
        return modelBadgeFor(msg.model) || 'Assistant';
    }

    // Image generation and saving new memories both go through the code-fence
    // tool contract, which the smallest tier cannot hold. Web search and reading
    // remembered facts are injected into the prompt instead, so those work on
    // every model and are deliberately not gated here.
    function modelSupportsTools() {
        const option = selectedModelOption();
        return option ? Boolean(option.dataset.tools) : true;
    }

    function modelSupportsVision() {
        const option = selectedModelOption();
        return option ? Boolean(option.dataset.vision) : true;
    }

    function modelSupportsThinking() {
        const option = selectedModelOption();
        return option ? Boolean(option.dataset.thinking) : true;
    }

    // Keeps the header badge, the thinking toggle and the attach button honest
    // about what the selected model can actually do. A greyed-out control with a
    // reason in its tooltip beats a request the PC silently drops.
    function applyModelCapabilities() {
        const option = selectedModelOption();
        const label = option ? option.textContent.split('·')[0].trim() : 'Qwen3-VL 4B Abliterated';
        if (chatModelBadge) {
            chatModelBadge.textContent = option?.dataset.badge || label;
            // Say what this tier cannot do, rather than letting the user find
            // out by asking for a picture and being told to switch models.
            chatModelBadge.title = modelSupportsTools()
                ? label + ' running on your PC'
                : label + ' running on your PC · cannot generate images or save memories. '
                  + 'Web search and remembered facts still work.';
        }
        // Prefer the curated badge: taking the first two words of the full label
        // turns "Llama 3.2 1B Abliterated" into "Llama 3.2", which reads as a
        // version number rather than a model.
        const shortLabel = option?.dataset.badge || label.split(' ').slice(0, 2).join(' ');
        if (chatInput) chatInput.placeholder = 'Message ' + shortLabel + '…';

        const thinking = modelSupportsThinking();
        if (enableThinkingCheckbox) {
            enableThinkingCheckbox.disabled = !thinking;
            const thinkingLabel = enableThinkingCheckbox.closest('label');
            if (thinkingLabel) {
                thinkingLabel.classList.toggle('is-unavailable', !thinking);
                thinkingLabel.title = thinking
                    ? 'Let the model reason before answering. Slower, usually better on hard questions.'
                    : label + ' has no thinking mode, so this does nothing on it.';
            }
        }

        const vision = modelSupportsVision();
        if (chatAttachBtn) {
            chatAttachBtn.disabled = false;
            chatAttachBtn.title = vision
                ? 'Attach documents or images (PDF, TXT, DOCX, XLSX, CSV, RTF, Code)'
                : 'Attach documents (PDF, TXT, DOCX, XLSX, CSV, RTF, Code) · ' + label + ' cannot see images';
        }

        // The composer's maxlength is markup, so it starts at the floor and has to
        // be raised here or a big paste is silently clipped to it by the browser
        // before any of this code sees it.
        if (chatInput) chatInput.maxLength = maxTypedChars();
        updateCharCount();

        // Window size and the per-image rate are both per-model, so the meter has
        // to be redrawn whenever the tier changes - the same conversation is a
        // different percentage of a different model's context.
        renderContextMeter();
    }

    // The floor for one typed message, not the cap. The cap is per-model and
    // comes from maxTypedChars(): pasting a long document straight into the
    // composer is a normal way to use this, and a 128K window can take four
    // times what a 32K one can. The composer's maxlength is re-applied whenever
    // the tier changes, so the DOM never holds a stale ceiling.
    const MIN_TYPED_CHARS = 50000;
    function maxTypedChars() {
        return Math.max(MIN_TYPED_CHARS, documentCharBudget());
    }
    // Display only — functions/api/chat.js enforces this and is the authority.
    const MAX_QUEUED = 10;
    // How much of the conversation the PC may see. It trims this down to what
    // actually fits the selected model's context window, so these are ceilings:
    // send generously and let the side holding the tokenizer decide.
    //
    // Raised from 60/48000 when the context meter went in, then bumped to 150K
    // when single-turn max chars expanded to 50K, and now scaled to the window
    // itself: one window's worth of characters, floored at the old 150K so the
    // 32K tiers behave exactly as before. Offering more than a window is
    // pointless - the worker trims to fit either way - but offering less than one
    // means a 128K model never sees the history it could have held. Text is cheap
    // against the API's 5 MB body limit; the attachment caps keep that honest.
    const HISTORY_DEPTH = 100;
    const MIN_HISTORY_CHARS = 150000;
    function historyCharBudget() {
        // Measured the same way attachments are, not at the meter's chars/3. At
        // chars/3 a 443K-character document is over a 128K window's ceiling, so
        // the turn carrying it would be dropped from history the moment a second
        // question was asked - discarding something the worker measured at 95K
        // tokens and could hold comfortably. Offer a full window's worth by the
        // honest ratio and let the side with the tokenizer do the trimming.
        return Math.max(MIN_HISTORY_CHARS, modelContextLimit() * DOC_CHARS_PER_TOKEN);
    }
    // Images inline as base64 data URLs, so one can run ~1 MB. Only recent turns
    // keep theirs; older ones travel as text alone.
    const HISTORY_IMAGE_DEPTH = 6;
    const HISTORY_IMAGE_LIMIT = 3;
    // Scoped to the studio for the same reason the sync channel is: the two share
    // an origin, so an unscoped key is one localStorage slot that both studios
    // write and both read.
    const SIDEBAR_KEY = `studio-chat-sidebar-collapsed-${STUDIO.id}`;
    const MODEL_KEY = `studio-chat-model-${STUDIO.id}`;
    const THINKING_KEY = `studio-chat-thinking-${STUDIO.id}`;
    const SEARCH_KEY = `studio-chat-search-${STUDIO.id}`;
    const THINKING_DURATIONS_KEY = `studio-chat-thinking-durations-${STUDIO.id}`;
    const JOB_TIMERS_KEY = `studio-chat-job-timers-${STUDIO.id}`;

    // In-memory cache for thinking durations (keyed by message ID)
    const thinkingDurations = new Map();
    // In-memory cache for active/recent job timers (keyed by job ID)
    const jobThinkingTimers = new Map();

    function loadThinkingDurations() {
        try {
            const raw = localStorage.getItem(THINKING_DURATIONS_KEY);
            if (!raw) return;
            const parsed = JSON.parse(raw);
            if (parsed && typeof parsed === 'object') {
                for (const [id, sec] of Object.entries(parsed)) {
                    if (typeof sec === 'number' && Number.isFinite(sec)) {
                        thinkingDurations.set(id, sec);
                    }
                }
            }
        } catch (_) {}
    }

    function saveThinkingDuration(msgId, seconds) {
        if (!msgId || !Number.isFinite(seconds) || seconds <= 0) return;
        thinkingDurations.set(msgId, seconds);
        try {
            const obj = {};
            const entries = [...thinkingDurations.entries()].slice(-500);
            for (const [k, v] of entries) obj[k] = Math.round(v * 10) / 10;
            localStorage.setItem(THINKING_DURATIONS_KEY, JSON.stringify(obj));
        } catch (_) {}
    }

    function getThinkingDuration(msgId) {
        if (!msgId) return null;
        if (thinkingDurations.has(msgId)) return thinkingDurations.get(msgId);
        return null;
    }

    function loadJobThinkingTimers() {
        try {
            const raw = localStorage.getItem(JOB_TIMERS_KEY);
            if (!raw) return;
            const parsed = JSON.parse(raw);
            if (parsed && typeof parsed === 'object') {
                for (const [id, val] of Object.entries(parsed)) {
                    if (val && typeof val === 'object') {
                        jobThinkingTimers.set(id, {
                            startedAt: typeof val.startedAt === 'number' ? val.startedAt : null,
                            duration: typeof val.duration === 'number' ? val.duration : null
                        });
                    }
                }
            }
        } catch (_) {}
    }

    function persistJobThinkingTimers() {
        try {
            const obj = {};
            const entries = [...jobThinkingTimers.entries()].slice(-300);
            for (const [k, v] of entries) {
                obj[k] = { startedAt: v.startedAt, duration: v.duration };
            }
            localStorage.setItem(JOB_TIMERS_KEY, JSON.stringify(obj));
        } catch (_) {}
    }

    function saveJobThinkingDuration(jobId, seconds) {
        if (!jobId || !Number.isFinite(seconds) || seconds <= 0) return;
        const entry = jobThinkingTimers.get(jobId) || { startedAt: null, duration: null };
        entry.duration = Math.round(seconds * 10) / 10;
        jobThinkingTimers.set(jobId, entry);
        persistJobThinkingTimers();
    }

    function getJobThinkingDuration(jobId) {
        if (!jobId) return null;
        return jobThinkingTimers.get(jobId)?.duration ?? null;
    }

    function getJobThinkingTimer(jobId) {
        if (!jobId) return null;
        return jobThinkingTimers.get(jobId) || null;
    }

    loadThinkingDurations();
    loadJobThinkingTimers();

    function formatThinkingDuration(seconds) {
        if (!Number.isFinite(seconds) || seconds < 0) return '0.0s';
        if (seconds >= 60) {
            const mins = Math.floor(seconds / 60);
            const rem = (seconds % 60).toFixed(1);
            return `${mins}m ${rem}s`;
        }
        return `${seconds.toFixed(1)}s`;
    }

    function updateThinkingSummary(msg) {
        if (!msg || !msg.thinkingEl) return;
        const isLive = msg.thinkingEl.classList.contains('is-live');
        const duration = msg.thinkingDuration ?? (msg.jobId ? getJobThinkingDuration(msg.jobId) : null) ?? getThinkingDuration(msg.id);

        if (isLive) {
            if (msg.thinkingLabelEl) msg.thinkingLabelEl.textContent = 'Thinking process';
            if (msg.thinkingTimerEl) {
                let currentSec = 0;
                if (msg.thinkingStartedAt) {
                    const elapsedMs = (msg.thinkingStartedAt > 1e11)
                        ? (Date.now() - msg.thinkingStartedAt)
                        : (performance.now() - msg.thinkingStartedAt);
                    currentSec = Math.max(0, elapsedMs / 1000);
                }
                msg.thinkingTimerEl.textContent = `(${formatThinkingDuration(currentSec)})`;
                msg.thinkingTimerEl.hidden = false;
            }
        } else if (duration != null && duration > 0) {
            if (msg.thinkingLabelEl) msg.thinkingLabelEl.textContent = 'Thought for';
            if (msg.thinkingTimerEl) {
                msg.thinkingTimerEl.textContent = formatThinkingDuration(duration);
                msg.thinkingTimerEl.hidden = false;
            }
        } else {
            if (msg.thinkingLabelEl) msg.thinkingLabelEl.textContent = 'Thinking process';
            if (msg.thinkingTimerEl) {
                msg.thinkingTimerEl.textContent = '';
                msg.thinkingTimerEl.hidden = true;
            }
        }
    }

    function startThinkingTimer(msg) {
        if (!msg || !msg.thinkingEl) return;
        if (!msg.thinkingStartedAt) {
            msg.thinkingStartedAt = Date.now();
        }
        if (msg.jobId && !jobThinkingTimers.has(msg.jobId)) {
            jobThinkingTimers.set(msg.jobId, { startedAt: msg.thinkingStartedAt, duration: null });
            persistJobThinkingTimers();
        }
        if (msg.thinkingTimerInterval) return;

        updateThinkingSummary(msg);
        msg.thinkingTimerInterval = setInterval(() => {
            if (!msg.thinkingEl || !msg.thinkingEl.classList.contains('is-live')) {
                stopThinkingTimer(msg);
                return;
            }
            updateThinkingSummary(msg);
        }, 50);
    }

    function stopThinkingTimer(msg) {
        if (!msg) return;
        if (msg.thinkingTimerInterval) {
            clearInterval(msg.thinkingTimerInterval);
            msg.thinkingTimerInterval = null;
        }
        if (msg.thinkingStartedAt && (msg.thinkingDuration == null || msg.thinkingEl?.classList.contains('is-live'))) {
            const elapsedMs = (msg.thinkingStartedAt > 1e11)
                ? (Date.now() - msg.thinkingStartedAt)
                : (performance.now() - msg.thinkingStartedAt);
            const elapsed = Math.max(0.1, elapsedMs / 1000);
            msg.thinkingDuration = Math.round(elapsed * 10) / 10;
            if (msg.id) {
                saveThinkingDuration(msg.id, msg.thinkingDuration);
            }
            if (msg.jobId) {
                saveJobThinkingDuration(msg.jobId, msg.thinkingDuration);
            }
        }
        if (msg.thinkingEl) {
            msg.thinkingEl.classList.remove('is-live');
        }
        updateThinkingSummary(msg);
    }

    // --------------------------------------------------------------- Icons ---
    const icon = (paths, extra = '') =>
        `<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false" ${extra}>${paths}</svg>`;
    const ICONS = {
        copy: icon('<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/>'),
        check: icon('<path d="m4 12 5 5L20 6"/>'),
        edit: icon('<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/>'),
        regenerate: icon('<path d="M21 12a9 9 0 1 1-2.6-6.4"/><path d="M21 3v6h-6"/>'),
        trash: icon('<path d="M4 7h16"/><path d="M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/><path d="M6 7l1 13a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1l1-13"/><path d="M10 11v6M14 11v6"/>'),
        stop: icon('<rect x="6" y="6" width="12" height="12" rx="2"/>'),
        dots: icon('<circle cx="12" cy="5" r="1.7"/><circle cx="12" cy="12" r="1.7"/><circle cx="12" cy="19" r="1.7"/>', 'style="fill:currentColor;stroke:none"')
    };

    // ----------------------------------------------------------- Utilities ---
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text == null ? '' : String(text);
        return div.innerHTML;
    }

    function formatTime(timestamp) {
        if (!timestamp) return '';
        const date = new Date(timestamp * 1000);
        const now = new Date();
        const sameDay = date.toDateString() === now.toDateString();
        if (sameDay) return date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
        const yesterday = new Date(now);
        yesterday.setDate(now.getDate() - 1);
        if (date.toDateString() === yesterday.toDateString()) return 'Yesterday';
        if (date.getFullYear() === now.getFullYear()) return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
        return date.toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' });
    }

    function fullTime(timestamp) {
        if (!timestamp) return '';
        return new Date(timestamp * 1000).toLocaleString();
    }

    function dayBucket(timestamp) {
        const date = new Date((timestamp || 0) * 1000);
        const midnight = new Date();
        midnight.setHours(0, 0, 0, 0);
        const days = Math.floor((midnight - date) / 86400000);
        if (days < 0) return 'Today';
        if (days < 1) return 'Today';
        if (days < 2) return 'Yesterday';
        if (days < 7) return 'Previous 7 days';
        if (days < 30) return 'Previous 30 days';
        return 'Older';
    }

    // navigator.clipboard needs a secure context; the textarea fallback keeps
    // copy working over plain http on the LAN.
    async function copyText(text) {
        if (!text) return false;
        try {
            if (navigator.clipboard && window.isSecureContext) {
                await navigator.clipboard.writeText(text);
                return true;
            }
        } catch (_) { /* fall through */ }
        try {
            const scratch = document.createElement('textarea');
            scratch.value = text;
            scratch.setAttribute('readonly', '');
            scratch.style.cssText = 'position:fixed;top:-1000px;opacity:0';
            document.body.appendChild(scratch);
            scratch.select();
            const ok = document.execCommand('copy');
            scratch.remove();
            return ok;
        } catch (_) {
            return false;
        }
    }

    let toastRegion = null;
    function toast(message, kind = 'info') {
        if (!toastRegion) {
            toastRegion = document.createElement('div');
            toastRegion.className = 'chat-toast-region';
            toastRegion.setAttribute('role', 'status');
            toastRegion.setAttribute('aria-live', 'polite');
            document.body.appendChild(toastRegion);
        }
        const el = document.createElement('div');
        el.className = `chat-toast${kind === 'error' ? ' is-error' : ''}`;
        el.textContent = message;
        toastRegion.appendChild(el);
        setTimeout(() => {
            el.classList.add('is-leaving');
            setTimeout(() => el.remove(), 200);
        }, kind === 'error' ? 4200 : 2000);
    }

    function confirmDialog({ title, message, confirmLabel = 'Delete', danger = true }) {
        return new Promise(resolve => {
            if (typeof HTMLDialogElement === 'undefined' || !HTMLDialogElement.prototype.showModal) {
                resolve(window.confirm(`${title}\n\n${message}`));
                return;
            }
            const dialog = document.createElement('dialog');
            dialog.className = 'chat-confirm';
            dialog.innerHTML = `
                <h3></h3>
                <p></p>
                <div class="chat-confirm-actions">
                    <button type="button" data-act="cancel">Cancel</button>
                    <button type="button" data-act="confirm" class="${danger ? 'danger' : 'primary'}"></button>
                </div>`;
            dialog.querySelector('h3').textContent = title;
            dialog.querySelector('p').textContent = message;
            dialog.querySelector('[data-act="confirm"]').textContent = confirmLabel;
            document.body.appendChild(dialog);

            const close = (value) => {
                resolve(value);
                dialog.close();
                dialog.remove();
            };
            dialog.querySelector('[data-act="cancel"]').addEventListener('click', () => close(false));
            dialog.querySelector('[data-act="confirm"]').addEventListener('click', () => close(true));
            dialog.addEventListener('cancel', event => { event.preventDefault(); close(false); });
            dialog.showModal();
            dialog.querySelector('[data-act="confirm"]').focus();
        });
    }

    function flashButton(button, label = 'Copied') {
        if (!button) return;
        const original = button.innerHTML;
        const wasLabel = button.getAttribute('aria-label');
        button.classList.add('is-done');
        button.innerHTML = button.classList.contains('code-copy-btn')
            ? `${ICONS.check}<span>${escapeHtml(label)}</span>`
            : ICONS.check;
        setTimeout(() => {
            button.classList.remove('is-done');
            button.innerHTML = original;
            if (wasLabel) button.setAttribute('aria-label', wasLabel);
        }, 1400);
    }

    function downloadImageFile(url, filename = 'studio-image.png') {
        if (!url) return;
        const link = document.createElement('a');
        link.style.display = 'none';
        link.href = url;
        link.download = filename || 'studio-image.png';
        document.body.appendChild(link);
        link.click();
        setTimeout(() => link.remove(), 200);
    }

    let chatLightbox = null;

    function ensureChatLightbox() {
        if (chatLightbox && document.body.contains(chatLightbox.dialog)) {
            return chatLightbox;
        }
        const dialog = document.createElement('dialog');
        dialog.className = 'chat-lightbox-dialog';
        dialog.id = 'chat-lightbox-dialog';
        dialog.setAttribute('aria-label', 'Image preview');
        dialog.innerHTML = `
            <div class="chat-lightbox-header">
                <span class="chat-lightbox-title">Image Preview</span>
                <div class="chat-lightbox-actions">
                    <button type="button" class="chat-lightbox-btn chat-lightbox-download" title="Download image">⬇️ Download</button>
                    <button type="button" class="chat-lightbox-btn chat-lightbox-close" aria-label="Close preview" title="Close preview">✕</button>
                </div>
            </div>
            <div class="chat-lightbox-body">
                <img class="chat-lightbox-img" src="" alt="Full image preview">
            </div>
        `;
        document.body.appendChild(dialog);

        const img = dialog.querySelector('.chat-lightbox-img');
        const titleEl = dialog.querySelector('.chat-lightbox-title');
        const downloadBtn = dialog.querySelector('.chat-lightbox-download');
        const closeBtn = dialog.querySelector('.chat-lightbox-close');

        const close = () => {
            if (dialog.open) {
                if (typeof dialog.close === 'function') dialog.close();
                else dialog.removeAttribute('open');
            }
            img.src = '';
        };

        closeBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            close();
        });

        dialog.addEventListener('cancel', (e) => {
            e.preventDefault();
            close();
        });

        dialog.addEventListener('click', (e) => {
            if (e.target === dialog || e.target.classList.contains('chat-lightbox-body')) {
                close();
            }
        });

        chatLightbox = { dialog, img, titleEl, downloadBtn, close };
        return chatLightbox;
    }

    function openImagePreview(src, options = {}) {
        if (!src) return;
        const lb = ensureChatLightbox();
        const prompt = typeof options === 'string' ? options : (options.prompt || '');
        const jobId = typeof options === 'object' && options.jobId ? options.jobId : 'image';
        const filename = `studio-${jobId}.png`;

        lb.img.src = src;
        lb.img.alt = prompt || 'Generated image preview';
        lb.titleEl.textContent = prompt ? (prompt.slice(0, 80) + (prompt.length > 80 ? '…' : '')) : 'Image Preview';
        lb.titleEl.title = prompt || 'Image Preview';

        lb.downloadBtn.onclick = (e) => {
            e.preventDefault();
            e.stopPropagation();
            downloadImageFile(src, filename);
        };

        if (typeof lb.dialog.showModal === 'function') {
            if (!lb.dialog.open) lb.dialog.showModal();
        } else {
            lb.dialog.setAttribute('open', '');
        }
    }

    // ------------------------------------------------------------ Markdown ---
    if (window.marked && typeof window.marked.setOptions === 'function') {
        window.marked.setOptions({ breaks: true, gfm: true });
    }

    function renderMarkdown(md) {
        if (!md) return '';
        try {
            if (window.marked) {
                const rawHtml = window.marked.parse(md);
                return window.DOMPurify ? window.DOMPurify.sanitize(rawHtml) : rawHtml;
            }
        } catch (err) {
            console.warn('Markdown parsing error:', err);
        }
        return escapeHtml(md).replace(/\n/g, '<br>');
    }

    function parseImageGenBlock(text) {
        let ratio = '1:1';
        const ratioMatch = text.match(/ratio\s*:\s*([^\n\r]+)/i);
        if (ratioMatch) ratio = ratioMatch[1].trim();

        let jobId = null;
        const jobMatch = text.match(/job_id\s*:\s*([^\n\r]+)/i);
        if (jobMatch) jobId = jobMatch[1].trim();

        let status = null;
        const statusMatch = text.match(/status\s*:\s*([^\n\r]+)/i);
        if (statusMatch) status = statusMatch[1].trim().toLowerCase();

        let mode = 'txt2img';
        let explicitMode = null;
        const modeMatch = text.match(/mode\s*:\s*([^\n\r]+)/i);
        if (modeMatch) {
            const m = modeMatch[1].trim().toLowerCase();
            if (m === 'img2img' || m === 'inpaint' || m === 'txt2img') {
                mode = m;
                explicitMode = m;
            }
        }

        let denoise = mode === 'inpaint' ? 0.75 : 0.65;
        const denoiseMatch = text.match(/denoise\s*:\s*([^\n\r]+)/i);
        if (denoiseMatch) {
            const dVal = parseFloat(denoiseMatch[1].trim());
            if (Number.isFinite(dVal) && dVal >= 0.05 && dVal <= 1.0) denoise = dVal;
        }

        let growMask = 6;
        const growMatch = text.match(/grow_mask\s*:\s*([^\n\r]+)/i);
        if (growMatch) {
            const gVal = parseInt(growMatch[1].trim(), 10);
            if (Number.isInteger(gVal) && gVal >= 0 && gVal <= 64) growMask = gVal;
        }

        let inputImageKey = null;
        const inputKeyMatch = text.match(/input_image_key\s*:\s*([^\n\r]+)/i);
        if (inputKeyMatch) inputImageKey = inputKeyMatch[1].trim();

        let maskImageKey = null;
        const maskKeyMatch = text.match(/mask_image_key\s*:\s*([^\n\r]+)/i);
        if (maskKeyMatch) maskImageKey = maskKeyMatch[1].trim();

        let prompt = '';
        const promptMatch = text.match(/prompt\s*:\s*([\s\S]+?)(?=(?:\n\s*(?:ratio|job_id|status|mode|denoise|grow_mask|input_image_key|mask_image_key)\s*:|$))/i);
        if (promptMatch) {
            prompt = promptMatch[1].trim();
        } else {
            prompt = text
                .replace(/job_id\s*:\s*[^\n\r]+/gi, '')
                .replace(/status\s*:\s*[^\n\r]+/gi, '')
                .replace(/ratio\s*:\s*[^\n\r]+/gi, '')
                .replace(/mode\s*:\s*[^\n\r]+/gi, '')
                .replace(/denoise\s*:\s*[^\n\r]+/gi, '')
                .replace(/grow_mask\s*:\s*[^\n\r]+/gi, '')
                .replace(/input_image_key\s*:\s*[^\n\r]+/gi, '')
                .replace(/mask_image_key\s*:\s*[^\n\r]+/gi, '')
                .replace(/^```\w*|```$/g, '')
                .trim();
        }

        const validRatios = ['1:1', '16:9', '9:16', '4:3', '3:4', '21:9', '9:21'];
        if (!validRatios.includes(ratio)) ratio = '1:1';
        return { prompt, ratio, jobId, mode, explicitMode, denoise, growMask, inputImageKey, maskImageKey, status };
    }

    function normalizeRatio(val) {
        if (!val) return 'square';
        const s = String(val).toLowerCase().trim();
        if (s === 'wide' || s === '16:9' || s === '16/9' || s === '16x9' || s === '21:9') return 'wide';
        if (s === 'landscape' || s === '4:3' || s === '4/3' || s === '4x3') return 'landscape';
        if (s === 'portrait' || s === '3:4' || s === '3/4' || s === '3x4' || s === '9:16' || s === '9/16') return 'portrait';
        return 'square';
    }

    function extractJobIdsFromText(text) {
        if (!text || typeof text !== 'string') return [];
        const matches = text.matchAll(/job_id:\s*([a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12})/gi);
        const ids = [];
        for (const m of matches) {
            if (m[1]) ids.push(m[1].toLowerCase());
        }
        return ids;
    }

    // ------------------------------------------------ Inpaint Pop-Up Canvas ---
    const pendingInpaintAssets = new Map();
    const imageMaskMap = new Map();

    // The one place the mask's paint colour is written down.
    const MASK_PAINT = 'rgba(235, 75, 75, 0.7)';

    const inpaintModal = {
        dialog: null,
        stage: null,
        viewport: null,
        baseCanvas: null,
        maskCanvas: null,
        brushCursor: null,
        promptInput: null,
        saveBtn: null,
        submitBtn: null,
        infoSpan: null,
        closeBtn: null,
        toolBrush: null,
        toolEraser: null,
        brushSizeInput: null,
        brushSizeDisplay: null,
        toolZoomOut: null,
        toolZoomReset: null,
        toolZoomIn: null,
        toolZoomFit: null,
        toolUndo: null,
        toolRedo: null,
        toolInvert: null,
        toolClear: null,

        currentImage: null,
        currentSrc: null,
        currentOptions: null,
        activeTool: 'brush',
        // A fingertip is blunter than a cursor, so touch starts with a brush
        // that is visible at fit-to-screen zoom.
        brushSize: window.matchMedia && window.matchMedia('(pointer: coarse)').matches ? 90 : 40,
        isCoarsePointer: Boolean(window.matchMedia && window.matchMedia('(pointer: coarse)').matches),
        gestures: null,
        maskHistory: [],
        maskFuture: [],
        lastStrokePoint: null,
        // Where the last stroke ended, so Shift+click can run a straight edge
        // on from it the way a Photoshop brush does.
        lastStrokeEnd: null,
        isDrawing: false,
        zoom: 1.0,
        panX: 0,
        panY: 0,
        isSpacePressed: false,
        isPanning: false,
        isOpen: false,

        init() {
            this.dialog = document.querySelector('#chat-inpaint-dialog');
            if (!this.dialog) return;

            this.stage = document.querySelector('#chat-inpaint-stage');
            this.viewport = document.querySelector('#chat-inpaint-viewport');
            this.baseCanvas = document.querySelector('#chat-inpaint-base-canvas');
            this.maskCanvas = document.querySelector('#chat-inpaint-mask-canvas');
            this.brushCursor = document.querySelector('#chat-inpaint-brush-cursor');
            this.promptInput = document.querySelector('#chat-inpaint-prompt');
            this.saveBtn = document.querySelector('#chat-inpaint-save');
            this.submitBtn = document.querySelector('#chat-inpaint-submit');
            this.infoSpan = document.querySelector('#chat-inpaint-info');
            this.closeBtn = document.querySelector('#chat-inpaint-close');

            this.toolBrush = document.querySelector('#chat-tool-brush');
            this.toolEraser = document.querySelector('#chat-tool-eraser');
            this.brushSizeInput = document.querySelector('#chat-brush-size');
            this.brushSizeDisplay = document.querySelector('#chat-brush-size-display');
            this.toolZoomOut = document.querySelector('#chat-tool-zoom-out');
            this.toolZoomReset = document.querySelector('#chat-tool-zoom-reset');
            this.toolZoomIn = document.querySelector('#chat-tool-zoom-in');
            this.toolZoomFit = document.querySelector('#chat-tool-zoom-fit');
            this.toolUndo = document.querySelector('#chat-tool-undo');
            this.toolRedo = document.querySelector('#chat-tool-redo');
            this.toolInvert = document.querySelector('#chat-tool-invert');
            this.toolClear = document.querySelector('#chat-tool-clear');

            this.bindEvents();
        },

        bindEvents() {
            this.closeBtn?.addEventListener('click', () => this.close());
            this.dialog?.addEventListener('cancel', (e) => {
                e.preventDefault();
                this.close();
            });

            this.toolBrush?.addEventListener('click', () => {
                this.activeTool = 'brush';
                this.toolBrush.classList.add('active');
                this.toolEraser?.classList.remove('active');
                if (this.brushCursor) this.brushCursor.classList.remove('is-eraser');
            });

            this.toolEraser?.addEventListener('click', () => {
                this.activeTool = 'eraser';
                this.toolEraser.classList.add('active');
                this.toolBrush?.classList.remove('active');
                if (this.brushCursor) this.brushCursor.classList.add('is-eraser');
            });

            this.brushSizeInput?.addEventListener('input', () => {
                this.setBrushSize(parseInt(this.brushSizeInput.value, 10));
            });

            this.setBrushSize(this.brushSize);

            this.toolUndo?.addEventListener('click', () => this.undo());
            this.toolRedo?.addEventListener('click', () => this.redo());
            this.toolInvert?.addEventListener('click', () => this.invert());
            this.toolClear?.addEventListener('click', () => this.clear());

            this.toolZoomFit?.addEventListener('click', () => this.fitToStage());
            this.toolZoomReset?.addEventListener('click', () => {
                if (Math.abs(this.zoom - 1.0) < 0.05) this.fitToStage();
                else this.centerAtZoom(1.0);
            });
            this.toolZoomIn?.addEventListener('click', () => this.zoomAtStageCenter(1.25));
            this.toolZoomOut?.addEventListener('click', () => this.zoomAtStageCenter(0.8));

            this.dialog?.querySelector('#chat-inpaint-toolbar')?.addEventListener('click', e => {
                const btn = e.target.closest('button');
                if (btn && btn.id !== 'chat-tool-more-btn') {
                    btn.blur();
                    this.stage?.focus({ preventScroll: true });
                }
            });

            // Touch, pen and mouse input all run through the shared gesture
            // layer, which brings pinch-to-zoom and two-finger pan with it.
            this.gestures = window.InpaintUI?.attachGestures({
                stage: this.stage,
                isReady: () => this.isOpen && Boolean(this.currentImage),
                getMaskRect: () => this.maskCanvas?.getBoundingClientRect(),
                getContentSize: () => ({
                    width: this.maskCanvas?.width || 0,
                    height: this.maskCanvas?.height || 0
                }),
                getZoom: () => this.zoom,
                setZoom: value => { this.zoom = value; },
                getPan: () => ({ x: this.panX, y: this.panY }),
                setPan: (x, y) => { this.panX = x; this.panY = y; },
                applyTransform: () => this.applyTransform(),
                isPanModifier: () => this.isSpacePressed,
                getBrushSize: () => this.brushSize,
                setBrushSize: value => this.setBrushSize(value),
                onStageFocus: () => this.stage?.focus({ preventScroll: true }),
                onStrokeStart: e => {
                    this.isDrawing = true;
                    this.saveHistory();
                    const coords = this.getCanvasCoords(e);
                    // Shift+click runs a straight edge on from wherever the
                    // last stroke stopped, the Photoshop way of masking a hard
                    // line without a steady hand.
                    if (e.shiftKey && this.lastStrokeEnd) {
                        this.lastStrokePoint = this.lastStrokeEnd;
                        this.drawPoint(coords.x, coords.y, false);
                    } else {
                        this.lastStrokePoint = null;
                        this.drawPoint(coords.x, coords.y, true);
                    }
                },
                onStrokeMove: e => {
                    const coords = this.getCanvasCoords(e);
                    this.drawPoint(coords.x, coords.y, false);
                },
                onStrokeEnd: () => {
                    this.isDrawing = false;
                    this.lastStrokeEnd = this.lastStrokePoint;
                    this.lastStrokePoint = null;
                },
                onStrokeCancel: () => {
                    this.isDrawing = false;
                    this.lastStrokePoint = null;
                    this.restoreHistory();
                },
                onPanStateChange: active => {
                    this.isPanning = active;
                    this.stage?.classList.toggle('is-dragging-pan', active);
                    this.updateCursorPosition(null);
                },
                onCursor: e => this.updateCursorPosition(e)
            });

            window.InpaintUI?.attachToolbarMenu(
                document.querySelector('#chat-tool-more-btn'),
                document.querySelector('#chat-tool-more-panel')
            );

            this.stage?.addEventListener('pointerenter', () => {
                if (document.activeElement && !['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName)) {
                    this.stage?.focus({ preventScroll: true });
                }
            });

            this.stage?.addEventListener('wheel', e => {
                if (!this.isOpen || !this.currentImage) return;

                // Alt + Scroll: Zoom in/out at pointer
                if (e.altKey) {
                    e.preventDefault();
                    e.stopPropagation();
                    const factor = e.deltaY < 0 ? 1.15 : (1 / 1.15);
                    this.gestures?.zoomAt(e.clientX, e.clientY, factor);
                    this.updateCursorSize();
                    this.updateCursorPosition(e);
                    return;
                }

                // Ctrl + Scroll: Resize brush
                if (e.ctrlKey || e.metaKey) {
                    e.preventDefault();
                    e.stopPropagation();
                    const step = e.deltaY < 0 ? 5 : -5;
                    this.setBrushSize(this.brushSize + step);
                    this.updateCursorPosition(e);
                    return;
                }

                e.preventDefault();
                this.gestures?.setPan(this.panX - e.deltaX, this.panY - e.deltaY);
                this.updateCursorPosition(e);
            }, { passive: false });

            // Escape and Enter belong to the dialog rather than the canvas,
            // so they stay here and fire even while the prompt has focus.
            window.addEventListener('keydown', e => {
                if (!this.isOpen) return;
                if (e.key === 'Escape') {
                    e.preventDefault();
                    this.close();
                    return;
                }
                if (e.key === 'Enter' && e.target === this.promptInput) {
                    e.preventDefault();
                    this.submit();
                }
            }, true);

            // Photoshop-style keyboard map, shared with both studio pages so
            // the dialog answers to exactly the same keys the full editor does.
            window.InpaintUI?.attachShortcuts({
                isActive: () => this.isOpen && Boolean(this.currentImage),
                onSpaceChange: down => {
                    this.isSpacePressed = down;
                    if (this.stage) this.stage.style.cursor = down ? 'grab' : '';
                    if (!down) this.updateCursorPosition(null);
                },
                brush: () => this.toolBrush?.click(),
                eraser: () => this.toolEraser?.click(),
                toggleTool: () => (this.activeTool === 'brush' ? this.toolEraser : this.toolBrush)?.click(),
                adjustBrush: delta => this.setBrushSize(this.brushSize + delta),
                undo: () => this.undo(),
                redo: () => this.redo(),
                invert: () => this.invert(),
                clear: () => this.clear(),
                fit: () => this.fitToStage(),
                zoom100: () => this.centerAtZoom(1.0),
                zoomBy: factor => this.zoomAtStageCenter(factor),
                onWindowBlur: () => {
                    if (!this.isOpen) return;
                    this.isPanning = false;
                    this.gestures?.reset();
                    this.stage?.classList.remove('is-dragging-pan');
                    if (this.stage) this.stage.style.cursor = '';
                    this.updateCursorPosition(null);
                }
            });

            this.saveBtn?.addEventListener('click', () => this.saveMaskAndClose());
            this.submitBtn?.addEventListener('click', () => this.submit());
        },

        getCanvasCoords(event) {
            if (!this.maskCanvas) return { x: 0, y: 0 };
            const rect = this.maskCanvas.getBoundingClientRect();
            const scaleX = this.maskCanvas.width / rect.width;
            const scaleY = this.maskCanvas.height / rect.height;
            return {
                x: (event.clientX - rect.left) * scaleX,
                y: (event.clientY - rect.top) * scaleY
            };
        },

        snapshotMask() {
            if (!this.maskCanvas) return null;
            return this.maskCanvas.getContext('2d').getImageData(0, 0, this.maskCanvas.width, this.maskCanvas.height);
        },

        saveHistory() {
            if (!this.maskCanvas) return;
            this.maskHistory.push(this.snapshotMask());
            if (this.maskHistory.length > 20) this.maskHistory.shift();
            // Painting again abandons the branch redo would have walked back
            // into, exactly as Photoshop's history does.
            this.maskFuture = [];
            this.updateUndoState();
        },

        updateUndoState() {
            if (this.toolUndo) this.toolUndo.disabled = this.maskHistory.length === 0;
            if (this.toolRedo) this.toolRedo.disabled = this.maskFuture.length === 0;
        },

        // Every entry is the mask as it looked *before* a stroke, so undo pops
        // the top entry and restores it. The old code compared against length 1,
        // which left the first stroke permanently un-undoable and made the
        // second undo wipe both strokes at once.
        restoreHistory() {
            if (!this.maskCanvas || !this.maskHistory.length) return;
            const previous = this.maskHistory.pop();
            this.maskCanvas.getContext('2d').putImageData(previous, 0, 0);
            this.updateUndoState();
        },

        undo() {
            if (!this.maskCanvas || !this.maskHistory.length) return;
            this.maskFuture.push(this.snapshotMask());
            this.maskCanvas.getContext('2d').putImageData(this.maskHistory.pop(), 0, 0);
            this.lastStrokeEnd = null;
            this.updateUndoState();
        },

        redo() {
            if (!this.maskCanvas || !this.maskFuture.length) return;
            this.maskHistory.push(this.snapshotMask());
            this.maskCanvas.getContext('2d').putImageData(this.maskFuture.pop(), 0, 0);
            this.lastStrokeEnd = null;
            this.updateUndoState();
        },

        invert() {
            if (!this.maskCanvas) return;
            this.saveHistory();
            const ctx = this.maskCanvas.getContext('2d');
            const imgData = ctx.getImageData(0, 0, this.maskCanvas.width, this.maskCanvas.height);
            const data = imgData.data;
            for (let i = 0; i < data.length; i += 4) {
                if (data[i + 3] > 0) {
                    data[i + 3] = 0;
                } else {
                    data[i] = 235;
                    data[i + 1] = 75;
                    data[i + 2] = 75;
                    data[i + 3] = 178;
                }
            }
            ctx.putImageData(imgData, 0, 0);
        },

        clear() {
            if (!this.maskCanvas) return;
            this.saveHistory();
            const ctx = this.maskCanvas.getContext('2d');
            ctx.clearRect(0, 0, this.maskCanvas.width, this.maskCanvas.height);
        },

        // Each move draws one discrete segment. The old code kept extending a
        // single path and re-stroking all of it on every move, which cost
        // O(n^2) per stroke and darkened the semi-transparent mask unevenly.
        drawPoint(x, y, isStart = false) {
            if (!this.maskCanvas) return;
            const ctx = this.maskCanvas.getContext('2d');
            ctx.save();
            ctx.lineWidth = this.brushSize;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';

            if (this.activeTool === 'brush') {
                ctx.globalCompositeOperation = 'source-over';
                ctx.strokeStyle = MASK_PAINT;
                ctx.fillStyle = MASK_PAINT;
            } else {
                ctx.globalCompositeOperation = 'destination-out';
                ctx.strokeStyle = 'rgba(0, 0, 0, 1)';
                ctx.fillStyle = 'rgba(0, 0, 0, 1)';
            }

            if (isStart || !this.lastStrokePoint) {
                ctx.beginPath();
                ctx.arc(x, y, this.brushSize / 2, 0, Math.PI * 2);
                ctx.fill();
            } else {
                ctx.beginPath();
                ctx.moveTo(this.lastStrokePoint.x, this.lastStrokePoint.y);
                ctx.lineTo(x, y);
                ctx.stroke();
            }
            ctx.restore();
            this.lastStrokePoint = { x, y };
        },

        applyTransform() {
            if (!this.viewport) return;
            this.viewport.style.transform = `translate(${this.panX}px, ${this.panY}px) scale(${this.zoom})`;
            if (this.toolZoomReset) this.toolZoomReset.textContent = `${Math.round(this.zoom * 100)}%`;
        },

        centerAtZoom(zoom) {
            if (!this.stage || !this.maskCanvas) return;
            this.zoom = zoom;
            this.panX = (this.stage.clientWidth - this.maskCanvas.width * zoom) / 2;
            this.panY = (this.stage.clientHeight - this.maskCanvas.height * zoom) / 2;
            this.applyTransform();
            this.updateCursorSize();
        },

        fitToStage() {
            if (!this.stage || !this.currentImage || !this.maskCanvas) return;
            const stageW = this.stage.clientWidth;
            const stageH = this.stage.clientHeight;
            const imgW = this.maskCanvas.width;
            const imgH = this.maskCanvas.height;
            if (stageW <= 0 || stageH <= 0 || imgW <= 0 || imgH <= 0) return;

            const pad = this.isCoarsePointer ? 16 : 36;
            const availW = Math.max(80, stageW - pad);
            const availH = Math.max(80, stageH - pad);
            this.centerAtZoom(Math.max(0.05, Math.min(availW / imgW, availH / imgH, 1.0)));
        },

        zoomAtStageCenter(factor) {
            if (!this.stage) return;
            const rect = this.stage.getBoundingClientRect();
            this.gestures?.zoomAt(rect.left + rect.width / 2, rect.top + rect.height / 2, factor);
            this.updateCursorSize();
        },

        setBrushSize(newSize) {
            const min = parseInt(this.brushSizeInput?.min || '5', 10);
            const max = parseInt(this.brushSizeInput?.max || '200', 10);
            this.brushSize = Math.max(min, Math.min(max, Math.round(newSize)));
            if (this.brushSizeInput) this.brushSizeInput.value = this.brushSize;
            if (this.brushSizeDisplay) this.brushSizeDisplay.textContent = this.brushSize;
            this.updateCursorSize();
        },

        updateCursorSize() {
            if (!this.brushCursor) return;
            const size = Math.max(4, Math.round(this.brushSize * this.zoom));
            this.brushCursor.style.width = `${size}px`;
            this.brushCursor.style.height = `${size}px`;
        },

        // Pass null to hide. A fingertip already covers what it paints, so the
        // ring is a pointer affordance only.
        updateCursorPosition(e) {
            if (!this.brushCursor || !this.stage) return;
            if (!e || !this.isOpen || this.isPanning || this.isSpacePressed || this.isCoarsePointer) {
                this.brushCursor.style.display = 'none';
                this.viewport?.classList.remove('has-brush-cursor');
                return;
            }

            const rect = this.stage.getBoundingClientRect();
            const inside = e.clientX >= rect.left && e.clientX <= rect.right &&
                           e.clientY >= rect.top && e.clientY <= rect.bottom;
            if (!inside) {
                this.brushCursor.style.display = 'none';
                this.viewport?.classList.remove('has-brush-cursor');
                return;
            }

            this.updateCursorSize();
            this.brushCursor.style.display = 'block';
            this.brushCursor.style.left = `${e.clientX - rect.left}px`;
            this.brushCursor.style.top = `${e.clientY - rect.top}px`;

            const maskRect = this.maskCanvas?.getBoundingClientRect();
            const overCanvas = Boolean(maskRect) &&
                e.clientX >= maskRect.left && e.clientX <= maskRect.right &&
                e.clientY >= maskRect.top && e.clientY <= maskRect.bottom;
            this.viewport?.classList.toggle('has-brush-cursor', overCanvas);
        },

        hasMask() {
            if (!this.maskCanvas) return false;
            const ctx = this.maskCanvas.getContext('2d');
            const data = ctx.getImageData(0, 0, this.maskCanvas.width, this.maskCanvas.height).data;
            for (let i = 3; i < data.length; i += 4) {
                if (data[i] > 0) return true;
            }
            return false;
        },

        async getMaskBlob() {
            if (!this.maskCanvas) return null;
            return new Promise(resolve => this.maskCanvas.toBlob(resolve, 'image/png'));
        },

        async getInputBlob() {
            if (!this.currentImage) return null;
            const off = document.createElement('canvas');
            off.width = this.currentImage.naturalWidth || this.currentImage.width;
            off.height = this.currentImage.naturalHeight || this.currentImage.height;
            const octx = off.getContext('2d');
            octx.drawImage(this.currentImage, 0, 0);
            return new Promise(resolve => off.toBlob(resolve, 'image/png'));
        },

        open(src, options = {}) {
            if (!this.dialog) this.init();
            if (!this.dialog) return;

            this.currentSrc = src;
            this.currentOptions = options;
            const img = new Image();
            if (!src.startsWith('data:')) {
                img.crossOrigin = 'anonymous';
            }
            img.onload = () => {
                this.currentImage = img;
                const w = img.naturalWidth || img.width;
                const h = img.naturalHeight || img.height;

                this.baseCanvas.width = w;
                this.baseCanvas.height = h;
                this.maskCanvas.width = w;
                this.maskCanvas.height = h;

                // One image pixel per CSS pixel at zoom 1. Without an explicit
                // size the viewport shrink-wraps to the stage, so the zoom
                // readout lied and a phone-sized stage drew a thumbnail.
                this.viewport.style.width = `${w}px`;
                this.viewport.style.height = `${h}px`;

                const bctx = this.baseCanvas.getContext('2d');
                bctx.clearRect(0, 0, w, h);
                bctx.drawImage(img, 0, 0);

                const mctx = this.maskCanvas.getContext('2d');
                mctx.clearRect(0, 0, w, h);

                const existingMask = options.maskDataUrl || imageMaskMap.get(src)?.maskDataUrl;
                this.maskHistory = [];
                this.maskFuture = [];
                this.lastStrokeEnd = null;
                this.updateUndoState();
                if (existingMask) {
                    const maskImg = new Image();
                    maskImg.onload = () => mctx.drawImage(maskImg, 0, 0);
                    maskImg.src = existingMask;
                }

                if (this.infoSpan) this.infoSpan.textContent = `${w} × ${h} image`;
                if (this.promptInput) this.promptInput.value = options.prompt || '';

                this.dialog.showModal();
                this.isOpen = true;
                requestAnimationFrame(() => {
                    this.fitToStage();
                    this.updateCursorSize();
                    this.stage?.focus({ preventScroll: true });
                });
            };
            img.onerror = () => {
                toast('Failed to load image for inpainting.', 'error');
            };
            img.src = src;
        },

        async saveMask(silent = false) {
            if (!this.hasMask()) {
                if (!silent) toast('Please paint a mask over the area first.', 'error');
                return null;
            }

            const maskBlob = await this.getMaskBlob();
            const inputBlob = await this.getInputBlob();
            const maskDataUrl = this.maskCanvas.toDataURL('image/png');

            if (!inputBlob || !maskBlob) {
                if (!silent) toast('Could not prepare inpaint assets.', 'error');
                return null;
            }

            const record = { inputBlob, maskBlob, maskDataUrl, src: this.currentSrc };
            if (this.currentSrc) {
                imageMaskMap.set(this.currentSrc, record);
            }
            pendingInpaintAssets.set('latest', record);

            if (Number.isInteger(this.currentOptions?.targetAttachmentIdx) && attachedImages[this.currentOptions.targetAttachmentIdx]) {
                const att = attachedImages[this.currentOptions.targetAttachmentIdx];
                att.maskBlob = maskBlob;
                att.maskDataUrl = maskDataUrl;
                att.inputBlob = inputBlob;
                renderAttachmentTray();
            }

            if (this.currentOptions?.targetMsg) {
                const targetMsg = this.currentOptions.targetMsg;
                if (!Array.isArray(targetMsg.masks)) targetMsg.masks = [];
                const imgIdx = (targetMsg.images || []).indexOf(this.currentSrc);
                if (imgIdx >= 0) {
                    targetMsg.masks[imgIdx] = maskDataUrl;
                } else {
                    targetMsg.masks.push(maskDataUrl);
                }
                pendingInpaintAssets.set(targetMsg.id, record);
            }

            if (this.currentSrc) {
                try {
                    window.dispatchEvent(new CustomEvent('studio-mask-saved', { detail: { src: this.currentSrc, record } }));
                } catch (_) {}
            }

            return record;
        },

        async saveMaskAndClose() {
            const record = await this.saveMask(false);
            if (record) {
                toast('Mask saved. Any image generation on this image will inpaint the masked area.', 'success');
                this.close();
            }
        },

        async close() {
            if (!this.dialog || !this.isOpen) return;
            if (this.hasMask()) {
                await this.saveMask(true);
            }
            this.dialog.close();
            this.isOpen = false;
            this.isSpacePressed = false;
            this.isPanning = false;
            this.gestures?.reset();
            this.stage?.classList.remove('is-dragging-pan');
            if (this.brushCursor) this.brushCursor.style.display = 'none';
            chatInput?.focus();
        },

        async submit() {
            const record = await this.saveMask(false);
            if (!record) return;

            const promptText = this.promptInput?.value.trim() || 'inpaint';
            const w = this.currentImage.naturalWidth || this.currentImage.width;
            const h = this.currentImage.naturalHeight || this.currentImage.height;
            let ratioVal = '1:1';
            const aspect = w / h;
            if (aspect >= 1.6) ratioVal = '16:9';
            else if (aspect >= 1.25) ratioVal = '4:3';
            else if (aspect <= 0.62) ratioVal = '9:16';
            else if (aspect <= 0.8) ratioVal = '3:4';

            this.close();
            await sendInpaintMessage(promptText, ratioVal, record.inputBlob, record.maskBlob);
        }
    };

    async function sendInpaintMessage(promptText, ratioVal, inputBlob, maskBlob) {
        if (!activeChatId) {
            await createNewChat();
        }
        if (!activeChatId) return;

        const fakeUserId = crypto.randomUUID();
        const fakeAssistantId = crypto.randomUUID();

        pendingInpaintAssets.set(fakeAssistantId, { inputBlob, maskBlob });
        pendingInpaintAssets.set('latest', { inputBlob, maskBlob });

        const userContent = `Inpaint: ${promptText}`;
        const userMsg = {
            id: fakeUserId,
            chat_id: activeChatId,
            role: 'user',
            content: userContent,
            images: [inpaintModal.currentSrc],
            created: now()
        };

        const blockContent = [
            '```image-gen',
            'mode: inpaint',
            `prompt: ${promptText}`,
            `ratio: ${ratioVal}`,
            'denoise: 0.85',
            'grow_mask: 6',
            '```'
        ].join('\n');

        const assistantMsg = {
            id: fakeAssistantId,
            chat_id: activeChatId,
            role: 'assistant',
            content: blockContent,
            created: now(),
            model: selectedModel(),
            isLiveTurn: true
        };

        try {
            const sealedUser = await crypt().sealText(userContent);
            await api('save-message', {
                chat_id: activeChatId,
                message_id: fakeUserId,
                role: 'user',
                sealed_content: sealedUser,
                images: [inpaintModal.currentSrc]
            }, 'POST');
        } catch (_) {}

        try {
            const sealedAssistant = await crypt().sealText(blockContent);
            await api('save-message', {
                chat_id: activeChatId,
                message_id: fakeAssistantId,
                role: 'assistant',
                sealed_content: sealedAssistant
            }, 'POST');
        } catch (_) {}

        activeMessages.push(userMsg);
        activeMessages.push(assistantMsg);
        renderMessages();
        scrollToBottom(true);
    }

    function dataUrlToBytes(dataUrl) {
        const commaIdx = dataUrl.indexOf(',');
        if (commaIdx === -1) throw new Error('Invalid data URL');
        const base64 = dataUrl.slice(commaIdx + 1);
        const binary = atob(base64);
        const len = binary.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
            bytes[i] = binary.charCodeAt(i);
        }
        return bytes;
    }

    async function urlOrDataToBytes(url) {
        if (!url || typeof url !== 'string') return null;
        if (url.startsWith('data:')) {
            return dataUrlToBytes(url);
        }
        const res = await fetch(url, { cache: 'no-store' });
        if (!res.ok) throw new Error(`Failed to load reference image (${res.status})`);
        return new Uint8Array(await res.arrayBuffer());
    }

    function renderImageGenCard(pre, rawCodeText, msg) {
        const parsed = parseImageGenBlock(rawCodeText);
        if (!parsed.prompt) return;

        // Check for reference image and mask in current or prior conversation messages
        let referenceImageUrl = null;
        let referenceMaskData = null;
        const msgIdx = activeMessages.findIndex(m => m === msg || (m.id && m.id === msg?.id));
        if (msgIdx >= 0) {
            for (let i = msgIdx - 1; i >= 0; i--) {
                const m = activeMessages[i];
                if (m.images && Array.isArray(m.images) && m.images.length > 0) {
                    const lastImgIdx = m.images.length - 1;
                    referenceImageUrl = m.images[lastImgIdx];
                    if (m.masks && Array.isArray(m.masks) && m.masks[lastImgIdx]) {
                        referenceMaskData = m.masks[lastImgIdx];
                    }
                    break;
                }
            }
        }
        if (!referenceImageUrl && attachedImages.length > 0) {
            const lastAtt = attachedImages[attachedImages.length - 1];
            referenceImageUrl = lastAtt.dataUrl;
            if (lastAtt.maskDataUrl || lastAtt.maskBlob) {
                referenceMaskData = lastAtt.maskDataUrl;
            }
        }

        const mappedAsset = referenceImageUrl ? imageMaskMap.get(referenceImageUrl) : null;
        const pendingAsset = pendingInpaintAssets.get(msg?.id) || 
                             mappedAsset || 
                             pendingInpaintAssets.get('latest');

        // Check if there is ANY mask associated with the image or request
        const hasMask = Boolean(parsed.maskImageKey) || 
                        Boolean(referenceMaskData) || 
                        Boolean(pendingAsset?.maskBlob) || 
                        Boolean(pendingAsset?.maskDataUrl) ||
                        Boolean(mappedAsset?.maskBlob) || 
                        Boolean(mappedAsset?.maskDataUrl);

        // IF THERE IS A MASK ON THE IMAGE, IT MUST USE INPAINT AND NOT IMG2IMG!
        const isInpaint = (parsed.mode === 'inpaint' || hasMask) && parsed.explicitMode !== 'txt2img';
        const isImg2Img = !isInpaint && parsed.explicitMode !== 'txt2img' && ((parsed.mode === 'img2img' || Boolean(referenceImageUrl) || Boolean(parsed.inputImageKey)) && (Boolean(referenceImageUrl) || Boolean(parsed.inputImageKey) || Boolean(parsed.jobId)));

        const card = document.createElement('div');
        card.className = 'chat-image-gen-card';
        let metaBadges = `<span class="chat-image-gen-badge">${escapeHtml(parsed.ratio)}</span>`;
        if (isInpaint) {
            const denoisePct = Math.round((parsed.denoise || 0.85) * 100);
            metaBadges = `<span class="chat-image-gen-badge is-inpaint">Inpaint</span><span class="chat-image-gen-badge">${denoisePct}% Denoise</span><span class="chat-image-gen-badge">${escapeHtml(parsed.ratio)}</span>`;
        } else if (isImg2Img) {
            const denoisePct = Math.round((parsed.denoise || 0.65) * 100);
            metaBadges = `<span class="chat-image-gen-badge is-img2img">Img2Img</span><span class="chat-image-gen-badge">${denoisePct}% Denoise</span><span class="chat-image-gen-badge">${escapeHtml(parsed.ratio)}</span>`;
        }

        const modelTitle = isInpaint ? 'Krea 2 Turbo (LanPaint)' : 'Krea 2 Turbo';

        card.innerHTML = `
            <div class="chat-image-gen-header">
                <div class="chat-image-gen-title">
                    <svg class="chat-image-gen-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="10"></circle>
                        <path d="m14.31 8 5.74 9.94M9.69 8h11.48M7.38 12l5.74-9.94M9.69 16 3.95 6.06M14.31 16H2.83M16.62 12l-5.74 9.94"></path>
                    </svg>
                    <span>${modelTitle}</span>
                </div>
                <div class="chat-image-gen-meta">
                    ${metaBadges}
                    <button type="button" class="chat-card-action-btn chat-card-quick-copy" data-act="quick-copy-prompt" title="Copy prompt to clipboard">📋 Copy</button>
                </div>
            </div>
            <div class="chat-image-gen-body">
                <div class="chat-image-gen-status-box">
                    <div class="chat-image-gen-status-row">
                        <svg class="chat-image-gen-spinner" viewBox="0 0 24 24" width="20" height="20" fill="none" aria-hidden="true">
                            <circle cx="12" cy="12" r="9.5" stroke="currentColor" stroke-opacity="0.18" stroke-width="2.5"></circle>
                            <path d="M12 2.5a9.5 9.5 0 0 1 9.5 9.5" stroke="currentColor" stroke-width="2.5" stroke-linecap="round">
                                <animateTransform attributeName="transform" type="rotate" from="0 12 12" to="360 12 12" dur="0.75s" repeatCount="indefinite"/>
                            </path>
                        </svg>
                        <div class="chat-image-gen-status-text">Preparing image generation…</div>
                        <button type="button" class="chat-card-action-btn chat-card-cancel-btn" data-act="cancel-gen" title="Cancel this generation">✕ Cancel</button>
                    </div>
                    <div class="chat-image-gen-progress-track" style="display: none;">
                        <div class="chat-image-gen-progress-fill"></div>
                    </div>
                </div>
            </div>
            <div class="chat-image-gen-prompt">${escapeHtml(parsed.prompt)}</div>
        `;
        pre.replaceWith(card);

        const bodyEl = card.querySelector('.chat-image-gen-body');
        const statusBoxEl = card.querySelector('.chat-image-gen-status-box');
        const statusTextEl = card.querySelector('.chat-image-gen-status-text');
        const spinnerEl = card.querySelector('.chat-image-gen-spinner');
        const progressTrackEl = card.querySelector('.chat-image-gen-progress-track');
        const progressFillEl = card.querySelector('.chat-image-gen-progress-fill');

        card.querySelector('[data-act="quick-copy-prompt"]')?.addEventListener('click', async (e) => {
            e.stopPropagation();
            const ok = await copyText(parsed.prompt);
            if (ok) flashButton(e.currentTarget, 'Copied');
            else toast('Could not copy prompt.', 'error');
        });

        let isCancelled = false;
        let activeJobId = parsed.jobId || null;

        function renderCancelButton() {
            if (isCancelled || card.querySelector('[data-act="cancel-gen"]')) return;
            const statusRow = card.querySelector('.chat-image-gen-status-row');
            if (!statusRow) return;
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'chat-card-action-btn chat-card-cancel-btn';
            btn.dataset.act = 'cancel-gen';
            btn.title = 'Cancel this generation';
            btn.textContent = '✕ Cancel';
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                e.preventDefault();
                cancelGeneration();
            });
            statusRow.appendChild(btn);
        }

        async function cancelGeneration() {
            isCancelled = true;
            const toCancel = activeJobId || parsed.jobId;
            parsed.jobId = null;
            activeJobId = null;
            parsed.status = 'cancelled';
            if (spinnerEl) spinnerEl.style.display = 'none';
            if (progressTrackEl) progressTrackEl.style.display = 'none';
            if (progressFillEl) progressFillEl.style.width = '0%';
            card.querySelector('[data-act="cancel-gen"]')?.remove();
            statusBoxEl?.classList.remove('is-error');
            statusBoxEl?.classList.add('is-cancelled');

            if (statusTextEl) {
                statusTextEl.innerHTML = `Generation cancelled. <button type="button" class="chat-card-retry-btn">🎨 Generate Image</button>`;
                statusTextEl.querySelector('.chat-card-retry-btn')?.addEventListener('click', (e) => {
                    e.stopPropagation();
                    e.preventDefault();
                    isCancelled = false;
                    parsed.status = null;
                    statusBoxEl?.classList.remove('is-cancelled');
                    statusBoxEl?.classList.remove('is-error');
                    if (spinnerEl) spinnerEl.style.display = '';
                    if (statusTextEl) statusTextEl.textContent = 'Preparing image generation…';
                    renderCancelButton();
                    startNewGeneration();
                });
            }

            if (msg && msg.content) {
                if (/status\s*:\s*[^\n\r]+/i.test(msg.content)) {
                    msg.content = msg.content.replace(/status\s*:\s*[^\n\r]+/gi, 'status: cancelled');
                } else if (/job_id\s*:\s*[^\n\r]+/i.test(msg.content)) {
                    msg.content = msg.content.replace(/job_id\s*:\s*[^\n\r]+/gi, 'status: cancelled');
                } else {
                    msg.content = msg.content.replace(/(```(?:generate_image|generate-image|image-gen)[\s\S]*?)(```)/, `$1\nstatus: cancelled\n$2`);
                }
                msg.content = msg.content
                    .replace(/input_image_key\s*:\s*[^\n\r]+\n?/gi, '')
                    .replace(/mask_image_key\s*:\s*[^\n\r]+\n?/gi, '');
                const targetChatId = activeChatId || stream?.chatId || msg?.chatId;
                let targetMsgId = msg.id || msg.el?.dataset?.msgId;
                if (!targetMsgId) {
                    const found = activeMessages.find(m => m === msg || (m.created === msg.created && m.role === 'assistant'));
                    if (found && found.id) {
                        targetMsgId = found.id;
                        msg.id = found.id;
                    }
                }
                if (!targetMsgId && targetChatId) {
                    try {
                        const syncParams = { active_chat_id: targetChatId };
                        if (lastMsgId) syncParams.last_msg_id = lastMsgId;
                        const syncRes = await api('sync', null, 'GET', syncParams);
                        if (syncRes && syncRes.new_messages) {
                            await mergeRemoteMessages(syncRes.new_messages);
                            targetMsgId = msg.id || msg.el?.dataset?.msgId;
                        }
                    } catch (_) {}
                }
                if (targetChatId && targetMsgId) {
                    try {
                        api('save-message', {
                            chat_id: targetChatId,
                            message_id: targetMsgId,
                            role: 'assistant',
                            sealed_content: await crypt().sealText(msg.content),
                            sealed_reasoning: msg.reasoning ? await crypt().sealText(msg.reasoning) : null
                        }, 'POST').catch(err => console.warn('Failed to save cancelled status into message:', err));
                    } catch (_) {}
                }
            }

            if (toCancel) {
                try {
                    await fetch(`/api/studio?action=delete&app=${STUDIO.imageApp}`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ id: toCancel }),
                        cache: 'no-store'
                    });
                } catch (err) {
                    console.warn('Failed to delete cancelled job:', err);
                }
            }
            toast('Image generation cancelled.', 'info');
        }

        card.querySelector('[data-act="cancel-gen"]')?.addEventListener('click', (e) => {
            e.stopPropagation();
            e.preventDefault();
            cancelGeneration();
        });

        function renderCompletedImage(imgUrl, jobId) {
            if (msg) {
                if (!Array.isArray(msg.images)) msg.images = [];
                if (!msg.images.includes(imgUrl)) msg.images.push(imgUrl);
            }
            const downloadFilename = `studio-${jobId || 'image'}.png`;
            bodyEl.innerHTML = `
                <div class="chat-image-gen-preview-wrap">
                    <img class="chat-image-gen-img" src="${imgUrl}" alt="${escapeHtml(parsed.prompt)}" title="Click to view full image">
                </div>
                <div class="chat-image-gen-actions">
                    <button type="button" class="chat-card-action-btn" data-act="lightbox">🔍 Full View</button>
                    <a class="chat-card-action-btn" data-act="download" href="${imgUrl}" download="${downloadFilename}">⬇️ Download</a>
                    <button type="button" class="chat-card-action-btn" data-act="use-input">💬 Use in Chat</button>
                    <button type="button" class="chat-card-action-btn" data-act="inpaint">🎨 Inpaint</button>
                    <button type="button" class="chat-card-action-btn" data-act="copy-prompt">📋 Copy Prompt</button>
                </div>
            `;
            const img = bodyEl.querySelector('.chat-image-gen-img');
            const previewOptions = { prompt: parsed.prompt, jobId };
            img?.addEventListener('click', () => openImagePreview(imgUrl, previewOptions));
            bodyEl.querySelector('[data-act="lightbox"]')?.addEventListener('click', () => openImagePreview(imgUrl, previewOptions));
            bodyEl.querySelector('[data-act="download"]')?.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                downloadImageFile(imgUrl, downloadFilename);
            });
            bodyEl.querySelector('[data-act="inpaint"]')?.addEventListener('click', () => {
                inpaintModal.open(imgUrl, { prompt: parsed.prompt, targetMsg: msg });
            });
            bodyEl.querySelector('[data-act="copy-prompt"]')?.addEventListener('click', async (e) => {
                const ok = await copyText(parsed.prompt);
                if (ok) flashButton(e.currentTarget, 'Copied');
                else toast('Could not copy prompt.', 'error');
            });
            bodyEl.querySelector('[data-act="use-input"]')?.addEventListener('click', () => {
                const existingMask = imageMaskMap.get(imgUrl);
                const safeJobId = (jobId && typeof jobId === 'string') ? jobId.slice(0, 8) : 'image';
                attachedImages.push({
                    dataUrl: imgUrl,
                    name: `studio-${safeJobId}.png`,
                    size: 0,
                    maskBlob: existingMask?.maskBlob || null,
                    maskDataUrl: existingMask?.maskDataUrl || null,
                    inputBlob: existingMask?.inputBlob || null
                });
                renderAttachmentTray();
                chatInput?.focus();
                toast('Image attached to composer tray.', 'success');
            });
            keepAnchored();
        }

        async function startPollingJob(jobId) {
            activeJobId = jobId;
            if (isCancelled) return;
            if (spinnerEl) spinnerEl.style.display = '';
            statusBoxEl?.classList.remove('is-error');
            statusBoxEl?.classList.remove('is-cancelled');
            if (progressTrackEl) progressTrackEl.style.display = 'none';
            if (statusTextEl) statusTextEl.textContent = 'Queued on PC…';
            renderCancelButton();

            let attempts = 0;
            const maxAttempts = 180;
            let maxPercent = 0;
            let notFoundCount = 0;

            while (attempts < maxAttempts) {
                if (isCancelled) return;
                await new Promise(r => setTimeout(r, 1500));
                if (isCancelled) return;
                attempts++;

                try {
                    const statusRes = await fetch(`/api/studio?action=status&app=${STUDIO.imageApp}&job_id=${encodeURIComponent(jobId)}`, { cache: 'no-store' });
                    if (isCancelled) return;
                    if (!statusRes.ok) continue;
                    const statusData = await statusRes.json();
                    if (isCancelled) return;
                    const job = (statusData.jobs || []).find(j => j.id === jobId);

                    if (job) {
                        notFoundCount = 0;
                        if (job.status === 'complete') {
                            if (isCancelled) return;
                            if (statusTextEl) statusTextEl.textContent = 'Finalizing and decrypting image…';
                            if (progressFillEl) progressFillEl.style.width = '100%';
                            try {
                                const imgUrl = await (crypt()?.imageFor ? crypt().imageFor(job) : null);
                                if (isCancelled) return;
                                if (imgUrl) {
                                    renderCompletedImage(imgUrl, jobId);
                                    return;
                                }
                            } catch (decryptErr) {
                                if (isCancelled) return;
                                console.warn('Decrypt retry in 2s:', decryptErr);
                                await new Promise(r => setTimeout(r, 2000));
                                if (isCancelled) return;
                                const imgUrl = await (crypt()?.imageFor ? crypt().imageFor(job) : null);
                                if (isCancelled) return;
                                if (imgUrl) {
                                    renderCompletedImage(imgUrl, jobId);
                                    return;
                                }
                            }
                        } else if (job.status === 'failed') {
                            if (isCancelled) return;
                            if (spinnerEl) spinnerEl.style.display = 'none';
                            if (progressTrackEl) progressTrackEl.style.display = 'none';
                            card.querySelector('[data-act="cancel-gen"]')?.remove();
                            const errMsg = job.error || 'Unknown ComfyUI error';
                            if (statusTextEl) {
                                statusTextEl.innerHTML = `Generation failed: ${escapeHtml(errMsg)} <button type="button" class="chat-card-retry-btn">Retry</button>`;
                                statusTextEl.querySelector('.chat-card-retry-btn')?.addEventListener('click', (e) => {
                                    e.stopPropagation();
                                    e.preventDefault();
                                    statusTextEl.textContent = 'Retrying…';
                                    if (spinnerEl) spinnerEl.style.display = '';
                                    if (progressTrackEl) progressTrackEl.style.display = 'none';
                                    statusBoxEl?.classList.remove('is-error');
                                    parsed.jobId = null;
                                    renderCancelButton();
                                    setTimeout(() => startNewGeneration(), 50);
                                });
                            }
                            statusBoxEl?.classList.add('is-error');
                            return;
                        } else if (job.status === 'running') {
                            if (isCancelled) return;
                            const hasProgress = Number.isFinite(job.progress) && Number.isFinite(job.progress_total) && job.progress_total > 0;
                            let percent = hasProgress ? Math.min(100, Math.max(0, Math.round((job.progress / job.progress_total) * 100))) : null;
                            if (percent !== null) {
                                percent = Math.max(maxPercent, percent);
                                maxPercent = percent;
                            }
                            const etaText = Number.isFinite(job.eta_seconds) && job.eta_seconds > 0
                                ? ` · about ${job.eta_seconds < 60 ? `${job.eta_seconds}s` : `${Math.ceil(job.eta_seconds / 60)}m`} left`
                                : '';

                            const labelPrefix = isInpaint ? 'Inpainting with LanPaint (Krea 2 Turbo)' : (isImg2Img ? 'Rendering Img2Img with Krea 2 Turbo' : 'Rendering with Krea 2 Turbo');
                            if (job.progress_stage === 'finishing') {
                                if (isCancelled) return;
                                if (statusTextEl) statusTextEl.textContent = `Finishing…${percent ? ` · ${percent}%` : ''}`;
                                if (progressTrackEl) progressTrackEl.style.display = '';
                                if (progressFillEl) progressFillEl.style.width = `${percent || 99}%`;
                            } else if (hasProgress) {
                                if (isCancelled) return;
                                if (statusTextEl) statusTextEl.textContent = `${labelPrefix} · ${percent}%${etaText}`;
                                if (progressTrackEl) progressTrackEl.style.display = '';
                                if (progressFillEl) progressFillEl.style.width = `${percent}%`;
                            } else {
                                if (isCancelled) return;
                                if (statusTextEl) statusTextEl.textContent = isInpaint ? 'Starting LanPaint Inpainter…' : 'Starting Krea 2 Turbo…';
                                if (progressTrackEl) progressTrackEl.style.display = 'none';
                            }
                        } else {
                            if (isCancelled) return;
                            const pos = job.queue_position != null ? (job.queue_position <= 1 ? ' · Up next' : ` · #${job.queue_position}`) : '';
                            if (statusTextEl) statusTextEl.textContent = `Queued on PC${pos}…`;
                            if (progressTrackEl) progressTrackEl.style.display = 'none';
                        }
                    } else {
                        if (isCancelled) return;
                        // Check if completed image is available
                        try {
                            const imgUrl = await (crypt()?.imageFor ? crypt().imageFor({ id: jobId }) : null);
                            if (isCancelled) return;
                            if (imgUrl) {
                                renderCompletedImage(imgUrl, jobId);
                                return;
                            }
                        } catch (_) {}

                        if (isCancelled) return;
                        notFoundCount++;
                        if (notFoundCount >= 3) {
                            isCancelled = true;
                            parsed.status = 'cancelled';
                            parsed.jobId = null;
                            activeJobId = null;
                            if (spinnerEl) spinnerEl.style.display = 'none';
                            if (progressTrackEl) progressTrackEl.style.display = 'none';
                            if (progressFillEl) progressFillEl.style.width = '0%';
                            card.querySelector('[data-act="cancel-gen"]')?.remove();
                            statusBoxEl?.classList.remove('is-error');
                            statusBoxEl?.classList.add('is-cancelled');
                            if (statusTextEl) {
                                statusTextEl.innerHTML = `Generation cancelled. <button type="button" class="chat-card-retry-btn">🎨 Generate Image</button>`;
                                statusTextEl.querySelector('.chat-card-retry-btn')?.addEventListener('click', (e) => {
                                    e.stopPropagation();
                                    e.preventDefault();
                                    isCancelled = false;
                                    parsed.status = null;
                                    statusBoxEl?.classList.remove('is-cancelled');
                                    statusBoxEl?.classList.remove('is-error');
                                    if (spinnerEl) spinnerEl.style.display = '';
                                    if (statusTextEl) statusTextEl.textContent = 'Preparing image generation…';
                                    renderCancelButton();
                                    startNewGeneration();
                                });
                            }
                            if (msg && msg.content) {
                                if (/status\s*:\s*[^\n\r]+/i.test(msg.content)) {
                                    msg.content = msg.content.replace(/status\s*:\s*[^\n\r]+/gi, 'status: cancelled');
                                } else if (/job_id\s*:\s*[^\n\r]+/i.test(msg.content)) {
                                    msg.content = msg.content.replace(/job_id\s*:\s*[^\n\r]+/gi, 'status: cancelled');
                                } else {
                                    msg.content = msg.content.replace(/(```(?:generate_image|generate-image|image-gen)[\s\S]*?)(```)/, `$1\nstatus: cancelled\n$2`);
                                }
                                msg.content = msg.content
                                    .replace(/input_image_key\s*:\s*[^\n\r]+\n?/gi, '')
                                    .replace(/mask_image_key\s*:\s*[^\n\r]+\n?/gi, '');
                                const targetChatId = activeChatId || stream?.chatId || msg?.chatId;
                                let targetMsgId = msg.id || msg.el?.dataset?.msgId;
                                if (!targetMsgId) {
                                    const found = activeMessages.find(m => m === msg || (m.created === msg.created && m.role === 'assistant'));
                                    if (found && found.id) {
                                        targetMsgId = found.id;
                                        msg.id = found.id;
                                    }
                                }
                                if (targetChatId && targetMsgId) {
                                    try {
                                        api('save-message', {
                                            chat_id: targetChatId,
                                            message_id: targetMsgId,
                                            role: 'assistant',
                                            sealed_content: await crypt().sealText(msg.content),
                                            sealed_reasoning: msg.reasoning ? await crypt().sealText(msg.reasoning) : null
                                        }, 'POST').catch(() => {});
                                    } catch (_) {}
                                }
                            }
                            return;
                        }
                    }
                } catch (pollErr) {
                    if (isCancelled) return;
                    console.warn('Image job poll error:', pollErr);
                }
            }

            if (isCancelled) return;
            if (spinnerEl) spinnerEl.style.display = 'none';
            if (progressTrackEl) progressTrackEl.style.display = 'none';
            card.querySelector('[data-act="cancel-gen"]')?.remove();
            if (statusTextEl) {
                statusTextEl.innerHTML = `Generation timed out. Check that the local engine is running on your PC. <button type="button" class="chat-card-retry-btn">Retry</button>`;
                statusTextEl.querySelector('.chat-card-retry-btn')?.addEventListener('click', (e) => {
                    e.stopPropagation();
                    e.preventDefault();
                    statusTextEl.textContent = 'Retrying…';
                    if (spinnerEl) spinnerEl.style.display = '';
                    if (progressTrackEl) progressTrackEl.style.display = 'none';
                    statusBoxEl?.classList.remove('is-error');
                    parsed.jobId = null;
                    renderCancelButton();
                    setTimeout(() => startNewGeneration(), 50);
                });
            }
            statusBoxEl?.classList.add('is-error');
        }

        async function startNewGeneration() {
            if (!isUnlocked() || isCancelled) return;
            const newJobId = crypto.randomUUID();
            parsed.jobId = newJobId;
            activeJobId = newJobId;
            renderCancelButton();

            try {
                let uploadedInputKey = parsed.inputImageKey || null;
                let uploadedMaskKey = parsed.maskImageKey || null;
                const activeAsset = pendingAsset || mappedAsset;

                if (isInpaint) {
                    if (statusTextEl) statusTextEl.textContent = 'Encrypting & uploading inpaint assets…';

                    // 1. Input image
                    if (!uploadedInputKey) {
                        let inputBytes = null;
                        if (activeAsset?.inputBlob) {
                            inputBytes = new Uint8Array(await activeAsset.inputBlob.arrayBuffer());
                        } else if (referenceImageUrl) {
                            inputBytes = await urlOrDataToBytes(referenceImageUrl);
                        }
                        if (isCancelled) return;
                        if (!inputBytes) throw new Error('Missing input image for inpainting.');
                        const sealedInput = await crypt().sealBinary(inputBytes);
                        if (isCancelled) return;
                        const upRes = await fetch(`/api/studio?action=upload-asset&app=${STUDIO.imageApp}&id=${encodeURIComponent(newJobId)}&type=input`, {
                            method: 'POST',
                            body: sealedInput,
                            headers: { 'Content-Type': 'application/octet-stream' },
                            cache: 'no-store'
                        });
                        if (isCancelled) return;
                        if (!upRes.ok) {
                            const upErr = await upRes.json().catch(() => ({}));
                            throw new Error(upErr.error || `Failed to upload input image (${upRes.status})`);
                        }
                        const upJson = await upRes.json();
                        uploadedInputKey = upJson.key;
                    }

                    // 2. Mask image
                    if (!uploadedMaskKey) {
                        if (isCancelled) return;
                        let maskBytes = null;
                        if (activeAsset?.maskBlob) {
                            maskBytes = new Uint8Array(await activeAsset.maskBlob.arrayBuffer());
                        } else if (activeAsset?.maskDataUrl) {
                            maskBytes = await urlOrDataToBytes(activeAsset.maskDataUrl);
                        } else if (referenceMaskData) {
                            maskBytes = await urlOrDataToBytes(referenceMaskData);
                        }
                        if (isCancelled) return;
                        if (!maskBytes) throw new Error('Missing mask for inpainting. Please paint a mask over the area.');
                        const sealedMask = await crypt().sealBinary(maskBytes);
                        if (isCancelled) return;
                        const upMaskRes = await fetch(`/api/studio?action=upload-asset&app=${STUDIO.imageApp}&id=${encodeURIComponent(newJobId)}&type=mask`, {
                            method: 'POST',
                            body: sealedMask,
                            headers: { 'Content-Type': 'application/octet-stream' },
                            cache: 'no-store'
                        });
                        if (isCancelled) return;
                        if (!upMaskRes.ok) {
                            const upErr = await upMaskRes.json().catch(() => ({}));
                            throw new Error(upErr.error || `Failed to upload inpaint mask (${upMaskRes.status})`);
                        }
                        const upMaskJson = await upMaskRes.json();
                        uploadedMaskKey = upMaskJson.key;
                    }
                } else if (isImg2Img && referenceImageUrl && !uploadedInputKey) {
                    if (statusTextEl) statusTextEl.textContent = 'Encrypting & uploading reference image…';
                    const inputBytes = await urlOrDataToBytes(referenceImageUrl);
                    if (isCancelled) return;
                    if (!inputBytes) throw new Error('Missing reference image for img2img.');
                    const sealedInput = await crypt().sealBinary(inputBytes);
                    if (isCancelled) return;

                    const upRes = await fetch(`/api/studio?action=upload-asset&app=${STUDIO.imageApp}&id=${encodeURIComponent(newJobId)}&type=input`, {
                        method: 'POST',
                        body: sealedInput,
                        headers: { 'Content-Type': 'application/octet-stream' },
                        cache: 'no-store'
                    });
                    if (isCancelled) return;
                    if (!upRes.ok) {
                        const upErr = await upRes.json().catch(() => ({}));
                        throw new Error(upErr.error || `Failed to upload reference image (${upRes.status})`);
                    }
                    const upJson = await upRes.json();
                    uploadedInputKey = upJson.key;
                }

                if (isCancelled) return;

                // Persist jobId and mode metadata into message content so it never re-runs
                if (msg && msg.content) {
                    const metaLines = [`job_id: ${newJobId}`];
                    if (isInpaint) {
                        metaLines.unshift('mode: inpaint');
                        if (uploadedInputKey) metaLines.push(`input_image_key: ${uploadedInputKey}`);
                        if (uploadedMaskKey) metaLines.push(`mask_image_key: ${uploadedMaskKey}`);
                        metaLines.push(`grow_mask: ${parsed.growMask || 6}`);
                    } else if (isImg2Img) {
                        metaLines.unshift('mode: img2img');
                        if (uploadedInputKey) metaLines.push(`input_image_key: ${uploadedInputKey}`);
                    }
                    const targetChatId = activeChatId || stream?.chatId || msg?.chatId;
                    msg.content = msg.content
                        .replace(/status\s*:\s*[^\n\r]+\n?/gi, '')
                        .replace(/(```(?:generate_image|generate-image|image-gen)[\s\S]*?)(```)/, `$1\n${metaLines.join('\n')}\n$2`);
                    let targetMsgId = msg.id || msg.el?.dataset?.msgId;
                    if (!targetMsgId) {
                        const found = activeMessages.find(m => m === msg || (m.created === msg.created && m.role === 'assistant'));
                        if (found && found.id) {
                            targetMsgId = found.id;
                            msg.id = found.id;
                        }
                    }
                    if (targetChatId && targetMsgId) {
                        try {
                            api('save-message', {
                                chat_id: targetChatId,
                                message_id: targetMsgId,
                                role: 'assistant',
                                sealed_content: await crypt().sealText(msg.content),
                                sealed_reasoning: msg.reasoning ? await crypt().sealText(msg.reasoning) : null
                            }, 'POST').catch(err => console.warn('Failed to save job_id into message:', err));
                        } catch (_) {}
                    }
                }

                if (isCancelled) return;
                if (statusTextEl) statusTextEl.textContent = 'Submitting to your PC…';
                const sealedPrompt = await crypt().sealText(parsed.prompt);
                if (isCancelled) return;
                const targetChatId = activeChatId || stream?.chatId || msg?.chatId;

                let genPayload;
                if (isInpaint) {
                    if (!uploadedInputKey || !uploadedMaskKey) {
                        throw new Error('Missing input image or mask for inpainting.');
                    }
                    genPayload = {
                        id: newJobId,
                        chat_id: targetChatId,
                        prompt: sealedPrompt,
                        negativePrompt: '',
                        seed: '',
                        model: 'krea2_turbo',
                        ratio: normalizeRatio(parsed.ratio),
                        resolution: '1mp',
                        steps: 16,
                        guidance: 1.0,
                        sampler: 'euler',
                        loras: [],
                        mode: 'inpaint',
                        denoise: parsed.denoise || 0.85,
                        growMask: parsed.growMask || 6,
                        inputImageKey: uploadedInputKey,
                        maskImageKey: uploadedMaskKey,
                        workflow: 'standard'
                    };
                } else {
                    const canDoImg2Img = isImg2Img && Boolean(uploadedInputKey);
                    genPayload = {
                        id: newJobId,
                        chat_id: targetChatId,
                        prompt: sealedPrompt,
                        negativePrompt: '',
                        seed: '',
                        model: 'krea2_turbo',
                        ratio: normalizeRatio(parsed.ratio),
                        resolution: '1mp',
                        steps: 16,
                        guidance: 1.0,
                        sampler: 'euler',
                        loras: [],
                        mode: canDoImg2Img ? 'img2img' : 'txt2img',
                        denoise: canDoImg2Img ? (parsed.denoise || 0.65) : undefined,
                        inputImageKey: canDoImg2Img ? uploadedInputKey : undefined,
                        workflow: 'standard'
                    };
                }
                if (IS_LITE) {
                    const keys = await liteKeys();
                    genPayload.app = 'lite';
                    genPayload.clientPubkey = keys?.publicKeySpki;
                    genPayload.workerPayload = await window.StudioLiteCrypto.sealForWorker({
                        prompt: parsed.prompt,
                        negativePrompt: ''
                    });
                }
                if (isCancelled) return;
                const genRes = await fetch(`/api/studio?action=generate&app=${STUDIO.imageApp}`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(genPayload),
                    cache: 'no-store'
                });
                if (!genRes.ok) {
                    const errData = await genRes.json().catch(() => ({}));
                    throw new Error(errData.error || `Failed to queue generation (${genRes.status})`);
                }
                if (isCancelled) {
                    try {
                        await fetch(`/api/studio?action=delete&app=${STUDIO.imageApp}`, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ id: newJobId }),
                            cache: 'no-store'
                        });
                    } catch (_) {}
                    return;
                }
                startPollingJob(newJobId);
            } catch (err) {
                if (isCancelled) return;
                console.error('Image generation startup error:', err);
                parsed.jobId = null;
                card.querySelector('[data-act="cancel-gen"]')?.remove();
                if (spinnerEl) spinnerEl.style.display = 'none';
                if (progressTrackEl) progressTrackEl.style.display = 'none';
                if (statusTextEl) {
                    if (err.message && err.message.includes('Missing mask for inpainting')) {
                        statusBoxEl?.classList.add('is-waiting-mask');
                        statusTextEl.innerHTML = `
                            <span>Please paint a mask over the area you want to change:</span>
                            <button type="button" class="chat-card-action-btn" data-act="open-inpaint-mask" style="margin-left: 8px;">🎨 Paint Mask</button>
                        `;
                        statusTextEl.querySelector('[data-act="open-inpaint-mask"]')?.addEventListener('click', () => {
                            if (referenceImageUrl) {
                                inpaintModal.open(referenceImageUrl, {
                                    prompt: parsed.prompt,
                                    targetMsg: msg
                                });
                            } else {
                                toast('No base image found to paint mask on.', 'error');
                            }
                        });
                    } else {
                        statusTextEl.innerHTML = `Generation error: ${escapeHtml(err.message)} <button type="button" class="chat-card-retry-btn">Retry</button>`;
                        statusTextEl.querySelector('.chat-card-retry-btn')?.addEventListener('click', (e) => {
                            e.stopPropagation();
                            e.preventDefault();
                            statusTextEl.textContent = 'Retrying…';
                            if (spinnerEl) spinnerEl.style.display = '';
                            if (progressTrackEl) progressTrackEl.style.display = 'none';
                            statusBoxEl?.classList.remove('is-error');
                            statusBoxEl?.classList.remove('is-waiting-mask');
                            renderCancelButton();
                            setTimeout(() => startNewGeneration(), 50);
                        });
                    }
                }
                statusBoxEl?.classList.add('is-error');
            }
        }

        if (parsed.status === 'cancelled') {
            isCancelled = true;
            if (spinnerEl) spinnerEl.style.display = 'none';
            if (progressTrackEl) progressTrackEl.style.display = 'none';
            if (progressFillEl) progressFillEl.style.width = '0%';
            card.querySelector('[data-act="cancel-gen"]')?.remove();
            statusBoxEl?.classList.remove('is-error');
            statusBoxEl?.classList.add('is-cancelled');
            if (statusTextEl) {
                statusTextEl.innerHTML = `Generation cancelled. <button type="button" class="chat-card-retry-btn">🎨 Generate Image</button>`;
                statusTextEl.querySelector('.chat-card-retry-btn')?.addEventListener('click', (e) => {
                    e.stopPropagation();
                    e.preventDefault();
                    isCancelled = false;
                    parsed.status = null;
                    statusBoxEl?.classList.remove('is-cancelled');
                    statusBoxEl?.classList.remove('is-error');
                    if (spinnerEl) spinnerEl.style.display = '';
                    if (statusTextEl) statusTextEl.textContent = 'Preparing image generation…';
                    renderCancelButton();
                    startNewGeneration();
                });
            }
            return;
        }

        if (parsed.jobId) {
            if (statusTextEl) statusTextEl.textContent = 'Loading generated image…';
            (async () => {
                try {
                    if (crypt()?.imageFor) {
                        const imgUrl = await crypt().imageFor({ id: parsed.jobId });
                        if (imgUrl) {
                            renderCompletedImage(imgUrl, parsed.jobId);
                            return;
                        }
                    }
                } catch (_) {}
                startPollingJob(parsed.jobId);
            })();
            return;
        }

        // If this message was not created in the live active turn (e.g. loaded from history or page refresh),
        // do NOT automatically queue a new generation. Let the user choose when to generate.
        if (!msg?.isLiveTurn) {
            if (spinnerEl) spinnerEl.style.display = 'none';
            if (progressTrackEl) progressTrackEl.style.display = 'none';
            if (progressFillEl) progressFillEl.style.width = '0%';
            card.querySelector('[data-act="cancel-gen"]')?.remove();
            if (statusTextEl) {
                statusTextEl.innerHTML = `Image prompt ready. <button type="button" class="chat-card-retry-btn">🎨 Generate Image</button>`;
                statusTextEl.querySelector('.chat-card-retry-btn')?.addEventListener('click', (e) => {
                    e.stopPropagation();
                    e.preventDefault();
                    isCancelled = false;
                    parsed.status = null;
                    statusBoxEl?.classList.remove('is-cancelled');
                    statusBoxEl?.classList.remove('is-error');
                    if (spinnerEl) spinnerEl.style.display = '';
                    if (statusTextEl) statusTextEl.textContent = 'Preparing image generation…';
                    renderCancelButton();
                    startNewGeneration();
                });
            }
            return;
        }

        if (msg) msg.isLiveTurn = false;

        if (!isUnlocked()) {
            if (spinnerEl) spinnerEl.style.display = 'none';
            if (statusTextEl) {
                statusTextEl.innerHTML = `
                    <span>Studio is locked. Unlock to generate this image.</span>
                    <button type="button" class="chat-card-action-btn" style="margin-left: 8px;">Unlock</button>
                `;
                statusTextEl.querySelector('button')?.addEventListener('click', () => {
                    document.querySelector('#studio-key')?.focus();
                    toast('Enter your Studio key on the unlock screen to enable image generation.', 'info');
                });
            }
            window.addEventListener('studio-unlocked', () => {
                startNewGeneration();
            }, { once: true });
            return;
        }

        window.addEventListener('studio-mask-saved', (e) => {
            if (isInpaint && !parsed.jobId && (!referenceImageUrl || e.detail?.src === referenceImageUrl)) {
                if (statusBoxEl?.classList.contains('is-error') || statusBoxEl?.classList.contains('is-waiting-mask')) {
                    statusBoxEl.classList.remove('is-error');
                    statusBoxEl.classList.remove('is-waiting-mask');
                    if (spinnerEl) spinnerEl.style.display = '';
                    if (statusTextEl) statusTextEl.textContent = 'Mask saved. Starting inpaint…';
                    setTimeout(() => startNewGeneration(), 100);
                }
            }
        });

        startNewGeneration();
    }

    // Words that carry the frame of a memory sentence rather than its content.
    // A line built only from these says nothing the user could have told us.
    const MEMORY_FRAME_WORDS = new Set([
        'the', 'user', "user's", 'users', 'they', 'their', 'them', 'theyre', 'this', 'that', 'these',
        'those', 'is', 'was', 'are', 'were', 'has', 'have', 'had', 'and', 'with', 'for', 'from',
        'about', 'also', 'like', 'likes', 'prefer', 'prefers', 'want', 'wants', 'enjoy', 'enjoys',
        'named', 'called', 'currently', 'been', 'being', 'his', 'her', 'its', 'own', 'new', 'some'
    ]);

    // Every word the human has actually typed in this conversation.
    function userVocabulary(messages) {
        const vocab = new Set();
        for (const msg of messages || []) {
            if (msg?.role !== 'user') continue;
            const text = typeof msg.content === 'string' ? msg.content : '';
            for (const word of text.toLowerCase().match(/[a-z0-9']+/g) || []) vocab.add(word);
        }
        return vocab;
    }

    // The models invent a second, plausible-sounding fact to keep the first one
    // company: told only a name, one of them also saved "The user is building
    // this website." A saved line is read back to the user later as something
    // they said, so every line has to contain at least one word they actually
    // typed. A line that shares nothing with the conversation but its frame is
    // not a memory of anything - it is the assistant writing the user's history
    // for them - and it is dropped here rather than argued with in the prompt.
    function isGroundedMemory(text, vocab) {
        if (!vocab || !vocab.size) return true;
        const words = (String(text).toLowerCase().match(/[a-z0-9']+/g) || [])
            .filter(word => (word.length >= 3 || /\d/.test(word)) && !MEMORY_FRAME_WORDS.has(word));
        if (!words.length) return false;
        return words.some(word => {
            if (vocab.has(word)) return true;
            const stem = word.replace(/(?:'s|es|ed|ing|s)$/, '');
            if (stem.length >= 3 && vocab.has(stem)) return true;
            // "building" against a typed "builds", "developer" against "develop".
            const prefix = word.slice(0, 5);
            if (prefix.length < 5) return false;
            for (const typed of vocab) {
                if (typed.startsWith(prefix) || word.startsWith(typed.slice(0, 5))) return true;
            }
            return false;
        });
    }

    function parseMemoryBlock(rawText, vocab = null) {
        if (!rawText || typeof rawText !== 'string') return [];
        const placeholderPatterns = [
            // Any line that is nothing but an angle-bracket slot, whatever the
            // prompt happens to word it as this month.
            /^<[^>]*>$/,
            /<concise.*?>/i,
            /<fact.*?>/i,
            /<preference.*?>/i,
            /<one clear.*?>/i,
            /^none$/i,
            /^null$/i,
            /^undefined$/i,
            /^n\/a$/i
        ];

        const lines = rawText.split('\n')
            .map(l => l.trim())
            .filter(Boolean);

        const results = [];

        for (const rawLine of lines) {
            let line = rawLine.replace(/^[-*•]\s+/, '').replace(/^\d+[\.\)]\s+/, '').trim();
            if (!line || placeholderPatterns.some(p => p.test(line))) continue;

            // Detect space-separated or comma-separated key-value pairs like:
            // "user_name: Alex hobby: photography created_website: yes"
            const kvMatches = [...line.matchAll(/([a-zA-Z0-9_]+)\s*:\s*([^:]+?)(?=(?:\s+[a-zA-Z0-9_]+\s*:|$))/g)];
            if (kvMatches.length > 1 || (kvMatches.length === 1 && /^[a-zA-Z0-9_]+\s*:/.test(line))) {
                for (const m of kvMatches) {
                    const key = m[1].replace(/_/g, ' ').toLowerCase().trim();
                    let val = m[2].trim().replace(/[,;]$/, '').trim();
                    if (!val || placeholderPatterns.some(p => p.test(val))) continue;

                    if (key === 'user name' || key === 'name' || key === 'username') {
                        results.push(`The user's name is ${val}.`);
                    } else if (key === 'created website' || key === 'website') {
                        if (val.toLowerCase() === 'yes' || val.toLowerCase() === 'true') {
                            results.push('The user created this website.');
                        } else {
                            results.push(`User website: ${val}.`);
                        }
                    } else if (key === 'hobby' || key === 'hobbies') {
                        results.push(`User hobby: ${val}.`);
                    } else {
                        const capitalized = key.charAt(0).toUpperCase() + key.slice(1);
                        results.push(`${capitalized}: ${val}.`);
                    }
                }
            } else {
                if (line.length >= 3 && !placeholderPatterns.some(p => p.test(line))) {
                    if (!/[.!?]$/.test(line)) line += '.';
                    results.push(line);
                }
            }
        }

        const unique = Array.from(new Set(results));
        if (!vocab) return unique;
        const grounded = unique.filter(entry => isGroundedMemory(entry, vocab));
        if (grounded.length !== unique.length) {
            console.warn('Dropped memory line(s) with no basis in what you typed:',
                unique.filter(entry => !grounded.includes(entry)));
        }
        return grounded;
    }

    // Post-processing that is too expensive to redo on every streamed token:
    // called once when a message settles.
    function enhanceBubble(container, msg = null) {
        if (!container) return;

        container.querySelectorAll('a[href]:not([download]):not([data-act="download"])').forEach(link => {
            link.target = '_blank';
            link.rel = 'noopener noreferrer';
        });

        container.querySelectorAll('table').forEach(table => {
            if (table.parentElement?.classList.contains('chat-table-scroll')) return;
            const scroller = document.createElement('div');
            scroller.className = 'chat-table-scroll';
            table.replaceWith(scroller);
            scroller.appendChild(table);
        });

        container.querySelectorAll('pre').forEach(pre => {
            if (pre.parentElement?.classList.contains('chat-code-block') || pre.classList.contains('is-handled')) return;
            const code = pre.querySelector('code');
            const match = (code?.className || '').match(/language-([\w+#-]+)/);
            const language = match ? match[1] : 'code';

            if (language === 'generate_image' || language === 'generate-image') {
                pre.classList.add('is-handled');
                renderImageGenCard(pre, code ? code.innerText : pre.innerText, msg);
                return;
            }

            if (language === 'save_memory' || language === 'save-memory' || language === 'remember') {
                pre.classList.add('is-handled');
                const rawMem = (code ? code.innerText : pre.innerText).trim();
                const entries = parseMemoryBlock(rawMem, userVocabulary(activeMessages));
                if (!entries.length) {
                    pre.remove();
                    return;
                }
                const chip = document.createElement('div');
                chip.className = 'chat-memory-chip';
                if (entries.length === 1) {
                    chip.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2a5 5 0 0 1 5 5c0 1.6-.7 3-1.9 4H17a4 4 0 0 1 4 4v2a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3v-2a4 4 0 0 1 4-4h1.9C7.7 10 7 8.6 7 7a5 5 0 0 1 5-5Z"/><circle cx="9.5" cy="7.5" r="1"/><circle cx="14.5" cy="7.5" r="1"/></svg><span>Saved to memory: ${escapeHtml(entries[0])}</span>`;
                } else {
                    const listHtml = entries.map(e => `<li>${escapeHtml(e)}</li>`).join('');
                    chip.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="align-self:flex-start; margin-top:2px;"><path d="M12 2a5 5 0 0 1 5 5c0 1.6-.7 3-1.9 4H17a4 4 0 0 1 4 4v2a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3v-2a4 4 0 0 1 4-4h1.9C7.7 10 7 8.6 7 7a5 5 0 0 1 5-5Z"/><circle cx="9.5" cy="7.5" r="1"/><circle cx="14.5" cy="7.5" r="1"/></svg><div class="chat-memory-chip-content"><strong>Saved ${entries.length} facts to memory:</strong><ul style="margin:4px 0 0 16px; padding:0; list-style-type:disc;">${listHtml}</ul></div>`;
                }
                pre.replaceWith(chip);
                if (!pre.dataset.saved) {
                    pre.dataset.saved = 'true';
                    for (const entry of entries) {
                        saveMemory(entry, 'fact').catch(err => console.error('Auto-save memory failed:', err));
                    }
                }
                return;
            }

            const block = document.createElement('div');
            block.className = 'chat-code-block';
            const head = document.createElement('div');
            head.className = 'chat-code-head';
            const label = document.createElement('span');
            label.textContent = language;
            const copyBtn = document.createElement('button');
            copyBtn.type = 'button';
            copyBtn.className = 'code-copy-btn';
            copyBtn.innerHTML = `${ICONS.copy}<span>Copy</span>`;
            copyBtn.setAttribute('aria-label', 'Copy code to clipboard');
            copyBtn.addEventListener('click', async () => {
                const ok = await copyText(code ? code.innerText : pre.innerText);
                if (ok) flashButton(copyBtn, 'Copied');
                else toast('Could not copy to the clipboard.', 'error');
            });
            head.append(label, copyBtn);

            pre.replaceWith(block);
            block.append(head, pre);
        });
    }

    // ----------------------------------------------------------------- API ---
    // Streamed chunks arrive sealed with the Studio content key, the same key
    // that has always protected the saved message. Falls back to the raw text so
    // a worker that has not been reinstalled yet still renders: the site deploy
    // and the worker install are separate steps and are never simultaneous.
    let liteStreamKey = null;

    // The worker publishes one throwaway AES key per reply, wrapped to this
    // browser's public key. Unwrap it once; every chunk of that reply is then
    // iv||ciphertext under it.
    async function adoptStreamKey(sealedBase64) {
        if (!IS_LITE || !sealedBase64) return;
        try {
            const raw = window.StudioLiteCrypto.base64ToBytes(sealedBase64);
            const keyBytes = await window.StudioLiteCrypto.unsealPayload(raw, liteUserId());
            liteStreamKey = await crypto.subtle.importKey('raw', keyBytes, 'AES-GCM', false, ['decrypt']);
        } catch (err) {
            console.warn('Could not open the stream key for this reply:', err);
            liteStreamKey = null;
        }
    }

    async function openDelta(text) {
        if (!text) return text;
        if (IS_LITE) {
            if (!liteStreamKey) return text;
            try {
                const raw = window.StudioLiteCrypto.base64ToBytes(text);
                const plain = await crypto.subtle.decrypt(
                    { name: 'AES-GCM', iv: raw.slice(0, 12) }, liteStreamKey, raw.slice(12));
                return new TextDecoder().decode(plain);
            } catch (_) {
                return text;
            }
        }
        if (!crypt()?.isUnlocked?.()) return text;
        try {
            return await crypt().unsealText(text);
        } catch (_) {
            return text;
        }
    }

    // The session cookie expired, not the Studio key. Nothing here works without
    // it and every later call repeats the same 401, so re-authenticate instead
    // of showing a request-failed error the owner cannot act on.
    let leavingToLogin = false;
    function goSignIn() {
        if (leavingToLogin) return true;
        leavingToLogin = true;
        location.replace('/login/?returnTo=' + encodeURIComponent(location.pathname + location.search));
        return true;
    }
    async function api(action, bodyData = null, method = 'GET', params = null) {
        const options = { method, headers: {}, cache: 'no-store' };
        if (bodyData && method !== 'GET') {
            options.headers['Content-Type'] = 'application/json';
            options.body = JSON.stringify(bodyData);
        }
        const url = new URL(STUDIO.endpoint, window.location.origin);
        url.searchParams.set('action', action);
        if (params && typeof params === 'object') {
            for (const [key, value] of Object.entries(params)) {
                if (value != null) url.searchParams.set(key, String(value));
            }
        }
        const res = await fetch(url.toString(), options);
        if (!res.ok) {
            const errJson = await res.json().catch(() => ({}));
            if (res.status === 401 && errJson.code === 'signed-out') goSignIn();
            throw new Error(errJson.error || `Request failed (${res.status})`);
        }
        return res.json();
    }

    const isUnlocked = () => Boolean(crypt() && crypt().isUnlocked());

    async function unseal(sealed, fallback = '') {
        if (!sealed) return '';
        try {
            return await crypt().unsealText(sealed);
        } catch (_) {
            return fallback;
        }
    }

    // Conversation titles are sealed like message bodies. A sealed value is base64
    // of an envelope whose first bytes are "ASP1", which encodes to this prefix,
    // so it identifies a sealed title without attempting a decrypt.
    //
    // This tested for the pre-rename envelope until the title of every chat
    // started rendering as base64: the envelope became ASP1 and the prefix was
    // left matching the old name, so no title ever looked sealed and every one
    // was shown raw. Message bodies were unaffected because they always attempt
    // a decrypt rather than sniffing first.
    const SEALED_PREFIX = 'QVNQ';
    const looksSealed = value => typeof value === 'string' && value.startsWith(SEALED_PREFIX);

    async function sealTitle(plain) {
        return crypt().sealText(plain);
    }

    async function readTitle(stored) {
        if (!stored) return '';
        // With storage unencrypted the title is still base64 - sealing passes the
        // bytes through rather than being skipped - so it needs decoding even
        // though nothing about it looks sealed.
        const encrypted = crypt()?.encryptionEnabled?.();
        if (!looksSealed(stored) && encrypted !== false) return stored;
        if (encrypted && !isUnlocked()) return 'Locked conversation';
        try {
            return await crypt().unsealText(stored);
        } catch (_) {
            // Either a different Studio key, or a legacy plaintext title that
            // happens to start with the prefix. Showing the raw value beats
            // showing an error for something that may be perfectly readable.
            return stored;
        }
    }

    // Every path that receives chat rows funnels through here, so `chats` always
    // holds plaintext titles and rendering, search and export need no crypto.
    async function hydrateChats(rows) {
        return Promise.all((rows || []).map(async row => ({ ...row, title: await readTitle(row.title) })));
    }

    // --------------------------------------------------------------- State ---
    let chats = [];
    let searchTerm = '';
    let activeChatId = null;
    let activeMessages = [];
    let lastMsgId = null;
    let stream = null;           // { jobId, chatId, msg, ctrl, detached }
    let editingMsg = null;
    let isSyncing = false;
    let syncTimer = null;
    let activeJobs = [];   // every queued/running chat job, in the order the PC runs them
    let lastKnownHostState = null;
    let attachedImages = []; // [{ dataUrl, name, size }]
    let attachedDocuments = []; // [{ name, size, formattedSize, type, ext, text, rawText, charCount, estTokens, pages, truncated }]
    // Jobs this tab has already streamed to completion. sync should stop listing a
    // job the moment it completes, but if it ever lags, re-attaching would add a
    // second empty bubble for a reply that already arrived.
    const finishedJobs = new Set();
    let openRowMenu = null;

    const isStreaming = () => Boolean(stream);
    const jobForChat = chatId => (chatId
        ? activeJobs.find(job => job.chat_id === chatId && !finishedJobs.has(job.job_id)) || null
        : null);

    function markJobFinished(jobId) {
        if (!jobId) return;
        finishedJobs.add(jobId);
        if (finishedJobs.size > 50) finishedJobs.delete(finishedJobs.values().next().value);
    }
    const lastMessage = () => activeMessages[activeMessages.length - 1] || null;

    // Per studio, not per origin. Both studios shared one origin upstream, so one
    // shared channel let a Lite tab's "chat-updated" wake every open Plus tab into
    // a sync it had no reason to run - a cross-studio signal, and D1 reads spent
    // on someone else's conversation.
    const chatSyncChannel = typeof BroadcastChannel !== 'undefined' ? new BroadcastChannel(`studio-chat-sync-${STUDIO.id}`) : null;
    function notifyChatSync(type, chatId = null) {
        if (!chatSyncChannel) return;
        try { chatSyncChannel.postMessage({ type, chatId, timestamp: Date.now() }); } catch (_) {}
    }

    // -------------------------------------------------------------- Memory ---
    let memories = []; // [{ id, text, category, created, updated }]
    let isMemoryLoading = false;

    async function loadMemories() {
        if (!isUnlocked() || isMemoryLoading) return;
        isMemoryLoading = true;
        try {
            const res = await api('list-memories');
            if (res?.ok && Array.isArray(res.memories)) {
                const loaded = [];
                for (const row of res.memories) {
                    try {
                        const text = await crypt().unsealText(row.sealed_content);
                        if (text) {
                            loaded.push({
                                id: row.id,
                                text,
                                category: row.category || 'fact',
                                created: row.created,
                                updated: row.updated
                            });
                        }
                    } catch (e) {
                        console.warn('Could not unseal memory record:', row.id, e);
                    }
                }
                memories = loaded;
                renderMemoryList(chatMemorySearch?.value || '');
            }
        } catch (err) {
            console.error('Failed to load memories:', err);
        } finally {
            isMemoryLoading = false;
        }
    }

    async function saveMemory(text, category = 'fact', id = null) {
        if (!text || !text.trim() || !isUnlocked()) return null;
        const cleanText = text.trim();
        const existing = memories.find(m => m.text.toLowerCase() === cleanText.toLowerCase());
        if (existing && !id) return existing;

        try {
            const sealed = await crypt().sealText(cleanText);
            const res = await api('save-memory', {
                id: id || undefined,
                sealed_content: sealed,
                category
            }, 'POST');
            if (res?.ok) {
                const memObj = {
                    id: res.id,
                    text: cleanText,
                    category: res.category || category,
                    created: res.created || Math.floor(Date.now() / 1000),
                    updated: res.updated || Math.floor(Date.now() / 1000)
                };
                const idx = memories.findIndex(m => m.id === res.id);
                if (idx >= 0) memories[idx] = memObj;
                else memories.unshift(memObj);
                renderMemoryList(chatMemorySearch?.value || '');
                toast('Memory saved.');
                return memObj;
            }
        } catch (err) {
            console.error('Failed to save memory:', err);
            toast('Failed to save memory: ' + err.message, 'error');
        }
        return null;
    }

    async function deleteMemory(id) {
        if (!id) return;
        try {
            const res = await api('delete-memory', { id }, 'POST');
            if (res?.ok) {
                memories = memories.filter(m => m.id !== id);
                renderMemoryList(chatMemorySearch?.value || '');
                toast('Memory deleted.');
            }
        } catch (err) {
            console.error('Failed to delete memory:', err);
            toast('Failed to delete memory.', 'error');
        }
    }

    async function clearAllMemories() {
        if (!memories.length) return;
        if (!confirm('Are you sure you want to delete all saved memories? This cannot be undone.')) return;
        try {
            const res = await api('clear-memories', {}, 'POST');
            if (res?.ok) {
                memories = [];
                renderMemoryList();
                toast('All memories cleared.');
            }
        } catch (err) {
            console.error('Failed to clear memories:', err);
            toast('Failed to clear memories.', 'error');
        }
    }

    function renderMemoryList(filter = '') {
        resolveMemoryElements();
        if (!chatMemoryList) return;
        const query = filter.toLowerCase().trim();
        const filtered = query
            ? memories.filter(m => m.text.toLowerCase().includes(query))
            : memories;

        if (chatMemoryBadge) {
            chatMemoryBadge.textContent = memories.length;
            chatMemoryBadge.hidden = memories.length === 0;
        }

        chatMemoryList.innerHTML = '';
        if (!filtered.length) {
            if (chatMemoryEmpty) {
                chatMemoryEmpty.style.display = 'block';
                chatMemoryEmpty.querySelector('p').textContent = query
                    ? 'No memories match your search.'
                    : 'No memories stored yet. You can add them here or tell the assistant in chat to "remember that...".';
                chatMemoryList.appendChild(chatMemoryEmpty);
            }
            return;
        }

        const fragment = document.createDocumentFragment();
        for (const mem of filtered) {
            const item = document.createElement('div');
            item.className = 'chat-memory-item';
            item.dataset.id = mem.id;

            const body = document.createElement('div');
            body.className = 'chat-memory-item-body';

            const p = document.createElement('p');
            p.className = 'chat-memory-item-text';
            p.textContent = mem.text;
            body.appendChild(p);

            if (mem.created) {
                const timeEl = document.createElement('span');
                timeEl.className = 'chat-memory-item-date';
                timeEl.textContent = `Remembered ${formatTime(mem.created)}`;
                body.appendChild(timeEl);
            }

            const actions = document.createElement('div');
            actions.className = 'chat-memory-item-actions';

            const editBtn = document.createElement('button');
            editBtn.type = 'button';
            editBtn.className = 'chat-memory-item-edit-btn';
            editBtn.title = 'Edit memory';
            editBtn.setAttribute('aria-label', 'Edit memory');
            editBtn.innerHTML = ICONS.edit;
            editBtn.addEventListener('click', () => enterMemoryEditMode(item, mem));

            const delBtn = document.createElement('button');
            delBtn.type = 'button';
            delBtn.className = 'chat-memory-item-del-btn';
            delBtn.title = 'Delete memory';
            delBtn.setAttribute('aria-label', 'Delete memory');
            delBtn.innerHTML = ICONS.trash;
            delBtn.addEventListener('click', () => deleteMemory(mem.id));

            actions.append(editBtn, delBtn);
            item.append(body, actions);
            fragment.appendChild(item);
        }
        chatMemoryList.appendChild(fragment);
    }

    function enterMemoryEditMode(item, mem) {
        if (!item || item.classList.contains('is-editing')) return;
        item.classList.add('is-editing');
        const body = item.querySelector('.chat-memory-item-body');
        const actions = item.querySelector('.chat-memory-item-actions');
        if (!body) return;

        const originalText = mem.text;
        body.innerHTML = `
            <form class="chat-memory-inline-edit" style="display:flex; gap:6px; width:100%; align-items:center;">
                <input type="text" class="chat-memory-edit-input" value="${escapeHtml(originalText)}" maxlength="500" style="flex:1; height:32px; padding:0 8px; font-size:13px; border-radius:6px; border:1px solid var(--border); background:var(--input-bg, var(--surface)); color:var(--text);" required>
                <button type="submit" class="button primary" style="height:32px; padding:0 10px; font-size:12px;">Save</button>
                <button type="button" class="button chat-memory-edit-cancel" style="height:32px; padding:0 8px; font-size:12px;">Cancel</button>
            </form>
        `;
        if (actions) actions.style.display = 'none';

        const form = body.querySelector('form');
        const input = body.querySelector('input');
        const cancelBtn = body.querySelector('.chat-memory-edit-cancel');

        input.focus();
        input.setSelectionRange(input.value.length, input.value.length);

        form.addEventListener('submit', async e => {
            e.preventDefault();
            const val = input.value.trim();
            if (val && val !== originalText) {
                await saveMemory(val, mem.category, mem.id);
            } else {
                renderMemoryList(chatMemorySearch?.value || '');
            }
        });

        cancelBtn.addEventListener('click', () => {
            renderMemoryList(chatMemorySearch?.value || '');
        });
    }

    // -------------------------------------------------------------- Scroll ---
    let pinnedToBottom = true;

    function distanceFromBottom() {
        if (!chatMessagesContainer) return 0;
        return chatMessagesContainer.scrollHeight - chatMessagesContainer.scrollTop - chatMessagesContainer.clientHeight;
    }

    function updatePinnedState() {
        pinnedToBottom = distanceFromBottom() < 90;
        if (chatJumpLatest) chatJumpLatest.hidden = pinnedToBottom;
    }

    function scrollToBottom(behavior = 'auto') {
        if (!chatMessagesContainer) return;
        chatMessagesContainer.scrollTo({ top: chatMessagesContainer.scrollHeight, behavior });
        pinnedToBottom = true;
        if (chatJumpLatest) chatJumpLatest.hidden = true;
    }

    // Streaming must never yank the view down while the user is reading earlier text.
    function keepAnchored() {
        if (pinnedToBottom) scrollToBottom();
    }

    // ------------------------------------------------------------ Messages ---
    function renderEmptyState() {
        if (!chatMessagesContainer) return;
        chatMessagesContainer.innerHTML = `
            <div class="chat-empty-placeholder">
                <div class="chat-empty-icon" aria-hidden="true">
                    <svg viewBox="0 0 24 24" focusable="false"><path d="M21 12a8 8 0 0 1-8 8H7l-4 3V12a8 8 0 0 1 8-8h2a8 8 0 0 1 8 8Z"/></svg>
                </div>
                <h3>Start a conversation</h3>
                <p>Every model in the picker runs privately on the host GPU. Messages and saved images are sealed in this browser before they are stored.</p>
                <div class="chat-suggestions">
                    <button class="chat-suggestion" type="button" data-prompt="Explain how diffusion models turn noise into an image, step by step.">Explain diffusion models</button>
                    <button class="chat-suggestion" type="button" data-prompt="Write a Python function that watches a folder and prints any new file it sees.">Write a Python helper</button>
                    <button class="chat-suggestion" type="button" data-prompt="Give me five prompt ideas for a moody cinematic portrait, with lighting and lens notes.">Brainstorm image prompts</button>
                    <button class="chat-suggestion" type="button" data-prompt="Summarise the trade-offs between Q4_K_M and Q5_K_M quantisation for a 12B model on 12GB of VRAM.">Compare quantisations</button>
                </div>
            </div>`;
    }

    function actionButton(label, iconHtml, handler, extraClass = '') {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = `chat-icon-btn ${extraClass}`.trim();
        button.innerHTML = iconHtml;
        button.title = label;
        button.setAttribute('aria-label', label);
        button.addEventListener('click', handler);
        return button;
    }

    function buildActions(msg) {
        const wrap = document.createElement('div');
        wrap.className = 'chat-msg-actions';

        wrap.appendChild(actionButton('Copy message', ICONS.copy, async (event) => {
            const ok = await copyText(msg.content || '');
            if (ok) flashButton(event.currentTarget);
            else toast('Could not copy to the clipboard.', 'error');
        }));

        if (msg.role === 'user') {
            wrap.appendChild(actionButton('Edit and resend', ICONS.edit, () => beginEdit(msg)));
        }

        const isLast = msg === lastMessage();
        if (isLast && !msg.pending) {
            const label = msg.role === 'assistant' ? 'Regenerate response' : 'Send again';
            wrap.appendChild(actionButton(label, ICONS.regenerate, () => regenerateFrom(msg)));
        }

        wrap.appendChild(actionButton('Delete message', ICONS.trash, () => deleteMessage(msg), 'chat-delete-btn'));
        return wrap;
    }

    function createCompactionMarkerEl(msg) {
        const el = document.createElement('div');
        el.className = 'chat-compaction-marker';
        if (msg.id) el.dataset.msgId = msg.id;

        const lineBefore = document.createElement('span');
        lineBefore.className = 'chat-compaction-line';

        const badge = document.createElement('button');
        badge.type = 'button';
        badge.className = 'chat-compaction-badge';
        const savedStr = msg.tokensSaved ? ` (~${fmtTokens(msg.tokensSaved)} tokens saved)` : '';
        badge.title = 'Click to open Context Window panel';
        badge.innerHTML = `<span class="chat-compaction-icon" aria-hidden="true">📦</span><span>Earlier conversation compacted${savedStr}</span>`;
        badge.addEventListener('click', () => {
            openContextDialog();
        });

        const lineAfter = document.createElement('span');
        lineAfter.className = 'chat-compaction-line';

        el.append(lineBefore, badge, lineAfter);
        msg.el = el;
        return el;
    }

    function createMessageEl(msg) {
        if (msg.role === 'checkpoint') {
            return createCompactionMarkerEl(msg);
        }
        const el = document.createElement('div');
        el.className = `chat-msg ${msg.role}${msg.error ? ' is-error' : ''}`;
        if (msg.id) el.dataset.msgId = msg.id;

        const meta = document.createElement('div');
        meta.className = 'chat-msg-meta';
        const author = document.createElement('span');
        author.className = 'chat-msg-author';
        author.textContent = authorNameFor(msg);
        meta.appendChild(author);
        if (msg.created) {
            const time = document.createElement('time');
            time.className = 'chat-msg-time';
            time.dateTime = new Date(msg.created * 1000).toISOString();
            time.textContent = formatTime(msg.created);
            time.title = fullTime(msg.created);
            meta.appendChild(time);
        }
        el.appendChild(meta);

        if (msg.role === 'assistant') {
            const details = document.createElement('details');
            details.className = 'chat-thinking';
            details.hidden = !msg.reasoning;
            details.open = false;
            const summary = document.createElement('summary');
            summary.addEventListener('click', () => { details.dataset.userToggled = 'true'; });

            const labelSpan = document.createElement('span');
            labelSpan.className = 'thinking-label';
            const timerSpan = document.createElement('span');
            timerSpan.className = 'thinking-timer';
            summary.append(labelSpan, timerSpan);

            const content = document.createElement('div');
            content.className = 'thinking-content';
            content.textContent = msg.reasoning || '';
            details.append(summary, content);
            el.appendChild(details);
            msg.thinkingEl = details;
            msg.thinkingContentEl = content;
            msg.thinkingSummaryEl = summary;
            msg.thinkingLabelEl = labelSpan;
            msg.thinkingTimerEl = timerSpan;

            updateThinkingSummary(msg);
        }

        const bubble = document.createElement('div');
        bubble.className = 'chat-bubble';
        if (msg.role === 'assistant') {
            bubble.innerHTML = renderMarkdown(msg.content || '');
            if (!msg.pending) enhanceBubble(bubble, msg);
        } else {
            if (Array.isArray(msg.images) && msg.images.length > 0) {
                const mediaWrap = document.createElement('div');
                mediaWrap.className = 'chat-msg-media';
                for (const imgUrl of msg.images) {
                    const img = document.createElement('img');
                    img.src = imgUrl;
                    img.className = 'chat-msg-thumb';
                    img.alt = 'Uploaded image';
                    img.loading = 'lazy';
                    img.title = 'Click to open inpaint canvas';
                    img.addEventListener('click', () => {
                        inpaintModal.open(imgUrl, { targetMsg: msg });
                    });
                    mediaWrap.appendChild(img);
                }
                bubble.appendChild(mediaWrap);
            }
            if (Array.isArray(msg.documents) && msg.documents.length > 0) {
                const docsWrap = document.createElement('div');
                docsWrap.className = 'chat-msg-documents';
                for (const doc of msg.documents) {
                    const cardWrap = document.createElement('div');
                    cardWrap.className = 'chat-msg-doc-card';

                    const docPill = document.createElement('div');
                    docPill.className = 'chat-msg-doc-pill';

                    const icon = document.createElement('span');
                    icon.className = 'chat-msg-doc-icon';
                    icon.textContent = (window.DocIngest && window.DocIngest.getDocumentIcon(doc.type)) || '📄';
                    icon.setAttribute('aria-hidden', 'true');

                    const info = document.createElement('div');
                    info.className = 'chat-msg-doc-info';

                    const name = document.createElement('span');
                    name.className = 'chat-msg-doc-name';
                    name.textContent = doc.name;
                    name.title = doc.name;

                    const meta = document.createElement('span');
                    meta.className = 'chat-msg-doc-meta';
                    const pageText = doc.pages ? `${doc.pages} ${doc.pages === 1 ? 'page' : 'pages'} · ` : '';
                    meta.textContent = `${pageText}${doc.formattedSize || ''}${doc.truncated ? ' (truncated)' : ''}`;

                    info.appendChild(name);
                    info.appendChild(meta);
                    docPill.appendChild(icon);
                    docPill.appendChild(info);
                    cardWrap.appendChild(docPill);

                    if (doc.text) {
                        const previewToggle = document.createElement('details');
                        previewToggle.className = 'chat-msg-doc-preview';
                        const summary = document.createElement('summary');
                        summary.textContent = 'View extracted text';
                        const pre = document.createElement('pre');
                        pre.textContent = doc.text;
                        previewToggle.appendChild(summary);
                        previewToggle.appendChild(pre);
                        cardWrap.appendChild(previewToggle);
                    }

                    docsWrap.appendChild(cardWrap);
                }
                bubble.appendChild(docsWrap);
            }
            if (msg.content) {
                const textSpan = document.createElement('span');
                textSpan.className = 'chat-msg-text';
                textSpan.textContent = msg.content;
                bubble.appendChild(textSpan);
            }
        }
        el.appendChild(bubble);
        msg.bubbleEl = bubble;

        if (!msg.pending) el.appendChild(buildActions(msg));

        msg.el = el;
        return el;
    }

    function renderMessages() {
        if (!chatMessagesContainer) return;
        editingMsg = null;
        if (!activeMessages.length) {
            renderEmptyState();
            return;
        }
        const fragment = document.createDocumentFragment();
        for (const msg of activeMessages) fragment.appendChild(createMessageEl(msg));
        chatMessagesContainer.innerHTML = '';
        chatMessagesContainer.appendChild(fragment);
    }

    function appendMessage(msg) {
        if (!chatMessagesContainer) return;
        const placeholder = chatMessagesContainer.querySelector('.chat-empty-placeholder');
        if (placeholder) chatMessagesContainer.innerHTML = '';
        chatMessagesContainer.appendChild(createMessageEl(msg));
        keepAnchored();
    }

    // A finished message needs its toolbar, and the previous message may have
    // lost its "regenerate" affordance now that it is no longer last.
    function settleMessage(msg) {
        msg.pending = false;
        if (!msg.el || msg.role === 'checkpoint') return;
        msg.el.querySelector('.chat-msg-actions')?.remove();
        msg.el.appendChild(buildActions(msg));
        if (msg.id) {
            msg.el.dataset.msgId = msg.id;
            if (msg.thinkingDuration) saveThinkingDuration(msg.id, msg.thinkingDuration);
        }
        updateThinkingSummary(msg);
        const previous = activeMessages[activeMessages.indexOf(msg) - 1];
        if (previous && previous.el) {
            previous.el.querySelector('.chat-msg-actions')?.remove();
            previous.el.appendChild(buildActions(previous));
        }
    }

    // ------------------------------------------------------- Edit / delete ---
    function beginEdit(msg) {
        if (isStreaming()) { toast('Wait for the current response to finish.'); return; }
        if (!msg.el) return;
        if (editingMsg && editingMsg !== msg) renderMessages();
        editingMsg = msg;

        msg.el.querySelector('.chat-bubble').hidden = true;
        msg.el.querySelector('.chat-msg-actions')?.remove();

        const form = document.createElement('form');
        form.className = 'chat-edit-form';
        form.innerHTML = `
            <textarea maxlength="${maxTypedChars()}" aria-label="Edit message"></textarea>
            <div class="chat-edit-actions">
                <span class="chat-edit-hint">Replies after this message will be discarded.</span>
                <button type="button" data-act="cancel">Cancel</button>
                <button type="submit" class="primary">Save &amp; resend</button>
            </div>`;
        const textarea = form.querySelector('textarea');
        textarea.value = msg.content || '';

        form.addEventListener('submit', event => {
            event.preventDefault();
            const text = textarea.value.trim();
            if (!text) return;
            if (text === msg.content) { renderMessages(); return; }
            commitEdit(msg, text);
        });
        form.querySelector('[data-act="cancel"]').addEventListener('click', () => {
            editingMsg = null;
            renderMessages();
            chatInput?.focus();
        });
        textarea.addEventListener('keydown', event => {
            if (event.isComposing) return;

            if (event.key === 'Enter') {
                if (event.ctrlKey || event.metaKey) {
                    event.preventDefault();
                    form.requestSubmit();
                    return;
                }
                if (isMobileDevice()) {
                    return;
                }
                if (!event.shiftKey) {
                    event.preventDefault();
                    form.requestSubmit();
                    return;
                }
            } else if (event.key === 'Escape') {
                event.preventDefault();
                editingMsg = null;
                renderMessages();
                chatInput?.focus();
            }
        });
        textarea.addEventListener('input', () => {
            textarea.style.height = 'auto';
            textarea.style.height = Math.min(320, Math.max(76, textarea.scrollHeight)) + 'px';
        });

        msg.el.appendChild(form);
        textarea.focus();
        textarea.setSelectionRange(textarea.value.length, textarea.value.length);
        textarea.style.height = 'auto';
        textarea.style.height = Math.min(320, Math.max(76, textarea.scrollHeight)) + 'px';
    }

    function resendImages(msg) {
        return (msg.images || []).map((image, index) => ({
            ...(typeof image === 'string' ? { dataUrl: image } : image),
            maskDataUrl: msg.masks?.[index] || image?.maskDataUrl || null
        }));
    }

    async function commitEdit(msg, text) {
        editingMsg = null;
        const images = resendImages(msg);
        const documents = msg.documents || [];
        const trimmed = await truncateFrom(msg);
        if (!trimmed) return;
        await sendMessage(text, images, documents);
    }

    async function regenerateFrom(msg) {
        if (isStreaming()) { toast('Wait for the current response to finish.'); return; }
        const index = activeMessages.indexOf(msg);
        if (index < 0) return;

        let anchor = msg;
        if (msg.role === 'assistant') {
            let cursor = index - 1;
            while (cursor >= 0 && activeMessages[cursor].role !== 'user') cursor--;
            if (cursor < 0) { toast('Nothing to regenerate from.', 'error'); return; }
            anchor = activeMessages[cursor];
        }
        const text = anchor.content || '';
        const images = resendImages(anchor);
        const documents = anchor.documents || [];
        if (!text && !images.length && !documents.length) { toast('That message has no content to resend.', 'error'); return; }

        const trimmed = await truncateFrom(anchor);
        if (!trimmed) return;
        await sendMessage(text, images, documents);
    }

    // Drops `msg` and everything after it, locally and on the server.
    async function truncateFrom(msg) {
        const index = activeMessages.indexOf(msg);
        if (index < 0) return false;
        try {
            if (msg.id && activeChatId) {
                const doomedJobIds = activeMessages.slice(index).flatMap(m => extractJobIdsFromText(m.content));
                await api('trim-messages', { chat_id: activeChatId, from_message_id: msg.id, job_ids: doomedJobIds }, 'POST');
            }
        } catch (err) {
            toast(err.message || 'Could not edit the conversation.', 'error');
            return false;
        }
        activeMessages.splice(index);
        recomputeCursor();
        renderMessages();
        notifyChatSync('chat-updated', activeChatId);
        window.dispatchEvent(new CustomEvent('studio-jobs-changed'));
        return true;
    }

    async function deleteMessage(msg) {
        if (isStreaming()) { toast('Wait for the current response to finish.'); return; }
        const ok = await confirmDialog({
            title: 'Delete message',
            message: 'This removes the single message from the conversation. It cannot be undone.',
            confirmLabel: 'Delete'
        });
        if (!ok) return;

        try {
            if (msg.id && activeChatId) {
                const doomedJobIds = extractJobIdsFromText(msg.content);
                await api('delete-message', { chat_id: activeChatId, message_id: msg.id, job_ids: doomedJobIds }, 'POST');
            }
        } catch (err) {
            toast(err.message || 'Could not delete the message.', 'error');
            return;
        }
        const index = activeMessages.indexOf(msg);
        if (index >= 0) activeMessages.splice(index, 1);
        recomputeCursor();
        renderMessages();
        notifyChatSync('chat-updated', activeChatId);
        window.dispatchEvent(new CustomEvent('studio-jobs-changed'));
        toast('Message deleted.');
    }

    function recomputeCursor() {
        lastMsgId = null;
        for (let i = activeMessages.length - 1; i >= 0; i--) {
            if (activeMessages[i].id) { lastMsgId = activeMessages[i].id; break; }
        }
    }

    // ------------------------------------------------------------- Sidebar ---
    function filteredChats() {
        if (!searchTerm) return chats;
        const needle = searchTerm.toLowerCase();
        return chats.filter(chat => (chat.title || '').toLowerCase().includes(needle));
    }

    function renderChatList() {
        if (!chatSessionsList) return;
        const visible = filteredChats();

        if (!visible.length) {
            chatSessionsList.innerHTML = `<p class="chat-sidebar-empty">${
                searchTerm ? 'No conversations match that search.' : 'No conversations yet.<br>Start one below.'
            }</p>`;
            return;
        }

        const fragment = document.createDocumentFragment();
        let currentGroup = null;
        for (const chat of visible) {
            const group = dayBucket(chat.updated);
            if (group !== currentGroup && !searchTerm) {
                currentGroup = group;
                const heading = document.createElement('div');
                heading.className = 'chat-list-group';
                heading.textContent = group;
                fragment.appendChild(heading);
            }

            const liveJob = jobForChat(chat.id);
            // `active_job_id` comes from the chat row and can lag a cancellation by a
            // sync cycle, so a job this tab already retired never counts as live.
            const generating = Boolean(liveJob)
                || (Boolean(chat.active_job_id) && !finishedJobs.has(chat.active_job_id));
            const item = document.createElement('button');
            item.type = 'button';
            item.className = `chat-session-item${chat.id === activeChatId ? ' active' : ''}`;
            item.dataset.chatId = chat.id;

            if (generating) {
                const dot = document.createElement('span');
                dot.className = 'chat-item-live-indicator';
                dot.title = liveJob?.status === 'queued'
                    ? `Waiting in the queue${liveJob.queue_position ? ` — ${ordinal(liveJob.queue_position)} in line` : ''}`
                    : 'Generating a response';
                item.appendChild(dot);
            }

            const body = document.createElement('span');
            body.className = 'chat-session-body';
            const title = document.createElement('span');
            title.className = 'chat-session-title';
            title.textContent = chat.title || 'Untitled chat';
            const time = document.createElement('span');
            time.className = 'chat-session-time';
            time.textContent = formatTime(chat.updated);
            body.append(title, time);
            item.appendChild(body);

            const menuBtn = document.createElement('span');
            menuBtn.className = 'chat-session-menu-btn';
            menuBtn.setAttribute('role', 'button');
            menuBtn.setAttribute('tabindex', '0');
            menuBtn.setAttribute('aria-label', `Options for ${chat.title || 'Untitled chat'}`);
            menuBtn.innerHTML = ICONS.dots;
            const openMenu = event => {
                event.stopPropagation();
                event.preventDefault();
                showRowMenu(chat, menuBtn);
            };
            menuBtn.addEventListener('click', openMenu);
            menuBtn.addEventListener('keydown', event => {
                if (event.key === 'Enter' || event.key === ' ') openMenu(event);
            });
            item.appendChild(menuBtn);

            item.addEventListener('click', () => selectChat(chat.id));
            fragment.appendChild(item);
        }

        chatSessionsList.innerHTML = '';
        chatSessionsList.appendChild(fragment);
    }

    function renderQueueChip() {
        if (!chatQueueChip || !chatQueueCount) return;
        const waiting = activeJobs.filter(job => job.status === 'queued').length;
        chatQueueChip.hidden = waiting === 0;
        if (!waiting) return;
        const full = waiting >= MAX_QUEUED;
        chatQueueCount.textContent = full ? `${waiting} / ${MAX_QUEUED} waiting` : `${waiting} waiting`;
        chatQueueChip.classList.toggle('is-full', full);
        chatQueueChip.title = full
            ? `The queue is full (${MAX_QUEUED} messages). Clear it, or wait for one to be answered.`
            : `${waiting} of ${MAX_QUEUED} queue slots used. Click to clear the queue.`;
    }

    async function cancelQueued({ chatId = null, label } = {}) {
        const ok = await confirmDialog({
            title: chatId ? 'Cancel this message' : 'Clear the queue',
            message: label,
            confirmLabel: chatId ? 'Cancel message' : 'Clear queue'
        });
        if (!ok) return;

        try {
            const res = await api('cancel-queued', chatId ? { chat_id: chatId } : {}, 'POST');
            const count = res.cancelled || 0;
            activeJobs = activeJobs.filter(job => !(res.job_ids || []).includes(job.job_id));
            (res.job_ids || []).forEach(markJobFinished);
            renderQueueChip();
            renderChatList();
            toast(count === 1 ? 'Message cancelled.' : `${count} messages cancelled.`);
            notifyChatSync('chat-updated');
            scheduleSync(150);
        } catch (err) {
            toast(err.message || 'Could not cancel.', 'error');
        }
    }

    // Cancels one conversation's pending message, whether it is queued or already
    // being generated. `stop` covers both states for a single job.
    async function cancelChatJob(chat) {
        const job = jobForChat(chat.id);
        if (!job) return;
        if (stream && stream.jobId === job.job_id) {
            await stopGenerating();
            return;
        }
        if (job.status === 'running') {
            const ok = await confirmDialog({
                title: 'Stop this reply',
                message: `"${chat.title || 'This conversation'}" is being answered right now. Stopping discards the partial reply.`,
                confirmLabel: 'Stop reply'
            });
            if (!ok) return;
            try {
                await api('stop', { job_id: job.job_id }, 'POST');
                markJobFinished(job.job_id);
                activeJobs = activeJobs.filter(entry => entry.job_id !== job.job_id);
                renderQueueChip();
                renderChatList();
                toast('Reply stopped.');
                scheduleSync(150);
            } catch (err) {
                toast(err.message || 'Could not stop the reply.', 'error');
            }
            return;
        }
        await cancelQueued({
            chatId: chat.id,
            label: `The message waiting in "${chat.title || 'this conversation'}" will not be answered. It stays in the conversation, so you can send it again later.`
        });
    }

    function closeRowMenu() {
        if (openRowMenu) {
            openRowMenu.remove();
            openRowMenu = null;
        }
    }

    function showRowMenu(chat, anchorEl) {
        closeRowMenu();
        const menu = document.createElement('div');
        menu.className = 'chat-row-menu';
        menu.setAttribute('role', 'menu');
        const pending = jobForChat(chat.id);
        menu.innerHTML = `
            ${pending ? `<button type="button" role="menuitem" data-act="cancel">${ICONS.stop}<span>${pending.status === 'running' ? 'Stop reply' : 'Cancel message'}</span></button>` : ''}
            <button type="button" role="menuitem" data-act="rename">${ICONS.edit}<span>Rename</span></button>
            <button type="button" role="menuitem" data-act="copy">${ICONS.copy}<span>Copy transcript</span></button>
            <button type="button" role="menuitem" data-act="delete" class="danger">${ICONS.trash}<span>Delete</span></button>`;
        document.body.appendChild(menu);

        const rect = anchorEl.getBoundingClientRect();
        const top = Math.min(rect.bottom + 4, window.innerHeight - menu.offsetHeight - 8);
        const left = Math.min(rect.left - 120, window.innerWidth - menu.offsetWidth - 8);
        menu.style.top = `${Math.max(8, top)}px`;
        menu.style.left = `${Math.max(8, left)}px`;

        menu.addEventListener('click', async event => {
            const button = event.target.closest('button');
            if (!button) return;
            closeRowMenu();
            if (button.dataset.act === 'cancel') {
                await cancelChatJob(chat);
            } else if (button.dataset.act === 'rename') {
                if (chat.id !== activeChatId) await selectChat(chat.id);
                beginTitleEdit();
            } else if (button.dataset.act === 'copy') {
                if (chat.id !== activeChatId) await selectChat(chat.id);
                copyTranscript();
            } else if (button.dataset.act === 'delete') {
                deleteChat(chat.id, chat.title);
            }
        });
        menu.querySelector('button')?.focus();
        openRowMenu = menu;
    }

    async function loadChats(autoSelectFirst = true) {
        try {
            const res = await api('list-chats');
            chats = await hydrateChats(res.chats);
            renderChatList();
            if (autoSelectFirst && !activeChatId && chats.length > 0) {
                await selectChat(chats[0].id);
            }
        } catch (err) {
            console.warn('Failed to load chats:', err);
        }
    }

    function collapseSidebarOnMobile() {
        if (window.innerWidth <= 760 && chatSidebar) {
            setMobileSidebar(false);
        }
    }

    // -------------------------------------------------------- Chat loading ---
    async function selectChat(chatId) {
        if (chatId === activeChatId && activeMessages.length) {
            collapseSidebarOnMobile();
            return;
        }
        // Leaving a generating chat only detaches this tab's reader; the job keeps
        // running on the PC and sync re-attaches when the chat is reopened.
        detachStream();
        collapseSidebarOnMobile();

        activeChatId = chatId;
        activeMessages = [];
        lastMsgId = null;
        editingMsg = null;
        if (attachedImages.length > 0 || attachedDocuments.length > 0) {
            attachedImages = [];
            attachedDocuments = [];
            renderAttachmentTray();
        }
        renderChatList();
        updateHeaderState();

        const known = chats.find(chat => chat.id === chatId);
        if (activeChatTitle) activeChatTitle.textContent = known?.title || 'Conversation';
        const earlyModel = jobForChat(chatId)?.model || known?.model;
        if (earlyModel && chatModelSelect && [...chatModelSelect.options].some(o => o.value === earlyModel)) {
            if (chatModelSelect.value !== earlyModel) {
                chatModelSelect.value = earlyModel;
                try { localStorage.setItem(MODEL_KEY, earlyModel); } catch (_) {}
                applyModelCapabilities();
            }
        }
        if (chatMessagesContainer) {
            chatMessagesContainer.innerHTML = '<p class="chat-sidebar-empty">Decrypting conversation…</p>';
        }

        try {
            const res = await api('get-chat', null, 'GET', { chat_id: chatId });
            if (activeChatId !== chatId) return; // user moved on while decrypting

            if (res.chat?.model && known) {
                known.model = res.chat.model;
            }

            const fetchedTitle = await readTitle(res.chat?.title);
            if (fetchedTitle && activeChatTitle && !activeChatTitle.hidden) {
                activeChatTitle.textContent = fetchedTitle;
            }

            for (const row of res.messages || []) {
                const rawContent = isUnlocked()
                    ? await unseal(row.sealed_content, '[Sealed with a different Studio key]')
                    : '[Locked — unlock Studio to decrypt]';
                let content = rawContent;
                let images = null;
                let masks = null;
                let documents = null;
                let isCheckpoint = (row.role === 'checkpoint');
                let checkpointData = null;
                if (typeof rawContent === 'string' && rawContent.startsWith('{')) {
                    try {
                        const parsed = JSON.parse(rawContent);
                        if (parsed && parsed.type === 'compaction_checkpoint') {
                            isCheckpoint = true;
                            checkpointData = parsed;
                            content = parsed.summary || '';
                        } else if (parsed && (Array.isArray(parsed.images) || Array.isArray(parsed.documents))) {
                            content = parsed.text || '';
                            if (Array.isArray(parsed.images)) {
                                images = parsed.images;
                                if (Array.isArray(parsed.masks)) {
                                    masks = parsed.masks;
                                    images.forEach((url, i) => {
                                        if (masks[i] && url) {
                                            imageMaskMap.set(url, { maskDataUrl: masks[i], src: url });
                                        }
                                    });
                                }
                            }
                            if (Array.isArray(parsed.documents)) {
                                documents = parsed.documents;
                            }
                        }
                    } catch (_) {}
                }
                const dur = (typeof row.thinking_duration === 'number' && row.thinking_duration > 0)
                    ? row.thinking_duration
                    : getThinkingDuration(row.id);
                if (dur && row.id) saveThinkingDuration(row.id, dur);

                activeMessages.push({
                    id: row.id,
                    role: isCheckpoint ? 'checkpoint' : row.role,
                    created: row.created,
                    content,
                    summary: isCheckpoint ? (checkpointData?.summary || content) : null,
                    throughId: isCheckpoint ? (checkpointData?.through_id || null) : null,
                    keepIds: isCheckpoint ? (checkpointData?.keep_ids || null) : null,
                    tokensSaved: isCheckpoint ? (checkpointData?.tokens_saved || 0) : 0,
                    images,
                    masks,
                    documents,
                    reasoning: isUnlocked() ? await unseal(row.sealed_reasoning) : '',
                    model: row.model || null,
                    thinkingDuration: dur
                });
            }
            activeMessages = sortMessagesWithCheckpoints(activeMessages);
            recomputeCursor();
            renderMessages();
            scrollToBottom();

            // Restore the meter from the newest turn that carried a breakdown.
            // Conversations answered before this shipped have none, and fall back
            // to the estimate rather than showing a conversation as costing zero.
            measuredUsage = null;
            const lastUsageRow = [...(res.messages || [])].reverse().find(r => r.sealed_usage);
            if (lastUsageRow && isUnlocked()) await applySealedUsage(lastUsageRow.sealed_usage);
            updateHeaderState();

            const job = res.active_job || jobForChat(chatId);
            const chatModel = job?.model || res.chat?.model || known?.model || [...activeMessages].reverse().find(m => m.model)?.model;
            if (chatModel && chatModelSelect && [...chatModelSelect.options].some(o => o.value === chatModel)) {
                if (chatModelSelect.value !== chatModel) {
                    chatModelSelect.value = chatModel;
                    try { localStorage.setItem(MODEL_KEY, chatModel); } catch (_) {}
                    applyModelCapabilities();
                }
            }
            if (job && job.chat_id === chatId) attachStream(job);
        } catch (err) {
            console.error('Failed to get chat:', err);
            if (activeChatId !== chatId || !chatMessagesContainer) return;
            chatMessagesContainer.innerHTML = `
                <div class="chat-sidebar-empty">
                    <p style="color:#ef4444;margin-bottom:12px;">${escapeHtml(err.message)}</p>
                    <button class="chat-suggestion" type="button" data-retry>Try again</button>
                </div>`;
            chatMessagesContainer.querySelector('[data-retry]')?.addEventListener('click', () => {
                activeChatId = null;
                selectChat(chatId);
            });
        }
    }

    function startNewChat() {
        if (isStreaming()) detachStream();
        collapseSidebarOnMobile();
        activeChatId = null;
        activeMessages = [];
        lastMsgId = null;
        editingMsg = null;
        // A fresh conversation carries none of the last one's context.
        measuredUsage = null;
        if (attachedImages.length > 0 || attachedDocuments.length > 0) {
            attachedImages = [];
            attachedDocuments = [];
            renderAttachmentTray();
        }
        renderChatList();
        if (activeChatTitle) activeChatTitle.textContent = 'New conversation';
        renderEmptyState();
        updateHeaderState();
        if (chatInput) {
            chatInput.value = '';
            autoResizeInput();
            updateCharCount();
            chatInput.focus();
        }
    }

    function updateHeaderState() {
        const hasChat = Boolean(activeChatId);
        const hasMessages = activeMessages.length > 0;
        if (chatTitleEditBtn) chatTitleEditBtn.disabled = !hasChat;
        if (chatDeleteBtn) chatDeleteBtn.disabled = !hasChat;
        if (chatCopyAllBtn) chatCopyAllBtn.disabled = !hasMessages;
        if (chatExportBtn) chatExportBtn.disabled = !hasMessages;
        renderContextMeter();
    }

    // ------------------------------------------------ Context window meter ---
    //
    // Two numbers feed this, and the difference matters enough that the UI always
    // says which one it is showing.
    //
    // The *measured* one comes back sealed from the PC after every turn: the
    // tokenizer that will actually run the prompt counted it, broken down by
    // section. It is exact, and it describes the turn that has already happened.
    //
    // The *estimated* one is this file's own arithmetic over what is on screen
    // plus whatever is in the composer. It is what makes the ring move while you
    // type. It reuses the measured system-prompt and memory figures from the last
    // turn wherever it can, so it is only really guessing about the conversation
    // text - which is the part it can see most accurately anyway.
    //
    // These mirror the worker's constants. They are display-side only: the PC
    // re-derives all of them and is the authority. If they drift, the meter is
    // wrong by a little until the next turn corrects it - nothing breaks.
    const CTX_MARGIN = 512;
    const CTX_MIN_OUTPUT = 1024;
    const CTX_MAX_OUTPUT = 8192;
    // Stand-in for the system prompt until a real turn reports its true size.
    // Deliberately on the high side: over-reporting free space is the failure that
    // surprises someone mid-conversation.
    const CTX_SYSTEM_FALLBACK = 1400;
    // The worker prices text at chars/3 when it cannot tokenize. Same ratio here,
    // for the same reason: it is close enough to steer a UI and never pretends to
    // be exact.
    const CHARS_PER_TOKEN = 3;

    const CTX_SECTIONS = [
        { key: 'messages',  label: 'Messages', hint: 'The conversation itself — every turn sent to the model this time.' },
        { key: 'compacted', label: 'Compacted briefing', hint: 'Distilled summary of earlier conversation turns.' },
        { key: 'system',    label: 'System prompt', hint: 'The model\'s standing instructions. Fixed per model and per turn type.' },
        { key: 'memories',  label: 'Memories', hint: 'Facts saved about you, injected into the system prompt. Managed from the memory panel.' },
        { key: 'images',    label: 'Images', hint: 'Attachments, priced at this model\'s per-image rate.' },
        { key: 'search',    label: 'Web search', hint: 'Results pulled in by the Search web toggle, folded into your last message.' }
    ];

    // Last breakdown the PC sent back, or null before the first reply lands.
    let measuredUsage = null;

    function modelContextLimit() {
        const raw = Number(selectedModelOption()?.dataset.ctx);
        return Number.isFinite(raw) && raw > 0 ? raw : 32768;
    }

    // What is left of the window once room is set aside for everything that is
    // not the attachment: the system prompt, the memories, the question itself, a
    // little history and the reply. That reserve is close to fixed - a reply does
    // not get longer because the window did - so this is the window minus a
    // constant rather than a fraction of it. Taking half of a 128K window would
    // throw away 60K tokens that nothing else was going to use.
    const MIN_DOCUMENT_CHARS = 2000;
    const CTX_ATTACHMENT_RESERVE = 12288;
    // Attachments are billed at close to what text actually measures. Sampled on
    // 2026-09-14 across all four tokenizers, a 443,723-character prose document
    // came out at 4.35 to 4.66 characters per token, so pricing it at the meter's
    // chars/3 - let alone lower - would have refused two thirds of a file that
    // fits with room to spare.
    //
    // Being wrong in this direction used to be the dangerous one: the worker pins
    // the final turn, and context shift is disabled on the server, so an overrun
    // was a failed reply rather than a shorter one. It is not any more. When the
    // question still overflows after history is trimmed, the worker now cuts the
    // turn's own text down by measurement (shrink_final_turn). So this number can
    // sit near the truth for prose and let the side holding the tokenizer handle
    // the documents that tokenize worse - code, CJK, dense tables.
    const DOC_CHARS_PER_TOKEN = 4;
    function documentCharBudget() {
        const usable = modelContextLimit() - CTX_ATTACHMENT_RESERVE;
        return Math.max(MIN_TYPED_CHARS, Math.floor(usable * DOC_CHARS_PER_TOKEN));
    }

    function modelImageTokens() {
        const raw = Number(selectedModelOption()?.dataset.imageTokens);
        return Number.isFinite(raw) && raw >= 0 ? raw : 300;
    }

    const textTokens = text => Math.ceil((text || '').length / CHARS_PER_TOKEN);

    // What the next turn would cost if it were sent right now. Mirrors the history
    // walk in sendMessage() so the meter measures what would actually travel, not
    // the whole conversation - a turn the client is about to drop for its own
    // budget reasons must not show up as context in use.
    function estimateContextUsage() {
        const ctx = modelContextLimit();
        const perImage = modelImageTokens();
        const vision = modelSupportsVision();

        const latestCheckpoint = [...activeMessages].reverse().find(m => m.role === 'checkpoint');
        const uncompactedMessages = messagesAfterCheckpoint(latestCheckpoint);

        const recent = uncompactedMessages
            .filter(msg => !msg.pending && msg.role !== 'checkpoint' && (msg.content || (Array.isArray(msg.images) && msg.images.length) || (Array.isArray(msg.documents) && msg.documents.length)))
            .slice(-HISTORY_DEPTH);

        let chars = 0;
        let images = 0;
        let turns = 0;
        let imagesDropped = 0;
        const historyBudget = historyCharBudget();
        for (let i = recent.length - 1; i >= 0; i--) {
            const msg = recent[i];
            const text = msg.content || '';
            const docChars = Array.isArray(msg.documents) ? msg.documents.reduce((acc, d) => acc + (d.charCount || d.text?.length || 0), 0) : 0;
            const turnChars = text.length + docChars;
            if (turns && chars + turnChars > historyBudget) break;
            chars += turnChars;
            const count = Array.isArray(msg.images) ? msg.images.length : 0;
            // Mirrors sendMessage()'s rule exactly, including that it is
            // all-or-nothing per message: a turn carrying more attachments than
            // the remaining budget sends none of them rather than a subset. The
            // meter has to agree with what actually travels, so it counts the
            // same way - and reports the shortfall so a zero has an explanation.
            const withImages = vision && msg.role === 'user' && count > 0
                && (recent.length - 1 - i) < HISTORY_IMAGE_DEPTH
                && images + count <= HISTORY_IMAGE_LIMIT;
            if (withImages) images += count;
            else if (count > 0 && msg.role === 'user') imagesDropped += count;
            turns++;
        }

        // The unsent draft counts: the whole point of a live meter is seeing the
        // cost of what you are about to send before you send it.
        const draft = chatInput?.value || '';
        chars += draft.length;
        if (attachedDocuments.length) {
            chars += attachedDocuments.reduce((acc, d) => acc + (d.charCount || d.text?.length || 0), 0);
        }
        if (vision && attachedImages.length) {
            // The tray follows the same all-or-nothing rule once it is sent.
            if (images + attachedImages.length <= HISTORY_IMAGE_LIMIT) images += attachedImages.length;
            else imagesDropped += attachedImages.length;
        } else if (!vision && attachedImages.length) {
            imagesDropped += attachedImages.length;
        }

        // Prefer the last turn's real figures for the parts the browser cannot see.
        const systemTokens = measuredUsage?.parts?.system ?? CTX_SYSTEM_FALLBACK;
        const memoryTokens = measuredUsage?.parts?.memories ?? estimateMemoryTokens();
        const compactedTokens = measuredUsage?.parts?.compacted ?? (latestCheckpoint?.summary ? textTokens(latestCheckpoint.summary) : 0);
        // Search cost is unknowable until the results come back, so it is left out
        // rather than guessed at. The panel says so when the toggle is on.
        const parts = {
            messages: Math.ceil(chars / CHARS_PER_TOKEN),
            compacted: compactedTokens,
            system: systemTokens,
            memories: memoryTokens,
            images: images * perImage,
            search: 0
        };
        const promptTokens = parts.messages + parts.compacted + parts.system + parts.memories + parts.images;
        const room = ctx - promptTokens - CTX_MARGIN;
        const replyReserve = Math.max(CTX_MIN_OUTPUT, Math.min(CTX_MAX_OUTPUT, room)) + CTX_MARGIN;

        return {
            ctx,
            prompt_tokens: promptTokens,
            reply_reserve: replyReserve,
            free: Math.max(0, ctx - promptTokens - replyReserve),
            measured: false,
            turns_sent: turns,
            turns_dropped: Math.max(0, recent.length - turns),
            images_dropped: imagesDropped,
            parts
        };
    }

    // Memories live in the system prompt, and the block has fixed scaffolding
    // around the facts themselves. Close enough before the first measured turn.
    function estimateMemoryTokens() {
        const texts = memories.map(m => m && m.text).filter(Boolean);
        if (!texts.length) return 0;
        return textTokens(texts.join('\n')) + 60;
    }

    // The measured figure describes the last completed turn. Once the user types
    // or the conversation grows past it, the estimate is the more honest answer -
    // so the meter shows whichever describes what would be sent *next*.
    function currentContextUsage() {
        const live = estimateContextUsage();
        if (!measuredUsage) return live;
        if (measuredUsage.ctx !== live.ctx) return live;
        // Nothing has been added since the PC last counted: show its exact number.
        if (live.prompt_tokens <= measuredUsage.prompt_tokens) return measuredUsage;
        return live;
    }

    const fmtTokens = n => {
        const v = Math.max(0, Math.round(n || 0));
        if (v < 1000) return String(v);
        const k = v / 1000;
        return (k < 100 ? k.toFixed(1) : Math.round(k)) + 'k';
    };

    function renderContextMeter() {
        if (!chatContextBtn) return;
        const usage = currentContextUsage();
        const ctx = usage.ctx || 1;
        const pct = Math.max(0, Math.min(100, Math.round((usage.prompt_tokens / ctx) * 100)));
        const over = usage.prompt_tokens > ctx;

        // A conic ring beats an SVG arc here: one CSS variable to update, no
        // per-frame path maths while someone is typing.
        chatContextBtn.style.setProperty('--ctx-pct', String(pct));
        chatContextBtn.classList.toggle('is-warn', pct >= 75 && !over);
        chatContextBtn.classList.toggle('is-over', over);
        chatContextBtn.classList.toggle('is-estimated', !usage.measured);
        if (chatContextPct) chatContextPct.textContent = over ? '!' : `${pct}%`;

        const precision = usage.measured ? 'measured on your PC' : 'estimated in this browser';
        chatContextBtn.title = over
            ? `Context window over budget — the PC will drop the oldest turns. ${fmtTokens(usage.prompt_tokens)} of ${fmtTokens(ctx)} (${precision}). Click for the breakdown.`
            : `Context window ${pct}% used — ${fmtTokens(usage.prompt_tokens)} of ${fmtTokens(ctx)} (${precision}). Click for the breakdown.`;
        chatContextBtn.setAttribute('aria-label', `Context window ${pct} percent used. Click for the breakdown.`);

        if (chatContextDialog?.open) renderContextPanel(usage);
    }

    function renderContextPanel(usage) {
        if (!chatContextBody) return;
        const ctx = usage.ctx || 1;
        const pctOf = n => ((Math.max(0, n) / ctx) * 100);
        const rows = CTX_SECTIONS
            .map(section => ({ ...section, value: Math.max(0, usage.parts?.[section.key] || 0) }))
            .filter(row => row.value > 0 || row.key === 'messages');

        const bar = rows.map(row =>
            `<span class="ctx-bar-seg ctx-seg-${row.key}" style="width:${pctOf(row.value).toFixed(2)}%" title="${escapeHtml(row.label)}"></span>`
        ).join('') +
            `<span class="ctx-bar-seg ctx-seg-reserve" style="width:${pctOf(usage.reply_reserve).toFixed(2)}%" title="Reserved for the reply"></span>`;

        const line = (cls, label, value, hint) => `
            <li class="ctx-row ${cls}">
                <span class="ctx-swatch ctx-seg-${cls}" aria-hidden="true"></span>
                <span class="ctx-row-label" title="${escapeHtml(hint || '')}">${escapeHtml(label)}</span>
                <span class="ctx-row-value">${fmtTokens(value)}</span>
                <span class="ctx-row-pct">${pctOf(value).toFixed(1)}%</span>
            </li>`;

        const notes = [];
        if (!usage.measured) {
            notes.push('These are this browser\'s estimates. The exact figures arrive with the next reply, counted by the tokenizer that runs the model.');
        }
        if (enableSearchCheckbox?.checked && !usage.parts?.search) {
            notes.push('Search is on. Results are fetched on the PC, so their cost only appears after the reply.');
        }
        if (usage.turns_dropped > 0) {
            notes.push(`${usage.turns_dropped} older turn${usage.turns_dropped === 1 ? '' : 's'} will not be sent — the conversation is longer than the window.`);
        }
        // Attachments travel all-or-nothing per message, and the composer accepts
        // more of them than the history budget carries. Without this line the
        // Images row just reads zero while the tray plainly shows pictures.
        if (usage.images_dropped > 0) {
            notes.push(`${usage.images_dropped} attachment${usage.images_dropped === 1 ? '' : 's'} will not reach the model. A message sends all of its images or none, and at most ${HISTORY_IMAGE_LIMIT} travel with a turn — send fewer per message to be sure they are seen.`);
        }
        if (usage.prompt_tokens > ctx) {
            notes.push('This is over the window. Your PC will drop the oldest turns until it fits, so the model will not see the start of this conversation.');
        } else if (usage.reply_reserve <= CTX_MIN_OUTPUT + CTX_MARGIN) {
            notes.push('Room for the reply is down to the minimum. Answers may get cut off — start a new conversation to clear it.');
        }

        const latestCheckpoint = [...activeMessages].reverse().find(m => m.role === 'checkpoint');
        const candidateTurns = getCompactionCandidates();
        const canCompact = candidateTurns.length >= 2 && !isStreaming() && !isCompacting;
        const candidateTokens = candidateTurns.reduce((acc, m) => acc + turnTokens(m), 0);

        let compactNote = '';
        if (isCompacting) {
            compactNote = 'Distilling earlier messages into a dense, verified context briefing to free up context space…';
        } else if (latestCheckpoint) {
            const savedStr = latestCheckpoint.tokensSaved ? ` (~${fmtTokens(latestCheckpoint.tokensSaved)} tokens saved)` : '';
            if (canCompact) {
                compactNote = `Active context briefing in effect${savedStr}. ${candidateTurns.length} subsequent messages can be compacted further to reclaim ~${fmtTokens(candidateTokens)} more tokens.`;
            } else {
                compactNote = `Active context briefing in effect${savedStr}. You can compact further as more turns accumulate.`;
            }
        } else if (canCompact) {
            compactNote = `${candidateTurns.length} earlier messages can be compacted to reclaim ~${fmtTokens(candidateTokens)} tokens.`;
        } else {
            compactNote = 'Context compaction becomes available once a conversation has at least 2 turns to summarize.';
        }

        const cp = isCompacting ? computeCompactionProgress() : null;

        const compactBox = `
            <div class="ctx-compact-box">
                <div class="ctx-compact-header">
                    <span class="ctx-compact-title"><span class="chat-compaction-icon" aria-hidden="true">📦</span> Context Compaction</span>
                    <div style="display:flex;align-items:center;gap:8px;">
                        ${latestCheckpoint && !isCompacting ? `<button class="button text-button" id="ctx-reset-compact-btn" type="button" style="font-size:11.5px;padding:4px 8px;color:var(--muted);" title="Remove active compaction briefing">↺ Reset</button>` : ''}
                        <button class="button primary ctx-compact-btn" id="ctx-compact-btn" type="button" ${canCompact ? '' : 'disabled'}>
                            ${isCompacting ? `Compacting… ${cp ? `${cp.pct}% (${cp.etaStr || `${cp.elapsed}s`})` : ''}` : '⚡ Compact Now'}
                        </button>
                    </div>
                </div>
                ${isCompacting && cp ? `
                    <div class="ctx-compact-progress-wrap">
                        <div class="ctx-compact-progress-track">
                            <div class="ctx-compact-progress-fill" style="width: ${cp.pct}%"></div>
                        </div>
                        <div class="ctx-compact-progress-meta">
                            <span class="ctx-compact-meta-stage">${escapeHtml(cp.stageDesc)} · ${cp.elapsed}s elapsed</span>
                            <span class="ctx-compact-meta-eta">${cp.pct}%${cp.etaStr ? ` · ${escapeHtml(cp.etaStr)}` : ''}</span>
                        </div>
                    </div>
                ` : ''}
                <p class="ctx-compact-note">${escapeHtml(compactNote)}</p>
                ${latestCheckpoint?.summary ? `
                    <details class="ctx-summary-preview" ${isCompacting ? '' : 'open'}>
                        <summary>View active context briefing</summary>
                        <div class="ctx-summary-preview-body">${escapeHtml(latestCheckpoint.summary)}</div>
                    </details>
                ` : ''}
            </div>
        `;

        chatContextBody.innerHTML = `
            <div class="ctx-summary">
                <div class="ctx-summary-figure">${fmtTokens(usage.prompt_tokens)} <span>/ ${fmtTokens(ctx)}</span></div>
                <div class="ctx-summary-meta">
                    <span class="ctx-precision ${usage.measured ? 'is-measured' : 'is-estimated'}">${usage.measured ? 'Measured on your PC' : 'Estimated in this browser'}</span>
                    <span class="ctx-turns">${usage.turns_sent} turn${usage.turns_sent === 1 ? '' : 's'} in play</span>
                </div>
            </div>
            <div class="ctx-bar" role="img" aria-label="Context window composition">${bar}</div>
            <ul class="ctx-rows">
                ${rows.map(r => line(r.key, r.label, r.value, r.hint)).join('')}
                ${line('reserve', 'Reply reserve', usage.reply_reserve, 'Held back so the answer has somewhere to go. Shrinks as the conversation grows.')}
                ${line('free', 'Free space', usage.free, 'Unused window.')}
            </ul>
            ${compactBox}
            ${notes.length ? `<div class="ctx-notes">${notes.map(n => `<p>${escapeHtml(n)}</p>`).join('')}</div>` : ''}
        `;

        const compactBtn = chatContextBody.querySelector('#ctx-compact-btn');
        if (compactBtn && canCompact) {
            compactBtn.addEventListener('click', () => {
                compactContext(activeChatId, true);
            });
        }
        const resetCompactBtn = chatContextBody.querySelector('#ctx-reset-compact-btn');
        if (resetCompactBtn) {
            resetCompactBtn.addEventListener('click', () => {
                resetCompaction();
            });
        }
    }

    function sortMessagesWithCheckpoints(msgs) {
        if (!msgs || !msgs.length) return [];
        const checkpoints = msgs.filter(m => m.role === 'checkpoint');
        if (!checkpoints.length) return msgs;
        const latestCheckpoint = checkpoints[checkpoints.length - 1];
        const regulars = msgs.filter(m => m.role !== 'checkpoint');
        const result = [];
        let inserted = false;
        for (const msg of regulars) {
            result.push(msg);
            if (!inserted && latestCheckpoint.throughId && msg.id === latestCheckpoint.throughId) {
                result.push(latestCheckpoint);
                inserted = true;
            }
        }
        if (!inserted) {
            result.unshift(latestCheckpoint);
        }
        return result;
    }

    // What a message actually costs. Documents live on msg.documents and never in
    // msg.content, so every measurement written as `m.content || ''` values a
    // 443,000-character attachment at zero - which is why compaction offered to
    // reclaim almost nothing from a conversation that was almost entirely file.
    function docChars(msg) {
        const retained = Array.isArray(msg?.documents)
            ? msg.documents.reduce((acc, d) => acc + (d.charCount || d.text?.length || 0), 0)
            : 0;
        // What travels, not what is held. A document past the budget contributes
        // excerpts sized to that budget, so billing the meter for its full length
        // would show a window as overfull when the turn actually fits.
        return Math.min(retained, documentCharBudget());
    }
    const hasDocuments = msg => Array.isArray(msg?.documents) && msg.documents.length > 0;
    const turnTokens = msg => Math.ceil(((msg?.content || '').length + docChars(msg)) / CHARS_PER_TOKEN);

    // Everything a checkpoint did not absorb, in order.
    //
    // A checkpoint replaces a *range* of turns with one briefing, so the three
    // callers used to drop every message at or before it. That is correct for
    // dialogue and wrong for a document: its text was never in the briefing, and
    // no summary of a reference document substitutes for the document. Those
    // turns are listed in keepIds and come back through untouched.
    function messagesAfterCheckpoint(checkpoint) {
        if (!checkpoint) return activeMessages;
        let chkIdx = activeMessages.findIndex(m => m === checkpoint || (m.id && m.id === checkpoint.id));
        if (checkpoint.throughId) {
            const throughIdx = activeMessages.findIndex(m => m.id === checkpoint.throughId);
            if (throughIdx >= 0) chkIdx = Math.max(chkIdx, throughIdx);
        }
        if (chkIdx < 0) return activeMessages;
        const keep = new Set(checkpoint.keepIds || []);
        return activeMessages.filter((m, i) =>
            i > chkIdx || (m.id && m.role !== 'checkpoint' && keep.has(m.id)));
    }

    function getCompactionCandidates() {
        if (!activeMessages.length) return [];
        const latestCheckpoint = [...activeMessages].reverse().find(m => m.role === 'checkpoint');
        const live = messagesAfterCheckpoint(latestCheckpoint);
        // Leave the most recent 2 messages (the immediate previous turn) uncompacted
        const endIdx = Math.max(0, live.length - 2);
        return live.slice(0, endIdx).filter(m => !m.pending && m.role !== 'checkpoint'
            && !hasDocuments(m)
            && (m.content || (Array.isArray(m.images) && m.images.length)));
    }

    let isCompacting = false;
    let compactionState = null;
    let compactionTickerInterval = null;

    function startCompactionTicker() {
        stopCompactionTicker();
        compactionTickerInterval = setInterval(() => {
            if (isCompacting && compactionState) {
                updateCompactionUI();
            } else {
                stopCompactionTicker();
            }
        }, 500);
    }

    function stopCompactionTicker() {
        if (compactionTickerInterval) {
            clearInterval(compactionTickerInterval);
            compactionTickerInterval = null;
        }
    }

    function computeCompactionProgress() {
        if (!compactionState) return null;
        const elapsed = Math.max(0, Math.floor((Date.now() - compactionState.startedAt) / 1000));
        const tokens = compactionState.tokensToCompact || 0;
        // ~250 tokens/sec prompt ingest + ~7s generation
        const expectedTotal = Math.max(8, Math.ceil(tokens / 250) + 7);

        let pct = 0;
        let eta = null;
        let stageDesc = 'Distilling context';

        if (compactionState.status === 'queued') {
            const pos = compactionState.queuePosition;
            stageDesc = pos != null ? (pos <= 1 ? 'Queued (up next on PC)' : `Queued (${ordinal(pos)} in line)`) : 'Queued on PC';
            eta = compactionState.etaSeconds ?? Math.max(2, (pos || 1) * expectedTotal);
            pct = Math.min(25, Math.round((elapsed / Math.max(1, elapsed + eta)) * 25));
        } else {
            const stage = compactionState.stage;
            if (stage === 'finishing') {
                stageDesc = 'Finalizing context briefing';
                pct = 98;
                eta = 0;
            } else if (stage === 'swapping') {
                stageDesc = 'Loading model into VRAM';
                pct = Math.min(30, Math.max(5, Math.round((elapsed / 8) * 30)));
                eta = Math.max(1, 8 - elapsed + expectedTotal);
            } else {
                stageDesc = `Distilling ${fmtTokens(tokens)} tokens on PC`;
                if (Number.isFinite(compactionState.progress) && compactionState.progress > 0) {
                    pct = Math.min(97, Math.max(10, compactionState.progress));
                } else {
                    pct = Math.min(92, Math.max(10, Math.round((elapsed / expectedTotal) * 100)));
                }
                if (Number.isFinite(compactionState.etaSeconds) && compactionState.etaSeconds >= 0) {
                    eta = compactionState.etaSeconds;
                } else {
                    eta = Math.max(1, expectedTotal - elapsed);
                }
            }
        }

        const etaStr = eta != null
            ? (eta <= 0 ? 'finishing now' : (eta < 60 ? `~${eta}s left` : `~${Math.ceil(eta / 60)}m left`))
            : '';

        return { elapsed, pct, eta, etaStr, stageDesc, tokens };
    }

    function updateCompactionUI() {
        if (!isCompacting || !compactionState) return;
        const p = computeCompactionProgress();
        if (!p) return;

        const statusText = `📦 ${p.stageDesc} · ${p.pct}% · ${p.elapsed}s elapsed${p.etaStr ? ` (${p.etaStr})` : ''}…`;
        setStatus(statusText);

        const compactBtn = chatContextBody?.querySelector('#ctx-compact-btn');
        if (compactBtn) {
            compactBtn.textContent = `Compacting… ${p.pct}% (${p.etaStr || `${p.elapsed}s`})`;
            compactBtn.disabled = true;
        }

        const progressFill = chatContextBody?.querySelector('.ctx-compact-progress-fill');
        const progressMetaStage = chatContextBody?.querySelector('.ctx-compact-meta-stage');
        const progressMetaEta = chatContextBody?.querySelector('.ctx-compact-meta-eta');
        if (progressFill) {
            progressFill.style.width = `${p.pct}%`;
        }
        if (progressMetaStage) {
            progressMetaStage.textContent = `${p.stageDesc} · ${p.elapsed}s elapsed`;
        }
        if (progressMetaEta) {
            progressMetaEta.textContent = `${p.pct}%${p.etaStr ? ` · ${p.etaStr}` : ''}`;
        }
    }

    async function compactContext(chatId = activeChatId, isManual = false) {
        if (isCompacting || isStreaming() || !chatId || !isUnlocked()) return;
        const candidates = getCompactionCandidates();
        if (candidates.length < 2) {
            if (isManual) {
                toast(activeMessages.some(hasDocuments)
                    ? 'Not enough conversation to compact yet. The attached document is what fills the window, and it is kept whole rather than summarized - compacting cannot reclaim it.'
                    : 'Not enough conversation turns to compact yet (needs at least 2 earlier messages).', 'info');
            }
            return;
        }

        const latestCheckpoint = [...activeMessages].reverse().find(m => m.role === 'checkpoint');
        const throughMsg = candidates[candidates.length - 1];
        const throughId = throughMsg.id || crypto.randomUUID();
        // Turns inside the compacted range that have to outlive it. A document's
        // text never reaches the briefing, and a summary of a reference document
        // is not the document - so the turn carrying it stays live while only the
        // dialogue around it is replaced. Earlier keeps carry forward: compacting
        // twice must not quietly drop what the first checkpoint preserved.
        const throughIdx = activeMessages.indexOf(throughMsg);
        const keepIds = [...new Set([
            ...(latestCheckpoint?.keepIds || []),
            ...activeMessages
                .slice(0, throughIdx + 1)
                .filter(m => hasDocuments(m) && m.id)
                .map(m => m.id)
        ])];
        const keptDocNames = activeMessages
            .filter(m => m.id && keepIds.includes(m.id))
            .flatMap(m => (m.documents || []).map(d => d.name))
            .filter(Boolean);
        const tokensToCompact = candidates.reduce((acc, m) => acc + turnTokens(m), 0);
        const tokensSaved = (latestCheckpoint?.tokensSaved || 0) + tokensToCompact;

        isCompacting = true;
        compactionState = {
            chatId,
            jobId: null,
            startedAt: Date.now(),
            tokensToCompact,
            tokensSaved,
            status: 'queued',
            stage: 'starting',
            queuePosition: 1,
            progress: 0,
            progressTotal: 100,
            etaSeconds: null
        };
        startCompactionTicker();
        updateCompactionUI();
        renderContextMeter();
        if (chatContextDialog?.open) renderContextPanel(currentContextUsage());

        let transcript = '';
        if (latestCheckpoint?.summary) {
            transcript += `### Previous Conversation Briefing\n${latestCheckpoint.summary}\n\n### Subsequent Conversation Turns\n`;
        }
        if (keptDocNames.length) {
            // Without this the briefing describes a conversation about a document it
            // was never shown, and the model fills that gap by inventing what the
            // file said. Name them, and say plainly that they are still present.
            transcript += '### Attached documents (still in context in full - do not summarize, describe or restate their contents)\n'
                + keptDocNames.join(', ') + '\n\n### Conversation Turns\n';
        }
        for (const m of candidates) {
            const speaker = m.role === 'user' ? 'User' : 'Assistant';
            const text = m.content || (Array.isArray(m.images) && m.images.length ? '[Image attached]' : '');
            transcript += `${speaker}: ${text}\n\n`;
        }

        const model = selectedModel();
        const liteChatKeys = IS_LITE ? await liteKeys() : null;
        const workerPayloadObj = {
            chat_id: chatId,
            is_compaction: true,
            through_id: throughId,
            keep_ids: keepIds,
            tokens_saved: tokensSaved,
            messages: [
                { role: 'user', content: `Please summarize and compact the following conversation excerpt into a structured briefing for future context:\n\n${transcript.trim()}` }
            ],
            enable_thinking: false,
            enable_search: false,
            model
        };

        const workerPayloadStr = JSON.stringify(workerPayloadObj);
        const sealWorkerPayload = IS_LITE
            ? window.StudioLiteCrypto.sealForWorker(JSON.parse(workerPayloadStr))
            : crypt().sealText(workerPayloadStr);

        try {
            const dummyContent = await crypt().sealText(JSON.stringify({ type: 'compaction_request', through_id: throughId }));
            const sealedWorkerPayload = await sealWorkerPayload;

            const res = await api('send', {
                chat_id: chatId,
                message_id: crypto.randomUUID(),
                sealed_content: dummyContent,
                worker_payload: sealedWorkerPayload,
                client_pubkey: liteChatKeys?.publicKeySpki,
                model,
                is_compaction: true
            }, 'POST');

            if (!res?.job_id) {
                throw new Error(res?.error || 'Failed to queue compaction job.');
            }

            if (compactionState) compactionState.jobId = res.job_id;
            const compacted = await attachCompactionStream({ job_id: res.job_id, chat_id: chatId, workflow: 'compaction', through_id: throughId });
            const elapsedSec = Math.max(1, Math.round((Date.now() - (compactionState?.startedAt || Date.now())) / 1000));
            if (compacted) {
                toast(`Context compacted: ~${fmtTokens(tokensSaved)} tokens saved in ${elapsedSec}s.`);
            } else if (isManual) {
                const failReason = compactionState?.error || 'Compaction did not complete.';
                toast(failReason, 'error');
            }
        } catch (err) {
            console.error('Compaction failed:', err);
            if (isManual) toast(err.message || 'Compaction failed.', 'error');
        } finally {
            stopCompactionTicker();
            isCompacting = false;
            compactionState = null;
            setStatus(null);
            renderContextMeter();
            if (chatContextDialog?.open) renderContextPanel(currentContextUsage());
        }
    }

    async function attachCompactionStream(job) {
        isCompacting = true;
        if (!compactionState) {
            const candidates = getCompactionCandidates();
            const tokens = candidates.reduce((acc, m) => acc + turnTokens(m), 0);
            compactionState = {
                chatId: job.chat_id,
                jobId: job.job_id,
                startedAt: (job.created ? job.created * 1000 : Date.now()),
                tokensToCompact: tokens,
                tokensSaved: tokens,
                status: job.status || 'running',
                stage: job.stage || 'compacting',
                queuePosition: job.queue_position,
                progress: job.progress || 0,
                progressTotal: 100,
                etaSeconds: job.eta_seconds || null,
                error: null
            };
        } else {
            compactionState.jobId = job.job_id;
        }
        startCompactionTicker();
        updateCompactionUI();
        renderContextMeter();
        if (chatContextDialog?.open) renderContextPanel(currentContextUsage());

        const pollInterval = 1200;
        const maxAttempts = 75;
        let attempts = 0;
        let succeeded = false;
        let jobSeen = false;
        let failedReason = null;
        const startedSec = Math.floor((compactionState?.startedAt || Date.now()) / 1000) - 2;

        try {
            while (attempts++ < maxAttempts) {
                await new Promise(r => setTimeout(r, pollInterval));
                if (activeChatId !== job.chat_id) break;

                const syncParams = { active_chat_id: job.chat_id };
                if (lastMsgId) syncParams.last_msg_id = lastMsgId;
                const syncRes = await api('sync', null, 'GET', syncParams);

                const activeCompJob = Array.isArray(syncRes?.active_jobs)
                    ? (syncRes.active_jobs.find(j => j.job_id === job.job_id) || syncRes.active_jobs.find(j => j.chat_id === job.chat_id && !finishedJobs.has(j.job_id)))
                    : null;

                if (Array.isArray(syncRes?.active_jobs)) {
                    activeJobs = syncRes.active_jobs;
                }

                if (activeCompJob) {
                    jobSeen = true;
                    if (activeCompJob.status === 'failed') {
                        failedReason = activeCompJob.error || 'Compaction failed on PC.';
                    }
                    if (compactionState) {
                        compactionState.status = activeCompJob.status;
                        compactionState.stage = activeCompJob.stage || (activeCompJob.status === 'running' ? 'compacting' : 'starting');
                        compactionState.queuePosition = activeCompJob.queue_position;
                        if (Number.isFinite(activeCompJob.progress) && activeCompJob.progress > 0) {
                            compactionState.progress = activeCompJob.progress;
                        }
                        if (Number.isFinite(activeCompJob.eta_seconds)) {
                            compactionState.etaSeconds = activeCompJob.eta_seconds;
                        }
                        updateCompactionUI();
                    }
                }

                if (syncRes?.new_messages?.length) {
                    const hasCheckpoint = syncRes.new_messages.some(m => m.role === 'checkpoint');
                    await mergeRemoteMessages(syncRes.new_messages);
                    if (hasCheckpoint) {
                        succeeded = true;
                        break;
                    }
                }

                // Check if the checkpoint for this turn has arrived
                const targetCheckpoint = activeMessages.find(m => m.role === 'checkpoint' && (
                    (job.through_id && m.throughId === job.through_id) ||
                    (m.created && m.created >= startedSec)
                ));
                if (targetCheckpoint) {
                    succeeded = true;
                    break;
                }

                if (failedReason) {
                    if (compactionState) compactionState.error = failedReason;
                    break;
                }

                if (activeCompJob && (activeCompJob.status === 'complete' || activeCompJob.status === 'failed')) {
                    const finalParams = { active_chat_id: job.chat_id };
                    if (lastMsgId) finalParams.last_msg_id = lastMsgId;
                    const finalSync = await api('sync', null, 'GET', finalParams);
                    if (finalSync?.new_messages?.length) {
                        await mergeRemoteMessages(finalSync.new_messages);
                    }
                    if (activeMessages.some(m => m.role === 'checkpoint' && ((job.through_id && m.throughId === job.through_id) || (m.created && m.created >= startedSec)))) {
                        succeeded = true;
                    }
                    break;
                }

                if (jobSeen && !activeCompJob) {
                    const finalParams = { active_chat_id: job.chat_id };
                    if (lastMsgId) finalParams.last_msg_id = lastMsgId;
                    const finalSync = await api('sync', null, 'GET', finalParams);
                    if (finalSync?.new_messages?.length) {
                        await mergeRemoteMessages(finalSync.new_messages);
                    }
                    if (activeMessages.some(m => m.role === 'checkpoint' && ((job.through_id && m.throughId === job.through_id) || (m.created && m.created >= startedSec)))) {
                        succeeded = true;
                    }
                    break;
                }

                if (!jobSeen && attempts >= 8) {
                    const finalParams = { active_chat_id: job.chat_id };
                    if (lastMsgId) finalParams.last_msg_id = lastMsgId;
                    const finalSync = await api('sync', null, 'GET', finalParams);
                    if (finalSync?.new_messages?.length) {
                        await mergeRemoteMessages(finalSync.new_messages);
                    }
                    if (activeMessages.some(m => m.role === 'checkpoint' && ((job.through_id && m.throughId === job.through_id) || (m.created && m.created >= startedSec)))) {
                        succeeded = true;
                    }
                    break;
                }
            }
        } catch (err) {
            console.warn('Compaction stream error:', err);
            if (compactionState) compactionState.error = err.message || 'Compaction stream error.';
        } finally {
            markJobFinished(job.job_id);
            stopCompactionTicker();
            isCompacting = false;
            compactionState = null;
            setStatus(null);
            renderMessages();
            renderContextMeter();
            if (chatContextDialog?.open) renderContextPanel(currentContextUsage());
        }
        return succeeded;
    }

    async function resetCompaction() {
        const checkpoints = activeMessages.filter(m => m.role === 'checkpoint');
        if (!checkpoints.length) return;
        const ok = await confirmDialog({
            title: 'Reset Context Compaction',
            message: 'This will remove the active context briefing and restore all original conversation turns into active context.',
            confirmLabel: 'Reset'
        });
        if (!ok) return;
        try {
            for (const chk of checkpoints) {
                if (chk.id && activeChatId) {
                    await api('delete-message', { chat_id: activeChatId, message_id: chk.id }, 'POST').catch(() => {});
                }
                const index = activeMessages.indexOf(chk);
                if (index >= 0) activeMessages.splice(index, 1);
            }
            recomputeCursor();
            renderMessages();
            renderContextMeter();
            if (chatContextDialog?.open) renderContextPanel(currentContextUsage());
            notifyChatSync('chat-updated', activeChatId);
            toast('Compacted context cleared.');
        } catch (err) {
            toast(err.message || 'Could not clear compaction.', 'error');
        }
    }

    function checkAutoCompaction() {
        if (isCompacting || isStreaming() || !activeChatId || !isUnlocked()) return;
        const usage = currentContextUsage();
        const ctx = usage.ctx || 32768;
        const pct = usage.prompt_tokens / ctx;
        if (pct >= 0.75) {
            const candidates = getCompactionCandidates();
            if (candidates.length >= 2) {
                compactContext(activeChatId, false);
            }
        }
    }

    function openContextDialog() {
        if (!chatContextDialog) return;
        renderContextPanel(currentContextUsage());
        if (typeof chatContextDialog.showModal === 'function') chatContextDialog.showModal();
        else chatContextDialog.setAttribute('open', '');
    }

    // A reply that has landed replaces the estimate wholesale. Anything that fails
    // to unseal is dropped rather than shown as zeros - a meter that reads 0%
    // mid-conversation is worse than one that keeps the last honest number.
    async function applySealedUsage(sealed) {
        if (!sealed) return;
        try {
            const raw = await unseal(sealed);
            if (!raw) return;
            const parsed = JSON.parse(raw);
            if (parsed && Number.isFinite(parsed.prompt_tokens) && Number.isFinite(parsed.ctx)) {
                measuredUsage = parsed;
                renderContextMeter();
            }
        } catch (_) { /* keep whatever the meter already had */ }
    }

    // --------------------------------------------------------- Title / chat ---
    function beginTitleEdit() {
        if (!activeChatId || !activeChatTitle || activeChatTitle.hidden) return;
        const current = activeChatTitle.textContent;
        const input = document.createElement('input');
        input.type = 'text';
        input.className = 'chat-title-input';
        input.value = current;
        input.maxLength = 100;
        input.setAttribute('aria-label', 'Conversation title');

        activeChatTitle.hidden = true;
        if (chatTitleEditBtn) chatTitleEditBtn.hidden = true;
        activeChatTitle.parentElement.insertBefore(input, activeChatTitle);
        input.focus();
        input.select();

        let settled = false;
        const finish = async (commit) => {
            if (settled) return;
            settled = true;
            const value = input.value.trim();
            input.remove();
            activeChatTitle.hidden = false;
            if (chatTitleEditBtn) chatTitleEditBtn.hidden = false;
            if (!commit || !value || value === current) return;

            activeChatTitle.textContent = value;
            try {
                await api('rename-chat', { chat_id: activeChatId, title: await sealTitle(value) }, 'POST');
                const chat = chats.find(entry => entry.id === activeChatId);
                if (chat) chat.title = value;
                renderChatList();
                notifyChatSync('chat-updated', activeChatId);
            } catch (err) {
                activeChatTitle.textContent = current;
                toast(err.message || 'Could not rename the conversation.', 'error');
            }
        };

        input.addEventListener('keydown', event => {
            if (event.key === 'Enter') { event.preventDefault(); finish(true); }
            else if (event.key === 'Escape') { event.preventDefault(); finish(false); }
        });
        input.addEventListener('blur', () => finish(true));
    }

    async function deleteChat(chatId = activeChatId, title = null) {
        if (!chatId) return;
        const ok = await confirmDialog({
            title: 'Delete conversation',
            message: `"${title || chats.find(c => c.id === chatId)?.title || 'This conversation'}" and every message in it will be permanently deleted.`,
            confirmLabel: 'Delete conversation'
        });
        if (!ok) return;

        let doomedJobIds = [];
        if (chatId === activeChatId) {
            doomedJobIds = activeMessages.flatMap(m => extractJobIdsFromText(m.content));
        }

        try {
            await api('delete-chat', { chat_id: chatId, job_ids: doomedJobIds }, 'POST');
        } catch (err) {
            toast(err.message || 'Could not delete the conversation.', 'error');
            return;
        }
        chats = chats.filter(chat => chat.id !== chatId);
        notifyChatSync('chat-deleted', chatId);
        window.dispatchEvent(new CustomEvent('studio-jobs-changed'));
        toast('Conversation deleted.');

        if (chatId === activeChatId) {
            if (stream && stream.chatId === chatId) detachStream();
            activeChatId = null;
            activeMessages = [];
            if (chats.length) await selectChat(chats[0].id);
            else startNewChat();
        } else {
            renderChatList();
        }
    }

    function transcriptMarkdown() {
        const title = activeChatTitle?.textContent || 'Conversation';
        const lines = [`# ${title}`, ''];
        for (const msg of activeMessages) {
            if (msg.role === 'checkpoint') {
                lines.push('---');
                lines.push('*[Earlier conversation compacted into active context briefing]*');
                lines.push('---');
                lines.push('');
                continue;
            }
            lines.push(`**${authorNameFor(msg)}**${msg.created ? ` · ${fullTime(msg.created)}` : ''}`);
            lines.push('');
            if (Array.isArray(msg.images) && msg.images.length > 0) {
                lines.push(`*[Attached ${msg.images.length === 1 ? '1 image' : `${msg.images.length} images`}]*`);
                lines.push('');
            }
            if (Array.isArray(msg.documents) && msg.documents.length > 0) {
                const docNames = msg.documents.map(d => d.name).join(', ');
                lines.push(`*[Attached ${msg.documents.length === 1 ? 'document' : 'documents'}: ${docNames}]*`);
                lines.push('');
            }
            if (msg.content) {
                lines.push(msg.content);
                lines.push('');
            }
        }
        return lines.join('\n');
    }

    async function copyTranscript() {
        if (!activeMessages.length) return;
        const ok = await copyText(transcriptMarkdown());
        if (ok) { flashButton(chatCopyAllBtn); toast('Conversation copied as Markdown.'); }
        else toast('Could not copy to the clipboard.', 'error');
    }

    function exportTranscript() {
        if (!activeMessages.length) return;
        const name = (activeChatTitle?.textContent || 'conversation')
            .toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 50) || 'conversation';
        const blob = new Blob([transcriptMarkdown()], { type: 'text/markdown;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `${name}.md`;
        document.body.appendChild(link);
        link.click();
        link.remove();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
        toast('Downloaded as Markdown.');
    }

    // ------------------------------------------------------------ Streaming ---
    function setStatus(text) {
        if (!chatStatusBar || !chatStatusText) return;
        if (text) {
            chatStatusText.textContent = text;
            chatStatusBar.hidden = false;
        } else {
            chatStatusBar.hidden = true;
        }
    }

    function setComposerState() {
        if (!chatSendBtn) return;
        if (isStreaming()) {
            chatSendBtn.disabled = false;
            chatSendBtn.classList.add('is-stop');
            chatSendBtn.title = 'Stop generating (Esc)';
            chatSendBtn.setAttribute('aria-label', 'Stop generating');
        } else {
            chatSendBtn.classList.remove('is-stop');
            chatSendBtn.title = 'Send message';
            chatSendBtn.setAttribute('aria-label', 'Send message');
            const hasText = Boolean(chatInput && chatInput.value.trim());
            const hasImages = attachedImages.length > 0;
            const hasDocs = attachedDocuments.length > 0;
            chatSendBtn.disabled = !hasText && !hasImages && !hasDocs;
        }
    }

    // -------------------------------------------------------- Attachments ---
    function processImageFile(file, maxDimension = 1120, quality = 0.82) {
        return new Promise((resolve, reject) => {
            if (!file || !file.type.startsWith('image/')) {
                return reject(new Error('Selected file is not an image.'));
            }
            const reader = new FileReader();
            reader.onerror = () => reject(new Error('Failed to read image file.'));
            reader.onload = (e) => {
                const img = new Image();
                img.onerror = () => reject(new Error('Failed to load image.'));
                img.onload = () => {
                    let { width, height } = img;
                    if (width > maxDimension || height > maxDimension) {
                        if (width > height) {
                            height = Math.round((height * maxDimension) / width);
                            width = maxDimension;
                        } else {
                            width = Math.round((width * maxDimension) / height);
                            height = maxDimension;
                        }
                    }
                    const canvas = document.createElement('canvas');
                    canvas.width = width;
                    canvas.height = height;
                    const ctx = canvas.getContext('2d');
                    ctx.fillStyle = '#ffffff';
                    ctx.fillRect(0, 0, width, height);
                    ctx.drawImage(img, 0, 0, width, height);
                    const dataUrl = canvas.toDataURL('image/jpeg', quality);
                    resolve({
                        dataUrl,
                        name: file.name || 'image.jpg',
                        size: dataUrl.length
                    });
                };
                img.src = e.target.result;
            };
            reader.readAsDataURL(file);
        });
    }

    function renderAttachmentTray() {
        if (!chatAttachmentTray) return;
        if (!attachedImages.length && !attachedDocuments.length) {
            chatAttachmentTray.hidden = true;
            chatAttachmentTray.innerHTML = '';
            setComposerState();
            return;
        }
        chatAttachmentTray.hidden = false;
        chatAttachmentTray.innerHTML = '';
        attachedImages.forEach((imgObj, idx) => {
            const item = document.createElement('div');
            item.className = 'chat-attachment-item';

            const thumb = document.createElement('img');
            thumb.src = imgObj.dataUrl;
            thumb.className = 'chat-attachment-thumb';
            thumb.alt = imgObj.name || `Attachment ${idx + 1}`;
            thumb.title = 'Click to open inpaint canvas';
            thumb.style.cursor = 'pointer';
            thumb.addEventListener('click', () => {
                inpaintModal.open(imgObj.dataUrl, {
                    targetAttachmentIdx: idx,
                    maskDataUrl: imgObj.maskDataUrl
                });
            });

            const removeBtn = document.createElement('button');
            removeBtn.type = 'button';
            removeBtn.className = 'chat-attachment-remove';
            removeBtn.innerHTML = '&times;';
            removeBtn.title = 'Remove attachment';
            removeBtn.setAttribute('aria-label', `Remove attachment ${imgObj.name || idx + 1}`);
            removeBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                attachedImages.splice(idx, 1);
                renderAttachmentTray();
                renderContextMeter();
            });

            item.appendChild(thumb);
            if (imgObj.maskBlob || imgObj.maskDataUrl) {
                const badge = document.createElement('span');
                badge.className = 'chat-attachment-inpaint-badge';
                badge.textContent = 'MASK';
                badge.title = 'Inpaint mask attached';
                item.appendChild(badge);
            }
            item.appendChild(removeBtn);
            chatAttachmentTray.appendChild(item);
        });

        attachedDocuments.forEach((docObj, idx) => {
            const item = document.createElement('div');
            item.className = 'chat-attachment-item chat-attachment-doc';

            const iconSpan = document.createElement('span');
            iconSpan.className = 'chat-attachment-doc-icon';
            iconSpan.textContent = (window.DocIngest && window.DocIngest.getDocumentIcon(docObj.type)) || '📄';
            iconSpan.setAttribute('aria-hidden', 'true');

            const infoDiv = document.createElement('div');
            infoDiv.className = 'chat-attachment-doc-info';

            const nameDiv = document.createElement('div');
            nameDiv.className = 'chat-attachment-doc-name';
            nameDiv.textContent = docObj.name;
            nameDiv.title = docObj.name;

            const metaDiv = document.createElement('div');
            metaDiv.className = 'chat-attachment-doc-meta';
            const pageStr = docObj.pages ? `${docObj.pages} ${docObj.pages === 1 ? 'page' : 'pages'} · ` : '';
            const truncStr = docObj.truncated ? ' · truncated' : '';
            metaDiv.textContent = `${pageStr}${docObj.formattedSize || ''} (~${docObj.estTokens || 0} tokens)${truncStr}`;

            infoDiv.appendChild(nameDiv);
            infoDiv.appendChild(metaDiv);

            const removeBtn = document.createElement('button');
            removeBtn.type = 'button';
            removeBtn.className = 'chat-attachment-remove';
            removeBtn.innerHTML = '&times;';
            removeBtn.title = 'Remove document';
            removeBtn.setAttribute('aria-label', `Remove document ${docObj.name}`);
            removeBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                attachedDocuments.splice(idx, 1);
                renderAttachmentTray();
                renderContextMeter();
            });

            item.appendChild(iconSpan);
            item.appendChild(infoDiv);
            item.appendChild(removeBtn);
            chatAttachmentTray.appendChild(item);
        });

        setComposerState();
    }

    async function handleFiles(files) {
        if (!files || !files.length) return;
        const list = Array.from(files);
        const imageFiles = [];
        const docFiles = [];
        const unsupported = [];

        for (const f of list) {
            if (window.DocIngest && window.DocIngest.isDocumentFile(f)) {
                docFiles.push(f);
            } else if (f.type && f.type.startsWith('image/')) {
                imageFiles.push(f);
            } else if (window.DocIngest && window.DocIngest.isImageFile(f)) {
                imageFiles.push(f);
            } else {
                const ext = (f.name || '').split('.').pop().toLowerCase();
                if (['txt', 'log', 'env', 'json', 'csv', 'tsv', 'md', 'xml', 'html', 'pdf', 'docx', 'xlsx', 'rtf'].includes(ext)) {
                    docFiles.push(f);
                } else {
                    unsupported.push(f.name || 'unknown file');
                }
            }
        }

        if (unsupported.length > 0 && !imageFiles.length && !docFiles.length) {
            toast(`Unsupported file format: ${unsupported.join(', ')}. Please choose images or documents (PDF, Word, Excel, CSV, RTF, TXT, Code).`, 'error');
            return;
        }

        const totalCurrent = attachedImages.length + attachedDocuments.length;
        if (totalCurrent + imageFiles.length + docFiles.length > 5) {
            toast('You can attach up to 5 files per message.', 'error');
            return;
        }

        const vision = modelSupportsVision();
        if (imageFiles.length > 0 && !vision) {
            const label = modelBadgeFor(selectedModel()) || 'This model';
            toast(docFiles.length
                ? `${label} cannot see images, so only the document${docFiles.length > 1 ? 's were' : ' was'} attached.`
                : `${label} cannot see images. Switch models to attach images.`, 'error');
            imageFiles.length = 0;
            if (!docFiles.length) return;
        }

        for (const file of imageFiles) {
            try {
                const processed = await processImageFile(file);
                attachedImages.push(processed);
            } catch (err) {
                toast(`Failed to load ${file.name || 'image'}: ${err.message}`, 'error');
            }
        }

        if (docFiles.length > 0) {
            if (!window.DocIngest) {
                toast('Document parser is initializing. Please try again in a moment.', 'error');
                return;
            }
            setStatus('Reading attached document(s)…');
            // Attachments are no longer cut down to the window here. What is kept
            // is the pool that excerpts are drawn from on every later turn, and a
            // question that has not been asked yet cannot be served from text that
            // was thrown away at attach time. The window gets applied at send time
            // by selectExcerpts instead. The cap that still bites is storage: a
            // message is sealed into one row, so the whole message shares it.
            const retentionCap = window.DocIngest.DEFAULT_MAX_CHARS || 1000000;
            let usedChars = attachedDocuments.reduce((sum, doc) => sum + (doc.charCount || 0), 0);
            for (const file of docFiles) {
                const remaining = retentionCap - usedChars;
                if (remaining < MIN_DOCUMENT_CHARS) {
                    toast(`No room left in this message for ${file.name}. Send these documents first, then attach it.`, 'error');
                    break;
                }
                try {
                    const parsed = await window.DocIngest.parseDocument(file, { maxChars: remaining });
                    attachedDocuments.push(parsed);
                    usedChars += parsed.charCount || 0;
                    const budget = documentCharBudget();
                    if (parsed.truncated) {
                        toast(`${file.name} is ${Number(parsed.originalLength).toLocaleString()} characters. The first ${Number(parsed.charCount).toLocaleString()} are kept — that is as much as one message can carry.`, 'info');
                    } else if ((parsed.charCount || 0) > budget) {
                        toast(`${file.name} (${Number(parsed.charCount).toLocaleString()} characters) is larger than this model's context. It is kept in full, and the passages that bear on each question will be selected from it.`, 'info');
                    }
                } catch (err) {
                    toast(`Failed to parse ${file.name || 'document'}: ${err.message}`, 'error');
                }
            }
            setStatus(null);
        }

        if (unsupported.length > 0) {
            toast(`Skipped ${unsupported.join(', ')} — unsupported format.`, 'info');
        }

        renderAttachmentTray();
        renderContextMeter();
    }

    const STAGE_LABELS = {
        starting: 'Starting model on PC…',
        swapping: 'Loading the model into VRAM (~8s)…',
        searching: 'Searching the web…',
        generating: 'Generating response…',
        compacting: 'Distilling context briefing…',
        finishing: 'Finishing up…'
    };

    function ordinal(n) {
        const teen = n % 100 >= 11 && n % 100 <= 13;
        const suffix = teen ? 'th' : ({ 1: 'st', 2: 'nd', 3: 'rd' }[n % 10] || 'th');
        return `${n}${suffix}`;
    }

    // The PC runs one job at a time, so a queued message is waiting on something
    // specific. Say which, and say how far down the line it is.
    function queueLabel({ position, running_app: runningApp, host_state: hostState }) {
        const effectiveHostState = hostState || lastKnownHostState;
        if (effectiveHostState === 'unavailable') {
            return position <= 1
                ? 'Queued — PC is unavailable, will answer when PC becomes available…'
                : `Queued — ${ordinal(position)} in line (PC unavailable, will answer when PC becomes available)`;
        }
        if (effectiveHostState === 'busy_gaming') {
            return position <= 1
                ? 'Queued — PC is under load (e.g. gaming), will answer when GPU is idle…'
                : `Queued — ${ordinal(position)} in line (PC under load, will answer when GPU is idle)`;
        }
        if (effectiveHostState === 'offline') {
            return position <= 1
                ? 'Queued — the studio is not running, waiting for it to start…'
                : `Queued — ${ordinal(position)} in line (waiting for the studio)`;
        }
        const busyWith = runningApp === 'chat' ? 'another reply'
            : runningApp ? 'an image' : null;
        if (position <= 1) {
            return busyWith ? `Next in line — finishing ${busyWith} first` : 'Queued — starting now…';
        }
        return busyWith
            ? `Queued — ${ordinal(position)} in line, behind ${busyWith}`
            : `Queued — ${ordinal(position)} in line`;
    }

    let renderFrame = 0;
    function queueBubbleRender(msg) {
        if (renderFrame) return;
        // Markdown re-parsing per token is wasteful; one paint per frame is plenty.
        renderFrame = requestAnimationFrame(() => {
            renderFrame = 0;
            // The message may have settled between scheduling and painting, and the
            // settled render carries the code-block and link work this one would undo.
            if (!msg.bubbleEl || !msg.pending) return;
            msg.bubbleEl.innerHTML = renderMarkdown(msg.content || '');
            const caret = document.createElement('span');
            caret.className = 'stream-caret';
            (msg.bubbleEl.lastElementChild || msg.bubbleEl).appendChild(caret);
            keepAnchored();
        });
    }

    function cancelQueuedRender() {
        if (renderFrame) {
            cancelAnimationFrame(renderFrame);
            renderFrame = 0;
        }
    }

    function attachStream(job) {
        if (stream || !job || job.chat_id !== activeChatId) return;
        if (finishedJobs.has(job.job_id)) return;

        const isCompactionJob = Boolean(job.workflow === 'compaction' || (job.prompt && job.prompt.startsWith('compact:')));
        if (isCompactionJob) {
            attachCompactionStream(job);
            return;
        }

        const jobTimer = getJobThinkingTimer(job.job_id);
        const jobThinkingDuration = (typeof job.thinking_duration === 'number' && job.thinking_duration > 0)
            ? job.thinking_duration
            : (jobTimer?.duration ?? null);
        let jobThinkingStartedAt = null;
        if (typeof job.thinking_started_at === 'number' && job.thinking_started_at > 0) {
            jobThinkingStartedAt = job.thinking_started_at > 1e11 ? job.thinking_started_at : job.thinking_started_at * 1000;
        } else if (jobTimer?.startedAt) {
            jobThinkingStartedAt = jobTimer.startedAt;
        }

        const jobModel = job.model || null;
        let pending = activeMessages.find(msg => msg.pending && msg.role === 'assistant');
        if (!pending) {
            pending = {
                id: null,
                jobId: job.job_id,
                role: 'assistant',
                content: '',
                reasoning: '',
                created: Math.floor(Date.now() / 1000),
                pending: true,
                model: jobModel || selectedModel(),
                isLiveTurn: true,
                thinkingDuration: jobThinkingDuration,
                thinkingStartedAt: jobThinkingStartedAt
            };
            activeMessages.push(pending);
            appendMessage(pending);
        } else {
            pending.jobId = job.job_id;
            if (jobThinkingDuration != null && pending.thinkingDuration == null) {
                pending.thinkingDuration = jobThinkingDuration;
            }
            if (jobThinkingStartedAt != null && !pending.thinkingStartedAt) {
                pending.thinkingStartedAt = jobThinkingStartedAt;
            }
            if (jobModel && pending.model !== jobModel) {
                pending.model = jobModel;
                const author = pending.el?.querySelector('.chat-msg-author');
                if (author) author.textContent = authorNameFor(pending);
            }
        }

        stream = { jobId: job.job_id, chatId: job.chat_id, msg: pending, ctrl: null, detached: false };
        setComposerState();
        const initialStatus = STAGE_LABELS[job.stage] || (job.status === 'queued'
            ? (lastKnownHostState === 'unavailable'
                ? 'Queued — PC is unavailable, will answer when PC becomes available…'
                : (lastKnownHostState === 'busy_gaming'
                    ? 'Queued — PC is under load (e.g. gaming), will answer when GPU is idle…'
                    : 'Checking the queue…'))
            : 'Waiting for your PC…');
        setStatus(initialStatus);

        const current = stream;
        readStream(current).catch(err => console.warn('Stream error:', err)).finally(() => {
            if (current.detached) return;
            finishStream(current);
        });
    }

    // Detach without cancelling: used when switching chats or tearing down.
    function detachStream() {
        if (!stream) return;
        cancelQueuedRender();
        stream.detached = true;
        try { stream.ctrl?.abort(); } catch (_) {}
        const msg = stream.msg;
        if (msg) {
            if (msg.thinkingTimerInterval) {
                clearInterval(msg.thinkingTimerInterval);
                msg.thinkingTimerInterval = null;
            }
            if (msg.id && msg.thinkingDuration) {
                saveThinkingDuration(msg.id, msg.thinkingDuration);
            }
            if (stream.jobId && msg.thinkingDuration) {
                saveJobThinkingDuration(stream.jobId, msg.thinkingDuration);
            }
        }
        stream = null;
        if (msg && msg.pending && !msg.content) {
            const index = activeMessages.indexOf(msg);
            if (index >= 0) activeMessages.splice(index, 1);
            msg.el?.remove();
        }
        setStatus(null);
        setComposerState();
    }

    async function finishStream(current) {
        cancelQueuedRender();
        markJobFinished(current.jobId);
        const msg = current.msg;
        if (msg) {
            msg.pending = false;
            if (current.jobId) {
                msg.jobId = current.jobId;
                const jobDur = getJobThinkingDuration(current.jobId);
                if (jobDur != null && msg.thinkingDuration == null) {
                    msg.thinkingDuration = jobDur;
                }
            }
            // Pre-sync to resolve message ID from D1 before enhanceBubble runs
            const targetChatId = activeChatId || current.chatId || msg.chatId;
            if (targetChatId && !msg.id) {
                try {
                    const syncParams = { active_chat_id: targetChatId };
                    if (lastMsgId) syncParams.last_msg_id = lastMsgId;
                    const syncRes = await api('sync', null, 'GET', syncParams);
                    if (syncRes && syncRes.new_messages) {
                        await mergeRemoteMessages(syncRes.new_messages);
                    }
                } catch (_) {}
            }
            if (msg.bubbleEl) {
                msg.bubbleEl.innerHTML = renderMarkdown(msg.content || '');
                enhanceBubble(msg.bubbleEl, msg);
            }
            if (msg.thinkingEl && !msg.thinkingEl.dataset.userToggled) {
                msg.thinkingEl.open = false;
            }
            stopThinkingTimer(msg);
            if (msg.id && msg.thinkingDuration) {
                saveThinkingDuration(msg.id, msg.thinkingDuration);
            }
            settleMessage(msg);
        }
        if (stream === current) stream = null;
        setStatus(null);
        setComposerState();
        keepAnchored();
        scheduleSync(150);
        setTimeout(() => checkAutoCompaction(), 600);
    }

    async function readStream(current) {
        const msg = current.msg;
        let lastSeq = 0;
        let done = false;
        let retryCount = 0;
        const MAX_RETRIES = 5;

        while (!done && !current.detached) {
            current.ctrl = new AbortController();
            try {
                const response = await fetch(
                    `${STUDIO.endpoint}?action=stream&job_id=${encodeURIComponent(current.jobId)}&from_seq=${lastSeq}`,
                    { signal: current.ctrl.signal, cache: 'no-store' }
                );
                if (response.status === 401) {
                    const errJson = await response.json().catch(() => ({}));
                    if (errJson.code === 'signed-out') goSignIn();
                }
                if (!response.ok) throw new Error(`Stream request failed (${response.status})`);

                const reader = response.body.getReader();
                const decoder = new TextDecoder();
                let buffer = '';
                let reconnect = false;
                retryCount = 0;

                while (!done && !reconnect && !current.detached) {
                    const { done: streamDone, value } = await reader.read();
                    if (streamDone) break;

                    buffer += decoder.decode(value, { stream: true });
                    const parts = buffer.split('\n\n');
                    buffer = parts.pop();

                    for (const part of parts) {
                        const trimmed = part.trim();
                        if (!trimmed.startsWith('data: ')) continue;
                        let event;
                        try { event = JSON.parse(trimmed.slice(6).trim()); }
                        catch (_) { continue; }

                        if (event.error) throw new Error(event.error);

                        if (event.stream_key) await adoptStreamKey(event.stream_key);

                        // The worker now seals every streamed chunk; it used to
                        // send them readable. Decrypt in place so the rest of
                        // this loop is unchanged.
                        if (event.delta_content) event.delta_content = await openDelta(event.delta_content);
                        if (event.delta_reasoning) event.delta_reasoning = await openDelta(event.delta_reasoning);

                        if (event.queued) {
                            if (event.queued.host_state) lastKnownHostState = event.queued.host_state;
                            setStatus(queueLabel(event.queued));
                        }

                        if (event.stage && STAGE_LABELS[event.stage]) setStatus(STAGE_LABELS[event.stage]);

                        if (current.jobId) msg.jobId = current.jobId;
                        if (typeof event.thinking_duration === 'number' && event.thinking_duration > 0) {
                            msg.thinkingDuration = event.thinking_duration;
                            if (current.jobId) saveJobThinkingDuration(current.jobId, event.thinking_duration);
                        }
                        if (typeof event.thinking_started_at === 'number' && event.thinking_started_at > 0 && !msg.thinkingStartedAt) {
                            msg.thinkingStartedAt = event.thinking_started_at > 1e11 ? event.thinking_started_at : event.thinking_started_at * 1000;
                        }

                        if (event.delta_reasoning && msg.thinkingEl) {
                            if (msg.thinkingEl.hidden) {
                                msg.thinkingEl.hidden = false;
                                if (!msg.thinkingEl.dataset.userToggled) msg.thinkingEl.open = true;
                                if (msg.thinkingDuration != null) {
                                    msg.thinkingEl.classList.remove('is-live');
                                    updateThinkingSummary(msg);
                                } else {
                                    msg.thinkingEl.classList.add('is-live');
                                    startThinkingTimer(msg);
                                }
                            } else if (msg.thinkingDuration != null && msg.thinkingEl.classList.contains('is-live')) {
                                msg.thinkingEl.classList.remove('is-live');
                                if (msg.thinkingTimerInterval) {
                                    clearInterval(msg.thinkingTimerInterval);
                                    msg.thinkingTimerInterval = null;
                                }
                                updateThinkingSummary(msg);
                            }
                            msg.reasoning += event.delta_reasoning;
                            msg.thinkingContentEl.textContent = msg.reasoning;
                            msg.thinkingContentEl.scrollTop = msg.thinkingContentEl.scrollHeight;
                            keepAnchored();
                        }

                        if (event.delta_content) {
                            // First answer token: the model is done thinking aloud, and
                            // whatever stage the job last reported is now out of date.
                            if (!msg.content) {
                                setStatus(STAGE_LABELS.generating);
                                const existingJobDuration = (current.jobId ? getJobThinkingDuration(current.jobId) : null);
                                if (typeof event.thinking_duration === 'number' && event.thinking_duration > 0) {
                                    msg.thinkingDuration = event.thinking_duration;
                                } else if (existingJobDuration != null) {
                                    msg.thinkingDuration = existingJobDuration;
                                }
                                stopThinkingTimer(msg);
                                if (msg.thinkingEl && !msg.thinkingEl.dataset.userToggled) {
                                    msg.thinkingEl.open = false;
                                }
                            }
                            msg.content += event.delta_content;
                            queueBubbleRender(msg);
                        }

                        if (event.seq != null && event.seq > lastSeq) lastSeq = event.seq;

                        if (event.done) {
                            if (typeof event.thinking_duration === 'number' && event.thinking_duration > 0) {
                                msg.thinkingDuration = event.thinking_duration;
                                if (msg.id) saveThinkingDuration(msg.id, msg.thinkingDuration);
                                if (current.jobId) saveJobThinkingDuration(current.jobId, msg.thinkingDuration);
                                updateThinkingSummary(msg);
                            }
                            // Exact numbers for the turn that just finished,
                            // sealed by the PC. Replaces whatever the live
                            // estimate had been guessing while it streamed.
                            if (event.sealed_usage) await applySealedUsage(event.sealed_usage);
                            done = true;
                            break;
                        }
                        if (event.reconnect) {
                            lastSeq = event.last_seq ?? lastSeq;
                            reconnect = true;
                            break;
                        }
                    }
                }
                try { await reader.cancel(); } catch (_) {}
            } catch (err) {
                if (err.name === 'AbortError' || current.detached) return;

                // Transient network / stream interruption: retry reconnecting from lastSeq
                if (retryCount < MAX_RETRIES && !done) {
                    retryCount++;
                    console.warn(`Stream interrupted (${err.message}). Retrying ${retryCount}/${MAX_RETRIES}…`);
                    setStatus('Reconnecting…');
                    await new Promise(r => setTimeout(r, Math.min(1000 * Math.pow(1.5, retryCount - 1), 4000)));
                    continue;
                }

                // If stream reconnects were exhausted, check if the job completed on the server
                if (activeChatId && isUnlocked()) {
                    try {
                        const syncRes = await api('sync', null, 'GET', { active_chat_id: activeChatId });
                        if (Array.isArray(syncRes.new_messages) && syncRes.new_messages.length > 0) {
                            const lastSaved = syncRes.new_messages[syncRes.new_messages.length - 1];
                            if (lastSaved && lastSaved.role === 'assistant') {
                                const unsealed = await unseal(lastSaved.sealed_content);
                                if (unsealed) {
                                    msg.id = lastSaved.id;
                                    msg.content = unsealed;
                                    msg.reasoning = (await unseal(lastSaved.sealed_reasoning)) || msg.reasoning;
                                    msg.error = false;
                                    msg.pending = false;
                                    done = true;
                                    return;
                                }
                            }
                        }
                    } catch (_) {}
                }

                msg.error = !msg.content;
                msg.content = msg.content
                    ? `${msg.content}\n\n_[Generation stopped: ${err.message}]_`
                    : `**Generation failed.** ${err.message}`;
                msg.el?.classList.toggle('is-error', Boolean(msg.error));
                return;
            }
        }
    }

    async function stopGenerating() {
        if (!stream) return;
        const current = stream;
        current.detached = true;
        stream = null;
        setStatus('Stopping…');
        try { current.ctrl?.abort(); } catch (_) {}
        // Settle the bubble before awaiting the network, so no queued frame can
        // repaint it as a still-streaming message while the stop call is in flight.
        cancelQueuedRender();
        markJobFinished(current.jobId);
        if (current.msg) current.msg.pending = false;

        if (current.jobId) {
            // No job id yet means `send` is still in flight; that path cancels itself
            // once the API answers, using the `detached` flag set above.
            try {
                await api('stop', { job_id: current.jobId }, 'POST');
            } catch (err) {
                console.warn('Failed to stop job:', err);
            }
        }

        const msg = current.msg;
        if (msg) {
            const partial = (msg.content || '').trim();
            msg.content = partial ? `${partial}\n\n_[Stopped]_` : '_[Stopped before the model replied]_';
            if (msg.bubbleEl) {
                msg.bubbleEl.innerHTML = renderMarkdown(msg.content);
                enhanceBubble(msg.bubbleEl, msg);
            }
            stopThinkingTimer(msg);
            if (msg.thinkingEl && !msg.thinkingEl.dataset.userToggled) msg.thinkingEl.open = false;
            settleMessage(msg);

            if (msg.jobId && msg.thinkingDuration) {
                const timer = jobThinkingTimers.get(msg.jobId) || {};
                timer.duration = msg.thinkingDuration;
                jobThinkingTimers.set(msg.jobId, timer);
                persistJobThinkingTimers();
            }

            // worker-done never fires for a stopped job, so persist the partial
            // answer here or it vanishes on the next load.
            if (partial && activeChatId && isUnlocked()) {
                try {
                    const messageId = crypto.randomUUID();
                    const payload = {
                        chat_id: activeChatId,
                        message_id: messageId,
                        role: 'assistant',
                        sealed_content: await crypt().sealText(msg.content)
                    };
                    if (msg.reasoning) payload.sealed_reasoning = await crypt().sealText(msg.reasoning);
                    if (msg.thinkingDuration) {
                        payload.thinking_duration = msg.thinkingDuration;
                        thinkingDurations.set(messageId, msg.thinkingDuration);
                    }
                    const saved = await api('save-message', payload, 'POST');
                    msg.id = messageId;
                    msg.created = saved.created || msg.created;
                    if (msg.el) msg.el.dataset.msgId = messageId;
                    recomputeCursor();
                } catch (err) {
                    console.warn('Could not persist the stopped response:', err);
                    toast('Stopped. This partial answer was not saved.', 'error');
                }
            }
        }

        setStatus(null);
        setComposerState();
        chatInput?.focus();
        scheduleSync(150);
    }

    // ----------------------------------------------------------------- Send ---
    async function sendMessage(text, images = null, documents = null) {
        if (isStreaming()) return;
        const body = (text || '').trim();
        const currentImages = images !== null ? images : [...attachedImages];
        const currentDocuments = documents !== null ? documents : [...attachedDocuments];
        if (!body && !currentImages.length && !currentDocuments.length) return;

        if (!isUnlocked()) {
            toast('Studio is locked. Unlock it to chat.', 'error');
            return;
        }

        const isNewChat = !activeChatId;
        const chatId = activeChatId || crypto.randomUUID();
        activeChatId = chatId;
        const messageId = crypto.randomUUID();
        const chatModel = selectedModel();
        const enableThinking = (enableThinkingCheckbox && !enableThinkingCheckbox.disabled)
            ? enableThinkingCheckbox.checked
            : false;
        const enableSearch = enableSearchCheckbox ? enableSearchCheckbox.checked : false;
        const stamp = Math.floor(Date.now() / 1000);

        let title = null;
        if (isNewChat) {
            if (body) {
                title = body.length > 42 ? `${body.slice(0, 42)}…` : body;
            } else if (currentDocuments.length > 0) {
                title = currentDocuments.length > 1 ? `${currentDocuments.length} Documents` : currentDocuments[0].name;
            } else {
                title = currentImages.length > 1 ? `${currentImages.length} Images` : 'Image Analysis';
            }
            if (activeChatTitle) activeChatTitle.textContent = title;
        }

        // Capture pending inpaint assets if any attached image has a mask
        const imageMasks = [];
        for (const img of currentImages) {
            let maskDataUrl = null;
            if (img && typeof img === 'object') {
                maskDataUrl = img.maskDataUrl || null;
                if (img.maskBlob || img.maskDataUrl) {
                    let inputBlob = img.inputBlob || null;
                    if (!inputBlob && img.dataUrl) {
                        try {
                            const bytes = dataUrlToBytes(img.dataUrl);
                            inputBlob = new Blob([bytes], { type: 'image/jpeg' });
                        } catch (_) {}
                    }
                    let maskBlob = img.maskBlob || null;
                    if (!maskBlob && img.maskDataUrl) {
                        try {
                            const bytes = dataUrlToBytes(img.maskDataUrl);
                            maskBlob = new Blob([bytes], { type: 'image/png' });
                        } catch (_) {}
                    }
                    if (inputBlob && maskBlob) {
                        const record = { inputBlob, maskBlob, maskDataUrl: img.maskDataUrl, src: img.dataUrl };
                        if (img.dataUrl) imageMaskMap.set(img.dataUrl, record);
                        pendingInpaintAssets.set('latest', record);
                        pendingInpaintAssets.set(messageId, record);
                    }
                }
            }
            imageMasks.push(maskDataUrl);
        }

        // Reset composer attached images and documents if we consumed current state
        if (images === null && attachedImages.length > 0) {
            attachedImages = [];
            renderAttachmentTray();
        }
        if (documents === null && attachedDocuments.length > 0) {
            attachedDocuments = [];
            renderAttachmentTray();
        }

        const imageUrls = currentImages.map(img => (typeof img === 'string' ? img : img.dataUrl));
        const userMsg = {
            id: messageId,
            chatId,
            role: 'user',
            content: body,
            images: imageUrls,
            masks: imageMasks,
            documents: currentDocuments,
            reasoning: '',
            created: stamp
        };
        activeMessages.push(userMsg);
        appendMessage(userMsg);
        settleMessage(userMsg);
        scrollToBottom();

        // Stamp the model that is about to answer, so the bubble stays correctly
        // attributed even if the picker is changed while the reply streams.
        const assistantMsg = { id: null, chatId, role: 'assistant', content: '', reasoning: '', created: stamp, pending: true, model: selectedModel(), isLiveTurn: true };
        activeMessages.push(assistantMsg);
        appendMessage(assistantMsg);

        stream = { jobId: null, chatId, msg: assistantMsg, ctrl: null, detached: false };
        setComposerState();
        setStatus(enableSearch ? 'Submitting to your PC (Search enabled)…' : 'Submitting to your PC…');

        const current = stream;
        try {
            const latestCheckpoint = [...activeMessages].reverse().find(m => m.role === 'checkpoint');
            const uncompactedMessages = messagesAfterCheckpoint(latestCheckpoint);

            const recent = uncompactedMessages
                .filter(msg => !msg.pending && msg.role !== 'checkpoint' && (msg.content || (Array.isArray(msg.images) && msg.images.length) || (Array.isArray(msg.documents) && msg.documents.length)))
                .slice(-HISTORY_DEPTH);

            // Walk back from the newest message so the turns nearest the question
            // survive the budget, then restore chronological order.
            const sendHistoryBudget = historyCharBudget();
            const kept = [];
            let historyChars = 0;
            let historyImages = 0;
            for (let i = recent.length - 1; i >= 0; i--) {
                const msg = recent[i];
                let text = msg.content || '';
                if (Array.isArray(msg.documents) && msg.documents.length > 0 && window.DocIngest) {
                    text = window.DocIngest.formatPromptWithDocuments(text, msg.documents, {
                        // Select against the question being asked now, not the one
                        // this turn was originally sent with - a follow-up should be
                        // able to reach a passage the first question never touched.
                        query: body || msg.content || '',
                        budgetChars: documentCharBudget()
                    });
                }
                // The newest turn always goes, budget or not: it is the question.
                if (kept.length && historyChars + text.length > sendHistoryBudget) break;
                historyChars += text.length;
                const imageCount = Array.isArray(msg.images) ? msg.images.length : 0;
                const withImages = msg.role === 'user'
                    && imageCount > 0
                    && (recent.length - 1 - i) < HISTORY_IMAGE_DEPTH
                    && (i === recent.length - 1 || historyImages + imageCount <= HISTORY_IMAGE_LIMIT);
                if (withImages) historyImages += imageCount;
                kept.unshift({ msg, withImages, formattedText: text });
            }

            const history = kept
                .map(({ msg, withImages, formattedText }) => {
                    const promptText = formattedText !== undefined ? formattedText : (msg.content || '');
                    if (withImages) {
                        const contentParts = [];
                        const hasMask = Array.isArray(msg.masks) && msg.masks.some(Boolean);
                        let fullPrompt = promptText || (msg.images.length > 1 ? 'Describe these images in detail.' : 'Describe this image in detail.');
                        if (hasMask) {
                            fullPrompt = `[User note: An inpaint mask has been painted on this image indicating the specific target area to edit, add, or replace.]\n${fullPrompt}`;
                        }
                        contentParts.push({ type: 'text', text: fullPrompt });
                        for (const imgUrl of msg.images) {
                            contentParts.push({
                                type: 'image_url',
                                image_url: { url: imgUrl }
                            });
                        }
                        return { role: 'user', content: contentParts };
                    }
                    // An image-only turn whose image was dropped still has to say
                    // something, or it reaches the model as an empty message.
                    if (!promptText && Array.isArray(msg.images) && msg.images.length > 0) {
                        return { role: msg.role, content: '[An image was attached earlier in this conversation.]' };
                    }
                    return { role: msg.role, content: promptText };
                });

            const liteChatKeys = IS_LITE ? await liteKeys() : null;
            const workerPayload = JSON.stringify({
                chat_id: chatId,
                messages: history,
                memories: memories.map(m => m.text).filter(Boolean),
                compacted_summary: latestCheckpoint?.summary || undefined,
                enable_thinking: enableThinking,
                enable_search: enableSearch,
                model: chatModel
            });

            const hasMasks = imageMasks.some(Boolean);
            const hasImgs = imageUrls.length > 0;
            const hasDocs = currentDocuments.length > 0;
            const sealedPayloadContent = (hasImgs || hasDocs)
                ? JSON.stringify({
                    text: body,
                    ...(hasImgs ? { images: imageUrls } : {}),
                    ...(hasMasks ? { masks: imageMasks } : {}),
                    ...(hasDocs ? { documents: currentDocuments } : {})
                })
                : body;

            // Two different keys, deliberately.
            //
            // The stored message is sealed to the user: Plus with the Studio
            // content key, Lite with this browser's own RSA key, so the site
            // can never read it back.
            //
            // The worker payload is sealed to whatever the PC actually holds.
            // For Plus that is the same Studio key. For Lite it is the shared
            // Lite worker secret -- the PC has no access to the user's private
            // key, so sealing this one to the user would be unreadable on the
            // other end and the turn would fail to decrypt.
            const sealWorkerPayload = IS_LITE
                ? window.StudioLiteCrypto.sealForWorker(JSON.parse(workerPayload))
                : crypt().sealText(workerPayload);

            const [sealedContent, sealedWorkerPayload, sealedTitle] = await Promise.all([
                crypt().sealText(sealedPayloadContent),
                sealWorkerPayload,
                title ? sealTitle(title) : Promise.resolve(null)
            ]);

            const res = await api('send', {
                chat_id: chatId,
                message_id: messageId,
                title: sealedTitle || undefined,
                sealed_content: sealedContent,
                worker_payload: sealedWorkerPayload,
                // Lite only: the PC seals this reply, and every chunk of it,
                // to this key. The API refuses a Lite chat job without one
                // rather than falling back to streaming in the clear.
                client_pubkey: liteChatKeys?.publicKeySpki,
                model: chatModel,
                thinking: Boolean(enableThinking),
                search: Boolean(enableSearch)
            }, 'POST');

            if (current.detached) {
                api('stop', { job_id: res.job_id }, 'POST').catch(() => {});
                return;
            }

            activeChatId = chatId;
            current.jobId = res.job_id;
            assistantMsg.jobId = res.job_id;
            if (assistantMsg.el) assistantMsg.el.dataset.jobId = res.job_id;
            if (assistantMsg.thinkingStartedAt) {
                const timer = jobThinkingTimers.get(res.job_id) || {};
                timer.startedAt = timer.startedAt || assistantMsg.thinkingStartedAt;
                jobThinkingTimers.set(res.job_id, timer);
                persistJobThinkingTimers();
            }
            recomputeCursor();
            const curChat = chats.find(c => c.id === chatId);
            if (curChat) {
                curChat.model = chatModel;
                curChat.active_job_id = res.job_id;
            } else if (isNewChat) {
                chats.unshift({ id: chatId, title, created: stamp, updated: stamp, active_job_id: res.job_id, model: chatModel });
                renderChatList();
                updateHeaderState();
            }
            setStatus(lastKnownHostState === 'busy_gaming'
                ? 'Queued — PC is under load (e.g. gaming), will answer when GPU is idle…'
                : 'Checking the queue…');

            await readStream(current);
            if (!current.detached) await finishStream(current);
        } catch (err) {
            if (current.detached) return;
            console.error('Send failed:', err);

            // Put the text and attachments back into composer so a failed send never loses them.
            const index = activeMessages.indexOf(assistantMsg);
            if (index >= 0) activeMessages.splice(index, 1);
            assistantMsg.el?.remove();
            stream = null;
            setStatus(null);
            setComposerState();

            const userIndex = activeMessages.indexOf(userMsg);
            if (userIndex >= 0) activeMessages.splice(userIndex, 1);
            userMsg.el?.remove();

            if (chatInput && !chatInput.value.trim() && body) {
                chatInput.value = body;
                autoResizeInput();
                updateCharCount();
            }
            if (imageUrls.length > 0 && attachedImages.length === 0) {
                attachedImages = currentImages.map((img, i) => typeof img === 'string'
                    ? { dataUrl: img, maskDataUrl: imageMasks[i], name: `image-${i + 1}.jpg`, size: img.length }
                    : { ...img });
                renderAttachmentTray();
            }
            if (currentDocuments.length > 0 && attachedDocuments.length === 0) {
                attachedDocuments = [...currentDocuments];
                renderAttachmentTray();
            }

            // The header was given a title derived from a message that never landed.
            if (isNewChat) {
                activeChatId = null;
                if (activeChatTitle && !activeChatTitle.hidden) {
                    activeChatTitle.textContent = 'New conversation';
                }
            }
            if (!activeMessages.length) renderEmptyState();
            toast(err.message || 'Could not send the message.', 'error');
        } finally {
            notifyChatSync('chat-updated', chatId);
            chatInput?.focus();
            scheduleSync(400);
        }
    }

    async function handleComposerSubmit(event) {
        if (event) event.preventDefault();
        if (isStreaming()) { stopGenerating(); return; }
        const text = chatInput ? chatInput.value : '';
        const hasText = Boolean(text.trim());
        const hasImages = attachedImages.length > 0;
        const hasDocs = attachedDocuments.length > 0;
        if (!hasText && !hasImages && !hasDocs) return;
        if (chatInput) {
            chatInput.value = '';
            autoResizeInput();
            updateCharCount();
        }
        await sendMessage(text);
    }

    // ----------------------------------------------------------------- Sync ---
    async function pollSync() {
        if (isSyncing) return;
        if (!isUnlocked()) { scheduleSync(5000); return; }

        isSyncing = true;
        try {
            const params = {
                chats_updated: chats.reduce((max, chat) => Math.max(max, chat.updated || 0), 0),
                chats_count: chats.length
            };
            if (activeChatId) {
                params.active_chat_id = activeChatId;
                params.msg_count = activeMessages.filter(msg => msg.id).length;
                if (lastMsgId) params.last_msg_id = lastMsgId;
            }

            const res = await api('sync', null, 'GET', params);
            if (res.host_state) lastKnownHostState = res.host_state;
            activeJobs = res.active_jobs || (res.active_job ? [res.active_job] : []);
            renderQueueChip();
            const syncedChatId = activeChatId;

            if (Array.isArray(res.chats)) {
                chats = await hydrateChats(res.chats);
                if (syncedChatId && !chats.some(chat => chat.id === syncedChatId)) {
                    startNewChat();
                    return;
                }
                renderChatList();
                const current = chats.find(chat => chat.id === activeChatId);
                if (current && activeChatTitle && !activeChatTitle.hidden && activeChatTitle.textContent !== (current.title || '')) {
                    activeChatTitle.textContent = current.title || 'Conversation';
                }
            } else {
                renderChatList();
            }

            // Nothing below is safe if the active chat changed mid-request.
            if (syncedChatId && syncedChatId === activeChatId) {
                if (res.active_chat_id === activeChatId) {
                    await mergeRemoteMessages(res.new_messages || []);
                    if (Array.isArray(res.message_ids)) pruneDeleted(res.message_ids);
                }
                // Attach to this conversation's own job, not whichever one is
                // nearest the front of the queue.
                const mine = jobForChat(activeChatId);
                if (mine && !stream) attachStream(mine);
            }
        } catch (err) {
            console.debug('Chat sync error:', err);
        } finally {
            isSyncing = false;
            const hasActiveChatWork = isStreaming() || (Array.isArray(activeJobs) && activeJobs.length > 0);
            const syncInterval = document.hidden
                ? (hasActiveChatWork ? 15000 : 30000)
                : (hasActiveChatWork ? 4000 : 15000);
            scheduleSync(syncInterval);
        }
    }

    async function mergeRemoteMessages(rows) {
        let appended = false;
        // A turn answered in another tab or on another device is still a turn that
        // grew this conversation, so its breakdown updates the meter here too.
        const remoteUsage = [...rows].reverse().find(r => r.sealed_usage);
        if (remoteUsage && isUnlocked()) await applySealedUsage(remoteUsage.sealed_usage);
        for (const row of rows) {
            if (activeMessages.some(msg => msg.id === row.id)) continue;

            const rawContent = await unseal(row.sealed_content, '[Sealed with a different Studio key]');
            const reasoning = await unseal(row.sealed_reasoning);
            let content = rawContent;
            let images = null;
            let masks = null;
            let documents = null;
            let isCheckpoint = (row.role === 'checkpoint');
            let checkpointData = null;
            if (typeof rawContent === 'string' && rawContent.startsWith('{')) {
                try {
                    const parsed = JSON.parse(rawContent);
                    if (parsed && parsed.type === 'compaction_checkpoint') {
                        isCheckpoint = true;
                        checkpointData = parsed;
                        content = parsed.summary || '';
                    } else if (parsed && (Array.isArray(parsed.images) || Array.isArray(parsed.documents))) {
                        content = parsed.text || '';
                        if (Array.isArray(parsed.images)) {
                            images = parsed.images;
                            if (Array.isArray(parsed.masks)) {
                                masks = parsed.masks;
                                images.forEach((url, i) => {
                                    if (masks[i] && url) {
                                        imageMaskMap.set(url, { maskDataUrl: masks[i], src: url });
                                    }
                                });
                            }
                        }
                        if (Array.isArray(parsed.documents)) {
                            documents = parsed.documents;
                        }
                    }
                } catch (_) {}
            }

            // A message this tab is already showing without an id (just sent, or
            // mid-stream) is the same row coming back: adopt the id, do not duplicate.
            const localTwin = activeMessages.find(msg => !msg.id && msg.role === row.role);
            if (localTwin) {
                localTwin.id = row.id;
                localTwin.created = row.created;
                if (!localTwin.model && row.model) localTwin.model = row.model;
                if (!localTwin.content && content) localTwin.content = content;
                if (!localTwin.images && images) localTwin.images = images;
                if (!localTwin.masks && masks) localTwin.masks = masks;
                if (!localTwin.documents && documents) localTwin.documents = documents;
                if (!localTwin.reasoning && reasoning) localTwin.reasoning = reasoning;
                if (localTwin.el) localTwin.el.dataset.msgId = row.id;
                if (localTwin.thinkingDuration) {
                    saveThinkingDuration(localTwin.id, localTwin.thinkingDuration);
                } else {
                    const savedDuration = getThinkingDuration(row.id);
                    if (savedDuration) {
                        localTwin.thinkingDuration = savedDuration;
                        updateThinkingSummary(localTwin);
                    }
                }
                if (localTwin.bubbleEl && !localTwin.bubbleEl.textContent.trim() && content) {
                    localTwin.bubbleEl.innerHTML = renderMarkdown(content);
                    enhanceBubble(localTwin.bubbleEl, localTwin);
                }
                lastMsgId = row.id;
                const localHasMeta = localTwin.content && (localTwin.content.includes('job_id:') || localTwin.content.includes('status: cancelled'));
                const remoteHasMeta = content && (content.includes('job_id:') || content.includes('status: cancelled'));
                if (activeChatId && localHasMeta && !remoteHasMeta) {
                    (async () => {
                        try {
                            await api('save-message', {
                                chat_id: activeChatId,
                                message_id: localTwin.id,
                                role: 'assistant',
                                sealed_content: await crypt().sealText(localTwin.content),
                                sealed_reasoning: localTwin.reasoning ? await crypt().sealText(localTwin.reasoning) : null
                            }, 'POST');
                        } catch (_) {}
                    })();
                }
                continue;
            }

            const msg = {
                id: row.id,
                role: isCheckpoint ? 'checkpoint' : row.role,
                content,
                summary: isCheckpoint ? (checkpointData?.summary || content) : null,
                throughId: isCheckpoint ? (checkpointData?.through_id || null) : null,
                keepIds: isCheckpoint ? (checkpointData?.keep_ids || null) : null,
                tokensSaved: isCheckpoint ? (checkpointData?.tokens_saved || 0) : 0,
                images,
                masks,
                documents,
                reasoning,
                created: row.created,
                model: row.model || null,
                thinkingDuration: getThinkingDuration(row.id)
            };
            if (isCheckpoint) {
                const existingChkIdx = activeMessages.findIndex(m => m.role === 'checkpoint');
                if (existingChkIdx >= 0) {
                    const [oldChk] = activeMessages.splice(existingChkIdx, 1);
                    oldChk?.el?.remove();
                }

                let targetIdx = -1;
                if (msg.throughId) {
                    targetIdx = activeMessages.findIndex(m => m.id === msg.throughId);
                }
                const el = createMessageEl(msg);
                if (targetIdx >= 0) {
                    activeMessages.splice(targetIdx + 1, 0, msg);
                    const targetEl = activeMessages[targetIdx]?.el;
                    if (targetEl && targetEl.parentNode) {
                        targetEl.after(el);
                    } else if (chatMessagesContainer) {
                        chatMessagesContainer.appendChild(el);
                    }
                } else {
                    activeMessages.unshift(msg);
                    if (chatMessagesContainer?.firstChild) {
                        chatMessagesContainer.firstChild.before(el);
                    } else if (chatMessagesContainer) {
                        chatMessagesContainer.appendChild(el);
                    }
                }
                lastMsgId = row.id;
                appended = true;
                continue;
            }

            // Keep a live pending bubble last so an incoming row cannot jump ahead of it.
            const pendingIndex = activeMessages.findIndex(entry => entry.pending);
            if (pendingIndex >= 0) {
                activeMessages.splice(pendingIndex, 0, msg);
                const el = createMessageEl(msg);
                activeMessages[pendingIndex + 1].el?.before(el);
            } else {
                activeMessages.push(msg);
                appendMessage(msg);
                settleMessage(msg);
            }
            lastMsgId = row.id;
            appended = true;
        }
        if (appended) keepAnchored();
    }

    function pruneDeleted(remoteIds) {
        const known = new Set(remoteIds);
        let removed = false;
        for (let i = activeMessages.length - 1; i >= 0; i--) {
            const msg = activeMessages[i];
            if (!msg.id || msg.pending) continue;
            if (known.has(msg.id)) continue;
            msg.el?.remove();
            activeMessages.splice(i, 1);
            removed = true;
        }
        if (removed) {
            recomputeCursor();
            renderMessages();
            if (!activeMessages.length) renderEmptyState();
        }
    }

    function scheduleSync(ms = 5000) {
        if (syncTimer) clearTimeout(syncTimer);
        syncTimer = setTimeout(pollSync, ms);
    }

    // -------------------------------------------------------------- Composer ---
    function updateCharCount() {
        if (!chatInput || !chatCharCount) return;
        const length = chatInput.value.length;
        // A counter that is always on is just noise; it matters near the ceiling.
        const cap = maxTypedChars();
        const show = length > cap * 0.75;
        chatCharCount.hidden = !show;
        if (show) {
            chatCharCount.textContent = `${length.toLocaleString()} / ${cap.toLocaleString()}`;
            chatCharCount.classList.toggle('is-near-limit', length > cap * 0.95);
        }
        // The draft counts toward the next turn, so the ring tracks the keystrokes.
        renderContextMeter();
    }

    function autoResizeInput() {
        if (!chatInput) return;
        chatInput.style.height = 'auto';
        chatInput.style.height = `${Math.min(220, Math.max(46, chatInput.scrollHeight))}px`;
    }

    function fillComposer(text) {
        if (!chatInput) return;
        chatInput.value = text;
        autoResizeInput();
        updateCharCount();
        setComposerState();
        chatInput.focus();
        chatInput.setSelectionRange(text.length, text.length);
    }

    // ----------------------------------------------------------------- Init ---
    function isMobileDevice() {
        if (typeof window === 'undefined' || typeof navigator === 'undefined') return false;
        const ua = navigator.userAgent || '';
        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|Mobile/i.test(ua)) {
            return true;
        }
        if (navigator.maxTouchPoints > 1 && /Macintosh/i.test(ua)) {
            return true;
        }
        const hasCoarse = Boolean(window.matchMedia && window.matchMedia('(pointer: coarse)').matches);
        const hasTouch = (navigator.maxTouchPoints && navigator.maxTouchPoints > 0) || hasCoarse;
        if (hasTouch && (window.innerWidth <= 760 || (window.matchMedia && window.matchMedia('(max-width: 760px)').matches))) {
            return true;
        }
        if (hasCoarse && !(window.matchMedia && window.matchMedia('(pointer: fine)').matches)) {
            return true;
        }
        return false;
    }

    // The flex layout fills the viewport; account for mobile keyboards as well.
    function sizeChatLayout() {
        if (!chatLayout || chatLayout.hidden) return;
        const viewport = window.visualViewport;
        // Safari may pan the visual viewport before or during keyboard resize.
        // Track both events so an empty focused composer stays on screen too.
        if (viewport && viewport.scale !== 1) return;
        document.body.style.setProperty('--chat-viewport-height', `${viewport?.height || window.innerHeight}px`);
        document.body.style.setProperty('--chat-viewport-top', `${viewport?.offsetTop || 0}px`);
        chatLayout.style.removeProperty('height');
    }

    function setMobileSidebar(open, returnFocus = false) {
        chatSidebar?.classList.toggle('expanded', open);
        const backdrop = document.querySelector('#chat-drawer-backdrop');
        if (backdrop) backdrop.hidden = !open;
        if (window.innerWidth <= 760) {
            sidebarCollapseBtn?.setAttribute('aria-expanded', String(open));
            sidebarCollapseBtn?.setAttribute('aria-label', open ? 'Hide conversation list' : 'Show conversation list');
            if (chatSidebar) chatSidebar.inert = !open;
        }
        if (open) document.querySelector('#chat-drawer-close')?.focus();
        else if (returnFocus) sidebarCollapseBtn?.focus();
    }

    function restorePreferences() {
        try {
            if (localStorage.getItem(SIDEBAR_KEY) === '1' && chatLayout) {
                chatLayout.classList.add('sidebar-collapsed');
                if (chatSidebar) chatSidebar.inert = window.innerWidth > 760;
                sidebarCollapseBtn?.setAttribute('aria-expanded', 'false');
            }
            const thinking = localStorage.getItem(THINKING_KEY);
            if (thinking !== null && enableThinkingCheckbox) {
                enableThinkingCheckbox.checked = thinking === '1';
            }
            const searchPref = localStorage.getItem(SEARCH_KEY);
            if (searchPref !== null && enableSearchCheckbox) {
                enableSearchCheckbox.checked = searchPref === '1';
            }
            const model = localStorage.getItem(MODEL_KEY);
            // Ignore a stored key that is no longer in the list - a model can be
            // retired between visits, and the <select> would silently keep index 0
            // while the stored value said otherwise.
            if (model && chatModelSelect && [...chatModelSelect.options].some(o => o.value === model)) {
                chatModelSelect.value = model;
            }
        } catch (_) { /* private window */ }
        applyModelCapabilities();
    }

    function init() {
        resolveMemoryElements();
        restorePreferences();
        updateHeaderState();
        setComposerState();

        newChatBtn?.addEventListener('click', event => {
            event.stopPropagation();
            startNewChat();
        });
        chatMemoryBtn?.addEventListener('click', () => {
            resolveMemoryElements();
            renderMemoryList(chatMemorySearch?.value || '');
            chatMemoryDialog?.showModal();
            chatMemoryInput?.focus();
        });
        chatMemoryClose?.addEventListener('click', () => chatMemoryDialog?.close());
        chatMemoryDialog?.addEventListener('click', event => {
            if (event.target === chatMemoryDialog) chatMemoryDialog.close();
        });
        chatContextBtn?.addEventListener('click', openContextDialog);
        chatContextClose?.addEventListener('click', () => chatContextDialog?.close());
        chatContextDialog?.addEventListener('click', event => {
            if (event.target === chatContextDialog) chatContextDialog.close();
        });
        chatMemorySearch?.addEventListener('input', e => {
            renderMemoryList(e.target.value);
        });
        chatMemoryClearBtn?.addEventListener('click', clearAllMemories);
        chatMemoryAddForm?.addEventListener('submit', async event => {
            event.preventDefault();
            const text = chatMemoryInput?.value;
            if (text) {
                await saveMemory(text);
                if (chatMemoryInput) chatMemoryInput.value = '';
            }
        });
        chatTitleEditBtn?.addEventListener('click', beginTitleEdit);
        activeChatTitle?.addEventListener('dblclick', beginTitleEdit);
        chatDeleteBtn?.addEventListener('click', () => deleteChat());
        chatCopyAllBtn?.addEventListener('click', copyTranscript);
        chatQueueChip?.addEventListener('click', () => {
            const waiting = activeJobs.filter(job => job.status === 'queued').length;
            cancelQueued({
                label: `${waiting === 1 ? 'One message is' : `${waiting} messages are`} waiting to be answered. Cancelling leaves them in their conversations, so you can send them again later. A reply already being generated is not affected.`
            });
        });
        chatExportBtn?.addEventListener('click', exportTranscript);
        chatComposerForm?.addEventListener('submit', handleComposerSubmit);

        chatAttachBtn?.addEventListener('click', () => chatFileInput?.click());
        chatFileInput?.addEventListener('change', e => {
            handleFiles(e.target.files);
            e.target.value = '';
        });

        if (chatComposerWrap) {
            ['dragenter', 'dragover'].forEach(eventName => {
                chatComposerWrap.addEventListener(eventName, e => {
                    e.preventDefault();
                    e.stopPropagation();
                    chatComposerWrap.classList.add('is-dragover');
                });
            });
            ['dragleave', 'drop'].forEach(eventName => {
                chatComposerWrap.addEventListener(eventName, e => {
                    e.preventDefault();
                    e.stopPropagation();
                    chatComposerWrap.classList.remove('is-dragover');
                });
            });
            chatComposerWrap.addEventListener('drop', e => {
                if (e.dataTransfer && e.dataTransfer.files) {
                    handleFiles(e.dataTransfer.files);
                }
            });
        }

        chatInput?.addEventListener('paste', e => {
            if (!e.clipboardData || !e.clipboardData.items) return;
            const items = Array.from(e.clipboardData.items);
            const fileItems = items.filter(item => {
                if (item.kind !== 'file') return false;
                if (item.type && item.type.startsWith('image/')) return true;
                const file = item.getAsFile();
                return file && window.DocIngest && window.DocIngest.isDocumentFile(file);
            });
            if (fileItems.length > 0) {
                e.preventDefault();
                const files = fileItems.map(item => item.getAsFile()).filter(Boolean);
                handleFiles(files);
            }
        });

        chatSendBtn?.addEventListener('click', event => {
            if (!isStreaming()) return;
            event.preventDefault();
            stopGenerating();
        });

        chatSearch?.addEventListener('input', () => {
            searchTerm = chatSearch.value.trim();
            renderChatList();
        });

        sidebarCollapseBtn?.addEventListener('click', () => {
            if (!chatLayout) return;
            if (window.innerWidth <= 760) {
                setMobileSidebar(!chatSidebar.classList.contains('expanded'));
                return;
            }
            const collapsed = chatLayout.classList.toggle('sidebar-collapsed');
            if (chatSidebar) chatSidebar.inert = collapsed && window.innerWidth > 760;
            sidebarCollapseBtn.setAttribute('aria-expanded', String(!collapsed));
            sidebarCollapseBtn.title = collapsed ? 'Show conversation list' : 'Hide conversation list';
            sidebarCollapseBtn.setAttribute('aria-label', sidebarCollapseBtn.title);
            try { localStorage.setItem(SIDEBAR_KEY, collapsed ? '1' : '0'); } catch (_) {}
        });

        enableThinkingCheckbox?.addEventListener('change', () => {
            try { localStorage.setItem(THINKING_KEY, enableThinkingCheckbox.checked ? '1' : '0'); } catch (_) {}
        });

        enableSearchCheckbox?.addEventListener('change', () => {
            try { localStorage.setItem(SEARCH_KEY, enableSearchCheckbox.checked ? '1' : '0'); } catch (_) {}
        });

        chatModelSelect?.addEventListener('change', () => {
            try { localStorage.setItem(MODEL_KEY, chatModelSelect.value); } catch (_) {}
            if (activeChatId) {
                const curChat = chats.find(c => c.id === activeChatId);
                if (curChat) curChat.model = chatModelSelect.value;
            }
            applyModelCapabilities();
            // Attachments staged before the switch would be dropped by the PC
            // without explanation, so say it here while they can still switch back.
            if (!modelSupportsVision() && attachedImages.length) {
                toast('This model cannot see images — image attachments will be ignored.', 'error');
            }
        });

        sizeChatLayout();
        window.visualViewport?.addEventListener('resize', sizeChatLayout);
        window.visualViewport?.addEventListener('scroll', sizeChatLayout);
        chatInput?.addEventListener('focus', () => requestAnimationFrame(sizeChatLayout));
        chatInput?.addEventListener('blur', () => requestAnimationFrame(sizeChatLayout));
        document.querySelector('#chat-back-to-images')?.addEventListener('click', () => {
            document.querySelector('#tab-txt2img')?.click();
            document.querySelector('#tab-txt2img')?.focus();
        });
        window.addEventListener('resize', () => {
            sizeChatLayout();
            if (chatSidebar) chatSidebar.inert = window.innerWidth <= 760
                ? !chatSidebar.classList.contains('expanded') : chatLayout?.classList.contains('sidebar-collapsed');
            // The textarea's height was measured at the old width; re-measure or a
            // wrapped line can leave it stuck several rows tall after a resize.
            autoResizeInput();
        });

        chatMessagesContainer?.addEventListener('scroll', updatePinnedState, { passive: true });
        chatMessagesContainer?.addEventListener('click', event => {
            const suggestion = event.target.closest('.chat-suggestion[data-prompt]');
            if (suggestion) fillComposer(suggestion.dataset.prompt);
        });
        chatJumpLatest?.addEventListener('click', () => scrollToBottom('smooth'));

        chatInput?.addEventListener('input', () => {
            updateCharCount();
            autoResizeInput();
            setComposerState();
        });

        chatInput?.addEventListener('keydown', event => {
            if (event.isComposing) return;

            if (event.key === 'Enter') {
                if (event.ctrlKey || event.metaKey) {
                    event.preventDefault();
                    handleComposerSubmit();
                    return;
                }
                if (isMobileDevice()) {
                    // On mobile keyboards, Return inserts a newline; send only via Send button or Ctrl/Cmd+Enter.
                    return;
                }
                if (!event.shiftKey) {
                    event.preventDefault();
                    handleComposerSubmit();
                    return;
                }
            }
            // Empty composer + Up: edit the last thing you said, as in most chat apps.
            if (event.key === 'ArrowUp' && !chatInput.value && !isStreaming()) {
                const lastUser = [...activeMessages].reverse().find(msg => msg.role === 'user' && !msg.pending);
                if (lastUser) {
                    event.preventDefault();
                    beginEdit(lastUser);
                    lastUser.el?.scrollIntoView({ block: 'center' });
                }
            }
        });

        document.addEventListener('keydown', event => {
            if (!document.body.classList.contains('studio-chat-active')) return;
            if (event.key === 'Escape') {
                if (openRowMenu) { closeRowMenu(); return; }
                if (isStreaming()) { stopGenerating(); return; }
            }
            if ((event.ctrlKey || event.metaKey) && event.shiftKey && event.key.toLowerCase() === 'o') {
                event.preventDefault();
                startNewChat();
            }
        });

        document.addEventListener('click', event => {
            if (openRowMenu && !event.target.closest('.chat-row-menu')) closeRowMenu();
        });
        window.addEventListener('resize', closeRowMenu);

        if (chatSyncChannel) {
            chatSyncChannel.onmessage = event => {
                if (!event.data || isStreaming()) return;
                const { type, chatId } = event.data;
                if (type === 'chat-deleted' && chatId && chatId === activeChatId) {
                    startNewChat();
                    return;
                }
                if (type === 'chat-updated' || type === 'chat-deleted') scheduleSync(50);
            };
        }

        document.addEventListener('visibilitychange', () => {
            if (!document.hidden && isUnlocked()) scheduleSync(50);
        });

        window.addEventListener('studio-unlocked', () => {
            loadChats().then(() => scheduleSync(800));
            loadMemories();
        });

        // Mobile history is a drawer, leaving the full conversation height available.
        if (chatSidebarHeader && chatSidebar) {
            chatSidebarHeader.removeAttribute('role');
            chatSidebarHeader.removeAttribute('tabindex');
            chatSidebarHeader.removeAttribute('aria-expanded');
            chatSidebarHeader.removeAttribute('title');
            const close = document.createElement('button');
            close.id = 'chat-drawer-close';
            close.className = 'chat-icon-btn chat-drawer-close';
            close.type = 'button';
            close.textContent = '×';
            close.setAttribute('aria-label', 'Close conversation list');
            close.onclick = () => setMobileSidebar(false, true);
            chatSidebarHeader.append(close);
            const backdrop = document.createElement('button');
            backdrop.id = 'chat-drawer-backdrop';
            backdrop.className = 'chat-drawer-backdrop';
            backdrop.type = 'button';
            backdrop.hidden = true;
            backdrop.tabIndex = -1;
            backdrop.setAttribute('aria-label', 'Close conversation list');
            backdrop.onclick = () => setMobileSidebar(false, true);
            chatLayout.append(backdrop);
            sidebarCollapseBtn?.setAttribute('aria-controls', 'chat-sidebar');
            setMobileSidebar(false);
            document.addEventListener('keydown', event => {
                if (event.key === 'Escape' && window.innerWidth <= 760 && chatSidebar.classList.contains('expanded')) {
                    setMobileSidebar(false, true);
                }
            });
        }

        const heroDescription = document.querySelector('.studio-hero .hero-description');
        const heroDefault = heroDescription ? heroDescription.textContent : '';
        window.addEventListener('studio-mode-change', event => {
            const isChat = event.detail?.mode === 'chat';
            document.body.dataset.studioMode = event.detail?.mode || '';
            document.body.classList.toggle('studio-chat-active', isChat);
            if (heroDescription) {
                heroDescription.textContent = isChat
                    ? 'Talk to a local uncensored model running on your own PC.'
                    : heroDefault;
            }
            if (isChat) {
                if (isUnlocked()) scheduleSync(50);
                requestAnimationFrame(() => {
                    sizeChatLayout();
                    scrollToBottom();
                });
                if (window.innerWidth > 760) chatInput?.focus();
            }
        });

        if (document.querySelector('#tab-chat')?.classList.contains('active')) {
            document.body.dataset.studioMode = 'chat';
            document.body.classList.add('studio-chat-active');
        }

        if (isUnlocked()) {
            loadChats().then(() => scheduleSync(800));
            loadMemories();
        }

        inpaintModal.init();
        // Not awaited: the composer works while the scan runs, and the picker is
        // corrected when it answers.
        applyHardwareProfile();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();

(function () {
    'use strict';

    // Updates.
    //
    // The check runs once, quietly, a few seconds after the page settles. It is
    // a request to a third party, so it does not fire during startup where it
    // would compete with the things the studio actually needs, and it never
    // interrupts: if there is nothing new, nothing appears at all.
    //
    // Installing is always a second, deliberate press. The check only reads.

    const pill = document.querySelector('#update-pill');
    const dialog = document.querySelector('#update-dialog');
    if (!pill || !dialog) return;

    const closeBtn = document.querySelector('#update-close');
    const installBtn = document.querySelector('#update-install');
    const versionEl = document.querySelector('#update-version');
    const notesEl = document.querySelector('#update-notes');
    const statusEl = document.querySelector('#update-status');

    let info = null;

    async function call(action, method) {
        const response = await fetch('/api/studio?action=' + action, {
            method: method || 'GET',
            headers: method === 'POST' ? { 'Content-Type': 'application/json' } : {},
            body: method === 'POST' ? '{}' : undefined
        });
        const result = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(result.error || 'The update server did not answer.');
        return result;
    }

    function show(latest) {
        if (!latest?.available) return;
        info = latest;
        if (!pill.hidden) return;                 // already offered
        pill.hidden = false;
        // Named rather than "Update available", so the number in the corner and
        // the number on the button are obviously the same kind of thing.
        pill.textContent = info.build ? ('Update to Build ' + info.build) : 'Update available';
    }

    async function check() {
        try {
            show(await call('update-check'));
        } catch (error) {
            // Offline, rate limited, or no release server yet. None of that is
            // the user's problem and none of it is worth a banner.
        }
    }

    pill.addEventListener('click', () => {
        if (!info) return;
        versionEl.textContent = info.version || info.latest || 'a newer build';
        if (info.installedBuild) {
            versionEl.textContent += ' — you have Build ' + info.installedBuild;
        }
        const notes = info.notes || 'No notes were published with this release.';
        if (window.StudioVersionLog) {
            window.StudioVersionLog.renderNotes(notesEl, notes);
        } else {
            notesEl.textContent = notes;
        }
        statusEl.textContent = '';
        installBtn.disabled = false;
        dialog.showModal();
    });

    closeBtn?.addEventListener('click', () => dialog.close());
    dialog.addEventListener('click', event => { if (event.target === dialog) dialog.close(); });

    installBtn?.addEventListener('click', async () => {
        installBtn.disabled = true;
        statusEl.textContent = 'Downloading and checking the release…';
        try {
            const result = await call('update-apply', 'POST');
            if (!result.ok) {
                statusEl.textContent = result.reason || 'Nothing to install.';
                installBtn.disabled = false;
                return;
            }
            statusEl.textContent = 'Installed ' + (result.version || 'the update') + ' — '
                + result.files + ' files. ' + (result.restart || '');
            pill.hidden = true;
        } catch (error) {
            statusEl.textContent = error.message;
            installBtn.disabled = false;
        }
    });

    // The server checks on a timer and reports what it found on the status
    // poll, so a release appears here on its own - no reload, and no request
    // from this page. That was the whole problem with the old behaviour: one
    // fetch six seconds after load and never again, so a studio left open
    // never noticed.
    window.addEventListener('studio-update-info', event => show(event.detail));

    // A backstop for the case where the status poll is not running: the
    // unlock screen, or a page that has not got that far. Cheap, because the
    // endpoint answers from the server's cache without touching the network.
    setTimeout(check, 6000);
    setInterval(check, 120000);
}());

(function () {
    'use strict';

    // The build number and the version log behind it.
    //
    // Three things, and they are the same thing seen from different angles:
    //
    //   1. A faint "Build 7" in the corner, so a problem report can name a
    //      version and so nobody has to guess whether an update landed.
    //   2. Clicking it opens the whole log.
    //   3. After an update, it opens itself once. Being told what changed is
    //      the part people actually want and the part that is easiest to skip,
    //      so the first launch on a new build does it for them.
    //
    // (3) is deliberately once. It fires when the number goes up and never
    // again, and never at all on a fresh install, where there is no previous
    // build to have changed from.

    const badge = document.querySelector('#build-badge');
    const dialog = document.querySelector('#changelog-dialog');
    if (!badge || !dialog) return;

    const list = document.querySelector('#changelog-entries');
    const subtitle = document.querySelector('#changelog-subtitle');
    const closeBtn = document.querySelector('#changelog-close');
    const doneBtn = document.querySelector('#changelog-done');

    const SEEN_KEY = 'studio-seen-build';
    const DEFAULT_SUBTITLE = subtitle ? subtitle.textContent : '';

    function seenBuild() {
        // Private windows, blocked site data and a few managed profiles all
        // make this throw rather than return nothing.
        try {
            const raw = localStorage.getItem(SEEN_KEY);
            const value = parseInt(raw, 10);
            return Number.isFinite(value) ? value : null;
        } catch (error) {
            return null;
        }
    }

    function rememberBuild(build) {
        try {
            localStorage.setItem(SEEN_KEY, String(build));
        } catch (error) {
            // Then the log opens again next launch. Annoying, not broken.
        }
    }

    function renderBody(markdown) {
        const holder = document.createElement('div');
        holder.className = 'changelog-body';
        if (!markdown) {
            holder.textContent = 'No notes were written for this build.';
            return holder;
        }
        // The same pair chat uses. This text shipped inside the build rather
        // than arriving from anywhere, but sanitising it costs nothing and the
        // habit is worth more than the exception.
        if (window.marked && window.DOMPurify) {
            try {
                holder.innerHTML = window.DOMPurify.sanitize(window.marked.parse(markdown));
                return holder;
            } catch (error) {
                // Fall through to plain text.
            }
        }
        const pre = document.createElement('p');
        pre.style.whiteSpace = 'pre-wrap';
        pre.textContent = markdown;
        holder.appendChild(pre);
        return holder;
    }

    function render(info) {
        list.textContent = '';
        const entries = info.entries || [];
        if (!entries.length) {
            const empty = document.createElement('p');
            empty.className = 'changelog-empty';
            empty.textContent = 'This build shipped without a version log.';
            list.appendChild(empty);
            return;
        }
        entries.forEach(entry => {
            const section = document.createElement('section');
            section.className = 'changelog-entry';

            const heading = document.createElement('div');
            heading.className = 'changelog-entry-heading';

            const title = document.createElement('h3');
            title.textContent = 'Build ' + entry.build;
            heading.appendChild(title);

            if (entry.date) {
                const date = document.createElement('span');
                date.className = 'changelog-date';
                date.textContent = entry.date;
                heading.appendChild(date);
            }
            if (entry.build === info.build) {
                const here = document.createElement('span');
                here.className = 'changelog-yours';
                here.textContent = 'You have this';
                heading.appendChild(here);
            }

            section.appendChild(heading);
            section.appendChild(renderBody(entry.body));
            list.appendChild(section);
        });
    }

    function open(note) {
        if (subtitle) subtitle.textContent = note || DEFAULT_SUBTITLE;
        list.scrollTop = 0;
        if (!dialog.open) dialog.showModal();
    }

    badge.addEventListener('click', () => open());
    closeBtn?.addEventListener('click', () => dialog.close());
    doneBtn?.addEventListener('click', () => dialog.close());
    dialog.addEventListener('click', event => {
        if (event.target === dialog) dialog.close();
    });

    async function load() {
        let info;
        try {
            const response = await fetch('/api/studio?action=version');
            if (!response.ok) return;
            info = await response.json();
        } catch (error) {
            return;
        }
        if (!info || !info.build) return;

        badge.textContent = info.label || ('Build ' + info.build);
        if (!info.released) {
            // A working copy, not an installed release. Worth saying, because
            // the number in the log is whatever is being written next rather
            // than something anybody has been given.
            const note = document.createElement('span');
            note.className = 'build-badge-note';
            note.textContent = ' · source';
            badge.appendChild(note);
        }
        badge.title = 'Version log' + (info.commit ? ' — ' + info.commit.slice(0, 7) : '');
        badge.hidden = false;
        render(info);

        const previous = seenBuild();
        rememberBuild(info.build);
        // Nothing to announce on a first run, and nothing to announce if they
        // have somehow gone backwards - only an actual step up.
        if (previous === null || previous >= info.build) return;

        // Late enough that the studio has drawn and any unlock step is up; a
        // modal that appears over a half-painted page reads as a fault.
        setTimeout(() => {
            if (document.querySelector('dialog[open]')) return;
            const jump = info.build - previous;
            open('Updated to ' + (info.label || 'Build ' + info.build) + '. '
                 + (jump === 1 ? 'Here is what changed.'
                               : 'Here is what changed across the last ' + jump + ' builds.'));
        }, 1500);
    }

    // Shared with the update dialog, which shows the entry for the build being
    // offered and would otherwise carry a second copy of this.
    window.StudioVersionLog = {
        renderNotes(target, markdown) {
            target.textContent = '';
            target.appendChild(renderBody(markdown));
        }
    };

    load();
}());

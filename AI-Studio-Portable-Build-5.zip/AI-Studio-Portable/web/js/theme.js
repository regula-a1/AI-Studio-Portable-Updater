(function () {
    const legacyStorageKey = "aistudio-theme";
    const modeStorageKey = "aistudio-theme-mode";
    const lightSchemeStorageKey = "aistudio-light-theme";
    const darkSchemeStorageKey = "aistudio-dark-theme";
    const sessionStorageKey = "aistudio-current-user";
    const defaultSchemes = {
        light: "daylight",
        dark: "midnight"
    };
    const schemes = {
        light: [
            {
                id: "daylight",
                name: "Daylight",
                description: "The original bright glass theme with blue accents.",
                swatches: ["#f8fbff", "#eef4fb", "#2563eb", "#16805a"]
            },
            {
                id: "seafoam",
                name: "Seafoam",
                description: "A calm glass theme with mint surfaces and teal accents.",
                swatches: ["#f1fffb", "#ddf8f0", "#0f766e", "#16a34a"]
            },
            {
                id: "notebook",
                name: "Notebook",
                description: "A clean paper-light theme with ink text and blue detail.",
                swatches: ["#fbfbf7", "#eef1f5", "#2563eb", "#2f6f5c"]
            },
            {
                id: "candy-glass",
                name: "Candy Glass",
                description: "A playful bright glass theme with pink and mint accents.",
                swatches: ["#fff1f6", "#e0f2fe", "#db2777", "#14b8a6"]
            },
            {
                id: "solar-desk",
                name: "Solar Desk",
                description: "A warm daytime workspace theme with amber highlights.",
                swatches: ["#fffef3", "#edf7df", "#ca8a04", "#15803d"]
            },
            {
                id: "blueprint",
                name: "Blueprint",
                description: "A crisp technical theme with blue and cyan accents.",
                swatches: ["#f8fbff", "#e0f2fe", "#1d4ed8", "#0891b2"]
            },
            {
                id: "cloud",
                name: "Cloud",
                description: "A monochrome frosted-glass theme with bright white and gray.",
                swatches: ["#ffffff", "#f4f4f4", "#1f1f1f", "#d2d2d2"]
            },
            {
                id: "violet-ember",
                name: "Violet Ember",
                description: "A purple and orange glass theme.",
                swatches: ["#f5f3ff", "#ede9fe", "#8b5cf6", "#f97316"],
            }
        ],
        dark: [
            {
                id: "midnight",
                name: "Midnight",
                description: "The original dark theme with cool blue-black glass.",
                swatches: ["#0d1118", "#181d26", "#8ab4ff", "#7ad6a8"]
            },
            {
                id: "deep-sea",
                name: "Deep Sea",
                description: "A deep navy glass theme with aqua and seafoam accents.",
                swatches: ["#06151a", "#0d2b33", "#67e8f9", "#5eead4"]
            },
            {
                id: "terminal",
                name: "Terminal",
                description: "A quiet charcoal theme with phosphor green highlights.",
                swatches: ["#090b0a", "#111713", "#86efac", "#22c55e"]
            },
            {
                id: "neon-arcade",
                name: "Neon Arcade",
                description: "A high-energy dark theme with cyan and pink neon.",
                swatches: ["#090a12", "#161827", "#22d3ee", "#f472b6"]
            },
            {
                id: "carbon-rose",
                name: "Carbon Rose",
                description: "A soft black-plum theme with rose and lavender accents.",
                swatches: ["#120b10", "#21121d", "#fb7185", "#c084fc"]
            },
            {
                id: "copper-night",
                name: "Copper Night",
                description: "A warm neutral dark theme with copper and blue highlights.",
                swatches: ["#0d0f12", "#1b1a18", "#f59e0b", "#7dd3fc"]
            },
            {
                id: "blackout",
                name: "Blackout",
                description: "A deeper dark theme built around solid blacks and neutral charcoal.",
                swatches: ["#030303", "#101010", "#f2f2f2", "#4ade80"]
            },
            {
                id: "violet-ember",
                name: "Violet Ember",
                description: "A purple and orange dark theme.",
                swatches: ["#0f0a14", "#1f142b", "#a78bfa", "#fdba74"],
            }
        ]
    };
    const toggles = new Set();
    let currentUser = null;

    function normalizeTheme(theme) {
        return theme === "dark" || theme === "light" ? theme : "light";
    }

    function themeSchemes(theme) {
        return schemes[normalizeTheme(theme)];
    }

    function normalizeUserId(value) {
        return String(value || "").trim().toLowerCase();
    }

    function storedUserMatches(user) {
        const userId = normalizeUserId(user && user.id);
        const storedUserId = normalizeUserId(localStorage.getItem(sessionStorageKey));
        return Boolean(userId && userId !== "guest" && storedUserId && storedUserId === userId);
    }

    function currentUserHasPermission(permission) {
        return Boolean(
            permission
            && currentUser
            && Array.isArray(currentUser.permissions)
            && currentUser.permissions.includes(permission)
        );
    }

    function currentUserMatchesAllowedId(userIds) {
        const userId = normalizeUserId(currentUser && currentUser.id);
        return Array.isArray(userIds)
            && userIds.map(normalizeUserId).includes(userId);
    }

    function schemeIsAvailable(scheme) {
        if (!scheme) {
            return false;
        }

        const hasGate = Boolean(scheme.permission || (Array.isArray(scheme.userIds) && scheme.userIds.length));
        if (!hasGate) {
            return true;
        }

        if (!storedUserMatches(currentUser)) {
            return false;
        }

        return currentUserHasPermission(scheme.permission) || currentUserMatchesAllowedId(scheme.userIds);
    }

    function getSchemes(theme) {
        return themeSchemes(theme).filter(schemeIsAvailable);
    }

    function normalizeScheme(theme, scheme) {
        const normalizedTheme = normalizeTheme(theme);
        const normalizedScheme = String(scheme || "").trim().toLowerCase();
        return themeSchemes(normalizedTheme).some((item) => item.id === normalizedScheme && schemeIsAvailable(item))
            ? normalizedScheme
            : defaultSchemes[normalizedTheme];
    }

    function currentTheme() {
        return normalizeTheme(document.documentElement.dataset.theme);
    }

    function systemMode() {
        // Only ever consulted when the user has made no choice. Once they press the
        // toggle, that choice is theirs and the operating system stops being asked.
        try {
            return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
        } catch (error) {
            return "light";
        }
    }

    function storedMode() {
        let stored = null;
        try {
            stored = localStorage.getItem(modeStorageKey) || localStorage.getItem(legacyStorageKey);
        } catch (error) {
            // A private window, or site data blocked. Fall through to the system.
            return systemMode();
        }
        if (stored === "dark" || stored === "light") {
            try { localStorage.setItem(modeStorageKey, stored); } catch (error) { /* read-only storage */ }
            return stored;
        }
        return systemMode();
    }

    function getStoredScheme(theme) {
        const normalizedTheme = normalizeTheme(theme);
        const key = normalizedTheme === "dark" ? darkSchemeStorageKey : lightSchemeStorageKey;
        return normalizeScheme(normalizedTheme, localStorage.getItem(key));
    }

    function activeSchemeFor(theme) {
        return getStoredScheme(theme);
    }

    function applyTheme(theme) {
        const nextTheme = normalizeTheme(theme);
        const nextScheme = activeSchemeFor(nextTheme);
        document.documentElement.dataset.theme = nextTheme;
        document.documentElement.dataset.themeScheme = nextScheme;
        return nextTheme;
    }

    function setTheme(theme) {
        const nextTheme = applyTheme(theme);
        try { localStorage.setItem(modeStorageKey, nextTheme); } catch (error) { /* not remembered */ }
        updateAllToggles();
        window.dispatchEvent(new CustomEvent("aistudio-theme-change", {
            detail: getPreferences()
        }));
        return nextTheme;
    }

    function setScheme(theme, schemeId) {
        const normalizedTheme = normalizeTheme(theme);
        const nextScheme = normalizeScheme(normalizedTheme, schemeId);
        const key = normalizedTheme === "dark" ? darkSchemeStorageKey : lightSchemeStorageKey;
        localStorage.setItem(key, nextScheme);
        if (currentTheme() === normalizedTheme) {
            applyTheme(normalizedTheme);
            updateAllToggles();
        }
        window.dispatchEvent(new CustomEvent("aistudio-theme-change", {
            detail: getPreferences()
        }));
        return nextScheme;
    }

    function resetSchemes() {
        localStorage.setItem(lightSchemeStorageKey, defaultSchemes.light);
        localStorage.setItem(darkSchemeStorageKey, defaultSchemes.dark);
        applyTheme(currentTheme());
        updateAllToggles();
        window.dispatchEvent(new CustomEvent("aistudio-theme-change", {
            detail: getPreferences()
        }));
        return getPreferences();
    }

    function getPreferences() {
        const mode = currentTheme();
        const lightScheme = getStoredScheme("light");
        const darkScheme = getStoredScheme("dark");
        return {
            mode,
            lightScheme,
            darkScheme,
            activeScheme: mode === "dark" ? darkScheme : lightScheme
        };
    }

    function setCurrentUser(user) {
        const previousScheme = document.documentElement.dataset.themeScheme;
        currentUser = user && user.id ? user : null;
        applyTheme(currentTheme());
        updateAllToggles();

        const preferences = getPreferences();
        window.dispatchEvent(new CustomEvent("aistudio-theme-access-change", {
            detail: preferences
        }));
        if (previousScheme !== preferences.activeScheme) {
            window.dispatchEvent(new CustomEvent("aistudio-theme-change", {
                detail: preferences
            }));
        }
        return currentUser;
    }

    function refreshAccess() {
        if (!window.StudioAuth || typeof window.StudioAuth.getCurrentUser !== "function") {
            return Promise.resolve(setCurrentUser(null));
        }

        return window.StudioAuth.getCurrentUser()
            .then((user) => setCurrentUser(user))
            .catch(() => setCurrentUser(null));
    }

    function updateToggle(button) {
        if (button) {
            const theme = currentTheme();
            if (!button.dataset.iconOnly) {
                button.textContent = theme === "dark" ? "Light" : "Dark";
            }
            button.dataset.themeState = theme;
            button.title = theme === "dark" ? "Use light theme" : "Use dark theme";
            button.setAttribute("aria-label", button.title);
        }
    }

    function updateAllToggles() {
        Array.from(toggles).forEach((button) => {
            if (!button.isConnected) {
                toggles.delete(button);
                return;
            }
            updateToggle(button);
        });
    }

    function initToggle(button) {
        updateToggle(button);
        if (!button) {
            return;
        }

        toggles.add(button);
        if (button.dataset.themeReady === "true") {
            return;
        }

        button.dataset.themeReady = "true";

        button.addEventListener("click", (event) => {
            const isDark = currentTheme() === "dark";
            const toggle = () => setTheme(isDark ? "light" : "dark");

            if (!document.startViewTransition || window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
                toggle();
                return;
            }

            const x = event.clientX;
            const y = event.clientY;
            document.documentElement.style.setProperty("--theme-x", `${x}px`);
            document.documentElement.style.setProperty("--theme-y", `${y}px`);
            document.documentElement.classList.add("theme-transition");

            const wanted = isDark ? "light" : "dark";
            let transition;
            try {
                transition = document.startViewTransition(toggle);
            } catch (error) {
                // Could not even start one. Change the theme anyway.
                toggle();
                document.documentElement.classList.remove("theme-transition");
                return;
            }
            // A transition started while another is running is skipped, and every
            // promise it hands back then rejects. Unattended that surfaced as uncaught
            // InvalidStateErrors in the console on a fast double press, so all three
            // are swallowed.
            //
            // The retry matters more. The theme change lives inside the callback the
            // transition runs, so a transition skipped before it gets that far leaves
            // the theme untouched and the press looks like it did nothing at all.
            // Observed with a modal dialog open. Whatever happened, once it has
            // settled, check and apply plainly if it did not take.
            const done = () => {
                document.documentElement.classList.remove("theme-transition");
                if (currentTheme() !== wanted) {
                    toggle();
                }
            };
            const ignore = () => {};
            transition.ready.then(ignore, ignore);
            transition.updateCallbackDone.then(ignore, ignore);
            transition.finished.then(done, done);
        });
    }

    applyTheme(storedMode());

    window.StudioTheme = {
        initToggles: wireDeclaredToggles,
        get schemes() {
            return {
                light: getSchemes("light"),
                dark: getSchemes("dark")
            };
        },
        currentTheme,
        setTheme,
        getPreferences,
        getSchemes,
        setScheme,
        resetSchemes,
        refreshAccess,
        setCurrentUser,
        updateAllToggles,
        initToggle
    };

    // Any element carrying data-theme-toggle becomes one, so a page that wants the
    // control only has to put the button somewhere. Nothing in this build called
    // initToggle, which is why the theme engine was complete and yet unreachable.
    function wireDeclaredToggles() {
        document.querySelectorAll("[data-theme-toggle]").forEach(initToggle);
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", function () {
            wireDeclaredToggles();
            refreshAccess();
        });
    } else {
        wireDeclaredToggles();
        refreshAccess();
    }
    window.addEventListener("aistudio-auth-change", refreshAccess);
    window.addEventListener("storage", refreshAccess);
}());

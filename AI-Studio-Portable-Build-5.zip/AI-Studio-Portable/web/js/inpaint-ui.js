/*
 * Shared UI plumbing for the inpaint canvases: the pointer/gesture layer and
 * the toolbar overflow menu.
 *
 * All inpaint surfaces (the image workspace and the chat
 * inpaint dialog) used to bind their own mouse-only listeners, which meant a
 * touch device could not paint a stroke, could not pan and could not zoom.
 * This module owns the input pipeline for every surface so the touch maths
 * only exists once:
 *
 *   1 finger on the image   -> paint / erase
 *   1 finger off the image  -> drag to pan
 *   2 fingers               -> pinch to zoom + drag to pan
 *   mouse                   -> left drag paints, space/middle pans, and
 *                              Alt + right drag resizes the brush the way
 *                              Photoshop does
 *
 * Dropping a second finger mid-stroke cancels the stroke the first finger
 * started, so starting a pinch never leaves a stray blob on the mask.
 *
 * The host page keeps ownership of its own zoom/pan state; this module reads
 * and writes it through the accessors passed to attach().
 */
(function () {
    "use strict";

    const DEFAULT_MIN_ZOOM = 0.05;
    const DEFAULT_MAX_ZOOM = 25;

    function clamp(value, low, high) {
        return Math.max(low, Math.min(high, value));
    }

    function attach(config) {
        const stage = config.stage;
        if (!stage) return null;

        const minZoom = config.minZoom ?? DEFAULT_MIN_ZOOM;
        const maxZoom = config.maxZoom ?? DEFAULT_MAX_ZOOM;
        const isReady = config.isReady || (() => true);

        // Live pointers on the stage, keyed by pointerId.
        const pointers = new Map();
        let mode = null;            // "draw" | "pan" | "pinch"
        let drawId = null;
        let panId = null;
        let panStartX = 0;
        let panStartY = 0;
        let pinch = null;           // { dist, cx, cy }
        let sizeId = null;
        let sizing = null;          // { startX, startSize, anchorX, anchorY }
        let swallowContextMenu = false;

        function points() {
            return Array.from(pointers.values());
        }

        function notifyPanning(active) {
            config.onPanStateChange?.(active);
        }

        function releaseCapture(pointerId) {
            if (pointerId == null) return;
            try {
                if (stage.hasPointerCapture(pointerId)) stage.releasePointerCapture(pointerId);
            } catch (err) {
                /* pointer already gone */
            }
        }

        function capture(pointerId) {
            try {
                stage.setPointerCapture(pointerId);
            } catch (err) {
                /* capture is a nicety, not a requirement */
            }
        }

        // Keep a usable slice of the image on screen so a stray flick can never
        // strand the canvas outside the stage with no way back.
        function clampPan(x, y) {
            const size = config.getContentSize?.();
            if (!size || !size.width || !size.height) return { x, y };
            const zoom = config.getZoom();
            const stageW = stage.clientWidth;
            const stageH = stage.clientHeight;
            const shownW = size.width * zoom;
            const shownH = size.height * zoom;
            const keepX = Math.min(shownW, Math.max(48, stageW * 0.2));
            const keepY = Math.min(shownH, Math.max(48, stageH * 0.2));
            return {
                x: clamp(x, keepX - shownW, stageW - keepX),
                y: clamp(y, keepY - shownH, stageH - keepY)
            };
        }

        function setPan(x, y) {
            const next = clampPan(x, y);
            config.setPan(next.x, next.y);
            config.applyTransform();
        }

        // Zoom around a viewport point so the pixel under the fingers/cursor
        // stays put.
        function zoomAt(clientX, clientY, factor) {
            const rect = stage.getBoundingClientRect();
            const stageX = clientX - rect.left;
            const stageY = clientY - rect.top;
            const zoom = config.getZoom();
            const pan = config.getPan();
            const nextZoom = clamp(zoom * factor, minZoom, maxZoom);
            if (Math.abs(nextZoom - zoom) < 0.0001) return;

            const imgX = (stageX - pan.x) / zoom;
            const imgY = (stageY - pan.y) / zoom;
            config.setZoom(nextZoom);
            setPan(stageX - imgX * nextZoom, stageY - imgY * nextZoom);
        }

        function beginPinch() {
            const [a, b] = points();
            if (!a || !b) return;
            pinch = {
                dist: Math.hypot(a.x - b.x, a.y - b.y) || 1,
                cx: (a.x + b.x) / 2,
                cy: (a.y + b.y) / 2
            };
        }

        function beginPan(pointerId, point) {
            const pan = config.getPan();
            mode = "pan";
            panId = pointerId;
            panStartX = point.x - pan.x;
            panStartY = point.y - pan.y;
            capture(pointerId);
            notifyPanning(true);
            config.onCursor?.(null);
        }

        /*
         * Photoshop resizes the brush on Alt + right-drag (Windows) or
         * Ctrl + Alt + left-drag (macOS): drag right to grow, left to shrink.
         * The ring stays pinned where the drag started so you can judge the
         * new size against the pixels you are about to paint.
         */
        function isSizeGesture(event) {
            if (event.pointerType !== "mouse") return false;
            if (!config.getBrushSize || !config.setBrushSize) return false;
            // Never hijack a gesture already under way: a right-click landing
            // mid-stroke would otherwise strand the stroke with no end event.
            if (mode) return false;
            if (event.button === 2) return event.altKey;
            return event.button === 0 && event.altKey && (event.ctrlKey || event.metaKey);
        }

        function beginSize(event) {
            mode = "size";
            sizeId = event.pointerId;
            sizing = {
                startX: event.clientX,
                startSize: config.getBrushSize(),
                anchorX: event.clientX,
                anchorY: event.clientY
            };
            swallowContextMenu = true;
            capture(event.pointerId);
            config.onCursor?.({ clientX: sizing.anchorX, clientY: sizing.anchorY });
        }

        function updateSize(event) {
            if (!sizing) return;
            // The brush is measured in image pixels but drawn through the zoom
            // transform, so dividing by the zoom keeps the drag 1:1 with the
            // ring the cursor is showing.
            const zoom = config.getZoom?.() || 1;
            const delta = (event.clientX - sizing.startX) / (zoom || 1);
            config.setBrushSize(sizing.startSize + delta);
            config.onCursor?.({ clientX: sizing.anchorX, clientY: sizing.anchorY });
        }

        function isOverImage(clientX, clientY) {
            const rect = config.getMaskRect?.();
            if (!rect || !rect.width || !rect.height) return false;
            return clientX >= rect.left && clientX <= rect.right &&
                   clientY >= rect.top && clientY <= rect.bottom;
        }

        function onPointerDown(event) {
            config.onStageFocus?.();
            if (!isReady()) return;

            if (isSizeGesture(event)) {
                event.preventDefault();
                beginSize(event);
                return;
            }

            if (event.pointerType === "mouse" && event.button !== 0 && event.button !== 1) return;

            pointers.set(event.pointerId, {
                x: event.clientX,
                y: event.clientY,
                type: event.pointerType
            });

            if (pointers.size === 2) {
                // A pinch is starting. Throw away whatever the first finger
                // just painted rather than leaving a dot behind.
                if (mode === "draw") {
                    config.onStrokeCancel?.();
                    releaseCapture(drawId);
                    drawId = null;
                }
                mode = "pinch";
                panId = null;
                beginPinch();
                capture(event.pointerId);
                notifyPanning(true);
                config.onCursor?.(null);
                event.preventDefault();
                return;
            }

            if (pointers.size > 2) return;

            const isTouchLike = event.pointerType !== "mouse";

            if (config.isPanModifier?.() || (event.pointerType === "mouse" && event.button === 1)) {
                event.preventDefault();
                beginPan(event.pointerId, { x: event.clientX, y: event.clientY });
                return;
            }

            if (isOverImage(event.clientX, event.clientY)) {
                mode = "draw";
                drawId = event.pointerId;
                capture(event.pointerId);
                config.onStrokeStart?.(event);
                config.onCursor?.(event);
                event.preventDefault();
                return;
            }

            // Touching the empty stage around the image drags the image, which
            // is the only way to pan without a keyboard.
            if (isTouchLike) {
                event.preventDefault();
                beginPan(event.pointerId, { x: event.clientX, y: event.clientY });
            }
        }

        function onPointerMove(event) {
            const tracked = pointers.get(event.pointerId);
            if (tracked) {
                tracked.x = event.clientX;
                tracked.y = event.clientY;
            }

            if (mode === "pinch" && pointers.size >= 2 && pinch) {
                const [a, b] = points();
                const dist = Math.hypot(a.x - b.x, a.y - b.y) || 1;
                const cx = (a.x + b.x) / 2;
                const cy = (a.y + b.y) / 2;

                // Track the two-finger centroid, then scale about it.
                const pan = config.getPan();
                setPan(pan.x + (cx - pinch.cx), pan.y + (cy - pinch.cy));
                zoomAt(cx, cy, dist / pinch.dist);

                pinch = { dist, cx, cy };
                event.preventDefault();
                return;
            }

            if (mode === "size" && event.pointerId === sizeId) {
                updateSize(event);
                event.preventDefault();
                return;
            }

            if (mode === "pan" && event.pointerId === panId) {
                setPan(event.clientX - panStartX, event.clientY - panStartY);
                event.preventDefault();
                return;
            }

            if (mode === "draw" && event.pointerId === drawId) {
                // Coalesced events keep fast strokes smooth on high-rate touch
                // screens instead of drawing long straight chords.
                const steps = typeof event.getCoalescedEvents === "function"
                    ? event.getCoalescedEvents()
                    : null;
                if (steps && steps.length) {
                    steps.forEach(step => config.onStrokeMove?.(step));
                } else {
                    config.onStrokeMove?.(event);
                }
                config.onCursor?.(event);
                event.preventDefault();
                return;
            }

            if (!mode) config.onCursor?.(event);
        }

        function endPointer(event) {
            pointers.delete(event.pointerId);
            releaseCapture(event.pointerId);

            if (mode === "size" && event.pointerId === sizeId) {
                sizeId = null;
                sizing = null;
                mode = null;
                config.onCursor?.(event);
                return;
            }

            if (mode === "draw" && event.pointerId === drawId) {
                drawId = null;
                mode = null;
                config.onStrokeEnd?.(event);
            } else if (mode === "pan" && event.pointerId === panId) {
                panId = null;
                mode = null;
                notifyPanning(false);
            } else if (mode === "pinch" && pointers.size < 2) {
                pinch = null;
                const remainingId = Array.from(pointers.keys())[0];
                const remaining = remainingId != null ? pointers.get(remainingId) : null;
                if (remaining) {
                    // Lifting one finger of a pinch keeps panning with the
                    // other; it never falls back into painting mid-gesture.
                    beginPan(remainingId, remaining);
                } else {
                    mode = null;
                    notifyPanning(false);
                }
            }

            if (pointers.size === 0 && mode !== "draw") {
                mode = null;
                notifyPanning(false);
            }
        }

        function onPointerLeave() {
            if (!mode) config.onCursor?.(null);
        }

        function onContextMenu(event) {
            // Chrome raises this on the press, Firefox on the release, so the
            // resize drag is swallowed at whichever end it arrives.
            if (swallowContextMenu || mode === "size" || event.altKey) {
                swallowContextMenu = false;
                event.preventDefault();
                return;
            }
            if (pointers.size > 1) event.preventDefault();
        }

        stage.addEventListener("pointerdown", onPointerDown);
        stage.addEventListener("pointermove", onPointerMove);
        stage.addEventListener("pointerup", endPointer);
        stage.addEventListener("pointercancel", endPointer);
        stage.addEventListener("pointerleave", onPointerLeave);
        stage.addEventListener("contextmenu", onContextMenu);

        return {
            zoomAt,
            clampPan,
            setPan,
            isGesturing: () => mode === "pinch" || mode === "pan" || mode === "size",
            reset() {
                pointers.forEach((_value, id) => releaseCapture(id));
                pointers.clear();
                mode = null;
                drawId = null;
                panId = null;
                pinch = null;
                sizeId = null;
                sizing = null;
                swallowContextMenu = false;
                notifyPanning(false);
            },
            destroy() {
                stage.removeEventListener("pointerdown", onPointerDown);
                stage.removeEventListener("pointermove", onPointerMove);
                stage.removeEventListener("pointerup", endPointer);
                stage.removeEventListener("pointercancel", endPointer);
                stage.removeEventListener("pointerleave", onPointerLeave);
                stage.removeEventListener("contextmenu", onContextMenu);
            }
        };
    }

    /*
     * The editor answers to Photoshop's muscle memory, so the key map lives
     * here once instead of drifting between the three surfaces that use it:
     *
     *   B / E / X              brush, eraser, swap between them
     *   [ / ]                  brush size (Shift for a coarse step)
     *   Space + drag           pan
     *   Ctrl/Cmd + Z           undo        Ctrl/Cmd + Shift + Z, Ctrl + Y  redo
     *   Ctrl/Cmd + 0 / 1       fit / 100%
     *   Ctrl/Cmd + + / -       zoom in / out about the middle of the stage
     *   Ctrl/Cmd + I           invert the mask
     *   Ctrl/Cmd + D           clear the mask
     *
     * Ctrl/Cmd + A is deliberately left alone: masking the whole canvas is a
     * destructive thing to do by accident, and select-all is worth more here.
     *
     * Every action is optional: a surface that has no Invert button leaves the
     * callback off and that key falls through to the browser untouched.
     */
    function attachShortcuts(config) {
        const isActive = config.isActive || (() => true);

        function isTypingTarget(target) {
            if (!target) return false;
            return target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable;
        }

        // Windows reads a bare Alt or F10 as "open the browser menu bar" and
        // Alt+Space as "open the window menu", either of which steals the key
        // out of a gesture that is still in progress.
        function isMenuKey(event) {
            return event.key === "Alt" || event.code === "AltLeft" || event.code === "AltRight" ||
                   event.keyCode === 18 || event.key === "F10" || event.keyCode === 121;
        }

        function isSpaceKey(event) {
            return event.code === "Space" || event.key === " " || event.keyCode === 32;
        }

        function run(event, action) {
            if (typeof action !== "function") return;
            event.preventDefault();
            event.stopPropagation();
            action();
        }

        function onKeyDown(event) {
            if (!isActive()) return;

            if (isMenuKey(event)) {
                event.preventDefault();
                return;
            }
            if (isSpaceKey(event) && event.altKey) {
                event.preventDefault();
                event.stopPropagation();
                return;
            }

            if (isTypingTarget(event.target)) return;

            if (isSpaceKey(event)) {
                event.preventDefault();
                event.stopPropagation();
                if (!event.repeat) config.onSpaceChange?.(true);
                return;
            }

            if (event.ctrlKey || event.metaKey) {
                const key = (event.key || "").toLowerCase();
                if (key === "0") run(event, config.fit);
                else if (key === "1") run(event, config.zoom100);
                else if (key === "=" || key === "+") run(event, () => config.zoomBy?.(1.25));
                else if (key === "-" || key === "_") run(event, () => config.zoomBy?.(1 / 1.25));
                else if (key === "z") run(event, event.shiftKey ? config.redo : config.undo);
                else if (key === "y") run(event, config.redo);
                else if (key === "i") run(event, config.invert);
                else if (key === "d") run(event, config.clear);
                return;
            }

            // Alt is the zoom and brush-resize modifier on the stage; it never
            // doubles as a tool shortcut.
            if (event.altKey) return;

            if (event.code === "KeyB") run(event, config.brush);
            else if (event.code === "KeyE") run(event, config.eraser);
            else if (event.code === "KeyX") run(event, config.toggleTool);
            else if (event.code === "BracketLeft") run(event, () => config.adjustBrush?.(event.shiftKey ? -10 : -2));
            else if (event.code === "BracketRight") run(event, () => config.adjustBrush?.(event.shiftKey ? 10 : 2));
        }

        function onKeyUp(event) {
            if (!isActive()) return;
            if (isMenuKey(event)) {
                event.preventDefault();
                return;
            }
            if (isSpaceKey(event)) {
                event.preventDefault();
                event.stopPropagation();
                config.onSpaceChange?.(false);
            }
        }

        // Alt-tabbing away holds Space down forever otherwise, and the editor
        // comes back stuck in pan mode.
        function onBlur() {
            config.onSpaceChange?.(false);
            config.onWindowBlur?.();
        }

        window.addEventListener("keydown", onKeyDown, true);
        window.addEventListener("keyup", onKeyUp, true);
        window.addEventListener("blur", onBlur);

        return {
            destroy() {
                window.removeEventListener("keydown", onKeyDown, true);
                window.removeEventListener("keyup", onKeyUp, true);
                window.removeEventListener("blur", onBlur);
            }
        };
    }

    /*
     * The toolbar carries more buttons than fit across a phone. On narrow
     * screens the secondary ones live behind a "More" button; on a wide screen
     * the CSS lays the same panel out inline and the trigger disappears.
     */
    function attachToolbarMenu(trigger, panel) {
        if (!trigger || !panel) return null;

        function isCollapsed() {
            // The stylesheet decides when the menu collapses, so ask the DOM
            // rather than duplicating the breakpoint here.
            return getComputedStyle(trigger).display !== "none";
        }

        function setOpen(open) {
            panel.classList.toggle("is-open", open);
            trigger.setAttribute("aria-expanded", open ? "true" : "false");
        }

        function close() {
            setOpen(false);
        }

        trigger.setAttribute("aria-expanded", "false");
        trigger.addEventListener("click", event => {
            event.preventDefault();
            event.stopPropagation();
            setOpen(!panel.classList.contains("is-open"));
        });

        // Picking a tool closes the menu so the canvas is not left covered.
        panel.addEventListener("click", event => {
            if (event.target.closest("button")) close();
        });

        // Capture phase: the tap that dismisses the menu is swallowed, so
        // reaching past the menu to close it does not also paint a blob on the
        // canvas underneath.
        document.addEventListener("pointerdown", event => {
            if (!panel.classList.contains("is-open")) return;
            if (panel.contains(event.target) || trigger.contains(event.target)) return;
            close();
            event.stopPropagation();
            event.preventDefault();
        }, true);

        document.addEventListener("keydown", event => {
            if (event.key === "Escape" && panel.classList.contains("is-open")) close();
        });

        window.addEventListener("resize", () => {
            if (!isCollapsed()) close();
        });

        return { close, isCollapsed };
    }

    // Own the decoded pixels and encoded bytes. File-backed Blobs and gallery
    // object URLs can disappear while the editor is left open on a phone.
    async function prepareImage(source) {
        let temporaryUrl;
        try {
            let image = source;
            if (!(source instanceof HTMLImageElement)) {
                image = new Image();
                image.crossOrigin = "anonymous";
                const src = source instanceof Blob
                    ? (temporaryUrl = URL.createObjectURL(new Blob([await source.arrayBuffer()], { type: source.type })))
                    : source;
                await new Promise((resolve, reject) => {
                    image.onload = resolve;
                    image.onerror = () => reject(new Error("Could not read the selected image. Your existing edit is still loaded."));
                    image.src = src;
                });
            } else if (!image.complete || !image.naturalWidth) {
                await image.decode();
            }
            const canvas = document.createElement("canvas");
            canvas.width = image.naturalWidth;
            canvas.height = image.naturalHeight;
            canvas.getContext("2d").drawImage(image, 0, 0);
            const blob = await new Promise((resolve, reject) => canvas.toBlob(
                value => value ? resolve(value) : reject(new Error("Could not save the image in the editor.")), "image/png"));
            // A data URL belongs to this editor, independent of gallery cleanup.
            const ownedImage = new Image();
            await new Promise((resolve, reject) => {
                ownedImage.onload = resolve;
                ownedImage.onerror = reject;
                ownedImage.src = canvas.toDataURL("image/png");
            });
            return { image: ownedImage, blob };
        } finally {
            if (temporaryUrl) URL.revokeObjectURL(temporaryUrl);
        }
    }

    window.InpaintUI = { attach, attachGestures: attach, attachShortcuts, attachToolbarMenu, prepareImage };
}());

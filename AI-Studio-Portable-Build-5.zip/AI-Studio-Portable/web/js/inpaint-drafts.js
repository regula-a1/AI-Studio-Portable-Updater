/*
 * Durable drafts for the image editors, and the sync that lets a phone and a
 * desktop share one.
 *
 * The problem this solves: the editor used to hold the loaded image, the mask
 * and the undo history in page memory only. A reload, a background tab the
 * phone evicted, or simply picking up the other device lost all of it, and the
 * work to recreate a mask is not small.
 *
 * The shape of the solution:
 *
 *   - Every edit is written to IndexedDB, already encrypted with the page's own
 *     content key. Nothing legible to anyone else is ever stored.
 *   - Each editing mode (img2img, inpaint) is a separate draft, so loading a
 *     reference image for one never disturbs the other.
 *   - Drafts are pushed to the account's own storage and pulled back on the
 *     other device. The server only ever sees sealed bytes.
 *   - A draft lives until the user explicitly clears it. Clearing is itself a
 *     revision, so a stale tab syncing later cannot bring it back.
 *
 * Two budgets shape the timings below. Local writes are cheap, so they happen
 * about a second after the last change. Remote writes are not - object storage
 * writes are a small daily allowance - so a push waits for the user to pause,
 * and unchanged bytes are never uploaded twice: asset keys are content
 * addressed, so a mask edit re-uploads the mask and leaves the image alone.
 *
 * The host page owns its editor state. This module asks for a snapshot when it
 * wants to save, and hands back a payload when it wants the editor to load
 * something. It never touches a canvas itself.
 */
(function () {
    "use strict";

    const DB_NAME = "studio-inpaint-drafts";
    const DB_VERSION = 1;
    const DRAFT_STORE = "drafts";
    const ASSET_STORE = "assets";

    // Time from the last edit to the local write, and to the remote push. The
    // remote one is long on purpose: see the budget note above.
    const LOCAL_DEBOUNCE = 900;
    const REMOTE_DEBOUNCE = 20000;
    const POLL_INTERVAL = 25000;
    // Storage is eventually consistent, so a manifest can point at bytes that
    // have not landed everywhere yet. Retry before believing a draft is broken.
    const ASSET_RETRIES = [400, 1500, 4000];

    const encoder = new TextEncoder();
    const decoder = new TextDecoder();

    function bytesToBase64(bytes) {
        let binary = "";
        const chunk = 0x8000;
        for (let i = 0; i < bytes.length; i += chunk) {
            binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
        }
        return btoa(binary);
    }

    function base64ToBytes(text) {
        const binary = atob(text);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
        return bytes;
    }

    // 32 hex characters is plenty to address one account's own draft assets,
    // and it keeps the storage key short.
    async function digestOf(bytes) {
        const hash = new Uint8Array(await crypto.subtle.digest("SHA-256", bytes));
        return [...hash.subarray(0, 16)].map(byte => byte.toString(16).padStart(2, "0")).join("");
    }

    function randomClientId() {
        return [...crypto.getRandomValues(new Uint8Array(8))].map(byte => byte.toString(16).padStart(2, "0")).join("");
    }

    function request(store, method, ...args) {
        return new Promise((resolve, reject) => {
            const operation = store[method](...args);
            operation.onsuccess = () => resolve(operation.result);
            operation.onerror = () => reject(operation.error);
        });
    }

    function openDatabase() {
        return new Promise((resolve, reject) => {
            if (typeof indexedDB === "undefined") {
                reject(new Error("This browser cannot save drafts on the device."));
                return;
            }
            const open = indexedDB.open(DB_NAME, DB_VERSION);
            open.onupgradeneeded = () => {
                const db = open.result;
                if (!db.objectStoreNames.contains(DRAFT_STORE)) db.createObjectStore(DRAFT_STORE, { keyPath: "id" });
                // Asset bytes live apart from the manifest so that painting a
                // stroke rewrites the mask and the small manifest, and leaves
                // the multi-megabyte source image where it is.
                if (!db.objectStoreNames.contains(ASSET_STORE)) db.createObjectStore(ASSET_STORE, { keyPath: "key" });
            };
            open.onsuccess = () => resolve(open.result);
            open.onerror = () => reject(open.error);
            open.onblocked = () => reject(new Error("Another tab is upgrading the draft store."));
        });
    }

    function create(config) {
        const {
            app, owner, modes = ["img2img", "inpaint"],
            seal, unseal, snapshot, apply,
            isBusy = () => false,
            onStatus = () => {},
            onConflict = () => {}
        } = config;

        const clientId = randomClientId();
        const records = new Map();
        const localTimers = new Map();
        const remoteTimers = new Map();
        const conflicts = new Map();
        // Sealed bytes not yet acknowledged by the server, so a push does not
        // depend on the local store having accepted them.
        const pendingBytes = new Map();
        let database = null;
        let storageFull = false;
        let pollTimer = null;
        let stopped = false;
        let pushing = Promise.resolve();

        const recordId = mode => `${app}|${owner}|${mode}`;
        // Ids are `app|owner|mode`, and both studio pages share one database
        // because they share an origin.
        const ownerOf = id => String(id).split('|')[1] || '';
        const isMine = id => ownerOf(id).toLowerCase() === String(owner).toLowerCase();
        const assetKey = (mode, type) => `${recordId(mode)}::${type}`;
        const query = params => `/api/studio?${new URLSearchParams({ app, ...params })}`;

        function blank(mode) {
            return {
                id: recordId(mode), app, owner, mode,
                state: "empty", revision: 0, dirty: false, updated: 0,
                imageHash: null, imageDigest: null, imageReceipt: null,
                maskHash: null, maskDigest: null, maskReceipt: null,
                meta: null
            };
        }

        function recordFor(mode) {
            if (!records.has(mode)) records.set(mode, blank(mode));
            return records.get(mode);
        }

        async function db() {
            if (!database) database = await openDatabase();
            return database;
        }

        async function readLocal(mode) {
            const handle = await db();
            const transaction = handle.transaction([DRAFT_STORE, ASSET_STORE], "readonly");
            const record = await request(transaction.objectStore(DRAFT_STORE), "get", recordId(mode));
            if (!record) return null;
            const assets = transaction.objectStore(ASSET_STORE);
            const [image, mask] = await Promise.all([
                request(assets, "get", assetKey(mode, "image")),
                request(assets, "get", assetKey(mode, "mask"))
            ]);
            return { record, image: image?.bytes || null, mask: mask?.bytes || null };
        }

        // `assets` is a map of type -> sealed bytes, or null for "leave alone",
        // so a stroke does not rewrite the source image.
        async function writeLocal(record, assets = {}) {
            if (storageFull) return false;
            try {
                const handle = await db();
                await new Promise((resolve, reject) => {
                    const transaction = handle.transaction([DRAFT_STORE, ASSET_STORE], "readwrite");
                    transaction.oncomplete = resolve;
                    transaction.onerror = () => reject(transaction.error);
                    transaction.onabort = () => reject(transaction.error);
                    transaction.objectStore(DRAFT_STORE).put(record);
                    const store = transaction.objectStore(ASSET_STORE);
                    for (const type of ["image", "mask"]) {
                        if (!(type in assets)) continue;
                        const bytes = assets[type];
                        if (bytes) store.put({ key: assetKey(record.mode, type), bytes });
                        else store.delete(assetKey(record.mode, type));
                    }
                });
                return true;
            } catch (error) {
                // A full or locked-down store must not take the editor with it.
                // The work stays in memory and the user is told it is at risk.
                if (error?.name === "QuotaExceededError") storageFull = true;
                onStatus("error", storageFull
                    ? "This device has no room left to save the draft. Your edit is still open here."
                    : "Could not save the draft on this device.");
                return false;
            }
        }

        async function api(params, options = {}) {
            const response = await fetch(query(params), {
                cache: "no-store",
                signal: AbortSignal.timeout(30000),
                ...options
            });
            const type = response.headers.get("Content-Type") || "";
            if (!type.includes("application/json")) {
                if (!response.ok) {
                    const error = new Error(`Draft sync failed (${response.status}).`);
                    error.status = response.status;
                    throw error;
                }
                return response;
            }
            const result = await response.json().catch(() => ({}));
            if (!response.ok) {
                const error = new Error(result.error || `Draft sync failed (${response.status}).`);
                error.status = response.status;
                error.result = result;
                throw error;
            }
            return result;
        }

        // ---- saving --------------------------------------------------------

        async function sealMeta(meta) {
            if (!meta) return null;
            return bytesToBase64(await seal(encoder.encode(JSON.stringify(meta))));
        }

        async function readMeta(sealed) {
            if (!sealed) return null;
            try { return JSON.parse(decoder.decode(await unseal(base64ToBytes(sealed)))); }
            catch { return null; }
        }

        async function persist(mode) {
            // Never capture a half-drawn stroke: come back when the finger or
            // the mouse button is up.
            if (isBusy()) {
                scheduleLocal(mode);
                return;
            }
            const record = recordFor(mode);
            let taken = null;
            try { taken = await snapshot(mode); } catch { taken = null; }
            if (!taken || !taken.imageBlob) return;

            const assets = {};
            const imageBytes = new Uint8Array(await taken.imageBlob.arrayBuffer());
            const imageHash = await digestOf(imageBytes);
            if (imageHash !== record.imageHash) {
                // Sealing uses a fresh nonce every time, so the sealed bytes of
                // an unchanged image would look new to storage. Hash the plain
                // bytes instead and only re-seal what actually changed.
                const sealed = await seal(imageBytes);
                record.imageHash = imageHash;
                record.imageDigest = await digestOf(sealed);
                record.imageReceipt = null;
                assets.image = sealed.buffer;
            }

            const maskBytes = taken.maskBlob ? new Uint8Array(await taken.maskBlob.arrayBuffer()) : null;
            const maskHash = maskBytes ? await digestOf(maskBytes) : null;
            if (maskHash !== record.maskHash) {
                record.maskHash = maskHash;
                if (maskBytes) {
                    const sealed = await seal(maskBytes);
                    record.maskDigest = await digestOf(sealed);
                    record.maskReceipt = null;
                    assets.mask = sealed.buffer;
                } else {
                    record.maskDigest = null;
                    record.maskReceipt = null;
                    assets.mask = null;
                }
            }

            if (!Object.keys(assets).length && record.state === "active" && !record.dirty) return;
            // Kept alongside the local write so that a browser which refuses
            // IndexedDB entirely - a private window, or storage turned off -
            // can still sync to the other devices.
            pendingBytes.set(mode, {
                image: assets.image || pendingBytes.get(mode)?.image || null,
                mask: "mask" in assets ? assets.mask : pendingBytes.get(mode)?.mask || null
            });
            record.state = "active";
            record.meta = await sealMeta(taken.meta);
            record.dirty = true;
            record.updated = Date.now();
            const saved = await writeLocal(record, assets);
            if (saved) onStatus("saved", "Draft saved on this device");
            scheduleRemote(mode);
        }

        // An explicit clear is a revision of its own. Without that, a tab that
        // had been asleep would push its old copy back and undo the clear.
        async function noteCleared(mode) {
            // Text-to-image and chat have no workspace of their own; their
            // clear buttons must not publish a draft for a mode that has none.
            if (!modes.includes(mode)) return;
            clearTimeout(localTimers.get(mode));
            clearTimeout(remoteTimers.get(mode));
            const record = recordFor(mode);
            if (record.state === "empty" && !record.dirty) return;
            pendingBytes.delete(mode);
            Object.assign(record, blank(mode), {
                revision: record.revision, state: "cleared", dirty: true, updated: Date.now()
            });
            clearConflict(mode);
            await writeLocal(record, { image: null, mask: null });
            onStatus("cleared", "Draft cleared");
            push(mode);
        }

        function scheduleLocal(mode) {
            clearTimeout(localTimers.get(mode));
            localTimers.set(mode, setTimeout(() => { persist(mode).catch(() => {}); }, LOCAL_DEBOUNCE));
        }

        function scheduleRemote(mode) {
            clearTimeout(remoteTimers.get(mode));
            remoteTimers.set(mode, setTimeout(() => { push(mode); }, REMOTE_DEBOUNCE));
        }

        function noteChange(mode) {
            if (!modes.includes(mode)) return;
            // Marked unsaved the instant the user edits, not when the debounced
            // write lands. Otherwise a sync arriving in that second sees a
            // clean record and adopts the other device's copy straight over a
            // stroke that was just finished.
            recordFor(mode).dirty = true;
            scheduleLocal(mode);
        }

        // ---- pushing -------------------------------------------------------

        async function uploadAsset(mode, type, digest, bytes) {
            const result = await api({ action: "draft-asset", mode, type, digest }, {
                method: "POST",
                headers: { "Content-Type": "application/octet-stream" },
                body: bytes
            });
            return result.receipt;
        }

        async function pushNow(mode) {
            const record = recordFor(mode);
            if (!record.dirty || stopped) return;
            const payload = {
                mode, state: record.state === "cleared" ? "cleared" : "active",
                base: record.revision, client: clientId, meta: record.meta
            };
            if (payload.state === "active") {
                const stored = await readLocal(mode).catch(() => null);
                const held = pendingBytes.get(mode);
                const local = { image: stored?.image || held?.image || null, mask: stored?.mask || held?.mask || null };
                if (!local.image) return;
                // Every asset is uploaded and acknowledged before the manifest
                // that names it is published, so another device never sees a
                // revision it cannot fully read.
                if (!record.imageReceipt) {
                    record.imageReceipt = await uploadAsset(mode, "image", record.imageDigest, local.image);
                }
                if (record.maskDigest && !record.maskReceipt) {
                    record.maskReceipt = await uploadAsset(mode, "mask", record.maskDigest, local.mask);
                }
                payload.image = record.imageDigest;
                payload.imageReceipt = record.imageReceipt;
                payload.mask = record.maskDigest || null;
                payload.maskReceipt = record.maskReceipt || null;
            }
            try {
                const result = await api({ action: "draft-publish" }, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(payload)
                });
                record.revision = result.revision;
                record.dirty = false;
                pendingBytes.delete(mode);
                await writeLocal(record);
                onStatus("synced", "Draft synced to your other devices");
            } catch (error) {
                if (error.status === 409 && error.result?.conflict) {
                    // Keep the local edit exactly as it is and let the user
                    // decide. Nothing is overwritten on either side.
                    raiseConflict(mode, error.result.draft);
                    return;
                }
                onStatus("offline", "Draft saved here, waiting to sync");
            }
        }

        function push(mode) {
            clearTimeout(remoteTimers.get(mode));
            pushing = pushing.then(() => pushNow(mode)).catch(() => {});
            return pushing;
        }

        // ---- pulling -------------------------------------------------------

        async function downloadAsset(mode, type, digest) {
            for (let attempt = 0; ; attempt++) {
                try {
                    const response = await api({ action: "draft-asset", mode, type, digest });
                    return new Uint8Array(await response.arrayBuffer());
                } catch (error) {
                    // Storage is eventually consistent: a just-published asset
                    // can be briefly missing on another edge.
                    if (error.status !== 404 || attempt >= ASSET_RETRIES.length) throw error;
                    await new Promise(done => setTimeout(done, ASSET_RETRIES[attempt]));
                }
            }
        }

        async function adoptRemote(mode, manifest) {
            const record = recordFor(mode);
            if (manifest.state === "cleared") {
                Object.assign(record, blank(mode), { revision: manifest.revision, state: "cleared", updated: Date.now() });
                await writeLocal(record, { image: null, mask: null });
                await apply(mode, null);
                onStatus("restored", "Draft cleared on another device");
                return;
            }
            if (!manifest.image) throw new Error("That draft is missing its image.");
            const local = await readLocal(mode).catch(() => null);
            // Content addressing pays off here too: an unchanged source image
            // is already on this device, so only the mask crosses the network.
            const sealedImage = manifest.image === record.imageDigest && local?.image
                ? new Uint8Array(local.image)
                : await downloadAsset(mode, "image", manifest.image);
            const sealedMask = !manifest.mask ? null
                : manifest.mask === record.maskDigest && local?.mask
                    ? new Uint8Array(local.mask)
                    : await downloadAsset(mode, "mask", manifest.mask);
            const plainImage = await unseal(sealedImage);
            const plainMask = sealedMask ? await unseal(sealedMask) : null;
            const meta = await readMeta(manifest.meta);

            Object.assign(record, {
                state: "active", revision: manifest.revision, dirty: false, updated: Date.now(),
                imageHash: await digestOf(plainImage), imageDigest: manifest.image, imageReceipt: manifest.imageReceipt || null,
                maskHash: plainMask ? await digestOf(plainMask) : null,
                maskDigest: manifest.mask || null, maskReceipt: manifest.maskReceipt || null,
                meta: manifest.meta
            });
            await writeLocal(record, { image: sealedImage.buffer, mask: sealedMask ? sealedMask.buffer : null });
            await apply(mode, {
                imageBlob: new Blob([plainImage], { type: "image/png" }),
                maskBlob: plainMask ? new Blob([plainMask], { type: "image/png" }) : null,
                meta
            });
            onStatus("restored", "Loaded the newer draft from your other device");
        }

        function raiseConflict(mode, remote) {
            if (!remote) return;
            conflicts.set(mode, remote);
            onConflict(mode, {
                remote,
                useRemote: async () => {
                    clearConflict(mode);
                    // The manifest is read again rather than trusted from the
                    // conflict payload, which may already be stale itself.
                    await syncMode(mode, { force: true });
                },
                keepLocal: async () => {
                    clearConflict(mode);
                    // Rebase onto what the other device published, so the next
                    // push wins the compare-and-swap instead of looping on it.
                    recordFor(mode).revision = remote.revision;
                    await push(mode);
                }
            });
        }

        function clearConflict(mode) {
            if (!conflicts.has(mode)) return;
            conflicts.delete(mode);
            onConflict(mode, null);
        }

        async function syncMode(mode, { force = false, manifests = null } = {}) {
            const record = recordFor(mode);
            let manifest = manifests?.get(mode) || null;
            if (!manifest) {
                const result = await api({ action: "drafts" });
                manifest = (result.drafts || []).find(entry => entry.mode === mode) || null;
            }
            if (!manifest) return;
            if (manifest.revision <= record.revision && !force) return;
            if (manifest.client === clientId && !force) {
                // Our own push coming back to us.
                record.revision = Math.max(record.revision, manifest.revision);
                return;
            }
            if (!force) {
                // Never overwrite work in progress, and never interrupt a
                // stroke. Both cases become a conflict the user resolves.
                if (isBusy()) return;
                if (record.dirty) { raiseConflict(mode, manifest); return; }
            }
            await adoptRemote(mode, manifest);
        }

        async function syncAll(options = {}) {
            if (stopped) return;
            try {
                const result = await api({ action: "drafts" });
                const manifests = new Map((result.drafts || []).map(entry => [entry.mode, entry]));
                for (const mode of modes) {
                    if (!manifests.has(mode)) continue;
                    try { await syncMode(mode, { ...options, manifests }); }
                    catch (error) { onStatus("offline", "Could not read the draft from your other device"); }
                }
            } catch {
                onStatus("offline", "Draft sync is unavailable right now");
            }
        }

        // ---- lifecycle -----------------------------------------------------

        // A browser profile outlives the person signed into it, and the local
        // copies are only as private as the key that sealed them: the Studio key
        // is typed and known only to its owner, but Lite's is a constant every
        // Lite page carries. So anything here belonging to a different account
        // is dropped before the first read rather than left on the device. It
        // costs that account nothing - their drafts are on the server, and come
        // back when they sign in again.
        async function forgetOtherAccounts() {
            try {
                const handle = await db();
                await new Promise((resolve, reject) => {
                    const transaction = handle.transaction([DRAFT_STORE, ASSET_STORE], 'readwrite');
                    transaction.oncomplete = resolve;
                    transaction.onerror = () => reject(transaction.error);
                    transaction.onabort = () => reject(transaction.error);
                    const drafts = transaction.objectStore(DRAFT_STORE);
                    const assets = transaction.objectStore(ASSET_STORE);
                    drafts.getAllKeys().onsuccess = event => {
                        for (const key of event.target.result || []) {
                            if (!isMine(key)) drafts.delete(key);
                        }
                    };
                    assets.getAllKeys().onsuccess = event => {
                        // `app|owner|mode::type`
                        for (const key of event.target.result || []) {
                            if (!isMine(String(key).split('::')[0])) assets.delete(key);
                        }
                    };
                });
            } catch {
                // Nothing to be done about it, and the live editor is unaffected.
            }
        }

        async function restore() {
            for (const mode of modes) {
                let local = null;
                try { local = await readLocal(mode); } catch { local = null; }
                if (!local) continue;
                records.set(mode, local.record);
                if (local.record.state !== "active" || !local.image) continue;
                try {
                    const plainImage = await unseal(new Uint8Array(local.image));
                    const plainMask = local.mask ? await unseal(new Uint8Array(local.mask)) : null;
                    await apply(mode, {
                        imageBlob: new Blob([plainImage], { type: "image/png" }),
                        maskBlob: plainMask ? new Blob([plainMask], { type: "image/png" }) : null,
                        meta: await readMeta(local.record.meta)
                    });
                    onStatus("restored", "Restored your last edit");
                } catch {
                    // Sealed with a different key, or damaged. Leave the record
                    // alone rather than destroying something still readable on
                    // another device.
                    onStatus("error", "A saved draft could not be opened with this Studio key");
                }
            }
        }

        function flush() {
            const pending = [];
            for (const mode of modes) {
                if (localTimers.has(mode)) {
                    clearTimeout(localTimers.get(mode));
                    localTimers.delete(mode);
                    pending.push(persist(mode).then(() => push(mode)));
                } else if (recordFor(mode).dirty) {
                    pending.push(push(mode));
                }
            }
            return Promise.allSettled(pending);
        }

        function onVisibility() {
            if (document.visibilityState === "hidden") {
                // A phone can suspend the tab without warning, so anything
                // pending is written and pushed as the tab goes away.
                flush();
                return;
            }
            syncAll();
        }

        function startPolling() {
            clearInterval(pollTimer);
            pollTimer = setInterval(() => {
                if (document.visibilityState === "visible") syncAll();
            }, POLL_INTERVAL);
        }

        async function start() {
            await forgetOtherAccounts();
            await restore();
            await syncAll();
            // A session that ended before its last push got out still owes the
            // other devices an update.
            for (const mode of modes) {
                if (recordFor(mode).dirty) push(mode);
            }
            startPolling();
            document.addEventListener("visibilitychange", onVisibility);
            window.addEventListener("focus", onVisibility);
            window.addEventListener("pagehide", flush);
        }

        function stop() {
            stopped = true;
            clearInterval(pollTimer);
            for (const timer of localTimers.values()) clearTimeout(timer);
            for (const timer of remoteTimers.values()) clearTimeout(timer);
            document.removeEventListener("visibilitychange", onVisibility);
            window.removeEventListener("focus", onVisibility);
            window.removeEventListener("pagehide", flush);
        }

        return {
            start, stop, flush, noteChange, noteCleared,
            noteModeShown: mode => { if (modes.includes(mode)) syncAll(); },
            // Pull now instead of waiting for the next poll. The page exposes
            // this so a stuck sync can be prodded from the console, and so the
            // regression tests do not have to sit through the poll interval.
            sync: options => syncAll(options),
            forgetOtherAccounts,
            revisionOf: mode => recordFor(mode).revision,
            stateOf: mode => recordFor(mode).state,
            isDirty: mode => recordFor(mode).dirty,
            clientId
        };
    }

    window.InpaintDrafts = { create };
}());

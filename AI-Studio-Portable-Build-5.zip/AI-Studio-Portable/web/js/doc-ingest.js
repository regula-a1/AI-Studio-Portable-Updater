/**
 * AI Studio - Client-Side Document Ingestion Module
 *
 * Extracts text and structured data in the browser from:
 * - PDF (.pdf) via Mozilla PDF.js
 * - Excel (.xlsx, .xls) via SheetJS mini / native XML
 * - Word (.docx) via native Zip decompression + OpenXML parser
 * - RTF (.rtf) via native RTF control parser
 * - Delimited Data (.csv, .tsv)
 * - Text, Markdown & Code (.txt, .md, .json, .xml, .html, .css, .js, .ts, .py, .sql, .yaml, .yml, .log, etc.)
 *
 * Runs 100% client-side to preserve End-to-End Encryption (E2EE) and
 * minimize network payload sizes before sealing messages.
 */

(function (root, factory) {
    if (typeof define === 'function' && define.amd) {
        define([], factory);
    } else if (typeof module === 'object' && module.exports) {
        module.exports = factory();
    } else {
        root.DocIngest = factory();
    }
}(typeof self !== 'undefined' ? self : this, function () {
    'use strict';

    // How much of a file is kept, not how much is sent. Since excerpts are chosen
    // per question (selectExcerpts), the text held here is the pool they are drawn
    // from, and throwing any of it away at parse time forecloses questions that
    // have not been asked yet. The ceiling is a storage one: a message is sealed
    // and stored as a single row, and ~1M characters is about 1.4 MB once sealed
    // and base64'd - inside D1's 2 MB row limit and the API's 5 MB body limit.
    const DEFAULT_MAX_CHARS = 1000000;

    // The whole file is read into memory to be parsed, so an enormous one takes
    // the tab with it. Well above any real document, well below that.
    const MAX_FILE_BYTES = 32 * 1024 * 1024;

    // The PDF and spreadsheet parsers are well over half a megabyte together,
    // and most visits to the chat never open either kind of file. They are
    // fetched the first time one is actually parsed rather than on every page
    // load. Same origin, so the site's script-src 'self' policy allows it.
    //
    // These are the only scripts on the site fetched by URL rather than from a
    // tag the page can version, and the asset cache holds a file for four
    // hours. Stamping each library's own version into its URL means swapping a
    // vendored build is picked up immediately instead of after that window, and
    // the URL says which build it is. Update these when you replace a file.
    const PDF_VERSION = '3.11.174';
    const XLSX_VERSION = '0.20.3';
    const VENDOR_SCRIPTS = {
        pdf: { src: `/assets/js/vendor/pdf.min.js?v=${PDF_VERSION}`, global: 'pdfjsLib', label: 'PDF reader' },
        xlsx: { src: `/assets/js/vendor/xlsx.mini.min.js?v=${XLSX_VERSION}`, global: 'XLSX', label: 'Spreadsheet reader' }
    };
    // pdf.js rejects a worker built from a different release than the library.
    const PDF_WORKER_SRC = `/assets/js/vendor/pdf.worker.min.js?v=${PDF_VERSION}`;
    const vendorLoads = new Map();

    function vendorGlobal(name) {
        const key = VENDOR_SCRIPTS[name].global;
        if (typeof window !== 'undefined' && window[key]) return window[key];
        if (typeof globalThis !== 'undefined' && globalThis[key]) return globalThis[key];
        return null;
    }

    function loadVendorScript(name) {
        const spec = VENDOR_SCRIPTS[name];
        const already = vendorGlobal(name);
        if (already) return Promise.resolve(already);
        if (typeof document === 'undefined') {
            return Promise.reject(new Error(`${spec.label} is not available in this runtime.`));
        }
        if (!vendorLoads.has(name)) {
            const pending = new Promise((resolve, reject) => {
                const script = document.createElement('script');
                script.src = spec.src;
                script.async = true;
                script.onload = () => {
                    const loaded = vendorGlobal(name);
                    if (loaded) resolve(loaded);
                    else reject(new Error(`${spec.label} loaded but did not start.`));
                };
                script.onerror = () => reject(new Error(`${spec.label} could not be loaded. Check your connection and try again.`));
                document.head.appendChild(script);
            }).catch(error => {
                // One failed fetch must not make every later attempt fail too.
                vendorLoads.delete(name);
                throw error;
            });
            vendorLoads.set(name, pending);
        }
        return vendorLoads.get(name);
    }

    const DOCUMENT_EXTENSIONS = new Set([
        'pdf', 'txt', 'csv', 'tsv', 'xlsx', 'xls', 'docx', 'rtf',
        'md', 'markdown', 'json', 'xml', 'html', 'htm', 'css',
        'js', 'mjs', 'cjs', 'ts', 'tsx', 'jsx', 'py', 'sql',
        'yaml', 'yml', 'ini', 'toml', 'log', 'env', 'sh', 'bash',
        'bat', 'ps1', 'c', 'cpp', 'h', 'hpp', 'cs', 'java', 'rs', 'go'
    ]);

    const IMAGE_EXTENSIONS = new Set(['png', 'jpg', 'jpeg', 'webp']);

    function getExtension(filename) {
        if (!filename || typeof filename !== 'string') return '';
        const idx = filename.lastIndexOf('.');
        return idx >= 0 ? filename.slice(idx + 1).toLowerCase() : '';
    }

    function isDocumentFile(file) {
        if (!file) return false;
        const ext = getExtension(file.name || '');
        if (DOCUMENT_EXTENSIONS.has(ext)) return true;
        const type = String(file.type || '').toLowerCase();
        return (
            type.startsWith('text/') ||
            type === 'application/pdf' ||
            type === 'application/rtf' ||
            type.includes('spreadsheet') ||
            type.includes('excel') ||
            type.includes('wordprocessingml') ||
            type.includes('json') ||
            type.includes('xml')
        );
    }

    function isImageFile(file) {
        if (!file) return false;
        const ext = getExtension(file.name || '');
        if (IMAGE_EXTENSIONS.has(ext)) return true;
        const type = String(file.type || '').toLowerCase();
        return type.startsWith('image/');
    }

    function formatBytes(bytes) {
        if (!bytes || bytes <= 0) return '0 B';
        const units = ['B', 'KB', 'MB', 'GB'];
        const i = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
        const val = bytes / Math.pow(1024, i);
        const valStr = Number(val.toFixed(i > 0 ? 1 : 0));
        return `${valStr} ${units[i]}`;
    }

    function estimateTokens(text) {
        if (!text) return 0;
        return Math.ceil(text.length / 4);
    }

    function truncateText(text, maxChars = DEFAULT_MAX_CHARS) {
        if (!text || text.length <= maxChars) {
            return { text: text || '', truncated: false, originalLength: (text || '').length };
        }
        const truncatedStr = text.slice(0, maxChars) +
            `\n\n[... Document truncated to first ${maxChars.toLocaleString()} characters (~${Math.round(maxChars / 4).toLocaleString()} tokens) ...]`;
        return { text: truncatedStr, truncated: true, originalLength: text.length };
    }

    async function readTextFile(file) {
        if (file && typeof file.text === 'function') {
            return await file.text();
        }
        if (typeof FileReader !== 'undefined') {
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onerror = () => reject(new Error(`Failed to read file: ${file.name}`));
                reader.onload = () => resolve(reader.result || '');
                reader.readAsText(file, 'utf-8');
            });
        }
        throw new Error('Neither file.text() nor FileReader is available.');
    }

    async function readArrayBuffer(file) {
        if (file && typeof file.arrayBuffer === 'function') {
            return await file.arrayBuffer();
        }
        if (typeof FileReader !== 'undefined') {
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onerror = () => reject(new Error(`Failed to read file: ${file.name}`));
                reader.onload = () => resolve(reader.result);
                reader.readAsArrayBuffer(file);
            });
        }
        throw new Error('Neither file.arrayBuffer() nor FileReader is available.');
    }

    function parseRtfText(rtf) {
        if (!rtf || typeof rtf !== 'string') return '';
        let text = '';
        let groupDepth = 0;
        const skipGroups = [];
        const len = rtf.length;
        let i = 0;

        while (i < len) {
            const ch = rtf[i];
            if (ch === '{') {
                groupDepth++;
                i++;
                if (rtf.slice(i, i + 2) === '\\*') {
                    skipGroups.push(groupDepth);
                } else {
                    const m = rtf.slice(i).match(/^\\(fonttbl|colortbl|stylesheet|info|pict|header|footer|stylesheet|xmlopen)\b/);
                    if (m) skipGroups.push(groupDepth);
                }
            } else if (ch === '}') {
                if (skipGroups.length && skipGroups[skipGroups.length - 1] === groupDepth) {
                    skipGroups.pop();
                }
                groupDepth = Math.max(0, groupDepth - 1);
                i++;
            } else if (skipGroups.length > 0) {
                i++;
            } else if (ch === '\\') {
                i++;
                if (i >= len) break;
                const next = rtf[i];
                if (next === '\\' || next === '{' || next === '}') {
                    text += next;
                    i++;
                } else if (next === "'") {
                    const hex = rtf.slice(i + 1, i + 3);
                    const code = parseInt(hex, 16);
                    if (!isNaN(code)) text += String.fromCharCode(code);
                    i += 3;
                } else if (next === '~') {
                    text += ' ';
                    i++;
                } else {
                    const m = rtf.slice(i).match(/^([a-zA-Z]+)(-?[0-9]+)? ?/);
                    if (m) {
                        const word = m[1];
                        const num = m[2];
                        if (word === 'par' || word === 'line') text += '\n';
                        else if (word === 'tab') text += '\t';
                        else if (word === 'u' && num) {
                            let code = parseInt(num, 10);
                            if (code < 0) code += 65536;
                            text += String.fromCharCode(code);
                        }
                        i += m[0].length;
                    } else {
                        i++;
                    }
                }
            } else if (ch === '\r' || ch === '\n') {
                i++;
            } else {
                text += ch;
                i++;
            }
        }
        return text.trim();
    }

    async function inflateRaw(bytes) {
        if (typeof DecompressionStream !== 'undefined') {
            try {
                const ds = new DecompressionStream('deflate-raw');
                const writer = ds.writable.getWriter();
                writer.write(bytes);
                writer.close();
                const reader = ds.readable.getReader();
                const chunks = [];
                let total = 0;
                while (true) {
                    const { done, value } = await reader.read();
                    if (done) break;
                    chunks.push(value);
                    total += value.length;
                }
                const out = new Uint8Array(total);
                let offset = 0;
                for (const chunk of chunks) {
                    out.set(chunk, offset);
                    offset += chunk.length;
                }
                return out;
            } catch (_) {}
        }
        const globalZlib = (typeof globalThis !== 'undefined' && globalThis.zlib) || (typeof window !== 'undefined' && window.zlib);
        if (globalZlib && typeof globalZlib.inflateRawSync === 'function') {
            const buf = (typeof Buffer !== 'undefined' && Buffer.from) ? Buffer.from(bytes) : bytes;
            const res = globalZlib.inflateRawSync(buf);
            return new Uint8Array(res.buffer, res.byteOffset, res.byteLength);
        }
        throw new Error('DecompressionStream with deflate-raw is not supported in this runtime.');
    }

    async function unzipEntry(arrayBuffer, targetPath) {
        const view = new DataView(arrayBuffer);
        const bytes = new Uint8Array(arrayBuffer);
        const len = bytes.length;

        let eocdOffset = -1;
        for (let i = len - 22; i >= Math.max(0, len - 65557); i--) {
            if (view.getUint32(i, true) === 0x06054b50) {
                eocdOffset = i;
                break;
            }
        }
        if (eocdOffset === -1) {
            throw new Error('Invalid zip file: EOCD signature not found');
        }

        const totalEntries = view.getUint16(eocdOffset + 10, true);
        const cdOffset = view.getUint32(eocdOffset + 16, true);
        const targetLower = targetPath.toLowerCase().replace(/\\/g, '/');

        let curr = cdOffset;
        for (let i = 0; i < totalEntries; i++) {
            if (curr + 46 > len || view.getUint32(curr, true) !== 0x02014b50) break;
            const method = view.getUint16(curr + 10, true);
            const compSize = view.getUint32(curr + 20, true);
            const fnLen = view.getUint16(curr + 28, true);
            const extraLen = view.getUint16(curr + 30, true);
            const commentLen = view.getUint16(curr + 32, true);
            const localHeaderOffset = view.getUint32(curr + 42, true);

            const fileNameBytes = bytes.subarray(curr + 46, curr + 46 + fnLen);
            const fileName = new TextDecoder().decode(fileNameBytes).replace(/\\/g, '/');

            if (fileName.toLowerCase() === targetLower) {
                const localFnLen = view.getUint16(localHeaderOffset + 26, true);
                const localExtraLen = view.getUint16(localHeaderOffset + 28, true);
                const dataStart = localHeaderOffset + 30 + localFnLen + localExtraLen;
                const compressedData = bytes.subarray(dataStart, dataStart + compSize);

                if (method === 0) {
                    return compressedData;
                } else if (method === 8) {
                    return await inflateRaw(compressedData);
                } else {
                    throw new Error(`Unsupported zip compression method: ${method}`);
                }
            }
            curr += 46 + fnLen + extraLen + commentLen;
        }
        return null;
    }

    function extractTextFromWordXml(xml) {
        if (!xml || typeof xml !== 'string') return '';
        const blocks = [];
        const tblRegex = /<w:tbl[\s\S]*?<\/w:tbl>/g;
        let lastIndex = 0;
        let match;

        function unescapeXml(str) {
            return str
                .replace(/&lt;/g, '<')
                .replace(/&gt;/g, '>')
                .replace(/&amp;/g, '&')
                .replace(/&quot;/g, '"')
                .replace(/&apos;/g, "'");
        }

        function parseParagraphs(pXml) {
            const pRegex = /<w:p[\s\S]*?<\/w:p>/g;
            let pMatch;
            const res = [];
            while ((pMatch = pRegex.exec(pXml)) !== null) {
                const pContent = pMatch[0];
                const isH1 = /<w:pStyle\s+w:val=["']Heading1["']/i.test(pContent);
                const isH2 = /<w:pStyle\s+w:val=["']Heading2["']/i.test(pContent);
                const isH3 = /<w:pStyle\s+w:val=["']Heading3["']/i.test(pContent);

                let text = '';
                const tokenRegex = /<w:t(?:\s+[^>]*)?>([\s\S]*?)<\/w:t>|<w:tab\s*\/?>|<w:br\s*\/?>/g;
                let tokenMatch;
                while ((tokenMatch = tokenRegex.exec(pContent)) !== null) {
                    if (tokenMatch[1] !== undefined) {
                        text += tokenMatch[1];
                    } else if (tokenMatch[0].includes('tab')) {
                        text += '\t';
                    } else if (tokenMatch[0].includes('br')) {
                        text += '\n';
                    }
                }
                text = unescapeXml(text).trim();
                if (text) {
                    if (isH1) res.push('# ' + text);
                    else if (isH2) res.push('## ' + text);
                    else if (isH3) res.push('### ' + text);
                    else res.push(text);
                }
            }
            return res;
        }

        function parseTable(tblXml) {
            const rows = [];
            const trRegex = /<w:tr[\s\S]*?<\/w:tr>/g;
            let trMatch;
            while ((trMatch = trRegex.exec(tblXml)) !== null) {
                const trContent = trMatch[0];
                const cells = [];
                const tcRegex = /<w:tc[\s\S]*?<\/w:tc>/g;
                let tcMatch;
                while ((tcMatch = tcRegex.exec(trContent)) !== null) {
                    const tcContent = tcMatch[0];
                    let cellText = '';
                    const cellTokenRegex = /<w:t(?:\s+[^>]*)?>([\s\S]*?)<\/w:t>|<w:tab\s*\/?>|<w:br\s*\/?>/g;
                    let cellTokenMatch;
                    while ((cellTokenMatch = cellTokenRegex.exec(tcContent)) !== null) {
                        if (cellTokenMatch[1] !== undefined) {
                            cellText += cellTokenMatch[1];
                        } else if (cellTokenMatch[0].includes('tab') || cellTokenMatch[0].includes('br')) {
                            cellText += ' ';
                        }
                    }
                    cellText = unescapeXml(cellText).replace(/\|/g, '\\|').trim();
                    cells.push(cellText || ' ');
                }
                if (cells.length) {
                    rows.push('| ' + cells.join(' | ') + ' |');
                }
            }
            if (rows.length > 0) {
                const colCount = rows[0].split('|').length - 2;
                const sep = '| ' + Array(Math.max(1, colCount)).fill('---').join(' | ') + ' |';
                if (rows.length > 1) {
                    return [rows[0], sep, ...rows.slice(1)].join('\n');
                }
                return rows.join('\n');
            }
            return '';
        }

        while ((match = tblRegex.exec(xml)) !== null) {
            const before = xml.slice(lastIndex, match.index);
            blocks.push(...parseParagraphs(before));
            const tableStr = parseTable(match[0]);
            if (tableStr) blocks.push(tableStr);
            lastIndex = match.index + match[0].length;
        }
        const remaining = xml.slice(lastIndex);
        blocks.push(...parseParagraphs(remaining));

        return blocks.join('\n\n').trim();
    }

    async function parseDocx(arrayBuffer) {
        const docXmlBytes = await unzipEntry(arrayBuffer, 'word/document.xml');
        if (!docXmlBytes) {
            throw new Error('Not a valid Word (.docx) document (missing word/document.xml)');
        }
        const xmlStr = new TextDecoder('utf-8').decode(docXmlBytes);
        return extractTextFromWordXml(xmlStr);
    }

    async function parseExcel(arrayBuffer, fileExt) {
        let globalXlsx = vendorGlobal('xlsx');
        if (!globalXlsx) {
            // The hand-rolled reader below covers a plain single-sheet .xlsx,
            // so a failed fetch is not necessarily the end of the road.
            try { globalXlsx = await loadVendorScript('xlsx'); } catch (_) { globalXlsx = null; }
        }
        if (globalXlsx && typeof globalXlsx.read === 'function') {
            const workbook = globalXlsx.read(arrayBuffer, { type: 'array' });
            const sheetOutputs = [];
            for (const sheetName of workbook.SheetNames) {
                const worksheet = workbook.Sheets[sheetName];
                const csv = globalXlsx.utils.sheet_to_csv(worksheet);
                if (csv && csv.trim()) {
                    sheetOutputs.push(`### Sheet: ${sheetName}\n\n${csv.trim()}`);
                }
            }
            return sheetOutputs.join('\n\n---\n\n').trim();
        }

        if (fileExt === 'xlsx') {
            try {
                const sharedBytes = await unzipEntry(arrayBuffer, 'xl/sharedStrings.xml');
                const sharedStrings = [];
                if (sharedBytes) {
                    const sharedXml = new TextDecoder('utf-8').decode(sharedBytes);
                    const tRegex = /<t[^>]*>([\s\S]*?)<\/t>/g;
                    let m;
                    while ((m = tRegex.exec(sharedXml)) !== null) {
                        sharedStrings.push(m[1]);
                    }
                }
                const sheetBytes = await unzipEntry(arrayBuffer, 'xl/worksheets/sheet1.xml');
                if (sheetBytes) {
                    const sheetXml = new TextDecoder('utf-8').decode(sheetBytes);
                    const rows = [];
                    const rowRegex = /<row[^>]*>([\s\S]*?)<\/row>/g;
                    let rMatch;
                    while ((rMatch = rowRegex.exec(sheetXml)) !== null) {
                        const rowXml = rMatch[1];
                        const cells = [];
                        const cRegex = /<c\s+[^>]*?(?:t="([^"]*)")?[^>]*>(?:<v>([\s\S]*?)<\/v>|<is><t>([\s\S]*?)<\/t><\/is>)?<\/c>/g;
                        let cMatch;
                        while ((cMatch = cRegex.exec(rowXml)) !== null) {
                            const type = cMatch[1];
                            const val = cMatch[2] !== undefined ? cMatch[2] : cMatch[3];
                            if (type === 's' && sharedStrings[parseInt(val, 10)] !== undefined) {
                                cells.push(sharedStrings[parseInt(val, 10)]);
                            } else {
                                cells.push(val || '');
                            }
                        }
                        if (cells.some(Boolean)) {
                            rows.push(cells.join(', '));
                        }
                    }
                    return rows.join('\n');
                }
            } catch (_) {}
        }
        throw new Error('Spreadsheet parser (XLSX) is not available.');
    }

    async function parsePdf(arrayBuffer) {
        const globalPdf = await loadVendorScript('pdf');
        if (!globalPdf || typeof globalPdf.getDocument !== 'function') {
            throw new Error('PDF reader (PDF.js) is not available.');
        }

        if (globalPdf.GlobalWorkerOptions && !globalPdf.GlobalWorkerOptions.workerSrc && typeof window !== 'undefined') {
            try {
                globalPdf.GlobalWorkerOptions.workerSrc = new URL(PDF_WORKER_SRC, window.location.origin).href;
            } catch (_) {
                globalPdf.GlobalWorkerOptions.workerSrc = PDF_WORKER_SRC;
            }
        }

        const loadingTask = globalPdf.getDocument({
            data: arrayBuffer,
            useSystemFonts: true,
            isEvalSupported: false
        });

        const pdfDoc = await loadingTask.promise;
        const numPages = pdfDoc.numPages;
        const pageTexts = [];

        for (let pageNum = 1; pageNum <= numPages; pageNum++) {
            const page = await pdfDoc.getPage(pageNum);
            const content = await page.getTextContent();
            let lastY = null;
            let pageStr = '';

            for (const item of content.items) {
                if (!item || typeof item.str !== 'string') continue;
                if (lastY !== null && Math.abs(item.transform[5] - lastY) > 5) {
                    pageStr += '\n';
                } else if (pageStr && !pageStr.endsWith(' ') && !pageStr.endsWith('\n')) {
                    pageStr += ' ';
                }
                pageStr += item.str;
                lastY = item.transform[5];
            }
            if (pageStr.trim()) {
                pageTexts.push(`--- Page ${pageNum} of ${numPages} ---\n${pageStr.trim()}`);
            }
        }

        return {
            text: pageTexts.join('\n\n').trim(),
            pages: numPages
        };
    }

    // ---------------------------------------------------------------- Retrieval ---
    // A document that does not fit the window used to contribute its first N
    // characters and nothing else, which answers "what does it say at the start"
    // and no other question. These pick the passages that bear on what was
    // actually asked, and hand back the same shape of string either way.
    //
    // Keyword scoring (BM25), not embeddings: it needs no second model on the GPU,
    // it runs in the browser so it works the same on Lite where only the browser
    // holds the key, and for a reference document - a prompt library, a manual, a
    // log - the words in the question are usually the words in the passage.
    const CHUNK_CHARS = 1200;
    const CHUNK_OVERLAP = 150;

    function chunkDocument(text) {
        const chunks = [];
        let i = 0;
        while (i < text.length) {
            let end = Math.min(text.length, i + CHUNK_CHARS);
            if (end < text.length) {
                // Break on a paragraph if there is one, then a line, so a chunk is
                // usually a whole entry rather than a sentence cut in half.
                const window = text.slice(i, end);
                const para = window.lastIndexOf('\n\n');
                const line = window.lastIndexOf('\n');
                const brk = para > CHUNK_CHARS * 0.4 ? para : (line > CHUNK_CHARS * 0.4 ? line : -1);
                if (brk > 0) end = i + brk;
            }
            const body = text.slice(i, end);
            if (body.trim()) chunks.push({ start: i, text: body });
            i = end >= text.length ? text.length : Math.max(end - CHUNK_OVERLAP, i + 1);
        }
        return chunks;
    }

    const STOPWORDS = new Set(('the a an and or of to in is it its for on with as at by this that be are was ' +
        'were from what which how why do does did can could should would you your i me my we our they them ' +
        'there here about into over under then than so if but not no yes all any some more most other').split(' '));
    const termsOf = s => (String(s).toLowerCase().match(/[a-z0-9'-]+/g) || [])
        .filter(t => t.length > 1 && !STOPWORDS.has(t));

    // Standard BM25. Returns null when the question shares no usable term with the
    // document - "summarise this" ranks nothing, and pretending otherwise would
    // pick chunks at random.
    function rankChunks(chunks, query) {
        const qTerms = [...new Set(termsOf(query))];
        if (!qTerms.length || !chunks.length) return null;
        const docs = chunks.map(c => termsOf(c.text));
        const N = docs.length;
        const avgLen = docs.reduce((acc, d) => acc + d.length, 0) / N || 1;
        const df = new Map();
        for (const d of docs) for (const t of new Set(d)) df.set(t, (df.get(t) || 0) + 1);
        const k1 = 1.5, b = 0.75;
        const scored = docs.map((d, i) => {
            const tf = new Map();
            for (const t of d) tf.set(t, (tf.get(t) || 0) + 1);
            let score = 0;
            for (const t of qTerms) {
                const f = tf.get(t);
                if (!f) continue;
                const n = df.get(t) || 0;
                const idf = Math.log(1 + (N - n + 0.5) / (n + 0.5));
                score += idf * (f * (k1 + 1)) / (f + k1 * (1 - b + b * (d.length || 1) / avgLen));
            }
            return { i, score };
        });
        return scored.some(s => s.score > 0) ? scored : null;
    }

    function evenSpread(chunks, budgetChars) {
        // No question to match on. An even spread represents a document better than
        // its opening pages, which is what a summary request deserves.
        const room = Math.max(1, Math.floor(budgetChars / CHUNK_CHARS));
        const stride = Math.max(1, Math.ceil(chunks.length / room));
        const picked = [];
        let used = 0;
        for (let i = 0; i < chunks.length; i += stride) {
            const len = chunks[i].text.length;
            if (used + len > budgetChars) break;
            picked.push(i);
            used += len;
        }
        return picked;
    }

    function selectExcerpts(text, query, budgetChars) {
        const full = text || '';
        if (!budgetChars || full.length <= budgetChars) {
            return { text: full, mode: 'full', chunksUsed: 0, totalChunks: 0, coverage: 1 };
        }
        const chunks = chunkDocument(full);
        const ranked = rankChunks(chunks, query);
        const scoreOf = new Map((ranked || []).map(r => [r.i, r.score]));
        let picked = [];
        let used = 0;
        if (ranked) {
            for (const r of [...ranked].sort((x, y) => y.score - x.score)) {
                if (r.score <= 0) break;
                const len = chunks[r.i].text.length;
                if (used + len > budgetChars) continue;
                picked.push(r.i);
                used += len;
                if (used >= budgetChars * 0.98) break;
            }
        }
        const mode = picked.length ? 'relevant' : 'spread';
        if (!picked.length) {
            picked = evenSpread(chunks, budgetChars);
        }

        // Read in document order, never in relevance order: the model should see
        // the file's own sequence, and adjacent chunks should rejoin seamlessly.
        const assemble = idxs => {
            const ordered = [...idxs].sort((a, b) => a - b);
            let out = '';
            let prev = -1;
            for (const i of ordered) {
                if (prev >= 0 && i > prev + 1) {
                    out += `\n\n[... ${(i - prev - 1).toLocaleString()} section(s) omitted ...]\n\n`;
                } else if (prev >= 0) {
                    out += '\n';
                }
                out += chunks[i].text;
                prev = i;
            }
            return out;
        };

        // The separators and the "omitted" markers are characters too, so a
        // selection measured on chunk lengths alone overshoots the budget once it
        // is joined. Measure what will actually be sent, and give back the least
        // useful picks until it fits - the weakest match when there was a query to
        // rank by, otherwise the last of the spread.
        let body = assemble(picked);
        if (body.length > budgetChars) {
            const giveUpOrder = ranked
                ? [...picked].sort((a, b) => (scoreOf.get(a) || 0) - (scoreOf.get(b) || 0))
                : [...picked].sort((a, b) => b - a);
            let drop = 0;
            while (body.length > budgetChars && drop < giveUpOrder.length && picked.length > 1) {
                const doomed = giveUpOrder[drop++];
                picked = picked.filter(i => i !== doomed);
                body = assemble(picked);
            }
            if (body.length > budgetChars) body = body.slice(0, budgetChars);
        }

        return {
            text: body,
            mode,
            chunksUsed: picked.length,
            totalChunks: chunks.length,
            coverage: chunks.length ? picked.length / chunks.length : 1
        };
    }

    async function parseDocument(file, options = {}) {
        if (!file) throw new Error('No file provided for document parsing.');
        const filename = file.name || 'document';
        if ((file.size || 0) > MAX_FILE_BYTES) {
            throw new Error(`${filename} is ${formatBytes(file.size)}. Attach a file under ${formatBytes(MAX_FILE_BYTES)}, or paste the part you want read.`);
        }
        const ext = getExtension(filename);
        const maxChars = options.maxChars || DEFAULT_MAX_CHARS;

        let rawText = '';
        let pageCount = null;
        let detectedType = 'text';

        if (ext === 'pdf' || file.type === 'application/pdf') {
            detectedType = 'pdf';
            const buffer = await readArrayBuffer(file);
            const pdfRes = await parsePdf(buffer);
            rawText = pdfRes.text;
            pageCount = pdfRes.pages;
        } else if (ext === 'docx') {
            detectedType = 'docx';
            const buffer = await readArrayBuffer(file);
            rawText = await parseDocx(buffer);
        } else if (ext === 'xlsx' || ext === 'xls') {
            detectedType = ext;
            const buffer = await readArrayBuffer(file);
            rawText = await parseExcel(buffer, ext);
        } else if (ext === 'rtf' || file.type === 'application/rtf') {
            detectedType = 'rtf';
            const rawRtf = await readTextFile(file);
            rawText = parseRtfText(rawRtf);
        } else if (ext === 'csv' || ext === 'tsv') {
            detectedType = ext;
            rawText = await readTextFile(file);
        } else {
            detectedType = ext || 'text';
            rawText = await readTextFile(file);
        }

        const { text, truncated, originalLength } = truncateText(rawText, maxChars);
        const charCount = text.length;
        const estTokens = estimateTokens(text);

        // Deliberately no copy of the untruncated text: this object is sealed
        // and stored with the message, and only `text` is ever read back.
        return {
            name: filename,
            size: file.size || 0,
            formattedSize: formatBytes(file.size || 0),
            type: detectedType,
            ext,
            text,
            charCount,
            estTokens,
            pages: pageCount,
            truncated,
            originalLength
        };
    }

    // options.budgetChars caps what the attachments may contribute to this turn;
    // options.query is what to select for, normally the question being asked.
    // Without a budget every document goes in whole, which is the old behaviour
    // and still the right one whenever the window can hold it.
    function formatPromptWithDocuments(userPrompt, documents, options = {}) {
        const prompt = (userPrompt || '').trim();
        if (!Array.isArray(documents) || documents.length === 0) {
            return prompt;
        }

        const query = options.query !== undefined ? options.query : prompt;
        const share = options.budgetChars
            ? Math.floor(options.budgetChars / documents.length)
            : 0;

        const docSections = documents.map(doc => {
            const pagesInfo = doc.pages ? ` (${doc.pages} ${doc.pages === 1 ? 'page' : 'pages'})` : '';
            const sizeInfo = doc.formattedSize ? ` [${doc.formattedSize}]` : '';
            const selection = selectExcerpts(doc.text || '', query, share);
            const textContent = selection.text.trim() || '[This document contains no readable text or is an image-only scan.]';
            if (selection.mode === 'full') {
                return `--- Attached Document: ${doc.name}${pagesInfo}${sizeInfo} ---\n${textContent}\n--- End of ${doc.name} ---`;
            }
            // Say plainly that this is a subset, or the model answers "is X in here?"
            // with a confident no when X was simply in a section that did not travel.
            const how = selection.mode === 'relevant'
                ? 'the sections most relevant to the question above were selected'
                : 'sections were sampled evenly across the whole file, because the request named nothing specific to search for';
            const pct = Math.round(selection.coverage * 100);
            return `--- Attached Document (EXCERPTS): ${doc.name}${pagesInfo}${sizeInfo} ---\n`
                + `[This file is too large for the context window, so ${how}. `
                + `You are seeing ${selection.chunksUsed} of ${selection.totalChunks} sections (~${pct}%), in document order. `
                + `Anything not shown is still in the file - if the answer is not in these excerpts, say so and ask for a narrower question rather than concluding it is absent.]\n\n`
                + `${textContent}\n--- End of ${doc.name} ---`;
        });

        const header = `[The user has attached ${documents.length} document${documents.length > 1 ? 's' : ''} to this message:]`;
        const body = docSections.join('\n\n');

        if (!prompt) {
            return `${header}\n\n${body}\n\nPlease read and summarize the attached document(s).`;
        }

        return `${header}\n\n${body}\n\n${prompt}`;
    }

    function getDocumentIcon(type) {
        const t = String(type || '').toLowerCase();
        if (t === 'pdf') return '📄';
        if (t === 'xlsx' || t === 'xls' || t === 'csv' || t === 'tsv') return '📊';
        if (t === 'docx') return '📝';
        if (t === 'rtf') return '📑';
        if (['js', 'ts', 'py', 'html', 'css', 'json', 'sql', 'xml', 'yaml', 'yml'].includes(t)) return '💻';
        return '📃';
    }

    return {
        isDocumentFile,
        isImageFile,
        parseDocument,
        parseRtfText,
        extractTextFromWordXml,
        formatPromptWithDocuments,
        selectExcerpts,
        chunkDocument,
        getDocumentIcon,
        estimateTokens,
        formatBytes,
        DEFAULT_MAX_CHARS,
        MAX_FILE_BYTES,
        loadVendorScript,
        DOCUMENT_EXTENSIONS,
        IMAGE_EXTENSIONS
    };
}));

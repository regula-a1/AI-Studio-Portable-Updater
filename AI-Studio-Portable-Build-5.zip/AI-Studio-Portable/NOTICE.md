# Third-party components

AI Studio Portable runs alongside several third-party projects. This file records
what they are, how they are licensed, and which constraints those licenses place
on this product. **It is a working engineering record, not legal advice — have a
lawyer review it before charging money for this software.**

## The rule that keeps our own code ours

ComfyUI is GPL-3.0. Our orchestrator talks to it **only over HTTP**
(`http://127.0.0.1:8189`), as a separate process, and never imports its code.
That arm's-length boundary is the strongest argument available for treating
AI Studio Portable's own source as a separate work rather than a derivative of
ComfyUI - GPL-3.0 §5 recognises an aggregation of independent programs. It is
an argument, not a guarantee: it has not been tested by a lawyer against this
specific arrangement, and it says nothing about llama.cpp, which is MIT and
does not raise the same question.

**Never `import` ComfyUI modules, custom-node modules, or anything from the
`comfy/` tree into our Python.** If that boundary is crossed, the licensing
analysis for this whole product changes. The same applies to llama.cpp, which we
drive through its HTTP server rather than linking against.

## Shipped in the ZIP

Only these are actually in the release archive; everything below this section
is fetched by setup afterward, onto the user's own machine, not distributed by
us as part of the ZIP.

| Component | License | Obligation when we redistribute |
|---|---|---|
| marked, DOMPurify, pdf.js, SheetJS | MIT / Apache-2.0 | Full license texts shipped in `web/js/vendor/THIRD-PARTY-LICENSES/`. |

## Downloaded by setup, not shipped

The installer fetches these from their own upstream hosts onto the user's
machine; none of their source or binaries travel inside our ZIP. The table
below records the obligations that would apply if we ever changed that -
by shipping a preconfigured install, an offline pack, or a hosted service -
which is a different distribution question from what today's bare ZIP raises.

| Component | License | Obligation if we ever redistribute it |
|---|---|---|
| ComfyUI | GPL-3.0 | Ship the license text; make the (unmodified) source available. Selling is permitted. |
| LanPaint | GPL-3.0 | Same as above. Provides the masked-edit nodes. |
| ComfyUI-SeedVR2_VideoUpscaler | Apache-2.0 | Ship the license and NOTICE; state any changes. |
| ComfyUI-Krea2T-Enhancer | MIT | Ship the license text. |
| KreaSeedVarianceEnhancer | MIT-0 | No attribution required; ship it anyway. |
| rgthree-comfy | MIT | Ship the license text. Optional — quality-of-life nodes only. |
| llama.cpp (`llama-server`) | MIT | Ship the license text. |
| NVIDIA CUDA runtime DLLs (cudart, cublas, cublasLt) | NVIDIA's own EULA, not MIT | These ride alongside llama.cpp's CUDA build but are NVIDIA's redistributables, not covered by llama.cpp's MIT license. Check NVIDIA's redistribution terms before shipping them as part of anything we distribute. |

## Deliberately NOT bundled

### RES4LYF — the Clownshark samplers

RES4LYF is AGPL-3.0 **plus** an added commercial rider:

> The use of this software or any derivative work for the purpose of providing a
> commercial service [...] is strictly prohibited without obtaining permission
> and/or a separate commercial license from the copyright holder. This includes
> any service that charges users directly or indirectly for access to this
> software's functionality, whether standalone or integrated into a larger
> product.

That last clause is aimed squarely at a paid product that integrates it. Because
AI Studio Portable is free now but may be monetized later, **RES4LYF is treated
as an optional component the user installs themselves**, never as something we
ship or require.

Consequences to honour in the code:

- The setup wizard may *offer* to install it, clearly labelled as third-party and
  non-commercial, but must not install it silently or by default.
- The Clownshark sampler options (`clownshark_2pass`, `linear/euler`) are hidden
  in the UI and stripped server-side (`orchestrator.available_samplers`,
  `server.studio_registry`'s `res4lyfAvailable`) whenever ComfyUI reports
  `ClownsharKSampler_Beta` unavailable, rather than offered and then failed.
- No shipped preset, workflow template or default may depend on them.
- If monetization happens, revisit this. The clean options are to drop the
  integration entirely or to obtain a commercial license from the author.

## Model weights

No model weights are redistributed - the installer streams each file directly
from the host named in the manifest to the user's disk, over plain anonymous
HTTP, never through infrastructure we control. That host is not always the
original publisher: several shipped defaults come from a repackager (Comfy-Org)
or a third-party quantizer (mradermacher). The default upscale model is
`RealESRGAN_x4plus.pth` (BSD-3-Clause, taken from the model author's own GitHub
release) specifically because the more common 4x-UltraSharp's only public
source was a disputed, noncommercially-licensed reupload. The default chat
model is Qwen3 1.7B Abliterated (Apache-2.0 base) rather than the Llama 3.2 1B
this project shipped with initially - Llama's licence forbids circumventing a
model's safety measures, which is exactly what an abliterated build does, and
this project's chat posture is deliberately uncensored, so a base licence
without that restriction was needed. The default Krea 2 Turbo checkpoint
carries its own commercial and acceptable-use terms this file does not track
in detail. There is no account-based license-acceptance flow; a download is
anonymous and unauthenticated. Several Civitai models a user points the studio
at are non-commercial or gated behind an account with adult content enabled;
that remains the user's relationship with Civitai, not ours.

The downloader must never proxy, mirror or cache weights on infrastructure we
control — that would make us a redistributor and pull every model licence into
this table. Direct download from the named host reduces redistribution
exposure; it does not by itself establish that the host had the right to host
that file, or that the resulting use is authorized.

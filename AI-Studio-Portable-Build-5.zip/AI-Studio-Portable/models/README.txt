Drop model files in here.

Each folder matches what ComfyUI calls that kind of model, apart from llm, which
is the studio's own. Put a file in the right one and the studio picks it up on
the next rescan - use Rescan in the Models panel, or just restart.

  checkpoints        all-in-one models (SDXL, Illustrious, and similar)
  diffusion_models   models that come split from their text encoder
  text_encoders      the text half of a split model
  vae                decoders
  loras              LoRA layers
  upscale_models     upscalers
  controlnet         ControlNet models
  embeddings         textual inversions
  clip_vision        vision encoders
  llm                chat models (.gguf), and their mmproj file if they see

The folders themselves ship empty. Nothing you put in them is ever committed or
included in a release, so what you drop here stays yours.

You can also use models you already have somewhere else without moving them.
In config.json:

  "models_path": "E:/SomeWhere/ComfyUI/models"

That folder is only ever read from. Nothing is written, moved or renamed there.

@echo off
REM Runs the full install: ComfyUI, the custom nodes, and the models.
REM Safe to run again - every step checks whether it is already done.
setlocal
cd /d "%~dp0\.."
if not exist "runtime\python\python.exe" (
    echo The studio has no python yet. Run Start.bat first.
    pause
    exit /b 1
)
"runtime\python\python.exe" "app\setup.py" install %*
pause

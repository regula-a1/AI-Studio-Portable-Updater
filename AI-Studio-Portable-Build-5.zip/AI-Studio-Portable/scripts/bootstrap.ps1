# Bring the studio up on a PC that has nothing installed.
#
# The installer cannot be written in Python, because a clean Windows machine does
# not have Python. It can only assume what Windows itself ships: PowerShell, and
# since Windows 10, curl and tar. So this script is the one piece that runs
# before anything exists, and its whole job is to obtain a Python of our own and
# then get out of the way.
#
# Our own, deliberately, even when the machine already has one. A Python that
# came with something else is a Python somebody else can upgrade, uninstall, or
# fill with packages that conflict with ours - and the failure would surface as
# the studio breaking for no visible reason. 10 MB is a cheap price for never
# having that conversation.
#
# ComfyUI keeps its own separate interpreter. Two Pythons sounds wasteful and is
# not: they have entirely different dependency sets, and the alternative is our
# crypto library and its torch build sharing one resolver.
#
# Everything here is safe to run again. Each step checks whether it is already
# done, so a failed install is fixed by running it a second time.

$ErrorActionPreference = 'Stop'

$Root = Split-Path -Parent $PSScriptRoot
$RuntimeDir = Join-Path $Root 'runtime'
$PythonDir = Join-Path $RuntimeDir 'python'
$PythonExe = Join-Path $PythonDir 'python.exe'
$DownloadDir = Join-Path $Root 'data\downloads'

# pip caches wheels in the user's profile by default, which puts part of this
# install outside the folder it claims to live in - and on the system drive,
# which is the one most likely to be full. Pointing it inside keeps a retry
# from re-downloading while still leaving nothing behind when the folder goes.
$env:PIP_CACHE_DIR = Join-Path $Root 'data\cache\pip'

# Pinned rather than "latest": an installer that silently changes Python version
# between two users' machines is an installer that produces bug reports nobody
# can reproduce. 3.12 because several ComfyUI node dependencies still lack 3.13
# wheels, and a source build needs a compiler this PC will not have.
$PythonVersion = '3.12.10'
$PythonUrl = "https://www.python.org/ftp/python/$PythonVersion/python-$PythonVersion-embed-amd64.zip"
$GetPipUrl = 'https://bootstrap.pypa.io/get-pip.py'

# What the studio itself needs. ComfyUI's dependencies are its own problem and
# are installed into its own interpreter.
$Packages = @('cryptography', 'pillow', 'websocket-client', 'psutil')

function Say($Message) { Write-Host "  $Message" }

function Get-File($Url, $Destination) {
    if (Test-Path $Destination) {
        Say "already downloaded: $(Split-Path -Leaf $Destination)"
        return
    }
    $parent = Split-Path -Parent $Destination
    if (-not (Test-Path $parent)) { New-Item -ItemType Directory -Force -Path $parent | Out-Null }
    $partial = "$Destination.part"
    Say "downloading $(Split-Path -Leaf $Destination)..."
    # -UseBasicParsing keeps this working on a machine where Internet Explorer's
    # first-run wizard has never been completed, which is most of them now.
    Invoke-WebRequest -Uri $Url -OutFile $partial -UseBasicParsing
    Move-Item -Force $partial $Destination
}

function Expand-Zip($Archive, $Destination) {
    if (-not (Test-Path $Destination)) { New-Item -ItemType Directory -Force -Path $Destination | Out-Null }
    Expand-Archive -Path $Archive -DestinationPath $Destination -Force
}

function Install-Python {
    if (Test-Path $PythonExe) {
        Say "python already present in runtime\python"
        return
    }
    $zip = Join-Path $DownloadDir "python-$PythonVersion-embed-amd64.zip"
    Get-File $PythonUrl $zip
    Say 'unpacking python...'
    Expand-Zip $zip $PythonDir

    # The embeddable build ships with site-packages disabled: its ._pth file has
    # "import site" commented out. Until that line is restored pip installs
    # succeed and then import as though nothing had been installed, which is a
    # deeply confusing way to fail.
    # The archive has served its purpose. Kept until now so an interrupted run
    # resumes instead of downloading it again; from here it is 11 MB that
    # nothing reads and nothing else would ever delete.
    Remove-Item -Force $zip -ErrorAction SilentlyContinue

    Get-ChildItem -Path $PythonDir -Filter '*._pth' | ForEach-Object {
        $content = Get-Content $_.FullName
        $patched = $content -replace '^#\s*import site', 'import site'
        if ($patched -notcontains 'import site') { $patched += 'import site' }
        Set-Content -Path $_.FullName -Value $patched -Encoding ascii
    }
}

# Whether our python can import a module. Deliberately not written with 2>&1:
# in Windows PowerShell 5.1 redirecting a native command's stderr wraps every
# line in an ErrorRecord, which under ErrorActionPreference=Stop turns an
# expected "no, that module is missing" into a fatal error and aborts the
# install. Probing for absent modules is the entire point of this function.
function Test-Module($Module) {
    $previous = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        # find_spec rather than a real import: a missing module then costs an exit
        # code instead of a traceback on stderr. The traceback was harmless but it
        # filled the log with Python errors for modules we were only asking about,
        # which is exactly the log someone sends when reporting a failure.
        $probe = "import importlib.util,sys; sys.exit(0 if importlib.util.find_spec('$Module') else 1)"
        & $PythonExe -c $probe | Out-Null
        return ($LASTEXITCODE -eq 0)
    } finally {
        $ErrorActionPreference = $previous
    }
}

function Install-Pip {
    if (Test-Module 'pip') {
        Say 'pip already present'
        return
    }
    $getPip = Join-Path $DownloadDir 'get-pip.py'
    Get-File $GetPipUrl $getPip
    Say 'installing pip...'
    & $PythonExe $getPip --no-warn-script-location | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'pip could not be installed.' }
    Remove-Item -Force $getPip -ErrorAction SilentlyContinue
}

function Install-Packages {
    $missing = @()
    foreach ($package in $Packages) {
        # The import name and the package name differ for two of these.
        $module = $package
        if ($package -eq 'pillow') { $module = 'PIL' }
        if ($package -eq 'websocket-client') { $module = 'websocket' }
        if (-not (Test-Module $module)) { $missing += $package }
    }
    if ($missing.Count -eq 0) {
        Say 'all studio packages present'
        return
    }
    Say "installing: $($missing -join ', ')"
    & $PythonExe -m pip install --no-warn-script-location @missing
    if ($LASTEXITCODE -ne 0) { throw "could not install: $($missing -join ', ')" }
}

# Everything this prints also goes to a file. A console window that closes takes
# the only account of what went wrong with it, and the machine that fails is
# usually not the machine that can be debugged on.
$logDir = Join-Path $Root 'data'
if (-not (Test-Path $logDir)) { New-Item -ItemType Directory -Force -Path $logDir | Out-Null }
$logFile = Join-Path $logDir 'setup-log.txt'
try { Start-Transcript -Path $logFile -Append -ErrorAction Stop | Out-Null } catch { }

Write-Host ''
Write-Host 'AI Studio Portable - first run'
Write-Host ("  " + (Get-Date -Format 'yyyy-MM-dd HH:mm') + "  log: data\setup-log.txt")
Write-Host ''

Install-Python
Install-Pip
Install-Packages

Write-Host ''

# From here Start.bat is the only thing anyone has to run, ever. It sets up if
# setting up is needed, then opens the studio. It never finishes by telling
# someone to go and find another file - the first version did exactly that,
# printing a plan and pointing at a batch file inside scripts\, which leaves a
# person staring at a folder with nothing obvious to click.
$setup = Join-Path $Root 'app\setup.py'
$server = Join-Path $Root 'app\server.py'
$comfyMarker = Join-Path $Root 'comfy\ComfyUI\main.py'

function Start-Studio {
    # The server runs until the window closes, so the log has to be closed first
    # or the transcript is left open for the life of the session.
    try { Stop-Transcript -ErrorAction Stop | Out-Null } catch { }
    Write-Host ''
    Write-Host '  Starting the studio. Your browser should open in a moment.'
    Write-Host '  Leave this window open while you use it. Close it to stop.'
    Write-Host ''
    & $PythonExe $server
}

# Whether setup has anything left to do. Deliberately asked of setup.py rather
# than answered here by looking for a file: the previous version checked for
# comfy\ComfyUI\main.py, which only says ComfyUI was unpacked. When setup stopped
# straight after that step - which is what happened the first time this ran on a
# real machine - the file was there, so every later launch skipped setup entirely
# and the install stayed stuck one step in, while the screen kept promising that
# running it again would carry on.
function Test-SetupComplete {
    $previous = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        & $PythonExe $setup status | Out-Null
        return ($LASTEXITCODE -eq 0)
    } finally {
        $ErrorActionPreference = $previous
    }
}

if (Test-SetupComplete) {
    Start-Studio
    return
}

# Part-way through already: they have agreed to this once, so carry on rather
# than asking again.
if (Test-Path $comfyMarker) {
    Write-Host ''
    Write-Host ' Setup did not finish last time. Carrying on from where it stopped -'
    Write-Host ' nothing already downloaded is fetched again.'
    Write-Host ''
    & $PythonExe $setup install
    if ($LASTEXITCODE -ne 0) {
        Write-Host ''
        Write-Host '  Still not finished. Run Start.bat again to retry.'
        Write-Host '  If it keeps failing, send data\setup-log.txt.'
    }
    Start-Studio
    return
}

# Not set up yet. Say what that involves in plain language, then ask - rather
# than printing a developer's dry run and stopping.
Write-Host '--------------------------------------------------------------'
Write-Host ' First time setup'
Write-Host '--------------------------------------------------------------'
Write-Host ''
Write-Host ' The studio needs to download the engines it runs on: about 2 GB'
Write-Host ' for image generation and another 0.5 GB for chat.'
Write-Host ''
Write-Host ' Then it will ask whether this PC already has ComfyUI models. If it'
Write-Host ' does, say where and they are used where they sit - nothing copied,'
Write-Host ' nothing moved. If not, the models are downloaded too, and those are'
Write-Host ' large: around 18 GB. It tells you the figure before starting.'
Write-Host ''
Write-Host ' Everything goes inside this folder. Nothing else on your PC is'
Write-Host ' changed, and any ComfyUI you already have is left alone.'
Write-Host ''
Write-Host ' You can stop it at any time and run Start.bat again - it picks up'
Write-Host ' from where it left off.'
Write-Host ''

$answer = Read-Host ' Install it now? (Y/n)'
if ($answer -and $answer.Trim().ToLower().StartsWith('n')) {
    Write-Host ''
    Write-Host ' Skipped. Opening the studio anyway so you can look around -'
    Write-Host ' image generation will not work until the engine is installed.'
    Write-Host ' Run Start.bat again whenever you want to install it.'
    Start-Studio
    return
}

Write-Host ''
& $PythonExe $setup install
$installOk = ($LASTEXITCODE -eq 0)

Write-Host ''
if ($installOk) {
    Write-Host '  Setup finished.'
} else {
    Write-Host '  Setup did not finish everything.'
    Write-Host '  Run Start.bat again to carry on from here - nothing is lost.'
    Write-Host '  If it keeps failing, send data\setup-log.txt.'
}

# Open the studio either way. A part-finished install still gives a working
# interface, and something on screen beats a console that has stopped talking.
Start-Studio

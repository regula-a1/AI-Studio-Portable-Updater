@echo off
REM Double-click entry point. Deliberately almost empty: this is the one file
REM that runs on a machine with nothing installed, so it can only use what
REM Windows itself provides. Everything else lives in scripts\bootstrap.ps1.
REM
REM -ExecutionPolicy Bypass applies to this process only. It does not change any
REM machine setting, and without it the default policy refuses to run a script
REM the user just downloaded - which would stop the studio before it began.
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\bootstrap.ps1"
if errorlevel 1 (
    echo.
    echo Setup did not finish. Nothing is lost - run Start.bat again and it
    echo carries on from where it stopped.
    echo.
)
pause

"""Runs the orchestrator against local storage instead of the cloud relay.

The orchestrator has no "run this job" function. The work lives inside Agent, and
every piece of I/O that class performs with the outside world goes through one
method - `Agent.cloud(action, job, data, params, raw)` - which makes an HTTPS
call to the relay. There are exactly six actions:

    claim      ask for the next job            -> {'job': {...}} or {}
    asset      fetch a sealed input or mask    -> bytes
    heartbeat  report progress                 -> ignored
    image      deliver the sealed result       -> ignored
    thumbnail  deliver the sealed thumbnail    -> ignored
    fail       mark the job failed             -> ignored

Chat is the exception, and it is worth knowing before trusting the count above:
replies do not go through cloud() at all. They go through a second method,
post_chat_api, with four more actions of its own. Ten in total, two seams. Both
are replaced here.

Everything above them - workflow construction, sampler installation, LoRA
chaining, inpaint geometry, the ComfyUI websocket, model swapping - runs
unmodified.

Subclassing rather than editing orchestrator.py is deliberate. The graph builders
there are covered by golden-file tests and nothing covers the rest of that file,
so the less it is touched the better. It also keeps the boundary honest:
storage decisions live here, engine decisions live there.
"""
import io
import json
import time
import uuid
from pathlib import Path


class LocalAgent:
    """Mixin supplying a local `cloud()`. Combined with Agent in build_agent().

    Kept as a mixin rather than a subclass written against the import so that
    importing this module does not require the orchestrator, which in turn keeps
    the server able to start and explain itself when the runtime is missing.
    """

    # Wired by build_agent so this class has no import-time dependency on either
    # the server or the orchestrator.
    store = None

    def cloud(self, action, job=None, data=None, params=None, raw=False):
        if action == 'claim':
            return {'job': self.store.claim(params or {})}
        if action == 'asset':
            return self.store.asset(job, (params or {}).get('type', 'input'))
        if action == 'heartbeat':
            self.store.heartbeat(job, data or {})
            return {}
        if action in ('image', 'thumbnail'):
            self.store.deliver(job, action, data)
            return {}
        if action == 'fail':
            self.store.fail(job, data)
            return {}
        raise RuntimeError('Unsupported local action: ' + str(action))

    # Chat has its own seam. `cloud()` is not the only way out of the
    # orchestrator: replies go through post_chat_api, with four more actions.
    #
    #     worker-token       one streamed fragment, sealed
    #     worker-stream-key  the per-job key the browser needs to open them
    #     worker-done        the turn finished
    #     worker-fail        the turn failed
    #
    # Together these are the streaming contract the client resumes with from_seq,
    # so tokens are appended to studio_chat_chunks rather than pushed.
    def post_chat_api(self, action, payload, app='chat'):
        return self.store.chat_event(action, payload or {})


class LocalStore:
    """Both seams, against SQLite and the images folder.

    Takes a connection factory rather than a connection: the job runner is its
    own thread and sqlite3 connections are not shareable across threads.
    """

    def __init__(self, connect, images_dir, owner='local'):
        self.connect = connect
        self.images = Path(images_dir)
        self.owner = owner
        # Set by the runner before each job so claim() hands back the row it
        # already selected, instead of racing the runner for the queue head.
        self.pending_job = None

    # -- the image seam ---------------------------------------------------

    def claim(self, params):
        """Hand over the job the runner already picked.

        The original polled a queue it shared with other machines, so claiming
        was a real transaction. Here the runner owns the queue and has already
        chosen; this only has to return that choice in the shape Agent expects.
        """
        job = self.pending_job
        self.pending_job = None
        return job

    def asset(self, job, kind):
        """Return the sealed bytes of an input image or mask."""
        column = 'input_image_key' if kind == 'input' else 'mask_image_key'
        row = self.connect().execute(
            'SELECT ' + column + ' AS k FROM studio_jobs WHERE id=?', (job['id'],)).fetchone()
        if not row or not row['k']:
            raise FileNotFoundError('No ' + kind + ' asset stored for ' + str(job['id']))
        path = self.safe(row['k'])
        if not path.exists():
            raise FileNotFoundError('Asset missing on disk: ' + str(path.name))
        return path.read_bytes()

    def heartbeat(self, job, payload):
        conn = self.connect()
        conn.execute(
            'UPDATE studio_jobs SET progress_stage=?, progress=?, progress_total=?, '
            'eta_seconds=?, updated=? WHERE id=?',
            (payload.get('stage'), payload.get('value'), payload.get('total'),
             payload.get('eta'), int(time.time()), job['id']))
        conn.commit()

    def deliver(self, job, kind, data):
        """Store a sealed result. Still ciphertext: only the browser opens it."""
        if not data:
            return
        # A readable file gets a readable name, and the right one: the full image
        # is a PNG but the thumbnail is WebP, so the extension comes from the
        # bytes rather than from an assumption. Sealed data stays .bin.
        extension = _extension_for(data)
        suffix = extension if kind == 'image' else '_thumb' + extension
        key = str(job['id']) + suffix
        self.safe(key).write_bytes(data)
        column = 'image_key' if kind == 'image' else 'thumbnail_key'
        conn = self.connect()
        # Only the image completes the job. A thumbnail can arrive first and must
        # not flip the row to complete before the full-size result is on disk.
        if kind == 'image':
            conn.execute(
                "UPDATE studio_jobs SET image_key=?, status='complete', error=NULL, updated=? "
                'WHERE id=?', (key, int(time.time()), job['id']))
        else:
            conn.execute('UPDATE studio_jobs SET ' + column + '=?, updated=? WHERE id=?',
                         (key, int(time.time()), job['id']))
        conn.commit()

    def fail(self, job, data=None):
        message = 'Generation failed.'
        if isinstance(data, dict) and data.get('error'):
            message = str(data['error'])[:500]
        conn = self.connect()
        conn.execute("UPDATE studio_jobs SET status='error', error=?, updated=? WHERE id=?",
                     (message, int(time.time()), job['id']))
        conn.commit()

    def chat_event(self, action, payload):
        """Record one chat streaming event for the client's stream poll."""
        job_id = payload.get('job_id')
        if not job_id:
            return {}
        conn = self.connect()
        if action == 'worker-token':
            seq = conn.execute('SELECT COALESCE(MAX(seq), 0) + 1 AS next FROM '
                               'studio_chat_chunks WHERE job_id=?', (job_id,)).fetchone()['next']
            conn.execute('INSERT INTO studio_chat_chunks(job_id, seq, kind, payload, created) '
                         'VALUES(?,?,?,?,?)',
                         (job_id, seq, 'token', json.dumps(payload), int(time.time())))
        elif action == 'worker-stream-key':
            conn.execute('INSERT OR REPLACE INTO studio_chat_chunks(job_id, seq, kind, payload, '
                         'created) VALUES(?,?,?,?,?)',
                         (job_id, 0, 'stream-key', json.dumps(payload), int(time.time())))
        elif action == 'worker-done':
            # This is what persists the reply. The client only saves an assistant
            # message for a turn the user *stopped* - its own comment says
            # worker-done never fires for those - so a reply that finished
            # normally exists nowhere until this writes it, and vanishes on the
            # next reload. It carries the sealed content, reasoning and usage
            # counts; all three are opaque here.
            self._save_reply(conn, job_id, payload)
            conn.execute("UPDATE studio_jobs SET status='complete', updated=? WHERE id=?",
                         (int(time.time()), job_id))
        elif action == 'worker-fail':
            conn.execute("UPDATE studio_jobs SET status='error', error=?, updated=? WHERE id=?",
                         (str(payload.get('error') or 'Chat failed.')[:500],
                          int(time.time()), job_id))
        conn.commit()
        return {}

    def _save_reply(self, conn, job_id, payload):
        """Write the finished assistant message into the conversation."""
        chat_id = payload.get('chat_id')
        if not chat_id or not payload.get('sealed_content'):
            return
        row = conn.execute('SELECT id FROM studio_messages WHERE job_id=? AND role=?',
                           (job_id, 'assistant')).fetchone()
        if row:
            conn.execute('UPDATE studio_messages SET sealed_content=?, sealed_reasoning=?, '
                         'sealed_usage=? WHERE id=?',
                         (payload.get('sealed_content'), payload.get('sealed_reasoning'),
                          payload.get('sealed_usage'), row['id']))
            return
        seq = conn.execute('SELECT COALESCE(MAX(seq), 0) + 1 AS n FROM studio_messages '
                           'WHERE chat_id=?', (chat_id,)).fetchone()['n']
        # 'checkpoint' is how the client recognises a compaction summary and folds
        # the turns it replaced; saving one as an ordinary reply would show the
        # summary as something the assistant said.
        role = 'checkpoint' if payload.get('is_compaction') else 'assistant'
        conn.execute(
            'INSERT INTO studio_messages(id, chat_id, owner, role, seq, sealed_content, '
            'sealed_reasoning, sealed_usage, job_id, created) VALUES(?,?,?,?,?,?,?,?,?,?)',
            (str(uuid.uuid4()), chat_id, self.owner, role, seq, payload.get('sealed_content'),
             payload.get('sealed_reasoning'), payload.get('sealed_usage'), job_id,
             int(time.time())))
        conn.execute('UPDATE studio_chats SET updated=? WHERE id=?', (int(time.time()), chat_id))

    # -- helpers ----------------------------------------------------------

    def safe(self, key):
        """Keys are ours here, but the check costs nothing and the folder is real."""
        candidate = (self.images / str(key)).resolve()
        if not str(candidate).startswith(str(self.images.resolve())):
            raise ValueError('Bad asset key: ' + str(key))
        return candidate


def _extension_for(data):
    """File extension matching the actual bytes."""
    if data[:4] == bytes.fromhex('41535031'):          # ASP1, still sealed
        return '.bin'
    if data[:8] == bytes.fromhex('89504e470d0a1a0a'):
        return '.png'
    if data[:3] == bytes.fromhex('ffd8ff'):
        return '.jpg'
    if data[:4] == b'RIFF' and data[8:12] == b'WEBP':
        return '.webp'
    return '.bin'


def job_for_agent(row):
    """Shape a database row the way Agent expects a claimed job.

    Agent reads `lease` when talking to the relay and when deriving a ComfyUI
    prompt id, and both must be stable for the life of the job so a retry after a
    restart recovers the same ComfyUI history entry rather than starting over.
    The row id is already stable and unique, so the lease is derived from it.
    """
    job = dict(row)
    job.setdefault('lease', str(uuid.uuid5(uuid.NAMESPACE_URL,
                                           'urn:aistudio-portable:lease:' + str(job['id']))))
    if isinstance(job.get('loras'), str):
        try:
            job['loras'] = json.loads(job['loras'])
        except json.JSONDecodeError:
            job['loras'] = None
    return job


def write_runtime_config(app_dir, passphrase):
    """Write the config Agent.__init__ reads, so it needs no edit.

    Agent loads app/config.json at construction. Rather than patch that, the
    server writes the file from its own settings. `site` and `worker_key` are the
    relay's credentials: they are kept as harmless placeholders because the
    overridden cloud() never reaches the network, and removing them would mean
    editing the constructor.

    The passphrase has to be here because the orchestrator unseals the prompt to
    build a graph. The browser seals with the same phrase; first-run setup is what
    makes the two agree.
    """
    config_path = Path(app_dir) / 'config.json'
    existing = {}
    if config_path.exists():
        try:
            existing = json.loads(config_path.read_text(encoding='utf-8'))
        except (OSError, json.JSONDecodeError):
            existing = {}
    existing.update({
        'studio_key': passphrase,
        'lite_key': existing.get('lite_key', 'studio-lite-v1-secret'),
        'worker_key': 'local',
        'site': 'http://127.0.0.1',
    })
    # Written with an explicit LF so this stays consistent on Windows. The file
    # is generated rather than committed, but the repo has one line-ending
    # convention and a generator that quietly breaks it is how drift starts.
    with io.open(config_path, 'w', encoding='utf-8', newline='\n') as handle:
        handle.write(json.dumps(existing, indent=2) + '\n')
    return config_path


def build_agent(orchestrator, store):
    """Compose Agent with the local seam. Returns a ready instance."""
    bound = type('LocalStudioAgent', (LocalAgent, orchestrator.Agent), {})
    agent = bound()
    agent.store = store
    return agent

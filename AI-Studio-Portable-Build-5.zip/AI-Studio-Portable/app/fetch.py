"""Downloading large files onto a machine that will interrupt you.

The install is roughly 19 GB of weights over whatever connection the user has.
Something will go wrong during it - a dropped wifi link, a closed lid, a reboot -
and the only acceptable behaviour is to carry on from where it stopped. A fresh
download after 17 GB is not a retry, it is a reason to give up on the product.

So every transfer here is resumable by HTTP range request, verified by hash when
the manifest knows one, and writes to a `.part` file that is only renamed into
place once it is complete and checked. A half-written model that is named as
though it were whole is worse than no model: ComfyUI fails on it in a way that
looks like a bug in the studio.

Standard library only, like the server: this has to run before any environment
has been installed, which is exactly when a dependency cannot be relied on.
"""
import hashlib
import os
import time
import urllib.error
import urllib.request
from pathlib import Path

USER_AGENT = 'AIStudioPortable/1'
CHUNK = 1024 * 256
# Retries are for a connection that dropped, not for a server saying no. Backoff
# is short because the loop is cheap and the alternative is a stalled install.
RETRY_DELAYS = (2, 5, 15, 30, 60)


class DownloadError(Exception):
    pass


def human(size):
    if size is None:
        return 'unknown size'
    for unit in ('B', 'KB', 'MB', 'GB'):
        if size < 1024 or unit == 'GB':
            return ('%.1f %s' % (size, unit)).replace('.0 ', ' ')
        size /= 1024.0
    return str(size)


def head(url, timeout=20):
    """Size and resumability, without starting the transfer.

    Used by `verify` to check a manifest is real before anyone waits on it, and
    by the planner to total up a download and tell the user what they are in for.
    """
    request = urllib.request.Request(url, method='HEAD', headers={'User-Agent': USER_AGENT})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            length = response.headers.get('Content-Length')
            return {
                'ok': True,
                'status': response.status,
                'size': int(length) if length and length.isdigit() else None,
                'resumable': response.headers.get('Accept-Ranges', '').lower() == 'bytes',
                'url': response.url,
            }
    except urllib.error.HTTPError as exc:
        return {'ok': False, 'status': exc.code, 'error': str(exc), 'size': None}
    except Exception as exc:                               # noqa: BLE001 - reported, not raised
        return {'ok': False, 'status': None, 'error': str(exc), 'size': None}


def file_sha256(path, chunk=1024 * 1024):
    digest = hashlib.sha256()
    with open(path, 'rb') as handle:
        while True:
            block = handle.read(chunk)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest()


def download(url, destination, sha256=None, expected_size=None, on_progress=None,
             retries=len(RETRY_DELAYS)):
    """Fetch `url` to `destination`, resuming and verifying. Returns the path.

    Already-present and correct files are left alone, which is what makes the
    whole installer safe to re-run: the second pass over a finished step costs a
    hash instead of a download.
    """
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    part = destination.with_suffix(destination.suffix + '.part')

    if destination.exists():
        if sha256 and file_sha256(destination) != sha256.lower():
            # Present but wrong. Refuse to guess whether it is a corrupt download
            # or a different file the user put there deliberately.
            raise DownloadError(
                str(destination.name) + ' is already here but does not match the expected '
                'checksum. Move it aside and run setup again.')
        return destination

    attempt = 0
    while True:
        have = part.stat().st_size if part.exists() else 0
        headers = {'User-Agent': USER_AGENT}
        if have:
            headers['Range'] = 'bytes=%d-' % have
        request = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(request, timeout=60) as response:
                # A server that ignores the range restarts the file; the local
                # offset has to be thrown away or the two halves interleave.
                if have and response.status != 206:
                    have = 0
                    part.unlink(missing_ok=True)
                total = response.headers.get('Content-Length')
                total = (int(total) + have) if total and total.isdigit() else expected_size
                mode = 'ab' if have else 'wb'
                last_report = 0.0
                with open(part, mode) as handle:
                    while True:
                        block = response.read(CHUNK)
                        if not block:
                            break
                        handle.write(block)
                        have += len(block)
                        now = time.time()
                        if on_progress and now - last_report > 0.5:
                            last_report = now
                            on_progress(have, total)
            if on_progress:
                on_progress(have, have)
            break
        except Exception as exc:                           # noqa: BLE001 - retried below
            attempt += 1
            if attempt > retries:
                raise DownloadError('Could not download ' + url + ': ' + str(exc))
            # Keep the .part file: the next attempt resumes from it, which is the
            # entire point of this module.
            time.sleep(RETRY_DELAYS[min(attempt - 1, len(RETRY_DELAYS) - 1)])

    if sha256:
        actual = file_sha256(part)
        if actual != sha256.lower():
            part.unlink(missing_ok=True)
            raise DownloadError(
                'Checksum mismatch for ' + destination.name + '. The download was '
                'corrupted or the file at that address has changed. Nothing was kept.')
    elif expected_size and part.stat().st_size != expected_size:
        raise DownloadError(
            destination.name + ' finished at ' + human(part.stat().st_size)
            + ' but the manifest expects ' + human(expected_size) + '.')

    # Rename last. Until this line the file is a .part and nothing will load it.
    os.replace(part, destination)
    return destination

CREATE TABLE IF NOT EXISTS studio_jobs (
    id TEXT PRIMARY KEY, owner TEXT NOT NULL, prompt TEXT NOT NULL, ratio TEXT NOT NULL,
    resolution TEXT DEFAULT '1mp', seed TEXT NOT NULL, model TEXT DEFAULT 'krea2_turbo',
    status TEXT NOT NULL DEFAULT 'queued', created INTEGER NOT NULL, updated INTEGER NOT NULL,
    lease TEXT, error TEXT, image_key TEXT, progress INTEGER, progress_total INTEGER,
    progress_stage TEXT, eta_seconds INTEGER, workflow TEXT DEFAULT 'standard',
    prompt_enhance INTEGER DEFAULT 1, enhancer_strength REAL DEFAULT 1.5,
    variance_strength REAL DEFAULT 1.0, variance_percent INTEGER DEFAULT 50,
    variance_mode TEXT DEFAULT 'values', upscale INTEGER DEFAULT 1,
    sampler TEXT DEFAULT 'clownshark', steps INTEGER, guidance REAL, loras TEXT, negative_prompt TEXT,
    thumbnail_key TEXT, queue_position INTEGER, mode TEXT DEFAULT 'txt2img',
    denoise REAL, input_image_key TEXT, mask_image_key TEXT, grow_mask INTEGER DEFAULT 6,
    app TEXT DEFAULT 'studio', priority INTEGER DEFAULT 10, chat_id TEXT,
    -- Chat turns. worker_payload is the sealed conversation the engine unseals to
    -- build the prompt; client_pubkey is only used by the second product variant,
    -- which does not exist here, and is carried so the engine's chat path runs
    -- unmodified.
    worker_payload TEXT, client_pubkey TEXT
);
CREATE INDEX IF NOT EXISTS studio_jobs_status ON studio_jobs(status, created);
CREATE INDEX IF NOT EXISTS studio_jobs_queue ON studio_jobs(status, queue_position, created);
CREATE INDEX IF NOT EXISTS studio_jobs_priority ON studio_jobs(status, priority DESC, queue_position, created);
CREATE INDEX IF NOT EXISTS studio_jobs_app_owner ON studio_jobs(app, owner, status, created);
CREATE INDEX IF NOT EXISTS studio_jobs_chat ON studio_jobs(chat_id);
CREATE TABLE IF NOT EXISTS studio_worker (id INTEGER PRIMARY KEY CHECK(id=1), seen INTEGER NOT NULL, host_state TEXT DEFAULT 'ready', current_app TEXT, lite_disabled INTEGER DEFAULT 0, lite_disabled_until INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS studio_user_presets (owner TEXT PRIMARY KEY, payload TEXT NOT NULL, updated INTEGER NOT NULL);
-- One editor draft per (owner, app, mode): the unfinished image and mask a user
-- is still working on. Deliberately separate from studio_jobs, which holds
-- finished results and is pruned as new ones arrive. The composite primary key
-- is also the index the draft poll seeks on.
CREATE TABLE IF NOT EXISTS studio_drafts (
    owner TEXT NOT NULL, app TEXT NOT NULL, mode TEXT NOT NULL,
    revision INTEGER NOT NULL, state TEXT NOT NULL,
    image_key TEXT, mask_key TEXT, meta TEXT, client TEXT,
    updated INTEGER NOT NULL,
    PRIMARY KEY(owner, app, mode)
);

-- ---------------------------------------------------------------------------
-- Chat. These four tables never existed as SQL: the original created them
-- inline from the cloud function, so this is a reconstruction from what the
-- interface actually reads and writes. Field names follow the wire contract in
-- web/js/studio-chat.js exactly - the client reads `sealed_content` and friends
-- straight off the row, so renaming a column here silently empties a message.
--
-- Everything the user wrote is sealed client-side before it arrives. The server
-- stores ciphertext and never holds the key; `title`, `sealed_*` and the chunk
-- payloads are all opaque blobs to it.

CREATE TABLE IF NOT EXISTS studio_chats (
    id TEXT PRIMARY KEY, owner TEXT NOT NULL, app TEXT NOT NULL DEFAULT 'studio',
    title TEXT, model TEXT,
    created INTEGER NOT NULL, updated INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS studio_chats_owner ON studio_chats(owner, app, updated DESC);

-- seq orders a conversation; the client pages by it and prunes with message_ids.
CREATE TABLE IF NOT EXISTS studio_messages (
    id TEXT PRIMARY KEY, chat_id TEXT NOT NULL, owner TEXT NOT NULL,
    role TEXT NOT NULL, seq INTEGER NOT NULL,
    sealed_content TEXT, sealed_reasoning TEXT, sealed_usage TEXT,
    job_id TEXT, created INTEGER NOT NULL,
    FOREIGN KEY(chat_id) REFERENCES studio_chats(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS studio_messages_chat ON studio_messages(chat_id, seq);
CREATE INDEX IF NOT EXISTS studio_messages_job ON studio_messages(job_id);

-- One row per streamed fragment. The client reconnects with from_seq and expects
-- to resume exactly where it left off, so chunks are kept until the job is
-- reaped rather than discarded as they are sent.
CREATE TABLE IF NOT EXISTS studio_chat_chunks (
    job_id TEXT NOT NULL, seq INTEGER NOT NULL,
    kind TEXT NOT NULL DEFAULT 'content', payload TEXT,
    created INTEGER NOT NULL,
    PRIMARY KEY(job_id, seq)
);

CREATE TABLE IF NOT EXISTS studio_memories (
    id TEXT PRIMARY KEY, owner TEXT NOT NULL, sealed_content TEXT NOT NULL,
    created INTEGER NOT NULL, updated INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS studio_memories_owner ON studio_memories(owner, created);

-- Server-local settings: the unlock verifier, the first-run marker. Not user
-- content and never sealed - this is the one table the server owns outright.
CREATE TABLE IF NOT EXISTS studio_settings (
    key TEXT PRIMARY KEY, value TEXT, updated INTEGER NOT NULL
);

-- LoRA metadata the user supplies, keyed by the file's stem.
--
-- A filename cannot tell you which architecture a LoRA was trained for, what its
-- trigger words are, or how strongly it wants to be applied, and guessing any of
-- those produces a layer that silently does nothing or wrecks an image. The
-- Models panel is where they are set; this is where they are kept.
--
-- Deliberately separate from the file scan: files come and go as the user moves
-- them about, and losing the trigger words they typed because a drive was
-- unplugged would be worse than showing a layer whose file is missing.
CREATE TABLE IF NOT EXISTS studio_loras (
    id TEXT PRIMARY KEY,
    label TEXT,
    architecture TEXT,
    triggers TEXT,
    implied TEXT,
    default_strength REAL DEFAULT 0.8,
    enabled INTEGER DEFAULT 1,
    updated INTEGER NOT NULL
);

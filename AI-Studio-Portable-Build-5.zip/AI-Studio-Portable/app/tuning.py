"""Work out what this machine can actually run.

Every VRAM-dependent number in the orchestrator was measured on one card - 12,282
MiB, about 1,372 MiB of it already spent on the desktop - and then written down
as a constant. `SAFE_VRAM_MB = 9500` is not a principle, it is that card. On an
8 GB machine the studio currently offers four chat tiers of which one fits, tries
to load one that does not, and fails somewhere the user never sees.

This module turns those constants back into a calculation. It is deliberately
separate from orchestrator.py: the setup wizard has to be able to ask "what will
this PC do?" before any engine is installed, and nothing here imports anything
that would prevent that.

**On the arithmetic.** Each tier in CHAT_MODELS carries `vram_mib`, the measured
peak with its window full. That is weights plus the KV cache for its default
context, so the two can be separated given a cost per token, and the file that
records those measurements states it: "16 KiB/token, a 64K window is 1 GiB of
cache". Gemma's 65,536-token window is therefore 1,024 MiB of cache and about
9,576 MiB of weights, which is what makes it possible to say whether a smaller
window would fit a smaller card rather than only ever answering yes or no.

That 16 KiB/token is one number applied to four models of different shapes, so
treat a reduced window as an estimate. Full-window fits are measured; reduced
ones are arithmetic, and the profile says which is which so the distinction
survives into the interface rather than being quietly averaged away.
"""
import json
import subprocess

# From the measurement note in orchestrator.py's CHAT_MODELS block. MiB of KV
# cache per 1,024 tokens of context.
KV_MIB_PER_1K = 16

# What the desktop, the compositor and everything else already holds before the
# studio asks for anything. Measured rather than assumed when the card can be
# queried; this is the fallback when free VRAM cannot be read.
ASSUMED_DESKTOP_MIB = 1400

# Never plan to fill the card exactly: allocators fragment and drivers round up.
#
# Small on purpose. Each tier's `vram_mib` is already the measured peak rounded
# up - Gemma measured 10,504 and is recorded as 10,600 - so a large margin here
# double-counts the same caution twice. At 512 this reported Gemma as needing a
# shortened window on the very card its measurement was taken on, where it
# demonstrably runs at full length.
HEADROOM_MIB = 256

NO_WINDOW = getattr(subprocess, 'CREATE_NO_WINDOW', 0x08000000)


def _nvidia_smi(query):
    try:
        result = subprocess.run(
            ['nvidia-smi', '--query-gpu=' + query, '--format=csv,noheader,nounits'],
            capture_output=True, text=True, timeout=4, creationflags=NO_WINDOW)
        if result.returncode == 0 and result.stdout.strip():
            # First GPU only. Multi-GPU scheduling is a different product.
            return [part.strip() for part in result.stdout.strip().splitlines()[0].split(',')]
    except Exception:                                      # noqa: BLE001 - absence is an answer
        pass
    return None


def _windows_adapter():
    """The real display adapter's name and memory, from Windows itself.

    Asked only when nvidia-smi has said nothing, so an NVIDIA machine never
    reaches this and behaves exactly as it always did.

    It exists because there was no answer here for anybody else. gpu_vendor()
    reads the name this returns; with no name it fell through to its 'nvidia'
    default, so an AMD or Intel machine downloaded the CUDA builds of both
    ComfyUI and llama.cpp - about 22 GB ending in a studio that cannot start.
    The manifest has had correct amd and intel entries all along; nothing could
    ever select them.

    Every adapter is listed and the choice is made here rather than in the
    query, because "the first one Windows returns" is not the GPU. The machine
    this was written on returned "Meta Virtual Monitor" first; streaming tools,
    headsets and virtual-display drivers all install adapters that look real to
    WMI. A name matching a known vendor wins; failing that, the one with the
    most memory, which is the discrete card on any machine that has one.

    Memory comes from the registry, not Win32_VideoController.AdapterRAM, which
    is a signed 32-bit field reporting 4095 MiB for every card above 4 GB.
    qwMemorySize is the 64-bit value the driver writes.
    """
    script = (
        "$ErrorActionPreference='SilentlyContinue';"
        + r"$key = 'HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}';"
        "$sizes = @{};"
        "Get-ChildItem $key | ForEach-Object {"
        " $p = Get-ItemProperty $_.PSPath;"
        " if ($p.DriverDesc -and $p.'HardwareInformation.qwMemorySize')"
        " { $sizes[$p.DriverDesc] = [int64]$p.'HardwareInformation.qwMemorySize' } };"
        "Get-CimInstance Win32_VideoController | ForEach-Object {"
        " $m = 0; if ($sizes.ContainsKey($_.Name)) { $m = $sizes[$_.Name] };"
        " Write-Output ($_.Name + '|' + $m) }"
    )
    try:
        result = subprocess.run(
            ['powershell', '-NoProfile', '-NonInteractive', '-Command', script],
            capture_output=True, text=True, timeout=20, creationflags=NO_WINDOW)
    except Exception:                                      # noqa: BLE001 - absence is an answer
        return None, None
    if result.returncode != 0 or not result.stdout.strip():
        return None, None

    adapters = []
    for line in result.stdout.strip().splitlines():
        name, _, raw = line.strip().partition('|')
        name = name.strip()
        if not name:
            continue
        try:
            mib = int(raw.strip()) // (1024 * 1024)
        except ValueError:
            mib = 0
        adapters.append((name, mib))
    return pick_adapter(adapters)


# Kept separate from the query so it can be tested without a machine that has
# the hardware in question.
_REAL_GPU = ('nvidia', 'geforce', 'rtx', 'gtx', 'quadro', 'tesla',
             'amd', 'radeon', 'rx ', 'vega', 'firepro',
             'intel', 'arc ', 'iris', 'uhd graphics', 'hd graphics')
_NOT_GPU = ('basic render', 'basic display', 'remote', 'mirror', 'virtual',
            'meta ', 'parsec', 'citrix', 'vmware', 'virtualbox', 'idd',
            'spacedesk', 'duet', 'sunshine')


def pick_adapter(adapters):
    """Choose the actual GPU from everything Windows calls a display adapter."""
    real = [(name, mib) for name, mib in adapters
            if not any(bad in name.lower() for bad in _NOT_GPU)]
    named = [(name, mib) for name, mib in real
             if any(good in name.lower() for good in _REAL_GPU)]
    pool = named or real or adapters
    if not pool:
        return None, None
    # Most memory wins within the pool: a discrete card outranks the integrated
    # one on a laptop, which is the card the studio should be sized against.
    name, mib = max(pool, key=lambda item: item[1])
    return name, (mib or None)


def probe_hardware():
    """What the machine has. Every field may be None when it cannot be read."""
    hardware = {'gpu': None, 'vramTotalMib': None, 'vramFreeMib': None,
                'ramFreeMib': None, 'source': 'unknown'}
    fields = _nvidia_smi('name,memory.total,memory.free')
    if fields and len(fields) >= 3:
        try:
            hardware.update({
                'gpu': fields[0],
                'vramTotalMib': int(fields[1]),
                'vramFreeMib': int(fields[2]),
                'source': 'nvidia-smi',
            })
        except ValueError:
            pass
    if not hardware['gpu']:
        # No NVIDIA card, or no driver tools. Ask Windows who is here.
        name, vram = _windows_adapter()
        if name:
            hardware['gpu'] = name
            hardware['source'] = 'windows'
            # Free VRAM is not available this way. Callers treat a missing
            # figure as "assume the card is otherwise idle", which is the
            # right assumption at install time.
            if vram:
                hardware['vramTotalMib'] = vram
    try:
        import psutil
        hardware['ramFreeMib'] = int(psutil.virtual_memory().available // (1024 * 1024))
        hardware['ramTotalMib'] = int(psutil.virtual_memory().total // (1024 * 1024))
    except Exception:                                      # noqa: BLE001 - optional dependency
        pass
    return hardware


def usable_vram_mib(hardware):
    """VRAM the studio can plan on having, after the desktop and a safety margin."""
    total = hardware.get('vramTotalMib')
    if not total:
        return None
    free = hardware.get('vramFreeMib')
    in_use = (total - free) if free is not None else None

    # Plan against the whole card minus what the desktop permanently costs, not
    # minus whatever happens to be resident at this instant.
    #
    # The first version of this took the larger of the two and produced "0 of 4
    # models fit" on a 12 GB card that runs all four - because it was probed while
    # the studio's own ComfyUI held 10.8 GB. Anything the studio loaded it can
    # also evict, so counting it as unavailable is backwards, and it would have
    # got worse the busier the machine was.
    #
    # Measured usage is therefore only allowed to *lower* the reserve, for a
    # leaner desktop than assumed, never to raise it.
    reserve = ASSUMED_DESKTOP_MIB
    if in_use is not None and in_use < ASSUMED_DESKTOP_MIB:
        reserve = in_use
    return max(0, total - reserve - HEADROOM_MIB)


def split_tier(spec):
    """(weights_mib, kv_mib) for a tier at its default window."""
    peak = spec.get('vram_mib') or spec.get('vram_mib_estimate')
    ctx = spec.get('ctx') or 0
    if not peak:
        return None, None
    kv = (ctx / 1024.0) * KV_MIB_PER_1K
    return max(0.0, peak - kv), kv


def fit_tier(spec, budget_mib):
    """How this tier fits in `budget_mib`, if at all.

    Returns the context it can be given and whether that is its full window, so
    the caller can tell a measured fit from a calculated one.
    """
    weights, _ = split_tier(spec)
    ctx = spec.get('ctx') or 0
    if weights is None:
        # No measurement to reason from. Offer it and let the engine find out
        # rather than hiding a tier on the strength of a missing field.
        return {'fits': True, 'ctx': ctx, 'reduced': False, 'basis': 'unmeasured'}
    peak = weights + (ctx / 1024.0) * KV_MIB_PER_1K
    if peak <= budget_mib:
        return {'fits': True, 'ctx': ctx, 'reduced': False, 'basis': 'measured'}
    spare = budget_mib - weights
    if spare <= 0:
        return {'fits': False, 'ctx': 0, 'reduced': False, 'basis': 'weights-too-large',
                'needsMib': int(weights)}
    # Round down to a whole 1K of context, and refuse to offer a window so small
    # the conversation is useless - below 8K a single long message plus a reply
    # can overflow, and llama.cpp treats overflow as a hard error rather than
    # trimming.
    possible = int(spare / KV_MIB_PER_1K) * 1024
    if possible < 8192:
        return {'fits': False, 'ctx': 0, 'reduced': False, 'basis': 'window-too-small',
                'needsMib': int(weights + 8 * KV_MIB_PER_1K)}
    return {'fits': True, 'ctx': min(possible, ctx), 'reduced': True, 'basis': 'estimated'}


def build_profile(chat_models, hardware=None, default_model=None):
    """What to offer, and what to leave alone, on this machine."""
    hardware = hardware or probe_hardware()
    budget = usable_vram_mib(hardware)
    profile = {
        'hardware': hardware,
        'usableVramMib': budget,
        'tiers': {},
        'notes': [],
    }

    if budget is None:
        # No card readable: keep every default. Guessing low here would hide
        # models from someone whose GPU simply is not an NVIDIA one, and the
        # engine's own failure message is better than a silent omission.
        profile['notes'].append(
            'No NVIDIA GPU detected, so nothing was tuned and every model is offered. '
            'If generation fails for lack of memory, set a smaller default by hand.')
        for key, spec in chat_models.items():
            profile['tiers'][key] = {'fits': True, 'ctx': spec.get('ctx'),
                                     'reduced': False, 'basis': 'untuned'}
        return profile

    for key, spec in chat_models.items():
        profile['tiers'][key] = fit_tier(spec, budget)

    free = hardware.get('vramFreeMib')
    total = hardware.get('vramTotalMib')
    if free is not None and total and (total - free) > ASSUMED_DESKTOP_MIB * 2:
        profile['notes'].append(
            'Something was using the GPU when this was measured, so the free-memory '
            'figure here is low. The profile is based on the card total and is not '
            'affected.')

    fitting = [k for k, v in profile['tiers'].items() if v['fits']]
    profile['defaultChatModel'] = pick_default(
        chat_models, profile['tiers'], preferred=default_model)

    # The threshold that decides whether ComfyUI is evicted before a model loads.
    # Was a constant chosen for one card; it is the largest tier that actually
    # fits here, which is the number it was always standing in for.
    largest = 0
    for key in fitting:
        weights, _ = split_tier(chat_models[key])
        entry = profile['tiers'][key]
        if weights is not None:
            largest = max(largest, weights + (entry['ctx'] / 1024.0) * KV_MIB_PER_1K)
    profile['safeVramMib'] = int(largest) if largest else None

    # Image work and a language model cannot both hold the card on a small one.
    # Above roughly 16 GB they can, and evicting ComfyUI for every chat message
    # costs seconds each time for nothing.
    profile['evictComfyForChat'] = bool(
        budget and largest and (budget - largest) < 6000)

    if not fitting:
        profile['notes'].append(
            'No chat model fits in this card. Chat will not work until a smaller '
            'model is installed.')
    else:
        reduced = [k for k in fitting if profile['tiers'][k]['reduced']]
        missing = [k for k, v in profile['tiers'].items() if not v['fits']]
        if missing:
            profile['notes'].append(
                str(len(missing)) + ' of ' + str(len(chat_models)) + ' chat models need '
                'more video memory than this card has, and are not offered.')
        if reduced:
            profile['notes'].append(
                'Shorter conversation memory on ' + str(len(reduced)) + ' model(s) so they '
                'fit. This is calculated rather than measured, so it is a starting point.')
        if not profile['evictComfyForChat']:
            profile['notes'].append(
                'Enough memory to keep image generation loaded while chatting, so replies '
                'start faster.')
    return profile


def pick_default(chat_models, tiers, preferred=None):
    """The best tier that fits: the most capable one, not merely the largest.

    The engine's own default wins whenever it fits - it was chosen deliberately,
    and a tuner that silently swaps it on hardware where it runs perfectly well is
    second-guessing the wrong decision. Only when it does not fit does this rank.

    Tool use is what makes the assistant able to generate images and keep
    memories, so a tier that has it beats a bigger one that does not.
    """
    if preferred and (tiers.get(preferred) or {}).get('fits'):
        return preferred
    best, best_rank = None, None
    for key, spec in chat_models.items():
        entry = tiers.get(key) or {}
        if not entry.get('fits'):
            continue
        rank = (1 if spec.get('tools') else 0,
                1 if spec.get('mmproj') else 0,
                entry.get('ctx') or 0)
        if best_rank is None or rank > best_rank:
            best, best_rank = key, rank
    return best


def describe(profile):
    """One human sentence about the machine, for the setup wizard and the log."""
    hardware = profile.get('hardware') or {}
    if not hardware.get('gpu'):
        return 'No NVIDIA GPU detected; nothing was tuned.'
    gb = round((hardware.get('vramTotalMib') or 0) / 1024.0, 1)
    fits = sum(1 for entry in profile.get('tiers', {}).values() if entry.get('fits'))
    total = len(profile.get('tiers') or {})
    return (hardware['gpu'] + ' with ' + str(gb) + ' GB: '
            + str(fits) + ' of ' + str(total) + ' chat models fit.')


if __name__ == '__main__':
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import orchestrator
    result = build_profile(orchestrator.CHAT_MODELS,
                           default_model=orchestrator.DEFAULT_CHAT_MODEL)
    print(describe(result))
    print(json.dumps(result, indent=2))

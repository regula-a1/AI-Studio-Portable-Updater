"""Which build this is, and the version log that goes with it.

Builds are numbered from 1 and count up by one, forever. No decimals, no major
and minor, nothing to decide at release time beyond adding the next number. A
friend saying "I'm on Build 7" is then unambiguous, which a short commit hash
never was.

The number is not kept in a file of its own. It is the newest `## Build N`
heading in CHANGELOG.md, which means:

  - a build cannot be numbered differently from its own version log, because
    there is only one place the number exists;
  - numbering a build and writing down what changed are the same action, so a
    build that tells the user nothing cannot be published by accident;
  - nothing has to be kept in step with anything.

VERSION is still the record of which commit a build came from. That is what the
updater compares, because a commit cannot be forgotten and a number can.
"""

import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
STUDIO = HERE.parent

CHANGELOG = STUDIO / 'CHANGELOG.md'
VERSION_FILE = STUDIO / 'VERSION'

# "## Build 7 - 2026-09-17", with the date optional and any kind of dash. Being
# lenient here costs nothing; being strict would mean a release silently losing
# its notes because somebody typed an en dash.
HEADING = re.compile(r'^##\s+Build\s+(\d+)\s*(?:[-\u2012-\u2015]\s*(.*))?$',
                     re.IGNORECASE)

# A version log is read by a person in a dialog box, so it is bounded: enough
# history to be useful, not so much that the response carries the whole file.
MAX_ENTRIES = 40
MAX_BODY = 6000


def entries(path=None):
    """Every build in the version log, newest first.

    Returns dicts of {build, date, body}. An unreadable or missing file gives an
    empty list rather than raising - a studio with no changelog should still
    start.
    """
    try:
        text = (path or CHANGELOG).read_text(encoding='utf-8')
    except OSError:
        return []

    found = []
    current = None
    for line in text.splitlines():
        match = HEADING.match(line.strip())
        if match:
            current = {'build': int(match.group(1)),
                       'date': (match.group(2) or '').strip(),
                       'lines': []}
            found.append(current)
        elif current is not None:
            # Any other heading ends the entry. Without this a trailing section
            # of the file - a licence note, an appendix - would be read as part
            # of the oldest build's notes.
            if line.startswith('# ') or line.startswith('## '):
                current = None
            else:
                current['lines'].append(line)

    result = []
    for item in found:
        body = '\n'.join(item.pop('lines')).strip()
        item['body'] = body[:MAX_BODY]
        result.append(item)
    result.sort(key=lambda item: item['build'], reverse=True)
    return result[:MAX_ENTRIES]


def build_number(path=None):
    """The build this copy is, or None if the version log says nothing."""
    log = entries(path)
    return log[0]['build'] if log else None


def label(number=None):
    """How a build is named everywhere a person sees it."""
    number = build_number() if number is None else number
    return ('Build %d' % number) if number else 'unreleased build'


def version_file():
    """The commit and build date stamped in by `git archive`.

    A source checkout still holds the literal $Format placeholders, so both
    values come back None and callers can tell a working copy from a release.
    """
    commit = built = None
    try:
        text = VERSION_FILE.read_text(encoding='utf-8')
    except OSError:
        return {'commit': None, 'built': None}
    for line in text.splitlines():
        parts = line.split(None, 1)
        if len(parts) != 2:
            continue
        key, value = parts[0].lower(), parts[1].strip()
        if value.startswith('$Format'):
            continue
        if key == 'commit':
            commit = value
        elif key == 'built':
            built = value
    return {'commit': commit, 'built': built}


def describe():
    """Everything the interface needs to show a version and a version log."""
    stamped = version_file()
    number = build_number()
    return {
        'build': number,
        'label': label(number),
        'commit': stamped['commit'],
        'built': stamped['built'],
        # False for a working copy, which is also the one case where the build
        # number in the log is ahead of what is actually installed.
        'released': bool(stamped['commit']),
        'entries': entries(),
    }

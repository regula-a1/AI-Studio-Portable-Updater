"""Checking for, downloading and applying an update.

The shape of this is decided by one fact: a release is a `git archive` of the
tracked files and nothing else. No `data/`, no `models/` contents, no `comfy/`,
no `runtime/`, no `config.json` - those are all either gitignored or generated.
So applying an update is unpacking the archive over the top, and the things that
belong to the user cannot be caught in it, by construction rather than by an
exclusion list somebody has to keep correct.

Three rules:

1. Verify before touching anything. The zip is downloaded in full and checked
   against the sha256 in the manifest, then unpacked to a staging folder and
   inspected, and only then copied over the install. A half-applied update is
   the one failure that leaves somebody worse off than not updating.

2. The address is configuration, not a constant. `update_url` in config.json
   points at a latest.json in the update repo; the zip is fetched from beside
   it. Set it to '' and updating is off.

3. Never restart itself. The files are replaced and the user is told to restart.
   A server that replaces its own code and then tries to relaunch has to get
   process handling exactly right on a machine nobody can see.
"""

import io
import json
import shutil
import zipfile
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

HERE = Path(__file__).resolve().parent
STUDIO = HERE.parent

import fetch                                              # noqa: E402
import version as build_version                           # noqa: E402

DOWNLOADS = STUDIO / 'data' / 'downloads'
STAGING = STUDIO / 'data' / 'update-staging'
MANIFEST_NAME = 'latest.json'
USER_AGENT = 'AI-Studio-Portable-Updater'

# Files that must exist in a staged archive before it is allowed anywhere near
# the install. Not a checksum - that has already passed - but a shape check, so
# a release built from the wrong thing is refused rather than unpacked.
REQUIRED = ('app/server.py', 'app/orchestrator.py', 'web/index.html', 'Start.bat',
            # The version log is where the build number comes from, so an
            # archive without one would install and then report no version at
            # all. The build refuses to produce an archive without one;
            # this is the same rule checked again at the other end.
            'CHANGELOG.md')


class UpdateError(Exception):
    pass


def installed_commit():
    """The commit this build came from, or None for a source checkout.

    The commit, not the build number, is what decides whether an update exists.
    A number is written by hand and can be forgotten; a commit is stamped in by
    `git archive` and cannot be. The number is carried alongside it for display,
    because that is what a person recognises.
    """
    return build_version.version_file()['commit']


def _api_url(url):
    """The GitHub API address for a raw.githubusercontent.com file, or None.

    https://raw.githubusercontent.com/ACCOUNT/REPO/REF/PATH
      -> https://api.github.com/repos/ACCOUNT/REPO/contents/PATH?ref=REF

    Returns None for anything else, including a self-hosted manifest, so a
    custom update_url is left exactly as the user wrote it.
    """
    prefix = 'https://raw.githubusercontent.com/'
    if not url.startswith(prefix):
        return None
    parts = url[len(prefix):].split('/')
    if len(parts) < 4:
        return None
    account, repo, ref = parts[0], parts[1], parts[2]
    path = '/'.join(parts[3:]).split('?', 1)[0]
    if not (account and repo and ref and path):
        return None
    return ('https://api.github.com/repos/' + account + '/' + repo
            + '/contents/' + path + '?ref=' + ref)


def _fetch(url, accept, timeout):
    request = Request(url, headers={'User-Agent': USER_AGENT,
                                    'Accept': accept,
                                    'Cache-Control': 'no-cache, no-store',
                                    'Pragma': 'no-cache'})
    with urlopen(request, timeout=timeout) as response:
        return json.loads(response.read(4 * 1024 * 1024))


def _get_json(url, timeout=30):
    """Fetch the manifest, preferring the route that is not behind a cache.

    raw.githubusercontent.com serves through a CDN that holds a file for about
    five minutes, and it keys that cache on the path alone. An earlier version
    of this added a unique query string to get a fresh copy; measured, that
    does nothing at all - the CDN answered x-cache: HIT with and without it,
    and a build confirmed present in the repo was served as the previous one
    for seven minutes. On top of a five minute checking interval that is ten
    minutes before somebody is told about a release.

    The API route for the same file is not cached that way: measured, it
    returned the new build while raw was still serving the old one. So it is
    tried first and raw is the fallback - for a manifest that is not on GitHub
    at all, for a network that blocks api.github.com, and for the 60 requests
    an hour that route allows unauthenticated. That limit is per IP and shared
    with anything else on it; at one check every five minutes a studio uses 12
    of them, so the fallback is for the machine that is already near the line
    rather than for us.

    Only the manifest is fetched this way, and it is the only file that needs
    it: every build's zip has a name of its own, so there is never a stale copy
    of one to serve. A zip is also checked against the sha256 in the manifest,
    which would catch it anyway.
    """
    api = _api_url(url)
    if api:
        try:
            return _fetch(api, 'application/vnd.github.raw', timeout)
        except Exception:                                  # noqa: BLE001 - fall back
            pass
    return _fetch(url, 'application/vnd.github+json', timeout)


def check(update_url):
    """Read latest.json from the update repo and compare it with this build.

    Deliberately a plain file, not the releases API. Publishing was a GitHub
    release with two files attached by hand, and that is too much ceremony for
    "I pushed a new build". Now the manifest and the zip are just files in the
    repo, so publishing is a commit and a push.

    The zip is fetched from beside the manifest, so the two cannot drift to
    different addresses.
    """
    if not update_url:
        return {'configured': False, 'available': False,
                'reason': 'No update address is set in config.json.'}
    try:
        manifest = _get_json(update_url)
    except HTTPError as error:
        # Nothing published yet. The ordinary state of a project before its
        # first build, and not a failure worth alarming anybody about.
        if error.code == 404:
            return {'configured': True, 'available': False,
                    'installed': installed_commit() or 'source checkout',
                    'reason': 'No build has been published yet.'}
        raise

    zip_name = manifest.get('zip')
    if not zip_name:
        raise UpdateError('The published manifest does not name a zip.')
    if '/' in zip_name or '\\' in zip_name:
        raise UpdateError('The manifest names a path rather than a file.')
    base = update_url.rsplit('/', 1)[0]

    here = installed_commit()
    latest = manifest.get('commit')
    return {
        'configured': True,
        # A source checkout records no commit, so nothing is offered: that would
        # be updating a working copy out from under whoever is editing it.
        'available': bool(here and latest and here != latest),
        'installed': here or 'source checkout',
        'latest': latest,
        'version': manifest.get('version'),
        # The build numbers on either side, so the dialog can say "Build 8, you
        # have Build 7" rather than showing two hashes nobody can compare.
        'build': manifest.get('build'),
        'installedBuild': build_version.build_number(),
        # What changed, taken from the newest entry in the published version
        # log rather than from a commit subject written for other developers.
        'notes': (manifest.get('notes') or '').strip()[:4000],
        'published': manifest.get('built'),
        'zip': zip_name,
        'url': base + '/' + zip_name,
        'sha256': manifest.get('sha256'),
        'bytes': manifest.get('bytes'),
    }


def download(info, on_progress=None):
    """Fetch the release zip and verify it against the manifest hash."""
    if not info.get('url'):
        raise UpdateError('Nothing to download.')
    if not info.get('sha256'):
        # Refused rather than fetched unverified. An update is code that will
        # run on someone else's machine.
        raise UpdateError('The release manifest has no sha256, so the download '
                          'cannot be verified. Refusing it.')
    target = DOWNLOADS / (info.get('zip') or 'update.zip')
    fetch.download(info['url'], target, sha256=info['sha256'],
                   expected_size=info.get('bytes'), on_progress=on_progress)
    return target


def _members(archive):
    """Entries with the archive's single top folder stripped, skipping nothing else."""
    names = archive.namelist()
    roots = {name.split('/', 1)[0] for name in names if '/' in name}
    prefix = (roots.pop() + '/') if len(roots) == 1 else ''
    for name in names:
        if name.endswith('/'):
            continue
        relative = name[len(prefix):] if prefix and name.startswith(prefix) else name
        if not relative:
            continue
        # A zip entry can name a path outside the folder it is unpacked into.
        # This one is ours and hash-checked, but an extractor that trusts its
        # input is a habit, not a property of one file.
        if relative.startswith(('/', '\\')) or '..' in Path(relative).parts:
            raise UpdateError('The archive contains an unsafe path: ' + relative)
        yield name, relative


def stage(zip_path):
    """Unpack to a staging folder and check it looks like the studio."""
    shutil.rmtree(STAGING, ignore_errors=True)
    STAGING.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path) as archive:
        pairs = list(_members(archive))
        for name, relative in pairs:
            destination = STAGING / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(name) as source, io.open(destination, 'wb') as handle:
                shutil.copyfileobj(source, handle)
    missing = [required for required in REQUIRED if not (STAGING / required).exists()]
    if missing:
        shutil.rmtree(STAGING, ignore_errors=True)
        raise UpdateError('That archive is missing ' + ', '.join(missing)
                          + ' - it does not look like a studio release.')
    return STAGING, len(pairs)


def apply(staged):
    """Copy the staged files over the install. Returns how many were written.

    Copy rather than move, so a failure part-way leaves the staging folder intact
    to retry from. Nothing is deleted: a file dropped from the project stays
    behind until someone reinstalls, which is untidy and harmless, where deleting
    by difference risks removing something the user put there.
    """
    written = 0
    for source in sorted(staged.rglob('*')):
        if source.is_dir():
            continue
        destination = STUDIO / source.relative_to(staged)
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        written += 1
    return written


def cleanup():
    shutil.rmtree(STAGING, ignore_errors=True)

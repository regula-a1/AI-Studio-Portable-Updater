"""Golden-file tests for build_workflow.

build_workflow is the least-tested and most intricate function in the repo: it
constructs the whole ComfyUI graph for every checkpoint, mode and resolution, and
nothing else asserts what it emits. These snapshots exist so that a change to a
workflow template or a builder branch shows up as a reviewable diff instead of a
silently different image.

Run:
    python tests/test_build_workflow.py            # compare against goldens
    python tests/test_build_workflow.py --update   # rewrite goldens

Two notes on what these snapshots are worth:

- The orchestrator imports `cryptography` and `websocket` at module scope but uses
  them only inside functions the builder never calls, so they are stubbed here.
  That keeps the suite runnable on a bare Python, which matters because a
  contributor may not have the runtime environment installed.
- ROOT is repointed at the repo, so `ComfyUI/models/...` does not exist during a
  run and the builder takes its no-upscale-model path. The upscale and
  pre-upscale branches are therefore NOT covered. Extend this file when those
  paths get config, rather than assuming green means safe.
"""
import json
import sys
import types
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
GOLDEN_DIR = Path(__file__).resolve().parent / 'golden'


def _stub_missing_modules():
    """Satisfy module-scope imports the graph builders do not exercise."""
    if 'cryptography' not in sys.modules:
        for name in ('cryptography',
                     'cryptography.hazmat',
                     'cryptography.hazmat.primitives',
                     'cryptography.hazmat.primitives.ciphers',
                     'cryptography.hazmat.primitives.ciphers.aead',
                     'cryptography.hazmat.primitives.asymmetric'):
            sys.modules.setdefault(name, types.ModuleType(name))
        sys.modules['cryptography.hazmat.primitives.ciphers.aead'].AESGCM = object
        primitives = sys.modules['cryptography.hazmat.primitives']
        primitives.hashes = types.SimpleNamespace(SHA256=object)
        primitives.serialization = types.SimpleNamespace(load_der_public_key=None)
        sys.modules['cryptography.hazmat.primitives.asymmetric'].padding = types.SimpleNamespace(
            OAEP=None, MGF1=None)
    sys.modules.setdefault('websocket', types.ModuleType('websocket'))


def load_orchestrator():
    _stub_missing_modules()
    sys.path.insert(0, str(REPO / 'app'))
    import orchestrator
    # Since phase 3 the paths come from config and default to the portable
    # layout, so WORKFLOWS_DIR already resolves to this repo. Set explicitly
    # anyway: a config.json on the machine running the tests must not change
    # what the snapshots compare against.
    orchestrator.WORKFLOWS_DIR = REPO / 'workflows'
    orchestrator.COMFY_DIR = REPO / 'comfy'
    orchestrator.ROOT = REPO
    return orchestrator


# Fixed seed and prompt everywhere: the point is to diff structure, not content.
BASE = {'prompt': 'a lighthouse on a cliff at dusk', 'seed': '12345', 'ratio': 'landscape'}
CHECKPOINTS = ('krea2_turbo', 'sdxl_cyberrealistic', 'anima_base', 'illustrious_base')
MODES = ('txt2img', 'img2img', 'inpaint')


def cases():
    """Every (name, job) pair the suite snapshots."""
    for model in CHECKPOINTS:
        for mode in MODES:
            job = dict(BASE, id='test-job', model=model, mode=mode)
            if mode in ('img2img', 'inpaint'):
                job['denoise'] = 0.6
            if mode == 'inpaint':
                job['grow_mask'] = 6
            yield f'{model}__{mode}', job
    # Resolution ladder on one checkpoint: catches dimension and upscale-branch drift.
    for resolution in ('draft', '1mp', '2mp', '4mp', '8mp_ultra'):
        yield (f'krea2_turbo__res_{resolution}',
               dict(BASE, id='test-job', model='krea2_turbo', mode='txt2img', resolution=resolution))
    # Ratios, which feed dimensions_for_job.
    for ratio in ('square', 'portrait', 'wide'):
        yield (f'krea2_turbo__ratio_{ratio}',
               dict(BASE, id='test-job', model='krea2_turbo', mode='txt2img', ratio=ratio))
    # Toggles that rewire the graph rather than just changing numbers.
    yield ('krea2_turbo__enhancer_on',
           dict(BASE, id='test-job', model='krea2_turbo', mode='txt2img', prompt_enhance=True))
    yield ('krea2_turbo__upscale_off',
           dict(BASE, id='test-job', model='krea2_turbo', mode='txt2img', upscale=False))
    yield ('krea2_turbo__negative',
           dict(BASE, id='test-job', model='krea2_turbo', mode='txt2img',
                negative_prompt='blurry, low quality'))


def build(orchestrator, job):
    """Return the graph, or a marker recording that the builder rejected the job.

    A raising branch is behaviour worth snapshotting too: if a checkpoint stops
    refusing something, or starts, that should show up as a diff.
    """
    try:
        result = orchestrator.build_workflow(dict(job))
    except Exception as exc:                                  # noqa: BLE001 - snapshot it
        return {'__raised__': f'{type(exc).__name__}: {exc}'}
    if isinstance(result, tuple):
        return {'__workflow__': result[0], '__extra__': [repr(x) for x in result[1:]]}
    return result


def pin_environment(orchestrator):
    """Remove the machine from the comparison.

    The builder asks what is installed - an upscale pass is only added when
    4x-UltraSharp is actually present - so without this the goldens describe the
    developer's disk rather than the builder. It went unnoticed while that lookup
    checked one folder that never exists in a checkout; widening it to every
    folder ComfyUI reads made two cases start producing an upscale pass here and
    nowhere else.

    Pinned to absent, which is what the stored goldens describe. The upscale
    branch is therefore still uncovered - noted in the handoff.
    """
    orchestrator.find_comfy_model = lambda folder, name: None


def main():
    update = '--update' in sys.argv
    orchestrator = load_orchestrator()
    pin_environment(orchestrator)
    GOLDEN_DIR.mkdir(parents=True, exist_ok=True)

    failures, written, checked = [], 0, 0
    for name, job in cases():
        actual = build(orchestrator, job)
        path = GOLDEN_DIR / f'{name}.json'
        rendered = json.dumps(actual, indent=2, sort_keys=True, default=str)
        if update or not path.exists():
            path.write_text(rendered + '\n', encoding='utf-8', newline='\n')
            written += 1
            continue
        checked += 1
        expected = path.read_text(encoding='utf-8')
        if expected.strip() != rendered.strip():
            failures.append(name)

    if update or written:
        print(f'wrote {written} golden file(s) to {GOLDEN_DIR.relative_to(REPO)}')
    if checked:
        print(f'compared {checked} case(s)')
    for name in failures:
        print(f'  CHANGED: {name}')
    if failures:
        print(f'\n{len(failures)} case(s) differ. Review the diff, then rerun with '
              f'--update if the change is intended.')
        return 1
    if checked and not failures:
        print('all cases match')
    return 0


if __name__ == '__main__':
    sys.exit(main())

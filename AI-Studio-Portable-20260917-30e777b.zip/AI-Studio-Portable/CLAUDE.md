# AI Studio Portable — working notes

Read `docs/HANDOFF.md` before doing anything. It has the state of the build, the
phase plan and the landmines. This file is the short version plus the house rules.

## What it is

A single-folder local studio: a browser interface driving ComfyUI and llama.cpp
on the user's own machine. Four modes — text to image, image to image, inpaint,
chat. Repackaged from a web app whose cloud relay has been removed.

Pre-alpha. The interface and orchestrator exist; the local server that connects
them does not. Nothing runs end to end.

## Non-negotiables

**No trace of the author's website, ever.** This ships to people who must not
learn of it. Before any commit that touches shipped files:

```bash
powershell -ExecutionPolicy Bypass -File scripts/check-release.ps1
```

It exits non-zero on any forbidden string. Do not commit over it, and do not add
an exemption to make a failure go away without asking first.

**No NSFW-specific content in the repo.** Shipped checkpoints are general-purpose,
the LoRA registry ships empty and is filled from the user's own folder at runtime,
and no shipped preset or prompt is explicit. The assistant's posture stays
uncensored — no moralising, no refusals — but the product is not NSFW-branded.

**Never import ComfyUI, custom-node or llama.cpp Python into our code.** HTTP
only. That process boundary is what keeps this source out of GPL-3.0's reach, and
therefore monetizable later. See `NOTICE.md`.

**RES4LYF is optional and opt-in,** never bundled or required — its licence
forbids charging for a product that integrates it. Hide the Clownshark samplers
when its node is absent rather than offering and failing.

## Conventions

- **Line endings are LF**, locked by `.gitattributes`. Do not reintroduce CRLF.
- **Prefix is `studio-`** for files, CSS classes and storage keys; `studio_` for
  database tables; `/api/studio` for routes; `ASP1` for the crypto envelope.
- **`krea2` is a model architecture, not branding.** `krea2_turbo`,
  `krea2t_enhancer` and friends stay as they are. Anything with `krea-` or `krea_`
  was branding and is already renamed.
- `web/` has **no build step** — plain HTML, CSS and JS, edited directly. Vendored
  libraries live in `web/js/vendor/` and are not ours to edit.
- Nothing under `data/`, `models/`, `runtime/`, `comfy/` or `logs/` is committed.

## Before editing the orchestrator

`app/orchestrator.py` is one 3,342-line module carrying workflow construction,
inpaint geometry, sampler installation, LoRA chaining, context fitting, web
search, model swapping and the job loop. It has no tests around the graph
builders.

Write golden-file tests for `build_workflow` before changing it — phase 3 in the
handoff. It is the single most likely source of silent breakage in this repo.

## Verify

```bash
python -m py_compile app/orchestrator.py
powershell -ExecutionPolicy Bypass -File scripts/check-release.ps1
```

# Handoff — AI Studio Portable

Written 2026-09-15 at the end of the session that created this repo. If you are a
new session picking this up, read this file first, then `CLAUDE.md`.

---

## 1. What this is

A standalone repackaging of a working web application. The original ran as a page
on a website: the browser posted jobs to a Cloudflare Pages Function, the jobs
sat in a D1 database, and a Python worker on a home PC polled for them over
outbound HTTPS, drove ComfyUI and llama.cpp, and uploaded encrypted results back.

That whole relay existed for one reason — reaching a PC behind NAT. On one
machine it is dead weight. **This product deletes the middle and keeps the ends:**
the interface, and the orchestrator that drives the two engines.

```
  Before                             Now
  browser                            browser
    -> Pages Function  (gone)          -> local server        (to be written)
    -> D1 + R2         (gone)          -> SQLite + a folder   (to be written)
    -> chat relay      (gone)
    -> 5s claim poll   (gone)
    -> worker                          -> orchestrator, called in-process
    -> ComfyUI + llama-server          -> ComfyUI + llama-server
```

### Hard privacy requirement

This product must carry **no trace of the author's website**. It is distributed to
people who must not learn of it or reach it. `scripts/check-release.ps1` enforces
the list of forbidden strings; it exits non-zero if any appear.

**Run it before every release, and never commit anything it rejects.** It already
caught three real leaks during the initial scrub, including a checkpoint filename
buried in a shipped workflow JSON.

---

## 2. State today

*Updated 2026-09-16. The original version of this section described a repo where
nothing ran; phases 2 to 5 have happened since. Everything below has been run,
not just written.*

| Piece | State |
|---|---|
| Interface (`web/`) | **Working.** Served by the local server; all four modes reachable. |
| Local server (`app/server.py`) | **Working.** Serves `web/`, owns SQLite and the image folder, runs the orchestrator in a thread. |
| Orchestrator | **Working locally.** Its two cloud seams are replaced by `app/local_agent.py`; no path in it points at anyone's machine. |
| Image generation | **Working end to end.** Prompt in the browser to a PNG in `data/images`. |
| Chat | **Working end to end.** Replies stream and persist. |
| Editing (img2img, inpaint) | **Krea 2 only.** The other three build a text-to-image graph and ignore the input; the studio now refuses those jobs rather than silently producing the wrong thing. Pre-existing, also present upstream. |
| Model registry | **Working.** `action=registry` reports what is installed by building each model's graph and checking the files it loads. |
| Models panel | **Working.** LoRAs from two sources — the studio's own `models/loras`, and the user's own folders read-only. |
| Hardware tuning | **Working** (`app/tuning.py`). Offers only what the card can hold, and shortens windows where that helps. |
| Setup / launcher | **Working.** `Start.bat` on a clean Windows 10 PC with no Python fetched its own runtime, installed ComfyUI and the nodes, and opened the studio. Verified 2026-09-16. |
| Model downloads | **Not done.** Five addresses in `app/manifest.json` are `null`; `setup.py verify` lists them. Nothing is guessed. |
| Updater | **Not written.** Blocked on the releases-hosting decision in section 6. |
| Database schema | `app/schema.sql`, with a migration helper in `server.py` for columns added later. |
| Chat schema | **Written.** Reconstructed from what the client reads. |

The one thing a new session should not assume is that any of this is *finished*.
It runs; it has not been lived with.

---

## 3. What the initial session changed

So that nothing here looks like an unexplained edit.

**Renamed, throughout:** the old hyphenated file/class/storage prefix became
`studio-`; the old table prefix became `studio_`; the old API route became
`/api/studio`; the crypto envelope magic became `ASP1`; the two browser globals
became `StudioCrypto` and `StudioLocal`; the product name became AI Studio
Portable.

The old names are deliberately not written out here. They are in
`scripts/forbidden.local.txt`, which never ships.

**Note:** `krea2` (no hyphen) is a *model architecture* name, not branding. It
stays. Do not rename `krea2_turbo`, `krea2t_enhancer` or similar.

**Removed from `app/orchestrator.py`** (3,872 → 3,342 lines):

- Two whole checkpoint-specific workflow builders and their dispatch
- The helper functions only those builders used
- The entire LoRA registry, now `LORA_SPECS = {}` / `LORA_ALIASES = {}`
- Checkpoint-specific negative-prompt constants
- The `if/elif/else` chain over Krea 2 checkpoints, collapsed to the one that
  ships. **The old `else:` fallback loaded a checkpoint that is no longer shipped
  — that was the trap, and it is now gone.**
- Hardcoded per-LoRA trigger-suppression rules, replaced by a generic mechanism:
  a registry entry may carry an `implied` list of terms, and its trigger words are
  skipped when the prompt already contains one
- Hardcoded preset LoRA layers in the anima / illustrious / sdxl branches,
  replaced with the generic `chain_loras` path

**Removed from `web/`:** a 340-line preset catalog and LoRA metadata block in
`web/js/studio.js`; the model and LoRA label maps in `web/js/studio-transport.js`;
the checkpoint dropdown options in `web/index.html`. The website auth gate is gone
— `init()` now uses a fixed local user.

**Shipped checkpoints** are now exactly four, all general-purpose:
`krea2_turbo`, `sdxl_cyberrealistic`, `anima_base`, `illustrious_base`.

**Line endings are LF everywhere,** locked by `.gitattributes`. The upstream tree
drifted per-file between sessions; this one does not. Keep it that way.

`python -m py_compile app/orchestrator.py` passes. That is the only verification
performed — **nothing has been run.**

---

## 4. What is left

*Phases 2 to 5 are done — see section 2. This is the remainder.*

### Model downloads

Five entries in `app/manifest.json` have `url: null`, and `setup.py verify` lists
them. They are deliberately unset: an installer that fetches a guessed address is
worse than one that says it does not know yet. Until they are filled in, setup
completes and the studio runs, and the only thing missing is weights - which a
user can also supply by pointing at a folder they already have.

Krea 2 is the only architecture intended to ship. That is about 19 GB: the model
itself is 13 GB, its text encoder 4.9 GB, plus the VAE and the upscaler. Dropping
the other three saved about 17 GB, and the registry greys them out until someone
brings their own, so nothing is lost by not shipping them.

### Editing on the other three architectures

`anima_*` and `sdxl_*` / `illustrious_*` build a text-to-image graph and return
before any mode handling runs, so img2img and inpaint ignore the input image. The
studio now refuses those jobs rather than silently generating something
unrelated. It was fixed properly upstream - implementing the encode rather than
gating it - and that fix can be ported when it matters. It matters less now that
Krea 2 is the only shipped architecture, since Krea 2 is the one that works.

Write the golden tests for whichever branch you touch first; they already cover
the graph builders and caught a 26-site refactor with no drift.

### Phase 6 — updater and packaging

`scripts/package.ps1` builds the release archive, and refuses to if the release
check fails, if the tree is dirty, or if the finished zip contains anything it
should not. What is missing is the update mechanism itself: check the releases
API on launch, download, verify, swap `app/` `web/` `workflows/` `scripts/` on
restart, never touch `data/` or `models/`.

**Still blocked on the same unresolved question** - see section 6. A private repo
cannot serve release downloads without a token, and a token inside a shipped app
is extractable.

### Smaller things worth doing

- `web/css/base.css` was lifted from a multi-page site and still carries rules
  for pages that do not exist here. Dead weight, safe to prune, not urgent.
- `StudioLiteCrypto` in `web/js/studio-chat.js` belongs to a second product
  variant that does not exist in this build. Dead code, ~15 references.
- `loraDetails` in `web/js/studio.js` is still `{}`. It only supplies display
  labels, so an unknown LoRA shows its filename instead. Not urgent.


## 5. Landmines

**Never import ComfyUI or any custom-node Python into our code.** HTTP only. That
boundary is what keeps this product's source out of GPL-3.0's reach. Same for
llama.cpp. See `NOTICE.md`.

**llama.cpp behaviour that is not visible in the code:**

- `--context-shift` defaults to *disabled* on the reference build. A context
  overflow is a hard error, not a graceful trim. The client's history cap and the
  orchestrator's trimming must stay in step.
- `-np` defaults to auto, which also enables `--kv-unified` and makes the
  effective per-chat window uncertain. `-np 1` is deliberate.
- One of the four chat tiers **cannot** take a quantized KV cache on this build —
  its attention head size is outside what the compiled kernels cover. Quantized KV
  also requires `-fa on`, which is already in the launch arguments; removing it
  breaks the other three.
- `/health` cannot tell you which model is loaded. `/props` can, and
  `default_generation_settings.n_ctx` is per slot.

**GPU arbitration is load-bearing.** The orchestrator puts ComfyUI into hot
standby, reaps it after five minutes or under load, and backs off when something
else claims the card. It fails as a silent hang rather than an error, which makes
it the most likely thing to behave differently on someone
else's machine. Surface what owns the GPU in the interface.

**Fixed since this list was written, recorded so nobody re-adds them.**

- The port reclaim used to force-kill whatever was listening on 8080, every pass,
  before checking whether it needed the port. It now identifies a llama-server
  through `/props` before touching anything and leaves a stranger alone, and the
  port is configurable.
- VRAM figures are no longer constants. `app/tuning.py` measures the card and
  decides what fits; `SAFE_VRAM_MB` had been a *local variable*, so assigning to
  it from outside did nothing at all.
- ComfyUI's launch command was one hardcoded path for a venv layout. The portable
  bundle setup installs matches neither half of it, so a fresh install could not
  start the ComfyUI it had just downloaded.
- Windows' bundled tar cannot extract the 7-Zip archives ComfyUI ships in on
  Windows 10 - the LZMA codec is absent, while Windows 11 has it. Extraction goes
  through py7zr now, and nothing in the installer depends on tar.

**Small chat tiers get a different system prompt, and it is load-bearing.** The
full prompt is ~1000 words and works on the larger tiers. At 1B it inverts: the
model reads the refusal vocabulary in "never refuse, except this one thing you
must refuse" and refuses everything, including "hi". `_compact_system_prompt` in
`app/orchestrator.py` is one 76-word block for tiers whose `style` is not
`full`, and the word count is the point - adding a single further sentence of
grounding took explicit adult requests from written 3/3 to refused 3/3 on the
shipped 1B. Measure before lengthening it, and re-check the minors limit after
any change; it currently refuses 12/12 across three framings.

**VRAM assumptions are tuned to 12 GB** — model tiers, KV choices, eviction order,
the SeedVR2 CPU block offload, the tiled 8 MP refinement. Phase 3 has to make
these adaptive or 8 GB users hit a wall immediately.

**Shipped presets are Krea 2 only, and deliberately state no advanced values.**
`presetCatalog` in `web/js/studio.js` holds ten. A preset naming a checkpoint that
is not installed would load and then fail at generation; and `useStarter` treats
any `steps`, `guidance` or `sampler` a preset spells out as deliberate, pinning it
across a later model swap. They also carry no negative prompt, because Krea 2
feeds its negative branch through `ConditioningZeroOut` and discards it. Anything
added there wants the same three constraints.

**The interface runs.** `python app/server.py` serves it on 127.0.0.1:8760 and the
layout, presets, queue, chat and mask editor have all been exercised in a browser.
What has never been proven is a full install and a real generation on a machine
with a GPU and nothing else on it - that is the remaining unknown.

---

## 6. Decisions still open

1. **Releases hosting** — still open, and still the thing blocking the updater.
   A private repo cannot serve downloads without a token, and a token inside a
   shipped app is extractable.
2. **~~Which GitHub account publishes this~~** — *settled 2026-09-15.* It is
   published from the same account that holds the website repo, which is private,
   so the two are not visible together. Two things to remember rather than
   rediscover: the account name resembles the author's email address, and making
   the website repo public at any point would expose the connection immediately.
   Commits here use a scrubbed identity, which is unaffected either way.
3. **~~Starter pack contents~~** — *settled 2026-09-16.* Krea 2 only, about
   19 GB, plus the smallest chat tier. The other three architectures are
   supported but not shipped; the registry greys them out until someone brings
   their own weights. What remains is finding real addresses for the five files -
   see section 4.
4. **Whether a lawyer reviews `LICENSE` before any money changes hands.** Flagged
   in the file itself. Untouched.
5. **Storage encryption defaults to off** — *settled 2026-09-15*, recorded here
   because it looks like a regression to anyone who does not know why. On a local
   single-machine tool the passphrase necessarily lives beside the files it
   protects, so anything that can read the images can read the key, while
   forgetting it destroys them for nothing. The switch remains for a shared PC or
   a synced folder, and `unseal` still opens anything sealed under the old
   setting.

---

## 7. Verifying a change

```bash
# Everything still parses
python -m py_compile app/orchestrator.py app/server.py app/local_agent.py app/tuning.py app/setup.py app/fetch.py

# The graph builders still emit what they did. This is the one that matters:
# it carried a 26-site path refactor with no drift, and it is the only thing
# standing between a change and a silently different image.
python tests/test_build_workflow.py

# Nothing forbidden leaked into the tree
powershell -ExecutionPolicy Bypass -File scripts/check-release.ps1

# Workflow templates are still valid JSON
python -c "import json,glob;[json.load(open(f,encoding='utf-8-sig')) for f in glob.glob('workflows/*.json')];print('ok')"

# Every address the installer would use is still real
python app/setup.py verify
```

The interface has no build step, so a change to `web/` is checked by loading it:
`node --check web/js/<file>.js` catches syntax, and the rest needs a browser.

The original project used a Python environment that has the `cryptography`
package; a bare system Python does not, so `orchestrator.py` will not import
under one. Any environment with `cryptography` and `websocket-client` will do.

# Refuses to package if anything that identifies the author, their other projects
# or their private build survives into the release tree.
#
#   powershell -ExecutionPolicy Bypass -File scripts\check-release.ps1
#
# Exit code 0 = clean, 1 = something leaked, 2 = no term list.
#
# The terms themselves are deliberately NOT in this file. Naming them here would
# put the very strings this repo must not contain into the repo. They live in
# scripts\forbidden.local.txt, which is gitignored and never distributed. See
# scripts\forbidden.example.txt for the format.

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$listPath = Join-Path $PSScriptRoot 'forbidden.local.txt'

if (-not (Test-Path $listPath)) {
    Write-Host "No term list at $listPath - cannot verify this tree." -ForegroundColor Yellow
    Write-Host "Copy scripts\forbidden.example.txt to forbidden.local.txt and fill it in." -ForegroundColor Yellow
    exit 2
}

$forbidden = Get-Content $listPath |
    ForEach-Object { $_.Trim() } |
    Where-Object { $_ -and -not $_.StartsWith('#') }

if ($forbidden.Count -eq 0) { Write-Host "Term list is empty." -ForegroundColor Yellow; exit 2 }

# Third-party bundles carry their own vocabulary; only our own files are scanned.
$skip = @('\.git\', '\node_modules\', '\vendor\', '\data\', '\logs\', '\runtime\', '\comfy\', '\dist\', '__pycache__')

# models\ is a special case rather than a blanket skip. Its README ships, so it
# has to be scanned; everything below it is weights or whatever the user dropped
# in, which is neither ours nor distributed.
$modelsRoot = Join-Path $root 'models'

$files = Get-ChildItem $root -Recurse -File |
    Where-Object { $p = $_.FullName; -not ($skip | Where-Object { $p -like "*$_*" }) } |
    Where-Object { $_.DirectoryName -notlike "$modelsRoot\*" } |
    Where-Object { $_.FullName -ne $listPath } |
    Where-Object { $_.Extension -in '.js', '.css', '.html', '.py', '.sql', '.json', '.md', '.ps1', '.bat', '.txt', '.yml', '.yaml' }

$hits = @()
foreach ($f in $files) {
    $text = Get-Content $f.FullName -Raw -ErrorAction SilentlyContinue
    if (-not $text) { continue }
    foreach ($term in $forbidden) {
        if ($text -match [regex]::Escape($term)) {
            $n = ($text -split "`n" | Select-String -SimpleMatch $term | Select-Object -First 1).LineNumber
            $hits += [pscustomobject]@{ File = $f.FullName.Replace("$root\", ''); Line = $n; Length = $term.Length }
        }
    }
}

if ($hits.Count -gt 0) {
    # The matched term is not printed - that would write it into build logs.
    Write-Host "RELEASE BLOCKED - $($hits.Count) forbidden reference(s):" -ForegroundColor Red
    $hits | Format-Table -AutoSize | Out-String | Write-Host
    Write-Host "Open each file at the line shown. Term lengths are given instead of the terms." -ForegroundColor Red
    exit 1
}

Write-Host "Clean - $($files.Count) files scanned against $($forbidden.Count) terms." -ForegroundColor Green
exit 0

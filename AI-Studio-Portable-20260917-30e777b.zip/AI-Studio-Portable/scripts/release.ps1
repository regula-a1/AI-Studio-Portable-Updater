# Publish a build. One command, start to finish.
#
#   powershell -ExecutionPolicy Bypass -File scripts\release.ps1
#
# Builds the archive, then pushes it to the update repo. Every studio already
# out there notices within a few minutes and offers it.
#
# The update repo is just files - a manifest and a zip, committed and pushed.
# The first version of this used GitHub releases with two assets attached by
# hand, which is a lot of ceremony for "I pushed a new build".
#
# Nothing here bypasses the safety checks: package.ps1 runs first, refuses a
# dirty tree, and fails the whole thing if a forbidden string survived into a
# shipped file. A build that was never made cannot be published.
#
# Publish through git, never through the GitHub contents API. The API commits
# as the account's own identity, which is a real name and a real email address,
# and it writes them into the history of a PUBLIC repository where deleting the
# file afterwards does not remove them. That happened once, during setup, from
# a one-off call made to test whether a token had write access - the identity
# configured below was bypassed entirely because git was never involved. Every
# write to the update repo goes through this script.

param(
    [switch]$Force,
    [string]$Message
)

$ErrorActionPreference = 'Stop'

$Root = Split-Path -Parent $PSScriptRoot
$DistDir = Join-Path $Root 'dist'
# Cloned under dist\, which is gitignored, so the update repo never ends up
# nested inside this one.
$RepoDir = Join-Path $DistDir 'updater-repo'
$RepoUrl = 'https://github.com/regula-a1/AI-Studio-Portable-Updater.git'

Push-Location $Root
try {
    # 1. Build. This is the gate: checks, dirty tree, leak inspection.
    & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'package.ps1') @(if ($Force) { '-Force' })
    if ($LASTEXITCODE -ne 0) {
        Write-Host ''
        Write-Host '  Nothing was published.'
        exit 1
    }

    $manifestPath = Join-Path $DistDir 'latest.json'
    if (-not (Test-Path $manifestPath)) { throw 'package.ps1 produced no latest.json.' }
    $manifest = Get-Content $manifestPath -Raw | ConvertFrom-Json
    $zipPath = Join-Path $DistDir $manifest.zip
    if (-not (Test-Path $zipPath)) { throw "package.ps1 produced no $($manifest.zip)." }

    # 2. The update repo, cloned on first use and refreshed after that.
    # A folder with a .git in it is not necessarily a clone of the update repo.
    # It can be left over from a half-finished run, or pointed somewhere else
    # entirely, and then every git command below fails with something that reads
    # like a permissions problem. Check it actually points at the right remote,
    # and start again if it does not.
    if (Test-Path (Join-Path $RepoDir '.git')) {
        # Asking a folder whether it has a remote is a question, and the answer
        # can be no. Windows PowerShell wraps a native command's stderr in an
        # ErrorRecord, which under ErrorActionPreference=Stop turns that no into
        # a fatal error - the same trap bootstrap.ps1 documents for Test-Module.
        $previous = $ErrorActionPreference
        $ErrorActionPreference = 'Continue'
        try {
            $existing = (& git -C $RepoDir remote get-url origin) 2>&1 | Select-Object -First 1
            $stale = ($LASTEXITCODE -ne 0) -or ("$existing".Trim() -ne $RepoUrl)
        } finally {
            $ErrorActionPreference = $previous
        }
        if ($stale) {
            Write-Host '  the staging clone is stale; starting it again'
            Remove-Item -Recurse -Force $RepoDir
        }
    }
    if (-not (Test-Path (Join-Path $RepoDir '.git'))) {
        Write-Host '  cloning the update repo...'
        & git clone --quiet $RepoUrl $RepoDir
        if ($LASTEXITCODE -ne 0) { throw 'Could not clone the update repo.' }
    } else {
        & git -C $RepoDir fetch --quiet origin
        # An update repo with no commits yet has no origin/HEAD to reset to, and
        # that is the state it is in exactly once - the first time this runs.
        & git -C $RepoDir rev-parse --verify --quiet origin/HEAD *> $null
        if ($LASTEXITCODE -eq 0) {
            & git -C $RepoDir reset --quiet --hard origin/HEAD
        }
    }

    # 3. Commit as the same neutral identity this repo uses.
    #
    #    The update repo is PUBLIC, and every commit in it carries an author
    #    name and email for anyone to read. Without this, git falls back to a
    #    global identity - a real name and address, or on a machine with none,
    #    a hostname-derived one and a hard failure. Neither belongs in a
    #    repository built so that the people using it cannot learn who wrote it.
    $authorName = (& git -C $Root config user.name)
    $authorMail = (& git -C $Root config user.email)
    if (-not $authorName -or -not $authorMail) {
        throw 'This repo has no user.name/user.email set, and the update repo is public. Set a neutral identity before publishing.'
    }
    & git -C $RepoDir config user.name $authorName
    & git -C $RepoDir config user.email $authorMail

    # 4. Only the newest build is kept. Old zips would accumulate forever in a
    #    repository nobody prunes, and nothing reads them: the manifest names
    #    exactly one.
    Get-ChildItem $RepoDir -Filter '*.zip' -File -ErrorAction SilentlyContinue |
        ForEach-Object { & git -C $RepoDir rm --quiet -f $_.Name }

    Copy-Item $zipPath (Join-Path $RepoDir $manifest.zip) -Force
    Copy-Item $manifestPath (Join-Path $RepoDir 'latest.json') -Force

    # 5. Push.
    & git -C $RepoDir add -A
    $pending = & git -C $RepoDir status --porcelain
    if (-not $pending) {
        Write-Host ''
        Write-Host '  That build is already published. Nothing to push.'
        exit 0
    }
    $subject = if ($Message) { $Message } else { $manifest.version + ' - ' + $manifest.notes }
    & git -C $RepoDir commit --quiet -m $subject
    if ($LASTEXITCODE -ne 0) { throw 'Could not commit to the update repo.' }
    # Pushing needs to be the update account, not whichever GitHub account this
    # machine has cached. That matters for more than permissions: a push shows
    # up in the pushing account's PUBLIC activity feed, so pushing here as the
    # author's main account would link the two in public and undo the reason
    # the update account exists.
    #
    # So: a fine-grained token for the update account, in a gitignored file
    # beside the forbidden-term list. Passed as a header rather than embedded in
    # the remote URL, so it is not written into .git/config and not echoed back
    # in an error message.
    #
    # -u origin HEAD rather than a bare push: the first commit to an empty repo
    # has no upstream, and naming it here makes the first run behave like the
    # rest.
    $tokenFile = Join-Path $PSScriptRoot 'updater-token.local.txt'
    if (Test-Path $tokenFile) {
        # First real line, ignoring blanks and # comments - the file ships with
        # instructions in it, and reading those as the token would be a baffling
        # way to fail.
        $token = (Get-Content $tokenFile |
                  Where-Object { $_.Trim() -and -not $_.Trim().StartsWith('#') } |
                  Select-Object -First 1).Trim()
        if (-not $token) { throw "No token in $tokenFile yet - paste it in and run this again." }
        $basic = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$token"))
        & git -C $RepoDir -c "http.extraheader=AUTHORIZATION: basic $basic" push --quiet -u origin HEAD
    } else {
        & git -C $RepoDir push --quiet -u origin HEAD
    }
    if ($LASTEXITCODE -ne 0) {
        Write-Host ''
        Write-Host '  The push was refused.'
        Write-Host ''
        Write-Host '  Two different causes, and the message from git says which:'
        Write-Host ''
        Write-Host '  "denied to <the update account>" - the right account, but the token'
        Write-Host '  is missing a permission. Edit the token and check both of these:'
        Write-Host '      Repository access : the updater repo is in the selected list'
        Write-Host '      Permissions       : Contents is Read AND WRITE, not read-only'
        Write-Host '  Read-only is the default, and it is enough to clone and to read the'
        Write-Host '  repo through the API, so everything looks fine until the push.'
        Write-Host ''
        Write-Host '  "denied to <some other account>" - the token file is missing or holds'
        Write-Host '  a token belonging to the wrong account. Do not fix that by granting'
        Write-Host '  the other account access: a push shows in the pushing account''s'
        Write-Host '  public activity, which links the two for anyone to see.'
        Write-Host ''
        Write-Host ("  Token file: " + $tokenFile)
        Write-Host ''
        throw 'Could not push to the update repo.'
    }

    Write-Host ''
    Write-Host '  Published.'
    Write-Host ("    version : " + $manifest.version)
    Write-Host ("    zip     : " + $manifest.zip)
    Write-Host ''
    Write-Host '  Every studio already installed will offer this within a few minutes'
    Write-Host '  and ask the person to restart. Nothing else to do.'
    Write-Host ''
}
finally {
    Pop-Location
}

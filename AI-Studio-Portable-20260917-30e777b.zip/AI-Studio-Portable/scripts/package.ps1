# Build the release archive.
#
# Use this. Do not zip the folder.
#
# Zipping the working folder ships two things that must never leave this machine,
# and neither is caught by check-release.ps1 because that script deliberately does
# not scan them:
#
#   .git\config                 holds the remote URL, and therefore the account
#                               name it is published under
#   scripts\forbidden.local.txt is the list of every term that must not appear -
#                               handing someone that file is worse than any
#                               single leak, because it is the map
#
# `git archive` exports only tracked files and never touches .git, so both are
# excluded by construction rather than by remembering. The forbidden list is
# gitignored, so it cannot be in a git export even by accident.
#
# The release check runs first and a failure stops the build. An archive that was
# never created cannot be sent to anybody.

param([switch]$Force)

$ErrorActionPreference = 'Stop'

$Root = Split-Path -Parent $PSScriptRoot
Push-Location $Root

try {
    Write-Host ''
    Write-Host 'AI Studio Portable - building a release archive'
    Write-Host ''

    # 1. Nothing forbidden in any shipped file.
    Write-Host '  checking for forbidden strings...'
    & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'check-release.ps1')
    if ($LASTEXITCODE -ne 0) {
        Write-Host ''
        Write-Host '  BLOCKED. Nothing was built. Fix the files listed above and run this again.'
        exit 1
    }

    # 2. Refuse to build from a dirty tree. An archive is taken from the last
    #    commit, so uncommitted work would be silently missing from it - which is
    #    discovered later, on the machine it was sent to.
    $dirty = & git status --porcelain
    if ($dirty) {
        Write-Host ''
        Write-Host '  There are uncommitted changes:'
        $dirty | Select-Object -First 10 | ForEach-Object { Write-Host "    $_" }
        Write-Host ''
        Write-Host '  git archive exports the last commit, so those changes would not be in'
        Write-Host '  the build. Commit them, or pass -Force to build without them anyway.'
        if (-not $Force) { exit 1 }
    }

    # 3. Build it.
    $version = (& git rev-parse --short HEAD).Trim()
    $stamp = Get-Date -Format 'yyyyMMdd'
    $distDir = Join-Path $Root 'dist'
    if (-not (Test-Path $distDir)) { New-Item -ItemType Directory -Force -Path $distDir | Out-Null }
    $archive = Join-Path $distDir "AI-Studio-Portable-$stamp-$version.zip"

    Write-Host "  exporting $version..."
    & git archive --format=zip --prefix='AI-Studio-Portable/' -o $archive HEAD
    if ($LASTEXITCODE -ne 0) { throw 'git archive failed.' }

    # 4. Prove what is in it rather than trusting the method.
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip = [System.IO.Compression.ZipFile]::OpenRead($archive)
    try {
        $names = $zip.Entries | ForEach-Object { $_.FullName }
        $leaks = $names | Where-Object { $_ -match '(^|/)\.git/' -or $_ -match 'forbidden\.local' }
        $size = (Get-Item $archive).Length
    } finally {
        $zip.Dispose()
    }

    Write-Host ''
    if ($leaks) {
        Write-Host '  LEAK: the archive contains files it must not:'
        $leaks | ForEach-Object { Write-Host "    $_" }
        Remove-Item -Force $archive
        Write-Host '  The archive has been deleted.'
        exit 1
    }

    # 5. The manifest the updater reads. Published beside the zip as a release
    #    asset, so "is this newer" and "is this the file I expected" are both
    #    answered by something the build wrote, rather than inferred from a tag
    #    name that somebody has to remember to get right.
    $fullCommit = (& git rev-parse HEAD).Trim()
    $hash = (Get-FileHash -Algorithm SHA256 -Path $archive).Hash.ToLower()
    $manifest = [ordered]@{
        version = "$stamp-$version"
        commit  = $fullCommit
        zip     = (Split-Path -Leaf $archive)
        sha256  = $hash
        bytes   = (Get-Item $archive).Length
        built   = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
        notes   = (& git log -1 --pretty=%s).Trim()
    }
    $manifestPath = Join-Path $distDir 'latest.json'
    # ASCII, so no byte order mark: the updater parses this as JSON and a BOM is
    # a needless way for that to fail on somebody else's machine.
    [System.IO.File]::WriteAllText($manifestPath, ($manifest | ConvertTo-Json), (New-Object System.Text.UTF8Encoding $false))

    Write-Host ("  built: " + (Split-Path -Leaf $archive))
    Write-Host ("  {0} files, {1:N1} MB" -f $names.Count, ($size / 1MB))
    Write-Host '  contains no .git and no forbidden-term list - checked, not assumed.'
    Write-Host ''
    Write-Host ("  manifest: " + (Split-Path -Leaf $manifestPath) + "  sha256 " + $hash.Substring(0, 12) + "...")
    Write-Host ''
    Write-Host "  $archive"
    Write-Host "  $manifestPath"
    Write-Host ''
    Write-Host '  To publish this to everyone, run scripts\release.ps1 - it builds and'
    Write-Host '  pushes in one step. These two files on their own do nothing.'
    Write-Host ''
} finally {
    Pop-Location
}

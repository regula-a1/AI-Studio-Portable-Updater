"""First-run setup: build the studio its own ComfyUI, without touching anyone's.

    python app/setup.py plan          what it would do, and what it would download
    python app/setup.py verify        ask every address in the manifest if it is real
    python app/setup.py models <dir>  use models you already have, where they are
    python app/setup.py install       do it
    python app/setup.py install --only comfy,nodes

Three rules this follows, in order of how much damage breaking them does.

**Never modify an existing ComfyUI.** The obvious install - find theirs, add our
nodes, write our workflows in, share their Python - was considered and rejected
as the destructive option. It mutates a setup they have tuned, risks dependency
conflicts, and when it eventually breaks their workflows the tool gets blamed.
So: always our own ComfyUI and our own environment, and their *models* borrowed
read-only by path. The install is cheap and the models are expensive.

**Every step is resumable and re-runnable.** This is ~19 GB over a domestic
connection; something will interrupt it. Each step checks whether it is already
done before doing anything, so running setup twice costs a few hashes.

**Say what will happen before it happens.** `plan` is not a courtesy - a user
about to spend 19 GB of a metered connection is entitled to know first.
"""
import io
import json
import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))

import fetch                                               # noqa: E402
import tuning                                              # noqa: E402

COMFY_DIR = ROOT / 'comfy'
RUNTIME_DIR = ROOT / 'runtime'
MODELS_DIR = ROOT / 'models'
DOWNLOADS = ROOT / 'data' / 'downloads'
MANIFEST = HERE / 'manifest.json'
STATE = ROOT / 'data' / 'setup-state.json'

NO_WINDOW = getattr(subprocess, 'CREATE_NO_WINDOW', 0x08000000)


def load_manifest():
    return json.loads(MANIFEST.read_text(encoding='utf-8'))


def load_state():
    try:
        return json.loads(STATE.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return {'done': []}


def save_state(state):
    STATE.parent.mkdir(parents=True, exist_ok=True)
    STATE.write_text(json.dumps(state, indent=2), encoding='utf-8')


LOG = ROOT / 'data' / 'setup-log.txt'


def say(message, indent=0):
    """Print, and keep a copy.

    The machine that fails an install is usually not the machine anyone can
    debug on, and a console window closing takes the only account of what
    happened with it.
    """
    line = ('  ' * indent) + message
    print(line, flush=True)
    try:
        LOG.parent.mkdir(parents=True, exist_ok=True)
        with io.open(LOG, 'a', encoding='utf-8', newline=chr(10)) as handle:
            handle.write(line + chr(10))
    except OSError:
        pass                                               # Never fail over logging.


# ------------------------------------------------------------- extraction ---

def ensure_7zr():
    """Obtain the 7-Zip extractor, returning its path or None.

    Third attempt at this, and the reasoning behind the first two is worth keeping
    because both looked correct:

    Windows' own tar.exe recognises a 7-Zip container, but its libarchive is built
    without the LZMA codec on Windows 10 while Windows 11 has it. The probe meant
    to catch that asked whether the format was recognised, which says nothing
    about being able to decompress it, so it answered yes on both machines and was
    wrong on both.

    py7zr replaced it, being pure Python and therefore identical everywhere. It
    installs, it opens most archives, and it refuses this one: ComfyUI's portable
    build uses the BCJ2 filter, which py7zr does not implement. That failure
    arrives after the 1.8 GB download, at the one step the whole install depends
    on.

    7zr.exe is 7-Zip's own standalone build: one 0.6 MB public-domain executable,
    no installer, every filter supported. It comes from the GitHub release rather
    than 7-zip.org because that site is serving an expired certificate, which
    Python rejects even though browsers accept it - and turning certificate
    checking off inside an installer is not a trade worth making. It is pinned and
    checked by hash, so what gets run is what was verified.
    """
    spec = (load_manifest().get('tools') or {}).get('sevenzip') or {}
    if not spec.get('url'):
        say('no 7-Zip extractor is listed in the manifest.', 2)
        return None
    tool = RUNTIME_DIR / 'tools' / spec['file']
    if tool.exists():
        return tool
    say('fetching the 7-Zip extractor (' + fetch.human(spec.get('bytes')) + ')...', 2)
    try:
        fetch.download(spec['url'], tool, sha256=spec.get('sha256'),
                       expected_size=spec.get('bytes'))
    except fetch.DownloadError as exc:
        say('could not fetch 7zr.exe: ' + str(exc)[:160], 2)
        return None
    return tool if tool.exists() else None


def discard(archive):
    """Remove an archive whose contents are now installed.

    These are kept while a step is unfinished, because that is what makes the
    installer safe to re-run - a download interrupted at 80% resumes from 80%.
    Once the step has succeeded the archive is 1.8 GB of nothing: ComfyUI is
    unpacked, the file it came from is never read again, and nothing deletes it.

    On the machine this was measured on that was 2.5 GB of an 8.5 GB install,
    and every person who installed it would have carried that forever.

    Only ever called after the step has checked its own work, so the trade is
    a re-download on a later repair against a third of the disk on every
    install that goes fine.
    """
    try:
        Path(archive).unlink(missing_ok=True)
    except OSError as exc:                                 # noqa: BLE001 - never fatal
        say('could not remove ' + Path(archive).name + ': ' + str(exc)[:80], 2)


def extract(archive, destination):
    """Unpack an archive. Two formats, one handler each, no platform guesswork."""
    destination.mkdir(parents=True, exist_ok=True)
    suffix = archive.suffix.lower()
    if suffix == '.zip':
        with zipfile.ZipFile(archive) as bundle:
            bundle.extractall(destination)
        return True
    if suffix == '.7z':
        tool = ensure_7zr()
        if not tool:
            return False
        # Left uncaptured on purpose. This unpacks 57,000 files and takes about a
        # minute; a silent minute is how the first version of this looked like it
        # had hung, so 7zr's own progress is allowed through to the console.
        result = subprocess.run(
            [str(tool), 'x', str(archive), '-o' + str(destination), '-y'],
            creationflags=NO_WINDOW)
        if result.returncode == 0:
            return True
        say('7zr could not unpack ' + archive.name
            + ' (exit ' + str(result.returncode) + ')', 2)
        return False
    say('unknown archive type: ' + archive.name, 2)
    return False


# ------------------------------------------------------------------ steps ---

def step_comfy(manifest, state, dry_run):
    """Install our own ComfyUI, with its own embedded Python."""
    marker = COMFY_DIR / 'ComfyUI' / 'main.py'
    if marker.exists():
        say('ComfyUI is already installed in ' + str(COMFY_DIR), 1)
        return True

    spec = manifest['comfyui']
    vendor = gpu_vendor()
    asset_name = spec['assets'].get(vendor) or spec['assets']['nvidia']
    say('ComfyUI portable (' + vendor + '): ' + asset_name, 1)

    if dry_run:
        sizes = spec.get('verified', {}).get('sizes_mb', {})
        say('would download ~' + str(sizes.get(vendor, '?')) + ' MB and unpack to '
            + str(COMFY_DIR), 2)
        if not (RUNTIME_DIR / 'tools' / '7zr.exe').exists():
            say('a small 7-Zip extractor will be fetched first (0.6 MB)', 2)
        return True

    asset = resolve_release_asset(spec['release_api'], asset_name)
    if not asset:
        say('could not find ' + asset_name + ' in the latest release', 2)
        return False
    archive = DOWNLOADS / asset_name
    fetch.download(asset['url'], archive, expected_size=asset.get('size'),
                   on_progress=progress_reporter(asset_name))
    say('unpacking...', 2)
    if not extract(archive, COMFY_DIR):
        say('could not unpack ' + asset_name + '. 7-Zip archives need an extractor '
            'this machine does not have.', 2)
        return False
    flatten_single_child(COMFY_DIR)
    if marker.exists():
        discard(archive)
        # Point the fresh ComfyUI at the studio's own models folder straight away,
        # so anything dropped in there is loadable without a second setup step.
        write_extra_model_paths(state.get('modelsPath'))
        return True
    # Unpacked, but not into the shape expected. Say what is actually there
    # rather than returning False with nothing said, which is how this failed the
    # first time it ran on someone else's machine.
    say('unpacked, but ' + str(marker) + ' is not there afterwards.', 2)
    try:
        listing = sorted(p.name for p in COMFY_DIR.iterdir())[:10]
        say('the archive produced: ' + (', '.join(listing) or '(nothing)'), 2)
    except OSError:
        say('and ' + str(COMFY_DIR) + ' cannot be read.', 2)
    return False


def step_nodes(manifest, state, dry_run):
    """Add the custom nodes the shipped workflows need."""
    target = COMFY_DIR / 'ComfyUI' / 'custom_nodes'
    ok = True
    for node in manifest['nodes']:
        if node.get('optIn'):
            say('skipping ' + node['name'] + ' (opt-in only - see NOTICE.md)', 1)
            continue
        if not node.get('required'):
            say('skipping ' + node['name'] + ' (optional)', 1)
            continue
        destination = target / node['name']
        if destination.exists():
            say(node['name'] + ' already present', 1)
            continue
        url = ('https://codeload.github.com/' + node['repo']
               + '/zip/refs/heads/' + node['branch'])
        if dry_run:
            say('would fetch ' + node['name'] + ' from ' + node['repo']
                + ' (' + node['branch'] + ')', 1)
            continue
        archive = DOWNLOADS / (node['name'] + '.zip')
        say(node['name'] + '...', 1)
        try:
            fetch.download(url, archive)
        except fetch.DownloadError as exc:
            say(str(exc), 2)
            ok = False
            continue
        staging = DOWNLOADS / ('_' + node['name'])
        shutil.rmtree(staging, ignore_errors=True)
        if not extract(archive, staging):
            ok = False
            continue
        # GitHub archives unpack to <repo>-<branch>/; move that up to the name
        # ComfyUI expects, which is what the node's own imports assume.
        inner = next((p for p in staging.iterdir() if p.is_dir()), None)
        if inner:
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(inner), str(destination))
        shutil.rmtree(staging, ignore_errors=True)
        if destination.exists():
            discard(archive)
    return ok


def pip_env():
    """Environment for a pip run, with its cache kept inside this folder.

    pip's default cache lives in the user's profile. Leaving it there puts part of
    the install outside the folder that is supposed to contain all of it, on the
    drive most likely to be short of space.
    """
    return dict(os.environ, PIP_CACHE_DIR=str(ROOT / 'data' / 'cache' / 'pip'))


def step_node_requirements(manifest, state, dry_run):
    """Install each node's Python dependencies into our embedded interpreter."""
    python = embedded_python()
    if not python:
        say('ComfyUI is not installed yet, so there is nothing to install into.', 1)
        say('This will run once ComfyUI is in place.', 1)
        return False

    # ComfyUI's bundled interpreter does not always carry setuptools, and a node
    # whose requirements build from source needs it. Without this the failure
    # reads as "Cannot import setuptools.build_meta", which points at the wrong
    # thing entirely.
    if not dry_run:
        subprocess.run([str(python), '-m', 'pip', 'install', '--upgrade',
                        'setuptools', 'wheel'],
                       capture_output=True, text=True, creationflags=NO_WINDOW,
                       env=pip_env())
    target = COMFY_DIR / 'ComfyUI' / 'custom_nodes'
    for requirements in sorted(target.glob('*/requirements.txt')):
        name = requirements.parent.name
        if dry_run:
            say('would install requirements for ' + name, 1)
            continue
        say('dependencies for ' + name + '...', 1)
        result = subprocess.run(
            [str(python), '-m', 'pip', 'install', '-r', str(requirements)],
            capture_output=True, text=True, creationflags=NO_WINDOW,
            env=pip_env())
        if result.returncode != 0:
            # Not fatal. A node with a missing dependency fails to load and its
            # features are hidden; stopping the whole install over one is worse.
            say('failed (the node may not load): '
                + (result.stderr or '').strip().splitlines()[-1][:160], 2)
    return True


def step_progress_dependency(manifest, state, dry_run):
    """websocket-client, so generation shows real progress rather than a frozen bar."""
    python = embedded_python()
    if not python:
        # The studio's own runtime already has it from the bootstrap; this is
        # only for ComfyUI's, and there is no harm in it being absent.
        say('skipped until ComfyUI is installed', 1)
        return True
    if dry_run:
        say('would install websocket-client into the embedded Python', 1)
        return True
    result = subprocess.run([str(python), '-m', 'pip', 'install', 'websocket-client'],
                            capture_output=True, text=True, creationflags=NO_WINDOW,
                            env=pip_env())
    if result.returncode != 0:
        say('could not install websocket-client; progress will show stages only', 1)
    return True


def step_models(manifest, state, dry_run):
    """Weights: either point at what the user already has, or download the pack."""
    existing = state.get('modelsPath')
    if existing:
        say('using models already on this PC: ' + existing, 1)
        say('nothing is written there - the folder is only read from', 2)
        return True

    # The one branching question in the whole install, and until now the install
    # never asked it - it went straight to downloading about 18 GB even on a PC
    # with every one of those files already sitting in a ComfyUI folder. The code
    # to borrow them existed and could only be reached by knowing to run
    # `setup.py models <folder>` by hand, before the step that downloads.
    if not dry_run and interactive_console():
        say('')
        say('Before downloading anything: does this PC already have ComfyUI', 1)
        say('models? Using them saves the whole download, and nothing in that', 1)
        say('folder is copied, moved or written to.', 1)
        say('')
        if command_models(interactive=True) == 0:
            borrowed = load_state().get('modelsPath')
            if borrowed:
                state['modelsPath'] = borrowed
                save_state(state)
                return True

    pending = [entry['file'] for entry in manifest_downloads(manifest, ('models',))
               if not entry.get('url')]
    if pending:
        # Deliberately not a failure. ComfyUI is installed and the studio runs;
        # what is missing is weights, which is a separate decision the user makes.
        # Returning False here made a perfectly good install announce itself as
        # broken, which is worse than saying plainly what is still needed.
        say('No models yet, so the studio cannot generate images until it has some.', 1)
        say('', 1)
        say('If this PC already has ComfyUI models somewhere, point the studio at', 1)
        say('them and they stay where they are - nothing is copied or moved:', 1)
        say('runtime' + os.sep + 'python' + os.sep + 'python.exe app' + os.sep
            + 'setup.py models "C:' + os.sep + 'path' + os.sep + 'to' + os.sep
            + 'ComfyUI"', 2)
        state['modelsPending'] = True
        save_state(state)
        return True

    total = sum(entry.get('bytes') or 0
                for entry in manifest_downloads(manifest, ('models',)))
    if dry_run:
        say('would download ' + fetch.human(total) + ' of models', 1)
        return True

    # Image weights go under the ComfyUI folder they are loaded from; chat weights
    # go to the studio's own models folder, which is where the orchestrator looks.
    comfy_models = COMFY_DIR / 'ComfyUI' / 'models'
    # Say the total before starting rather than only the name of each file as it
    # begins. Someone who declined the borrow, or typed a path wrong, is one line
    # away from an 18 GB download and should see that number first.
    say('Downloading ' + fetch.human(total) + ' of models.', 1)
    ok = True
    for entry in manifest_downloads(manifest, ('models',)):
        folder = entry.get('folder')
        target = comfy_models / folder / entry['file']
        if target.exists():
            say(entry['file'] + ' already here', 1)
            continue
        say(entry['file'] + ' (' + fetch.human(entry.get('bytes')) + ')', 1)
        try:
            fetch.download(entry['url'], target, sha256=entry.get('sha256'),
                           expected_size=entry.get('bytes'),
                           on_progress=progress_reporter(entry['file']))
        except fetch.DownloadError as exc:
            say(str(exc), 2)
            ok = False
    return ok


def lift_to_root(folder, filename):
    """Move an archive's contents up if what we need landed in a subfolder.

    flatten_single_child is not enough here. Two archives unpack into the same
    folder, and once the first has put fifty files at the top there is no longer a
    single child to lift, so a second archive that happens to be nested would stay
    nested and its DLLs would never be found.
    """
    target = folder / filename
    if target.exists():
        return True
    for found in folder.rglob(filename):
        inner = found.parent
        if inner == folder:
            return True
        for item in list(inner.iterdir()):
            destination = folder / item.name
            if destination.exists():
                continue
            shutil.move(str(item), str(destination))
        return (folder / filename).exists()
    return False


def step_llama(manifest, state, dry_run):
    """Install llama.cpp and the chat weights it runs.

    Chat needs two things and used to install neither. The weights were bundled in
    with the image models, so pointing the studio at an existing ComfyUI folder -
    which never contains a gguf - skipped them; and nothing anywhere fetched a
    server to load them with. The result was a chat tab that could not work and
    did not say why.
    """
    spec = manifest.get('llama') or {}
    assets = spec.get('assets') or {}
    vendor = gpu_vendor()
    names = assets.get(vendor) or assets.get('cpu') or []
    target_dir = RUNTIME_DIR / 'llama'
    server = target_dir / 'llama-server.exe'
    weights = list(manifest_downloads(manifest, ('chat',)))

    if dry_run:
        sizes = spec.get('verified', {}).get('sizes_mb', {})
        if server.exists():
            say('llama.cpp is already in ' + str(target_dir), 1)
        else:
            say('llama.cpp (' + vendor + '): ~' + str(sizes.get(vendor, '?')) + ' MB', 1)
            if len(names) > 1:
                say('in two archives - the CUDA runtime ships separately', 2)
        pending = sum(entry.get('bytes') or 0 for entry in weights
                      if not (MODELS_DIR / 'llm' / entry['file']).exists())
        say('would download ' + fetch.human(pending) + ' of chat weights', 1)
        return True

    if server.exists():
        say('llama.cpp is already installed in ' + str(target_dir), 1)
    elif not names:
        say('no llama.cpp build is listed for this machine.', 1)
        return False
    else:
        for name in names:
            asset = resolve_release_asset(spec.get('release_api', ''), name)
            if not asset:
                say('could not find ' + name + ' in build ' + str(spec.get('build')), 2)
                return False
            archive = DOWNLOADS / name
            fetch.download(asset['url'], archive, expected_size=asset.get('size'),
                           on_progress=progress_reporter(name))
            say('unpacking ' + name + '...', 2)
            if not extract(archive, target_dir):
                return False
        if lift_to_root(target_dir, 'llama-server.exe'):
            for name in names:
                discard(DOWNLOADS / name)
        else:
            say('unpacked, but llama-server.exe is not in ' + str(target_dir), 2)
            try:
                listing = sorted(p.name for p in target_dir.iterdir())[:10]
                say('the archives produced: ' + (', '.join(listing) or '(nothing)'), 2)
            except OSError:
                pass
            return False
        say('llama.cpp ready: ' + str(server), 1)

    ok = True
    llm_dir = MODELS_DIR / 'llm'
    for entry in weights:
        target = llm_dir / entry['file']
        if target.exists():
            say(entry['file'] + ' already here', 1)
            continue
        if not entry.get('url'):
            say('no address for ' + entry['file'] + ' yet, so chat has no model.', 1)
            continue
        say(entry['file'] + ' (' + fetch.human(entry.get('bytes')) + ')', 1)
        try:
            fetch.download(entry['url'], target, sha256=entry.get('sha256'),
                           expected_size=entry.get('bytes'),
                           on_progress=progress_reporter(entry['file']))
        except fetch.DownloadError as exc:
            say(str(exc), 2)
            ok = False
    return ok


# The fourth field marks a step everything after it depends on. When ComfyUI
# fails there is no point installing nodes into a folder that has no ComfyUI in
# it, and doing so buries the real error under a page of consequential ones.
STEPS = (
    ('comfy', 'ComfyUI', step_comfy, True),
    ('nodes', 'Custom nodes', step_nodes, False),
    ('requirements', 'Node dependencies', step_node_requirements, False),
    ('progress', 'Progress reporting', step_progress_dependency, False),
    ('models', 'Image models', step_models, False),
    ('llama', 'Chat engine and model', step_llama, False),
)


# ----------------------------------------------------------------- helpers ---

def manifest_downloads(manifest, groups=('models', 'chat')):
    """Every weight file the manifest names, skipping its own documentation.

    Keys beginning with an underscore are comments. Iterating them as though they
    were download groups is what the first run of `plan` did, and it crashed on a
    string where it expected an entry.

    `groups` narrows it. Image weights and chat weights are installed by different
    steps because they answer to different things: image weights can be borrowed
    from an existing ComfyUI, and a chat gguf never lives in one.
    """
    for group in groups:
        for name, entries in (manifest.get(group) or {}).items():
            if name.startswith('_') or not isinstance(entries, list):
                continue
            for entry in entries:
                if isinstance(entry, dict):
                    yield entry


def gpu_vendor():
    hardware = tuning.probe_hardware()
    name = (hardware.get('gpu') or '').lower()
    if 'nvidia' in name or 'geforce' in name or 'rtx' in name or 'quadro' in name:
        return 'nvidia'
    if 'amd' in name or 'radeon' in name:
        return 'amd'
    if 'intel' in name or 'arc' in name:
        return 'intel'
    return 'nvidia'


def embedded_python():
    """ComfyUI's own interpreter, or None.

    Deliberately never falls back to the studio's runtime python. It used to,
    and the effect was that when the ComfyUI download failed, every node's
    requirements were installed into our 61 MB bootstrap interpreter instead -
    which has no setuptools, so they failed there too, reporting a confusing
    build-backend error that had nothing to do with the real problem.

    Node dependencies belong to ComfyUI's environment. If that environment is not
    there, the answer is that there is nothing to install into yet.
    """
    for candidate in (COMFY_DIR / 'python_embeded' / 'python.exe',
                      COMFY_DIR / 'python_embedded' / 'python.exe',
                      COMFY_DIR / 'venv' / 'Scripts' / 'python.exe'):
        if candidate.exists():
            return candidate
    return None


def flatten_single_child(folder):
    """Archives unpack to one wrapper directory; lift its contents up a level."""
    children = [p for p in folder.iterdir() if p.name != '.gitkeep']
    if len(children) == 1 and children[0].is_dir():
        inner = children[0]
        for item in list(inner.iterdir()):
            shutil.move(str(item), str(folder / item.name))
        inner.rmdir()


def resolve_release_asset(api_url, asset_name):
    import urllib.request
    request = urllib.request.Request(
        api_url, headers={'User-Agent': fetch.USER_AGENT,
                          'Accept': 'application/vnd.github+json'})
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            release = json.loads(response.read())
    except Exception as exc:                               # noqa: BLE001
        say('could not reach the release list: ' + str(exc), 2)
        return None
    for asset in release.get('assets', []):
        if asset.get('name') == asset_name:
            return {'url': asset.get('browser_download_url'), 'size': asset.get('size')}
    return None


def progress_reporter(label):
    def report(done, total):
        if total:
            percent = int(done * 100 / total)
            sys.stdout.write('\r    %s  %d%%  (%s of %s)   '
                             % (label, percent, fetch.human(done), fetch.human(total)))
        else:
            sys.stdout.write('\r    %s  %s   ' % (label, fetch.human(done)))
        sys.stdout.flush()
        if total and done >= total:
            sys.stdout.write('\n')
    return report


# ------------------------------------------------------- borrowed models ---
#
# The one branching question in the whole install: do you already have models?
#
# Answering yes must not mean "let us reorganise your ComfyUI". The models stay
# exactly where they are, are never written to, moved or renamed, and our own
# ComfyUI is told where to look by a file in *our* tree. ComfyUI reads
# extra_model_paths.yaml from its own folder, so pointing it at someone else's
# models needs no change to their install at all - which is the whole coexistence
# rule expressed in about twenty lines.

# Every folder name ComfyUI recognises, used for detecting somebody else's models
# folder and for mapping whatever layout theirs happens to use.
MODEL_FOLDERS = ('checkpoints', 'diffusion_models', 'unet', 'text_encoders', 'clip',
                 'vae', 'loras', 'upscale_models', 'controlnet', 'clip_vision',
                 'embeddings', 'style_models', 'gligen', 'hypernetworks')

# What the studio creates in its own models folder, and what models/README.txt
# documents. Deliberately shorter than the list above: `unet` and `clip` are the
# old names for diffusion_models and text_encoders, and offering somebody two
# folders that mean the same thing is a way to have them pick the wrong one. The
# rest are types nothing shipped here uses.
STUDIO_FOLDERS = ('checkpoints', 'diffusion_models', 'text_encoders', 'vae', 'loras',
                  'upscale_models', 'controlnet', 'embeddings', 'clip_vision')


def looks_like_models_folder(path):
    """Whether this folder plausibly holds ComfyUI models, and what is in it."""
    path = Path(path).expanduser()
    if not path.is_dir():
        return None
    # Tolerate being given either the models folder or the ComfyUI root above it.
    for candidate in (path, path / 'models', path / 'ComfyUI' / 'models'):
        if not candidate.is_dir():
            continue
        present = [name for name in MODEL_FOLDERS if (candidate / name).is_dir()]
        if len(present) >= 3:
            weights = sum(1 for _ in candidate.rglob('*.safetensors'))
            weights += sum(1 for _ in candidate.rglob('*.ckpt'))
            return {'path': candidate, 'folders': present, 'weights': weights}
    return None


def write_extra_model_paths(borrowed_root=None):
    """Tell our ComfyUI which folders to load models from.

    Always includes the studio's own `models/` folder. That is what makes drop-in
    work: put a checkpoint or a LoRA in there and ComfyUI can actually load it,
    rather than the studio listing a file the engine cannot open. Without this the
    Models panel would show a LoRA and then fail every job that used it.

    Optionally includes a folder belonging to another installation, read-only.
    Written into our own tree either way - their install never learns this file
    exists, and removing the studio removes the only trace of the arrangement.
    """
    target = COMFY_DIR / 'ComfyUI' / 'extra_model_paths.yaml'
    target.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        '# Written by AI Studio Portable. Setup rewrites this file.',
        '#',
        '# studio:   this installation own models folder. Anything dropped in',
        '#           there is loadable from here.',
        '# borrowed: a models folder belonging to another install, if one was',
        '#           chosen. Only ever read from - nothing is written, moved or',
        '#           renamed there. Delete that section to stop using it.',
    ]

    def section(name, root, default):
        root = Path(root)
        block = [name + ':',
                 '    base_path: ' + str(root).replace(chr(92), '/'),
                 '    is_default: ' + ('true' if default else 'false')]
        for folder in MODEL_FOLDERS:
            if (root / folder).is_dir():
                block.append('    ' + folder + ': ' + folder)
        return block

    studio_models = ROOT / 'models'
    for folder in STUDIO_FOLDERS:
        (studio_models / folder).mkdir(parents=True, exist_ok=True)
    lines += section('studio', studio_models, True)
    if borrowed_root:
        lines += section('borrowed', borrowed_root, False)

    with io.open(target, 'w', encoding='utf-8', newline=chr(10)) as handle:
        handle.write(chr(10).join(lines) + chr(10))
    return target


def update_studio_config(**values):
    """Merge settings into the studio's own config.json, preserving the rest."""
    path = ROOT / 'config.json'
    try:
        current = json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        current = {}
    current.update({k: v for k, v in values.items() if v is not None})
    with io.open(path, 'w', encoding='utf-8', newline='\n') as handle:
        handle.write(json.dumps(current, indent=2) + '\n')
    return path


def interactive_console():
    """Whether there is a person on the other end of stdin to answer a question.

    Setup also runs from Start.bat with a console attached and from scripts with
    none. Asking in the second case blocks forever on a machine nobody is looking
    at, so the question is only put when it can actually be answered.
    """
    try:
        return bool(sys.stdin) and sys.stdin.isatty()
    except (AttributeError, ValueError):
        return False


def ask(question, default=None):
    """Prompt, or take the default when nothing is attached to answer."""
    suffix = ' [' + default + ']' if default else ''
    try:
        reply = input(question + suffix + ' ').strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return default
    return reply or default


def command_models(path=None, interactive=True):
    """Point the studio at models that already exist on this PC."""
    if path is None and interactive:
        say('Do you already have ComfyUI models on this PC?')
        say('Give the folder and they will be used where they are - nothing is')
        say('copied, moved or written there. Leave blank to skip.')
        path = ask('  Models folder:')
    if not path:
        say('No folder given. The starter pack would be downloaded instead.')
        return 1

    found = looks_like_models_folder(path)
    if not found:
        say('That does not look like a ComfyUI models folder.', 1)
        say('Expected to find subfolders such as checkpoints, loras or vae inside it.', 1)
        return 1

    say('Found ' + str(found['weights']) + ' model file(s) in ' + str(found['path']), 1)
    say('folders: ' + ', '.join(found['folders'][:8]), 1)

    written = None
    if (COMFY_DIR / 'ComfyUI').is_dir():
        written = write_extra_model_paths(found['path'])
        say('our ComfyUI now reads them from there: ' + str(written.name), 1)
    else:
        say('ComfyUI is not installed yet - this will be written when it is.', 1)

    update_studio_config(models_path=str(found['path']).replace('\\', '/'),
                         lora_paths=[str(found['path'] / 'loras').replace('\\', '/')])
    state = load_state()
    state['modelsPath'] = str(found['path'])
    save_state(state)
    say('Saved. Nothing in that folder was changed.', 1)
    return 0


# ---------------------------------------------------------------- commands ---

def command_plan():
    manifest = load_manifest()
    state = load_state()
    # The orchestrator may not be importable before setup has run - it needs
    # cryptography - so the tier table is optional here and the description
    # degrades to just the card rather than failing.
    chat_models = {}
    default_model = None
    try:
        import orchestrator
        chat_models = orchestrator.CHAT_MODELS
        default_model = orchestrator.DEFAULT_CHAT_MODEL
    except Exception:                                      # noqa: BLE001 - optional
        pass
    profile = tuning.build_profile(chat_models, default_model=default_model)
    say('This PC')
    say(tuning.describe(profile), 1)
    say('')
    say('Setup would:')
    for key, title, handler, _critical in STEPS:
        say(title)
        handler(manifest, state, dry_run=True)
    say('')
    say('Nothing above has happened. Run `python app/setup.py install` to do it.')
    return 0


def command_verify():
    """Ask every address in the manifest whether it is still there."""
    manifest = load_manifest()
    problems = 0
    say('ComfyUI')
    spec = manifest['comfyui']
    for vendor, asset_name in spec['assets'].items():
        asset = resolve_release_asset(spec['release_api'], asset_name)
        if asset:
            say('%-42s %s' % (asset_name, fetch.human(asset.get('size'))), 1)
        else:
            say('%-42s MISSING FROM LATEST RELEASE' % asset_name, 1)
            problems += 1

    say('')
    say('Custom nodes')
    for node in manifest['nodes']:
        url = ('https://codeload.github.com/' + node['repo']
               + '/zip/refs/heads/' + node['branch'])
        info = fetch.head(url)
        flag = 'ok' if info['ok'] else str(info.get('status'))
        say('%-32s %-20s %s' % (node['name'], node['repo'], flag), 1)
        if not info['ok']:
            problems += 1

    say('')
    say('Models')
    for entry in manifest_downloads(manifest):
        if not entry.get('url'):
            say('%-46s no address set' % entry['file'], 1)
            problems += 1
            continue
        info = fetch.head(entry['url'])
        say('%-46s %s' % (entry['file'],
                          'ok ' + fetch.human(info.get('size')) if info['ok']
                          else 'UNREACHABLE (%s)' % info.get('status')), 1)
        if not info['ok']:
            problems += 1

    say('')
    say(('Everything checks out.' if not problems
         else str(problems) + ' thing(s) need attention before this can install.'))
    return 1 if problems else 0


def command_install(only=None):
    manifest = load_manifest()
    state = load_state()
    DOWNLOADS.mkdir(parents=True, exist_ok=True)
    chosen = set(only.split(',')) if only else None
    failed = []
    for key, title, handler, critical in STEPS:
        if chosen and key not in chosen:
            continue
        if key in state.get('done', []):
            say(title + ': already done')
            continue
        say(title)
        try:
            ok = handler(manifest, state, dry_run=False)
        except Exception as exc:                           # noqa: BLE001 - reported per step
            say('failed: ' + str(exc), 1)
            ok = False
        if ok:
            state.setdefault('done', []).append(key)
            save_state(state)
            continue
        failed.append(key)
        if critical:
            say('', 1)
            say('Everything after this needs ' + title + ', so setup is stopping', 1)
            say('here rather than piling up errors that are all caused by it.', 1)
            break
    if failed:
        say('')
        say('Stopped with ' + ', '.join(failed) + ' unfinished. Nothing is lost - '
            'run setup again and it carries on from here.')
        return 1
    say('')
    say('Setup finished.')
    return 0


def command_status():
    """Exit 0 only when every step has finished; name what is left otherwise.

    Start.bat used to decide this by looking for comfy/ComfyUI/main.py, which
    answers a different question. When setup stopped after ComfyUI - as it did
    the first time this ran on a real machine - that file existed, so every later
    launch went straight to the studio and setup never ran again. The install was
    stuck one step in, permanently, while the promise on screen was that running
    it again would carry on.

    STEPS is the list, so this stays right when steps are added.
    """
    done = set(load_state().get('done') or [])
    remaining = [title for key, title, _, _ in STEPS if key not in done]
    if not remaining:
        return 0
    say('Not finished: ' + ', '.join(remaining))
    return 1


def main(argv):
    command = argv[1] if len(argv) > 1 else 'plan'
    if command == 'plan':
        return command_plan()
    if command == 'verify':
        return command_verify()
    if command == 'status':
        return command_status()
    if command == 'models':
        path = argv[2] if len(argv) > 2 else None
        return command_models(path)
    if command == 'install':
        only = None
        if '--only' in argv:
            only = argv[argv.index('--only') + 1]
        return command_install(only)
    say(__doc__.strip().splitlines()[0])
    say('')
    say('Commands: plan, verify, status, models <folder>, install')
    return 2


if __name__ == '__main__':
    sys.exit(main(sys.argv))

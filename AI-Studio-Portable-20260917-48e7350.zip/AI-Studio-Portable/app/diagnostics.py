"""Logging and problem reports.

Three rules, in the order they matter:

1. A prompt, a chat message or a search query never enters a log. Not stripped
   afterwards - never written. See `redacted` in orchestrator.py. A filter
   applied later is one missed case away from leaking; text that was never
   written cannot leak however the file is handled afterwards.

2. No absolute path leaves this machine intact. Someone who unzips the studio
   onto their Desktop has their real name in every path it touches, and a
   traceback is made of paths. `scrub` rewrites them as they are written, so the
   file on disk is already safe - not safe only if something remembers to clean
   it on the way out.

3. Nothing is transmitted. A report is written to a file the user can read in
   full and then send wherever they choose. When that changes, the thing to keep
   is that they see the whole payload first: a privacy promise nobody can check
   is just a promise.
"""

import io
import json
import locale
import logging
import os
import platform
import re
import sys
import time
from logging.handlers import RotatingFileHandler
from pathlib import Path

HERE = Path(__file__).resolve().parent
STUDIO = HERE.parent
LOG_DIR = STUDIO / 'data' / 'logs'
LOG_FILE = LOG_DIR / 'studio.log'
REPORT_DIR = STUDIO / 'data' / 'reports'
INSTALL_ID_FILE = STUDIO / 'data' / 'install-id.txt'


# ----------------------------------------------------------------- scrub ---
#
# Built once. These run on every log line, so they are compiled patterns over a
# fixed list rather than anything clever.

def _replacements():
    """(pattern, replacement) for every path that identifies this machine."""
    pairs = []
    # Longest first: the install root often sits inside the user profile, and
    # replacing the profile first would leave a half-rewritten path behind.
    candidates = [
        (STUDIO, '<studio>'),
        (Path(os.environ.get('USERPROFILE') or Path.home()), '<user>'),
        (Path(os.environ.get('LOCALAPPDATA') or Path.home() / 'AppData/Local'), '<localappdata>'),
        (Path(os.environ.get('APPDATA') or Path.home() / 'AppData/Roaming'), '<appdata>'),
        (Path(os.environ.get('TEMP') or '/tmp'), '<temp>'),
    ]
    seen = set()
    for path, token in sorted(candidates, key=lambda item: len(str(item[0])), reverse=True):
        try:
            text = str(path.resolve())
        except OSError:
            text = str(path)
        if not text or text in seen or len(text) < 4:
            continue
        seen.add(text)
        # Three spellings of the same path, because all three occur. Forward
        # slashes because a config file and a URL use them. Doubled backslashes
        # because a traceback prints filenames through repr(), and
        # "C:\\Users\\name" does not match a pattern built from "C:\Users\name" -
        # which left the profile prefix intact in exception text until a test
        # caught it.
        for variant in {text, text.replace('\\', '/'), text.replace('\\', '\\\\')}:
            pairs.append((re.compile(re.escape(variant), re.IGNORECASE), token))
    # The account name on its own, for the places a bare username appears -
    # a URL, a registry key, an error message naming the owner of a file.
    #
    # Two names, not one, and on the machine this was written on they differ:
    # USERNAME was the person's actual first name while the profile folder was
    # something else entirely. Scrubbing either alone leaves the other in.
    names = {(os.environ.get('USERNAME') or '').strip(),
             (os.environ.get('USER') or '').strip()}
    profile = os.environ.get('USERPROFILE')
    if profile:
        names.add(Path(profile).name.strip())
    for name in names:
        # Short names are skipped: a two-letter account name would match inside
        # ordinary words and turn the log into nonsense. A long one that happens
        # to be an English word is still replaced - an unreadable line is a
        # cheaper mistake than a line naming the user.
        if len(name) > 2:
            pairs.append((re.compile(r'\b' + re.escape(name) + r'\b', re.IGNORECASE), '<user>'))
    return pairs


_SCRUB = _replacements()


def scrub(text):
    """Rewrite anything that names this machine or its owner."""
    if not text:
        return text
    text = str(text)
    for pattern, token in _SCRUB:
        text = pattern.sub(token, text)
    return text


class ScrubbingFormatter(logging.Formatter):
    """Formats a record, then rewrites identifying paths out of the result.

    On the formatted string rather than the arguments, because a traceback is
    attached to the record and only appears once the record is formatted.
    """

    def format(self, record):
        return scrub(super().format(record))


# ------------------------------------------------------------------ setup ---

def start_logging(level=logging.INFO):
    """Send this process's logging to data/logs/studio.log.

    The studio wrote no log at all before this. logging was configured only
    under `if __name__ == '__main__'` in the orchestrator, which is the entry
    point the cloud worker used and not the one the server imports - so every
    warning the engine raised went nowhere, and the only account of a failure
    was whatever was still on screen in a console window that had since closed.
    """
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    root = logging.getLogger()
    if any(getattr(h, 'studio_log', False) for h in root.handlers):
        return LOG_FILE
    handler = RotatingFileHandler(LOG_FILE, maxBytes=2 * 1024 * 1024,
                                  backupCount=3, encoding='utf-8')
    handler.setFormatter(ScrubbingFormatter(
        '%(asctime)s %(levelname)-7s %(name)s: %(message)s', '%Y-%m-%d %H:%M:%S'))
    handler.studio_log = True
    root.addHandler(handler)
    if root.level > level or root.level == logging.NOTSET:
        root.setLevel(level)
    return LOG_FILE


def install_id():
    """A random id for this installation, so repeated reports can be grouped.

    Random, not derived from the hardware or the account: two installations on
    one PC are two ids, and the id says nothing about the machine. Deleting the
    file is all it takes to become a different installation.
    """
    try:
        existing = INSTALL_ID_FILE.read_text(encoding='utf-8').strip()
        if existing:
            return existing
    except OSError:
        pass
    import uuid
    new = str(uuid.uuid4())
    try:
        INSTALL_ID_FILE.parent.mkdir(parents=True, exist_ok=True)
        INSTALL_ID_FILE.write_text(new + '\n', encoding='utf-8')
    except OSError:
        return 'unsaved-' + new
    return new


def reset_install_id():
    """Forget the id and take a new one."""
    try:
        INSTALL_ID_FILE.unlink(missing_ok=True)
    except OSError:
        pass
    return install_id()


# ---------------------------------------------------------------- reports ---
#
# What may be collected, and what may not, decided here once rather than at each
# call site. The deny list is the important half: everything on it is something
# the studio holds and a report must never carry.

NEVER_COLLECTED = (
    'prompts and negative prompts',
    'chat messages, replies and memories',
    'images, masks and thumbnails',
    'names of models, LoRAs or files the user added',
    'the studio key, and anything derived from it',
    'absolute paths, account names and the computer name',
)


def _software():
    return {
        'version': _git_describe(),
        'python': platform.python_version(),
        'os': platform.platform(),
        'osBuild': platform.version(),
        'arch': platform.machine(),
        'locale': (locale.getdefaultlocale() or (None, None))[0],
    }


def _git_describe():
    """Which build this is. Read from the file setup writes, never from git.

    A release is a git archive, so there is no repository beside it to ask - and
    shelling out to git on a machine that has none is a needless failure inside
    an error report.
    """
    try:
        text = (STUDIO / 'VERSION').read_text(encoding='utf-8')
    except OSError:
        return 'unknown'
    for line in text.splitlines():
        if line.lower().startswith('commit'):
            commit = line.split(None, 1)[-1].strip()
            # A checkout still holds the literal placeholder; only an archive has
            # it substituted. Saying so is more useful in a report than a string
            # of dollar signs, and distinguishes a release from a working copy.
            if commit.startswith('$Format'):
                return 'source checkout'
            return commit[:12]
    return 'unknown'


def _hardware():
    try:
        sys.path.insert(0, str(HERE))
        import tuning
        probe = tuning.probe_hardware()
    except Exception as exc:                               # noqa: BLE001 - never fail a report
        return {'error': str(exc)[:120]}
    # Only the fields that describe the card, not what is currently on it.
    return {'gpu': probe.get('gpu'), 'vramTotalMib': probe.get('vramTotalMib'),
            'ramFreeMib': probe.get('ramFreeMib'), 'source': probe.get('source')}


def _log_tail(lines=400):
    """The end of the log, already scrubbed when it was written."""
    try:
        text = LOG_FILE.read_text(encoding='utf-8', errors='replace')
    except OSError:
        return ['(no log file yet)']
    # Scrubbed again on the way out. The file is written scrubbed, so this is
    # belt and braces - and it also covers a log carried over from a build that
    # predates the scrubbing formatter.
    return [scrub(line) for line in text.splitlines()[-lines:]]


def build_report(note=None, recent_errors=None):
    """Everything a problem report contains. Nothing is sent; this is data.

    `note` is what the user typed. It is theirs and goes in as written - they
    wrote it in order to send it. Everything else is collected, and the list
    above says what is refused.
    """
    return {
        'kind': 'ai-studio-portable-report',
        'created': time.strftime('%Y-%m-%d %H:%M:%S'),
        'installId': install_id(),
        'note': (note or '').strip()[:4000] or None,
        'software': _software(),
        'hardware': _hardware(),
        'recentErrors': [scrub(str(e))[:500] for e in (recent_errors or [])][:20],
        'log': _log_tail(),
        'neverCollected': list(NEVER_COLLECTED),
    }


def render_report(report):
    """The report as the text the user reads and sends. Readable on purpose.

    JSON with the log folded in as lines would be technically the same content
    and nobody would read it, and a payload nobody reads is a privacy promise
    nobody can check.
    """
    out = ['AI Studio Portable - problem report',
           '=' * 62,
           'Created    : ' + report['created'],
           'Install id : ' + report['installId'],
           'Version    : ' + report['software'].get('version', '?'),
           'OS         : ' + str(report['software'].get('os')),
           'Python     : ' + str(report['software'].get('python')),
           'GPU        : ' + str(report['hardware'].get('gpu')),
           'VRAM (MiB) : ' + str(report['hardware'].get('vramTotalMib')),
           '']
    if report.get('note'):
        out += ['What the user said', '-' * 62, report['note'], '']
    if report.get('recentErrors'):
        out += ['Recent job errors', '-' * 62]
        out += ['  ' + line for line in report['recentErrors']]
        out += ['']
    out += ['Not included in this file', '-' * 62]
    out += ['  - ' + item for item in report['neverCollected']]
    out += ['', 'Log (most recent last)', '-' * 62]
    out += report['log']
    out += ['']
    return '\n'.join(out)


def write_report(report):
    """Save the report and return its path."""
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    name = 'report-' + time.strftime('%Y%m%d-%H%M%S') + '.txt'
    path = REPORT_DIR / name
    with io.open(path, 'w', encoding='utf-8', newline='\n') as handle:
        handle.write(render_report(report))
    return path


def log_environment(extra=None):
    """Write one line describing this machine, at every start.

    Without it a healthy run logs nothing at all, so the first report from a
    working install arrives with an empty log section - and there is no way to
    tell "logging is fine, nothing went wrong" from "logging is broken". It also
    means every report carries the baseline the failure happened against, which
    is most of what the log is read for.
    """
    software, hardware = _software(), _hardware()
    logging.info(
        'Studio starting | version=%s | python=%s | os=%s | gpu=%s | vram=%sMiB | ram_free=%sMiB%s',
        software.get('version'), software.get('python'), software.get('os'),
        hardware.get('gpu'), hardware.get('vramTotalMib'), hardware.get('ramFreeMib'),
        ''.join(' | %s=%s' % (k, v) for k, v in sorted((extra or {}).items())))


# ----------------------------------------------------------------- reveal ---

DATA_DIR = STUDIO / 'data'


def reveal(path):
    """Open the file manager with `path` selected. Returns True if it was asked.

    Only ever inside data/. The path arrives from the browser, and the browser
    is only trusted to name a file, not to choose one - an endpoint that opened
    whatever it was handed would be a way to launch Explorer on any path on the
    machine. Resolved and checked against the data folder before anything runs.

    explorer.exe exits 1 on success often enough that its return code is not
    worth reading; the call either starts or raises.
    """
    try:
        target = Path(path).resolve()
        root = DATA_DIR.resolve()
    except OSError:
        return False
    if not (target == root or root in target.parents):
        logging.warning('Refusing to reveal a path outside the data folder')
        return False
    if not target.exists():
        return False
    import subprocess
    try:
        if sys.platform == 'win32':
            # One argument, comma and path joined: explorer does not accept
            # /select and the path as two separate arguments.
            subprocess.Popen(['explorer', '/select,' + str(target)])
        elif sys.platform == 'darwin':
            subprocess.Popen(['open', '-R', str(target)])
        else:
            subprocess.Popen(['xdg-open', str(target.parent)])
        return True
    except Exception as exc:                               # noqa: BLE001 - never fatal
        logging.warning('Could not open the file manager: %s', exc)
        return False


def latest_report():
    """The most recently written report, or None."""
    try:
        reports = sorted(REPORT_DIR.glob('report-*.txt'))
    except OSError:
        return None
    return reports[-1] if reports else None

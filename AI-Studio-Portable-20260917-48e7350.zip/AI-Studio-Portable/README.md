# AI Studio Portable

A single-folder desktop studio for local image generation and chat. It provides
the interface; ComfyUI and llama.cpp do the work, both running on your own
machine. Nothing is sent anywhere.

Four modes in one workspace:

- **Text to image** — prompt, presets, LoRA layers, sampler and resolution control
- **Image to image** — denoise-controlled variation from a reference
- **Inpaint** — masked edits with a brush editor, powered by LanPaint
- **Chat** — a local uncensored assistant with vision, memory, web search and the
  ability to generate images into the conversation

**Status: pre-alpha.** The interface, the orchestrator and the local server that
connects them all work, and the studio installs and runs on a clean Windows
machine. What has not been proven is a full install followed by a real
generation on a PC with a GPU and nothing else on it. See
[docs/HANDOFF.md](docs/HANDOFF.md).

## Getting started

Double-click **`Start.bat`**.

That is the whole prerequisite list. You do not need Python, git, or anything
else installed first — the studio fetches its own private Python (about 60 MB)
the first time it runs, and everything it installs lives inside this folder.

The first run explains what it is about to download and asks before starting.
After that, `Start.bat` is the only thing you ever need: it sets up if setting up
is needed, then opens the studio. Every step can be interrupted and resumed, so a
download that dies at 80% picks up from 80% next time.

There are three ways to get models, and you can mix them:

- let the installer download them
- point the studio at a folder you already have, read-only
- drop files straight into `models\` - there is a folder for each kind and a
  README in there saying what goes where

## Requirements

- Windows 10 or 11
- An NVIDIA GPU. 12 GB VRAM is the reference configuration; 8 GB restricts which
  chat models can load, and image generation above 2 MP gets tight. The studio
  measures your card at startup and offers only what will actually fit
- ~10 GB of disk for the application, plus whatever the models you choose need
  (a minimal image-only setup is around 20 GB; a full one exceeds 100 GB)

AMD and Apple Silicon are not supported and are not planned.

## Already have ComfyUI?

It will not be touched. AI Studio Portable installs its own private ComfyUI and
its own Python environment, then asks where your model folders are and reads them
where they sit — read-only, never copied, never moved. Your existing install, its
custom nodes and its outputs are left exactly as they are.

Sharing an install rather than a model folder is what breaks people's setups, so
this build does not offer it.

## Layout

```
AIStudioPortable/
├─ app/           server, orchestrator, model registry, setup wizard
├─ web/           the interface — plain HTML, CSS and JS, no build step
├─ workflows/     ComfyUI API-format graph templates
├─ scripts/       release and maintenance tooling
├─ docs/          handoff and design notes
├─ runtime/       embedded Python, torch, llama.cpp binaries   (not in git)
├─ comfy/         our private ComfyUI and its custom nodes      (not in git)
├─ models/        drop models in here, or point at a folder you have
├─ data/          database, generated images, settings          (not in git)
└─ logs/                                                        (not in git)
```

Everything in `data/` and `models/` is yours. Everything above them is replaced
wholesale by an update, which is why updates can be an unzip over the top.

## Updates

The studio checks once at startup and says nothing unless there is a newer
build. Installing is a second, deliberate press: the release is downloaded,
checked against a published SHA-256, unpacked to a staging folder and inspected
before a single file is replaced. Your images, models, settings and
conversations are never touched - a release contains only the program.

Set `update_url` to `""` in `config.json` to switch checking off entirely.

## Licence

Source-available, not open source — see [LICENSE](LICENSE). If you received a
copy, you keep it: the grant is perpetual for the copy you have.

Bundled third-party components keep their own licences, recorded in
[NOTICE.md](NOTICE.md). Model weights are not redistributed; you download those
yourself from their publishers.

# Third-party components

AI Studio Portable runs alongside several third-party projects. This file records
what they are, how they are licensed, and which constraints those licenses place
on this product. **It is a working engineering record, not legal advice — have a
lawyer review it before charging money for this software.**

## The rule that keeps our own code ours

ComfyUI is GPL-3.0. Our orchestrator talks to it **only over HTTP**
(`http://127.0.0.1:8189`), as a separate process. That arm's-length boundary is
what keeps AI Studio Portable's own source from being a derivative work of
ComfyUI, and therefore from having to be GPL itself.

**Never `import` ComfyUI modules, custom-node modules, or anything from the
`comfy/` tree into our Python.** If that boundary is crossed, the licensing
analysis for this whole product changes. The same applies to llama.cpp, which we
drive through its HTTP server rather than linking against.

## Bundled

| Component | License | Obligation when we redistribute |
|---|---|---|
| ComfyUI | GPL-3.0 | Ship the license text; make the (unmodified) source available. Selling is permitted. |
| LanPaint | GPL-3.0 | Same as above. Provides the masked-edit nodes. |
| ComfyUI-SeedVR2_VideoUpscaler | Apache-2.0 | Ship the license and NOTICE; state any changes. |
| ComfyUI-Krea2T-Enhancer | MIT | Ship the license text. |
| KreaSeedVarianceEnhancer | MIT-0 | No attribution required; ship it anyway. |
| rgthree-comfy | MIT | Ship the license text. Optional — quality-of-life nodes only. |
| llama.cpp (`llama-server`) | MIT | Ship the license text. |
| marked, DOMPurify, pdf.js, SheetJS | MIT / Apache-2.0 | Ship the license texts in `web/js/vendor/`. |

## Deliberately NOT bundled

### RES4LYF — the Clownshark samplers

RES4LYF is AGPL-3.0 **plus** an added commercial rider:

> The use of this software or any derivative work for the purpose of providing a
> commercial service [...] is strictly prohibited without obtaining permission
> and/or a separate commercial license from the copyright holder. This includes
> any service that charges users directly or indirectly for access to this
> software's functionality, whether standalone or integrated into a larger
> product.

That last clause is aimed squarely at a paid product that integrates it. Because
AI Studio Portable is free now but may be monetized later, **RES4LYF is treated
as an optional component the user installs themselves**, never as something we
ship or require.

Consequences to honour in the code:

- The setup wizard may *offer* to install it, clearly labelled as third-party and
  non-commercial, but must not install it silently or by default.
- The Clownshark sampler options (`clownshark_2pass`, `linear/euler`) must be
  hidden when the `ClownsharKSampler_Beta` node is absent, not offered and then
  failed. The orchestrator's `SITE_SAMPLERS` tuple still lists them.
- No shipped preset, workflow template or default may depend on them.
- If monetization happens, revisit this. The clean options are to drop the
  integration entirely or to obtain a commercial license from the author.

## Model weights

No model weights are redistributed. Every checkpoint, LoRA, VAE, text encoder and
GGUF is downloaded by the user, from the original publisher, under that
publisher's own licence and the user's own account. Several Civitai models are
non-commercial or gated behind an account with adult content enabled; that is the
user's relationship with Civitai, not ours.

The downloader must never proxy, mirror or cache weights on infrastructure we
control — that would make us a redistributor and pull every model licence into
this table.

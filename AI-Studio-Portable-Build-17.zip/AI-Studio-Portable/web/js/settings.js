(function () {
    'use strict';

    // The settings page.
    //
    // Before this, settings lived in three places: a models panel, a theme
    // dialog, and config.json - a file somebody had to find, edit by hand and
    // get the JSON right in. In practice that meant nothing was ever changed,
    // and the setting that matters most on a small graphics card could not be
    // changed at all because nothing read it.
    //
    // The controls are built from what the server says the settings are, not
    // listed again here. Two hand-maintained copies of one list is how a
    // setting ends up saveable but invisible, or visible and ignored.
    //
    // Models and colour schemes keep their own panels and are reached from
    // here rather than rebuilt inside it: both are richer than a row with a
    // control on the end, and moving them would have meant rewriting working
    // interfaces to reach a tidier menu.

    const dialog = document.querySelector('#settings-dialog');
    const openBtn = document.querySelector('#open-settings');
    if (!dialog || !openBtn) return;

    const tabsEl = document.querySelector('#settings-tabs');
    const bodyEl = document.querySelector('#settings-body');
    const statusEl = document.querySelector('#settings-status');
    const saveBtn = document.querySelector('#settings-save');
    const resetBtn = document.querySelector('#settings-reset');
    const closeBtn = document.querySelector('#settings-close');

    // Buttons that open a panel which already exists, rather than editing a
    // value. Keyed by section, so a section can hold both - Models has a
    // setting of its own and then hands off to the panel that does the rest.
    const SECTION_LINKS = {
        models: [
            { label: 'Models & LoRAs', target: '#open-models-panel',
              note: 'Assign a model you added to a pipeline, set a LoRA’s '
                  + 'trigger words and default strength, and see the folders '
                  + 'the studio looks in.' }
        ],
        appearance: [
            { label: 'Colour schemes', target: '#theme-editor-open',
              note: 'Sixteen schemes, one for light and one for dark. The sun '
                  + 'and moon button switches between them.' }
        ],
        help: [
            { label: 'User manual (PDF)', action: () => window.open('/api/studio?action=manual-pdf', '_blank'),
              note: 'Publication-grade user guide covering all four studio modes, model management, hardware tuning, configuration, and troubleshooting.' },
            { label: 'Version log', target: '#build-badge',
              note: 'Detailed history of what changed in each build.' }
        ]
    };

    // Sections with no settings of their own, so the server does not know
    // about them.
    const LINK_ONLY_SECTIONS = [
        { key: 'appearance', label: 'Appearance', help: null },
        { key: 'help', label: 'Help & Manual', help: 'Official documentation and build history for AI Studio Portable.' }
    ];

    let spec = null;            // what the server told us the settings are
    let draft = {};             // edits not yet saved
    let active = null;          // which section is showing

    function dirty() {
        if (!spec) return false;
        return Object.keys(draft).some(key => draft[key] !== spec.values[key]);
    }

    function setStatus(text, tone) {
        if (!statusEl) return;
        statusEl.textContent = text || '';
        statusEl.dataset.tone = tone || '';
    }

    function field(entry) {
        const row = document.createElement('div');
        row.className = 'settings-field';

        const label = document.createElement('label');
        label.className = 'settings-label';
        label.setAttribute('for', 'setting-' + entry.key);
        label.textContent = entry.label;

        let input;
        if (entry.kind === 'bool') {
            input = document.createElement('input');
            input.type = 'checkbox';
            input.checked = Boolean(draft[entry.key]);
            input.addEventListener('change', () => {
                draft[entry.key] = input.checked;
                onEdit();
            });
            row.classList.add('is-toggle');
        } else if (entry.kind === 'choice') {
            input = document.createElement('select');
            for (const option of entry.options || []) {
                const opt = document.createElement('option');
                opt.value = option;
                // An empty option is the "not set" case, and "" reads as a bug.
                opt.textContent = entry.labels?.[option]
                    ?? (option === ''
                        ? 'Detect automatically'
                        : option.charAt(0).toUpperCase() + option.slice(1));
                opt.selected = option === draft[entry.key];
                input.append(opt);
            }
            input.addEventListener('change', () => {
                draft[entry.key] = input.value;
                onEdit();
            });
        } else if (entry.kind === 'number') {
            input = document.createElement('input');
            input.type = 'number';
            if (entry.min !== null) input.min = String(entry.min);
            if (entry.max !== null) input.max = String(entry.max);
            input.value = String(draft[entry.key]);
            input.addEventListener('input', () => {
                draft[entry.key] = input.value;
                onEdit();
            });
        } else {
            input = document.createElement('input');
            input.type = 'text';
            input.value = String(draft[entry.key] ?? '');
            input.spellcheck = false;
            input.addEventListener('input', () => {
                draft[entry.key] = input.value;
                onEdit();
            });
        }
        input.id = 'setting-' + entry.key;
        input.className = 'settings-input';

        const head = document.createElement('div');
        head.className = 'settings-field-head';
        head.append(label, input);
        row.append(head);

        if (entry.help) {
            const help = document.createElement('p');
            help.className = 'setting-note settings-help';
            help.textContent = entry.help;
            row.append(help);
        }
        if (draft[entry.key] !== entry.default) {
            const changed = document.createElement('span');
            changed.className = 'settings-changed';
            changed.textContent = 'changed from default';
            head.append(changed);
        }
        return row;
    }

    function machineNote() {
        const machine = spec.machine || {};
        if (!machine.gpu) return null;
        const note = document.createElement('p');
        note.className = 'setting-note settings-machine';
        const total = machine.vramTotalMib
            ? `, ${(machine.vramTotalMib / 1024).toFixed(1)} GB of video memory`
            : '';
        note.textContent = `This PC: ${machine.gpu}${total}.`;
        return note;
    }

    function sectionLinks(key) {
        const wrap = document.createDocumentFragment();
        for (const link of SECTION_LINKS[key] || []) {
            const row = document.createElement('div');
            row.className = 'settings-field';
            const button = document.createElement('button');
            button.type = 'button';
            button.className = 'button';
            button.textContent = 'Open ' + link.label;
            button.addEventListener('click', () => {
                if (link.action) {
                    link.action();
                    return;
                }
                const target = document.querySelector(link.target);
                // Closed first: two modal dialogs open at once leaves the one
                // underneath unreachable until the top one is dismissed, which
                // looks like the studio has frozen.
                dialog.close();
                target?.click();
            });
            const note = document.createElement('p');
            note.className = 'setting-note settings-help';
            note.textContent = link.note;
            row.append(button, note);
            wrap.append(row);
        }
        return wrap;
    }

    function renderBody() {
        bodyEl.textContent = '';
        const fields = spec.fields.filter(entry => entry.section === active);
        // Reset only means something where there is something to reset.
        resetBtn.hidden = fields.length === 0;

        const section = [...(spec.sections || []), ...LINK_ONLY_SECTIONS]
            .find(item => item.key === active);
        if (section?.help) {
            const help = document.createElement('p');
            help.className = 'setting-note';
            help.textContent = section.help;
            bodyEl.append(help);
        }
        if (active === 'performance') {
            const note = machineNote();
            if (note) bodyEl.append(note);
        }
        for (const entry of fields) {
            bodyEl.append(field(entry));
        }
        bodyEl.append(sectionLinks(active));
        if (active === 'advanced') {
            const paths = document.createElement('p');
            paths.className = 'setting-note settings-paths';
            paths.textContent = 'Settings are written to ' + spec.paths.config
                + '. Images are in ' + spec.paths.images + '.';
            bodyEl.append(paths);
        }
    }

    function renderTabs() {
        tabsEl.textContent = '';
        const sections = [...(spec.sections || []), ...LINK_ONLY_SECTIONS];
        for (const section of sections) {
            const tab = document.createElement('button');
            tab.type = 'button';
            tab.className = 'settings-tab';
            tab.textContent = section.label;
            tab.setAttribute('role', 'tab');
            tab.setAttribute('aria-selected', String(section.key === active));
            tab.addEventListener('click', () => {
                active = section.key;
                renderTabs();
                renderBody();
            });
            tabsEl.append(tab);
        }
    }

    function onEdit() {
        setStatus(dirty() ? 'Unsaved changes.' : '');
        saveBtn.disabled = !dirty();
        renderTabs();
        // Redrawn so the "changed from default" marks follow the edit. The
        // focused control is put back afterwards, or typing in a text box
        // would lose the cursor on every keystroke.
        const focused = document.activeElement?.id;
        const caret = document.activeElement?.selectionStart;
        renderBody();
        if (focused) {
            const again = document.getElementById(focused);
            if (again) {
                again.focus();
                if (caret !== null && caret !== undefined && again.setSelectionRange) {
                    try { again.setSelectionRange(caret, caret); } catch (error) { /* not a text input */ }
                }
            }
        }
    }

    async function load() {
        setStatus('Loading…');
        try {
            const response = await fetch('/api/studio?action=settings');
            if (!response.ok) throw new Error('settings unavailable');
            spec = await response.json();
        } catch (error) {
            setStatus('Could not read the settings.', 'bad');
            return;
        }
        draft = { ...spec.values };
        active = active || (spec.sections?.[0]?.key ?? 'performance');
        setStatus('');
        saveBtn.disabled = true;
        renderTabs();
        renderBody();
    }

    saveBtn?.addEventListener('click', async () => {
        saveBtn.disabled = true;
        setStatus('Saving…');
        const changed = {};
        for (const key of Object.keys(draft)) {
            if (draft[key] !== spec.values[key]) changed[key] = draft[key];
        }
        try {
            const response = await fetch('/api/studio?action=save-settings', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ values: changed })
            });
            const result = await response.json().catch(() => ({}));
            if (!response.ok) {
                setStatus(result.error || 'That could not be saved.', 'bad');
                saveBtn.disabled = false;
                return;
            }
            spec.values = { ...spec.values, ...changed };
            draft = { ...spec.values };
            // Some of these are read once, when an engine starts. Saying which
            // beats a setting that looks applied and is not.
            setStatus(result.restartFor?.length
                ? 'Saved. Restart the studio for that to take effect.'
                : 'Saved.', 'good');
            renderTabs();
            renderBody();
        } catch (error) {
            setStatus('That could not be saved.', 'bad');
            saveBtn.disabled = false;
        }
    });

    resetBtn?.addEventListener('click', () => {
        for (const entry of spec.fields) {
            if (entry.section === active) draft[entry.key] = entry.default;
        }
        onEdit();
    });

    openBtn.addEventListener('click', async () => {
        if (!dialog.open) dialog.showModal();
        await load();
    });
    closeBtn?.addEventListener('click', () => dialog.close());
    dialog.addEventListener('click', event => {
        if (event.target === dialog) dialog.close();
    });
    // Closing with unsaved edits throws them away silently otherwise, and the
    // only clue is that the thing you changed did not change.
    dialog.addEventListener('cancel', event => {
        if (dirty() && !confirm('Close without saving your changes?')) {
            event.preventDefault();
        }
    });
}());

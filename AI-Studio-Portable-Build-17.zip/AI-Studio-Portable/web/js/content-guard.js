/* Mirrors sexual_minor_request() and unsafe_image_prompt() in app/orchestrator.py.
 *
 * This is a speed bump, not the boundary. The backend re-checks every job
 * right before the engine starts and is what actually enforces the limit -
 * see app/orchestrator.py and app/server.py's JobRunner. What this buys is
 * instant feedback in the composer instead of a round trip to learn a job
 * was always going to be refused.
 *
 * Keep the two wordlists in step. A change here without the matching change
 * in orchestrator.py (or the reverse) is a silent gap: either this stops
 * catching what the backend still refuses, or it starts refusing something
 * the backend was fine with, which is its own kind of bug.
 */
(function () {
    'use strict';

    var MINOR_WORDS =
        '\\bchild(?:ren|ish|like)?\\b|\\bkids?\\b|\\bminors?\\b|\\btoddlers?\\b|' +
        '\\binfants?\\b|\\bbabies\\b|\\bnewborns?\\b|\\bpre-?teens?\\b|\\btweens?\\b|' +
        '\\bschool-?girls?\\b|\\bschool-?boys?\\b|\\bschool-?kids?\\b|' +
        '\\bmiddle\\s?school|\\belementary\\s?school|\\bgrade\\s?school|' +
        '\\bprimary\\s?school|\\bkindergart|\\bpre-?school|\\bnursery\\s?school|' +
        '\\b(?:first|second|third|fourth|fifth|sixth|seventh|eighth)\\s+grader?\\b|' +
        '\\bunder-?aged?\\b|\\bunderage\\b|\\bjail-?bait\\b|\\bloli(?:ta|con)?\\b|' +
        '\\bshota(?:con)?\\b|\\btoddlercon\\b|\\bcp\\b|\\bpre-?pubescent\\b|' +
        '\\bprepubescent\\b|\\bpubescent\\b|\\bnot\\s+yet\\s+(?:a\\s+)?(?:woman|man)\\b';

    var MINOR_AGE =
        '\\b(?:aged?\\s*)?(?:[0-9]|1[0-7])\\s*[-\\s]?\\s*(?:years?[\\s-]*old|yo|y/o|yrs?)\\b' +
        '|\\b(?:is|was|she\'s|he\'s|they\'re|only|just|barely|turns?|turned)\\s+(?:[0-9]|1[0-7])\\b';

    var SEXUAL_WORDS =
        'sex(?:ual|ually|y)?|erotic|explicit|nude|nudity|naked|porn|nsfw|aroused|' +
        'orgasm|masturbat|genital|penis|vagina|breasts?|nipples?|areola|' +
        'fuck|blowjob|handjob|cum|horny|seduce|seduct|molest|rape|' +
        'undress|strip(?:ping|ped)?\\s*(?:naked|nude)|in\\s+bed\\s+with|' +
        'lose\\s+(?:her|his|their)\\s+virginity|virgin|' +
        'lingerie|bikini|topless|bottomless|panties|underwear|thong|' +
        'spread\\s+legs?|legs?\\s+spread|crotch|upskirt|cleavage|' +
        'suggestive|provocative|seductive|fetish|bdsm|hentai|ecchi';

    var MINOR_RE = new RegExp('(?:' + MINOR_WORDS + ')|(?:' + MINOR_AGE + ')', 'i');
    var SEXUAL_RE = new RegExp(SEXUAL_WORDS, 'i');

    // Same lines the backend uses, so a refusal reads the same wherever it fires.
    var MINOR_REFUSAL = 'I won\'t write that.';
    var MINOR_IMAGE_REFUSAL =
        'This prompt was refused. The studio does not generate sexual imagery ' +
        'involving anyone under 18. Nothing else is off limits - reword it if that ' +
        'is not what you meant.';

    function sexualMinorRequest(text) {
        if (!text) return false;
        var value = String(text);
        return MINOR_RE.test(value) && SEXUAL_RE.test(value);
    }

    function unsafeImagePrompt(prompt, negative, mode) {
        var text = [prompt || '', negative || ''].filter(Boolean).join(' ');
        if (!text.trim()) return null;
        if (!MINOR_RE.test(text)) return null;
        if (mode === 'inpaint' || mode === 'img2img') return MINOR_IMAGE_REFUSAL;
        if (SEXUAL_RE.test(text)) return MINOR_IMAGE_REFUSAL;
        return null;
    }

    window.StudioContentGuard = {
        sexualMinorRequest: sexualMinorRequest,
        unsafeImagePrompt: unsafeImagePrompt,
        MINOR_REFUSAL: MINOR_REFUSAL,
        MINOR_IMAGE_REFUSAL: MINOR_IMAGE_REFUSAL
    };
}());

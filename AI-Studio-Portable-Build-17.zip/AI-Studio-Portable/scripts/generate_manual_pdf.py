"""Generate a publication-grade, professionally styled User Manual PDF for AI Studio Portable.
"""
import os
import sys
import argparse
from pathlib import Path

from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.pdfgen import canvas
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether, HRFlowable
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch

# Derive repo root cleanly without any hardcoded machine paths
REPO_ROOT = Path(__file__).resolve().parent.parent
OUTPUT_PDF = REPO_ROOT / "USER_MANUAL.pdf"

# Palette definitions
NAVY_PRIMARY = colors.HexColor("#0F172A")    # Slate 900
INDIGO_ACCENT = colors.HexColor("#4338CA")   # Indigo 700
SKY_ACCENT = colors.HexColor("#0284C7")      # Sky 600
TEXT_MAIN = colors.HexColor("#1E293B")       # Slate 800
TEXT_MUTED = colors.HexColor("#64748B")      # Slate 500
BG_LIGHT = colors.HexColor("#F8FAFC")        # Slate 50
BORDER_LIGHT = colors.HexColor("#E2E8F0")    # Slate 200
SUCCESS_GREEN = colors.HexColor("#059669")   # Emerald 600
WARNING_AMBER = colors.HexColor("#D97706")   # Amber 600
CODE_BG = colors.HexColor("#0F172A")
CODE_TEXT = colors.HexColor("#E2E8F0")


class NumberedCanvas(canvas.Canvas):
    """Two-pass canvas to dynamically compute and stamp total page count,
    running headers, and running footers.
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        num_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self.draw_page_decorations(num_pages)
            canvas.Canvas.showPage(self)
        canvas.Canvas.save(self)

    def draw_page_decorations(self, page_count):
        self.saveState()
        self.setFont("Helvetica", 8)
        self.setFillColor(TEXT_MUTED)
        self.setStrokeColor(BORDER_LIGHT)
        self.setLineWidth(0.6)

        page_w, page_h = letter

        # Running header on pages > 1
        if self._pageNumber > 1:
            self.line(40, page_h - 38, page_w - 40, page_h - 38)
            self.drawString(40, page_h - 32, "AI STUDIO PORTABLE — OFFICIAL USER MANUAL")
            self.drawRightString(page_w - 40, page_h - 32, "LOCAL IMAGE GENERATION & CHAT")

        # Running footer on all pages
        self.line(40, 40, page_w - 40, 40)
        self.drawString(40, 28, "AI Studio Portable | 100% Local GPU Computing | Zero Cloud Telemetry")
        page_str = f"Page {self._pageNumber} of {page_count}"
        self.drawRightString(page_w - 40, 28, page_str)
        self.restoreState()


def create_callout(text, kind="note", styles=None):
    """Render a styled callout box with a colored left accent border."""
    if kind == "tip":
        border_c = SUCCESS_GREEN
        bg_c = colors.HexColor("#F0FDF4")
        prefix = "<b>TIP:</b> "
    elif kind == "warning":
        border_c = WARNING_AMBER
        bg_c = colors.HexColor("#FFFBEB")
        prefix = "<b>IMPORTANT:</b> "
    else:  # note
        border_c = INDIGO_ACCENT
        bg_c = colors.HexColor("#EEF2FF")
        prefix = "<b>NOTE:</b> "

    p = Paragraph(f"{prefix}{text}", styles['CalloutText'])
    t = Table([[p]], colWidths=[letter[0] - 80])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), bg_c),
        ('LINELEFT', (0, 0), (0, -1), 3.5, border_c),
        ('TOPPADDING', (0, 0), (-1, -1), 7),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 7),
        ('LEFTPADDING', (0, 0), (-1, -1), 12),
        ('RIGHTPADDING', (0, 0), (-1, -1), 12),
        ('BOX', (0, 0), (-1, -1), 0.5, BORDER_LIGHT),
    ]))
    return t


def create_code_block(code_text, styles=None):
    """Render a monospace code snippet with dark background."""
    formatted = code_text.strip().replace("\n", "<br/>").replace(" ", "&nbsp;")
    p = Paragraph(f"<font face='Courier' color='#E2E8F0' size='8'>{formatted}</font>", styles['CodeText'])
    t = Table([[p]], colWidths=[letter[0] - 80])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), CODE_BG),
        ('BOX', (0, 0), (-1, -1), 0.5, colors.HexColor("#334155")),
        ('TOPPADDING', (0, 0), (-1, -1), 8),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
        ('LEFTPADDING', (0, 0), (-1, -1), 10),
        ('RIGHTPADDING', (0, 0), (-1, -1), 10),
    ]))
    return t


def build_manual_pdf(dest_path=None):
    target = Path(dest_path) if dest_path else OUTPUT_PDF
    target.parent.mkdir(parents=True, exist_ok=True)

    doc = SimpleDocTemplate(
        str(target),
        pagesize=letter,
        leftMargin=40,
        rightMargin=40,
        topMargin=48,
        bottomMargin=48
    )

    base_styles = getSampleStyleSheet()

    # Custom Typography Styles
    styles = {
        'DocTitle': ParagraphStyle(
            'DocTitle',
            parent=base_styles['Normal'],
            fontName='Helvetica-Bold',
            fontSize=26,
            leading=30,
            textColor=colors.white,
            spaceAfter=6
        ),
        'DocSubtitle': ParagraphStyle(
            'DocSubtitle',
            parent=base_styles['Normal'],
            fontName='Helvetica',
            fontSize=13,
            leading=17,
            textColor=colors.HexColor('#C7D2FE'),
            spaceAfter=12
        ),
        'BadgeText': ParagraphStyle(
            'BadgeText',
            parent=base_styles['Normal'],
            fontName='Helvetica-Bold',
            fontSize=8.5,
            leading=11,
            textColor=colors.HexColor('#0F172A'),
            alignment=1
        ),
        'ChapterH1': ParagraphStyle(
            'ChapterH1',
            parent=base_styles['Normal'],
            fontName='Helvetica-Bold',
            fontSize=16,
            leading=20,
            textColor=NAVY_PRIMARY,
            spaceBefore=14,
            spaceAfter=8,
            keepWithNext=True
        ),
        'SectionH2': ParagraphStyle(
            'SectionH2',
            parent=base_styles['Normal'],
            fontName='Helvetica-Bold',
            fontSize=12,
            leading=16,
            textColor=INDIGO_ACCENT,
            spaceBefore=10,
            spaceAfter=5,
            keepWithNext=True
        ),
        'SectionH3': ParagraphStyle(
            'SectionH3',
            parent=base_styles['Normal'],
            fontName='Helvetica-Bold',
            fontSize=10,
            leading=14,
            textColor=NAVY_PRIMARY,
            spaceBefore=8,
            spaceAfter=3,
            keepWithNext=True
        ),
        'Body': ParagraphStyle(
            'Body',
            parent=base_styles['Normal'],
            fontName='Helvetica',
            fontSize=9,
            leading=13.5,
            textColor=TEXT_MAIN,
            spaceAfter=6
        ),
        'BodyBold': ParagraphStyle(
            'BodyBold',
            parent=base_styles['Normal'],
            fontName='Helvetica-Bold',
            fontSize=9,
            leading=13.5,
            textColor=TEXT_MAIN,
            spaceAfter=4
        ),
        'Bullet': ParagraphStyle(
            'Bullet',
            parent=base_styles['Normal'],
            fontName='Helvetica',
            fontSize=9,
            leading=13,
            textColor=TEXT_MAIN,
            leftIndent=12,
            firstLineIndent=-8,
            spaceAfter=3
        ),
        'CalloutText': ParagraphStyle(
            'CalloutText',
            parent=base_styles['Normal'],
            fontName='Helvetica',
            fontSize=8.5,
            leading=12.5,
            textColor=TEXT_MAIN
        ),
        'CodeText': ParagraphStyle(
            'CodeText',
            parent=base_styles['Normal'],
            fontName='Courier',
            fontSize=8,
            leading=11,
            textColor=CODE_TEXT
        ),
        'TableHead': ParagraphStyle(
            'TableHead',
            parent=base_styles['Normal'],
            fontName='Helvetica-Bold',
            fontSize=8.5,
            leading=11,
            textColor=colors.white
        ),
        'TableCell': ParagraphStyle(
            'TableCell',
            parent=base_styles['Normal'],
            fontName='Helvetica',
            fontSize=8,
            leading=11.5,
            textColor=TEXT_MAIN
        ),
        'TableCellBold': ParagraphStyle(
            'TableCellBold',
            parent=base_styles['Normal'],
            fontName='Helvetica-Bold',
            fontSize=8,
            leading=11.5,
            textColor=TEXT_MAIN
        )
    }

    story = []
    content_w = letter[0] - 80

    # =========================================================================
    # COVER / HEADER HERO BANNER
    # =========================================================================
    hero_p = [
        Spacer(1, 4),
        Paragraph("AI STUDIO PORTABLE", styles['DocTitle']),
        Paragraph("Comprehensive User Guide & Technical Operations Manual", styles['DocSubtitle']),
        Spacer(1, 2)
    ]
    hero_cell = Table([[hero_p]], colWidths=[content_w])
    hero_cell.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#1E1B4B')),
        ('TOPPADDING', (0, 0), (-1, -1), 16),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 16),
        ('LEFTPADDING', (0, 0), (-1, -1), 16),
        ('RIGHTPADDING', (0, 0), (-1, -1), 16),
        ('BOX', (0, 0), (-1, -1), 1, colors.HexColor('#312E81')),
    ]))
    story.append(hero_cell)
    story.append(Spacer(1, 8))
    story.append(create_callout(
        "Build 17 is retired and does not start the studio. Your images, models, "
        "settings, and conversations remain in the folder. Request a current "
        "distribution from the person who supplied this copy.",
        kind="warning", styles=styles))
    story.append(Spacer(1, 8))

    # Feature Badges
    badge_data = [
        [
            Paragraph("<b>100% LOCAL & PRIVATE</b><br/><font size='7' color='#475569'>No telemetry / No cloud relay</font>", styles['BadgeText']),
            Paragraph("<b>DUAL AI ENGINES</b><br/><font size='7' color='#475569'>ComfyUI (Images) + llama.cpp (Chat)</font>", styles['BadgeText']),
            Paragraph("<b>ZERO PREREQUISITES</b><br/><font size='7' color='#475569'>Bundled private Python runtime</font>", styles['BadgeText']),
            Paragraph("<b>PORTABLE DESIGN</b><br/><font size='7' color='#475569'>Self-contained single directory</font>", styles['BadgeText']),
        ]
    ]
    badge_table = Table(badge_data, colWidths=[content_w / 4.0] * 4)
    badge_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), BG_LIGHT),
        ('BOX', (0, 0), (-1, -1), 0.5, BORDER_LIGHT),
        ('INNERGRID', (0, 0), (-1, -1), 0.5, BORDER_LIGHT),
        ('TOPPADDING', (0, 0), (-1, -1), 6),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ('LEFTPADDING', (0, 0), (-1, -1), 4),
        ('RIGHTPADDING', (0, 0), (-1, -1), 4),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
    ]))
    story.append(badge_table)
    story.append(Spacer(1, 14))

    # =========================================================================
    # CHAPTER 1: INTRODUCTION & ARCHITECTURE
    # =========================================================================
    story.append(Paragraph("1. Introduction & Architecture", styles['ChapterH1']))
    story.append(HRFlowable(width="100%", thickness=1, color=INDIGO_ACCENT, spaceBefore=2, spaceAfter=8))

    story.append(Paragraph(
        "<b>AI Studio Portable</b> is a complete desktop studio for local image generation, image editing, and "
        "conversational AI. The application operates as a single portable folder on your Windows PC. Both computational "
        "engines—<b>ComfyUI</b> for diffusion image rendering and <b>llama.cpp</b> for conversational chat—execute "
        "entirely on your local hardware. Prompts, reference images, generated outputs, and conversational context "
        "never touch external cloud servers.",
        styles['Body']
    ))

    # Network Boundary Callout
    story.append(create_callout(
        "<b>The Strict Privacy Boundary:</b> Only four actions ever contact the network: (1) Initial setup downloads; "
        "(2) Startup update checks against the official release repository; (3) Explicit web searches triggered in Chat; "
        "and (4) Direct model downloads requested via the installer. Generation and chat inference are 100% offline.",
        kind="note", styles=styles
    ))
    story.append(Spacer(1, 8))

    story.append(Paragraph("Internal Component Architecture", styles['SectionH2']))
    arch_data = [
        [Paragraph("Component", styles['TableHead']), Paragraph("Port / Location", styles['TableHead']), Paragraph("Role & Operation", styles['TableHead'])],
        [Paragraph("Web Interface", styles['TableCellBold']), Paragraph("127.0.0.1:8760", styles['TableCell']), Paragraph("Plain HTML/CSS/JS frontend; zero build step. Directly drives the studio workspace.", styles['TableCell'])],
        [Paragraph("Local Server", styles['TableCellBold']), Paragraph("app/server.py", styles['TableCell']), Paragraph("Threading HTTPServer running locally. Manages SQLite databases, asset folders, and job queuing.", styles['TableCell'])],
        [Paragraph("Image Engine", styles['TableCellBold']), Paragraph("ComfyUI (Port 8189)", styles['TableCell']), Paragraph("Private ComfyUI instance. Executes modular node graphs for txt2img, img2img, and inpainting.", styles['TableCell'])],
        [Paragraph("Chat Engine", styles['TableCellBold']), Paragraph("llama-server (Port 8080)", styles['TableCell']), Paragraph("High-speed llama.cpp server. Drives uncensored LLMs, multimodal vision, and context memory.", styles['TableCell'])],
    ]
    t_arch = Table(arch_data, colWidths=[105, 110, content_w - 215])
    t_arch.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), NAVY_PRIMARY),
        ('BOX', (0, 0), (-1, -1), 0.5, BORDER_LIGHT),
        ('INNERGRID', (0, 0), (-1, -1), 0.5, BORDER_LIGHT),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, BG_LIGHT]),
        ('TOPPADDING', (0, 0), (-1, -1), 5),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
        ('LEFTPADDING', (0, 0), (-1, -1), 6),
        ('RIGHTPADDING', (0, 0), (-1, -1), 6),
    ]))
    story.append(t_arch)
    story.append(Spacer(1, 8))

    story.append(Paragraph("Folder Structure & Data Ownership", styles['SectionH2']))
    story.append(Paragraph(
        "Everything inside <code>data/</code> (your generated images, chats, presets) and <code>models/</code> belongs to you. "
        "Updates only replace application code (<code>app/</code>, <code>web/</code>, etc.), so your creative assets and downloaded weights "
        "are perpetually preserved.",
        styles['Body']
    ))

    code_tree = (
        "AIStudioPortable/\n"
        "├── Start.bat           # Launcher script (double-click to start)\n"
        "├── MANUAL.md           # Standalone Markdown user manual\n"
        "├── USER_MANUAL.pdf     # This publication-grade manual\n"
        "├── config.json         # Optional configuration overrides\n"
        "├── models/             # Checkpoints, LoRAs, VAEs, and LLM weights\n"
        "├── data/               # Generated images, SQLite database, and session state\n"
        "└── logs/               # Local operational and error diagnostics"
    )
    story.append(create_code_block(code_tree, styles=styles))
    story.append(Spacer(1, 14))

    # =========================================================================
    # CHAPTER 2: SYSTEM REQUIREMENTS & SETUP
    # =========================================================================
    story.append(Paragraph("2. System Requirements & Getting Started", styles['ChapterH1']))
    story.append(HRFlowable(width="100%", thickness=1, color=INDIGO_ACCENT, spaceBefore=2, spaceAfter=8))

    story.append(Paragraph("Hardware Capabilities & VRAM Tiers", styles['SectionH2']))
    req_data = [
        [Paragraph("VRAM Tier", styles['TableHead']), Paragraph("Card Profile", styles['TableHead']), Paragraph("Image Generation", styles['TableHead']), Paragraph("Chat Model Capability", styles['TableHead'])],
        [Paragraph("16 GB - 24 GB+", styles['TableCellBold']), Paragraph("RTX 3090, 4080, 4090", styles['TableCell']), Paragraph("Full speed; up to 4K upscaling; simultaneous chat resident.", styles['TableCell']), Paragraph("Can run 14B-32B parameter models at Q4/Q8 quantization.", styles['TableCell'])],
        [Paragraph("12 GB (Reference)", styles['TableCellBold']), Paragraph("RTX 3060, 4070", styles['TableCell']), Paragraph("Smooth generation up to 2 megapixels; fast LoRA stacking.", styles['TableCell']), Paragraph("Comfortably runs 7B-9B parameter vision-capable models.", styles['TableCell'])],
        [Paragraph("8 GB (Minimum)", styles['TableCellBold']), Paragraph("RTX 2060, 3050, 4060", styles['TableCell']), Paragraph("Supported via aggressive offloading (VRAM Mode: Low).", styles['TableCell']), Paragraph("Runs compact 3B-8B Q4 models with layer offloading.", styles['TableCell'])],
    ]
    t_req = Table(req_data, colWidths=[90, 110, content_w - 330, 130])
    t_req.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), NAVY_PRIMARY),
        ('BOX', (0, 0), (-1, -1), 0.5, BORDER_LIGHT),
        ('INNERGRID', (0, 0), (-1, -1), 0.5, BORDER_LIGHT),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, BG_LIGHT]),
        ('TOPPADDING', (0, 0), (-1, -1), 5),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
        ('LEFTPADDING', (0, 0), (-1, -1), 6),
        ('RIGHTPADDING', (0, 0), (-1, -1), 6),
    ]))
    story.append(t_req)
    story.append(Spacer(1, 8))

    story.append(Paragraph("First-Time Setup in 3 Steps", styles['SectionH2']))
    story.append(Paragraph("<b>Step 1: Place the Studio Folder</b> — Extract the application into any folder on a fast SSD with at least 25 GB free disk space.", styles['Bullet']))
    story.append(Paragraph("<b>Step 2: Double-Click Start.bat</b> — The launcher automatically installs its private Python interpreter (no global Python or Git required) and boots ComfyUI & llama.cpp.", styles['Bullet']))
    story.append(Paragraph("<b>Step 3: Select Models & Launch</b> — The installer detects your GPU VRAM and prompts you to select an initial model tier. Once done, it opens your browser to <code>http://127.0.0.1:8760</code>.", styles['Bullet']))
    story.append(Spacer(1, 6))

    story.append(create_callout(
        "All downloads are completely resumable. If your internet connection drops midway through downloading a large model, "
        "simply re-run <code>Start.bat</code> and it will pick up exactly where it left off.",
        kind="tip", styles=styles
    ))
    story.append(Spacer(1, 14))

    # =========================================================================
    # CHAPTER 3: STUDIO MODES & WORKFLOWS
    # =========================================================================
    story.append(Paragraph("3. Studio Modes & Creative Workflows", styles['ChapterH1']))
    story.append(HRFlowable(width="100%", thickness=1, color=INDIGO_ACCENT, spaceBefore=2, spaceAfter=8))

    story.append(Paragraph("Mode 1: Text to Image (txt2img)", styles['SectionH2']))
    story.append(Paragraph(
        "Generate original artwork from written natural language descriptions. The workspace gives you fine-grained "
        "control over aspect ratios, composition guidance, sampling algorithms, and LoRA adaptations.",
        styles['Body']
    ))

    t2i_guide = [
        [Paragraph("Control", styles['TableHead']), Paragraph("Recommended Setting", styles['TableHead']), Paragraph("Operational Impact", styles['TableHead'])],
        [Paragraph("Positive Prompt", styles['TableCellBold']), Paragraph("Descriptive & Specific", styles['TableCell']), Paragraph("Detail subject, lighting, camera angle, and artistic medium.", styles['TableCell'])],
        [Paragraph("Negative Prompt", styles['TableCellBold']), Paragraph("Unwanted elements", styles['TableCell']), Paragraph("Suppress defects (e.g. 'blurry, lowres, distorted anatomy, text').", styles['TableCell'])],
        [Paragraph("Aspect Ratio", styles['TableCellBold']), Paragraph("1:1, 2:3, 3:2, 16:9", styles['TableCell']), Paragraph("Tuned resolution presets matching the native model aspect ratios.", styles['TableCell'])],
        [Paragraph("Sampling Steps", styles['TableCellBold']), Paragraph("20 - 30 steps (Standard)<br/>4 - 8 steps (Turbo/Lightning)", styles['TableCell']), Paragraph("Balance between generation speed and fine detail resolution.", styles['TableCell'])],
        [Paragraph("CFG Scale", styles['TableCellBold']), Paragraph("4.0 - 7.0 (Standard)<br/>1.0 - 2.0 (Turbo)", styles['TableCell']), Paragraph("Prompt guidance adherence. Excessively high values cause burned colors.", styles['TableCell'])],
        [Paragraph("Seed", styles['TableCellBold']), Paragraph("-1 (Random) or Locked", styles['TableCell']), Paragraph("Locking the seed enables controlled prompt and LoRA parameter tuning.", styles['TableCell'])],
    ]
    t_t2i = Table(t2i_guide, colWidths=[95, 130, content_w - 225])
    t_t2i.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), NAVY_PRIMARY),
        ('BOX', (0, 0), (-1, -1), 0.5, BORDER_LIGHT),
        ('INNERGRID', (0, 0), (-1, -1), 0.5, BORDER_LIGHT),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, BG_LIGHT]),
        ('TOPPADDING', (0, 0), (-1, -1), 4.5),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 4.5),
        ('LEFTPADDING', (0, 0), (-1, -1), 6),
        ('RIGHTPADDING', (0, 0), (-1, -1), 6),
    ]))
    story.append(t_t2i)
    story.append(Spacer(1, 8))

    story.append(Paragraph("Mode 2: Image to Image (img2img)", styles['SectionH2']))
    story.append(Paragraph(
        "Restyle, enhance, or transform existing artwork and photography using reference imagery. Denoise strength "
        "controls the degree of structural modification:",
        styles['Body']
    ))
    story.append(Paragraph("<b>Low Denoise (0.20 - 0.35)</b>: Retains geometry and fine details while applying subtle color grading and stylistic polish.", styles['Bullet']))
    story.append(Paragraph("<b>Medium Denoise (0.40 - 0.65)</b>: Transforms subjects and textures while retaining broad silhouettes, poses, and compositions.", styles['Bullet']))
    story.append(Paragraph("<b>High Denoise (0.70 - 0.90)</b>: Substantially recreates the image, using the reference merely for coarse color cues.", styles['Bullet']))
    story.append(Spacer(1, 6))

    story.append(Paragraph("Mode 3: Inpainting (LanPaint Canvas)", styles['SectionH2']))
    story.append(Paragraph(
        "Perform targeted edits, object removal, or character modifications using the built-in brush canvas:",
        styles['Body']
    ))
    story.append(Paragraph("<b>1. Canvas Tools</b> — Paint mask regions with adjustable brush sizes, erase mistakes, and hold spacebar to pan/zoom.", styles['Bullet']))
    story.append(Paragraph("<b>2. Boundary Bleed</b> — Paint slightly outside the object boundaries so the diffusion engine seamlessly blends edges.", styles['Bullet']))
    story.append(Paragraph("<b>3. Targeted Prompting</b> — Describe only what belongs inside the masked region (e.g. 'wearing an emerald silk dress').", styles['Bullet']))
    story.append(Spacer(1, 6))

    story.append(Paragraph("Mode 4: Conversational Chat & Assistant", styles['SectionH2']))
    story.append(Paragraph(
        "A private conversational assistant running on llama.cpp with integrated multimodal capabilities:",
        styles['Body']
    ))
    story.append(Paragraph("<b>Multimodal Vision</b>: Attach images to analyze visual content, inspect details, or critique compositions.", styles['Bullet']))
    story.append(Paragraph("<b>Document Ingestion</b>: Drag and drop PDF or text documents for instant local summarization and research.", styles['Bullet']))
    story.append(Paragraph("<b>Live Web Search</b>: Optional toggle to fetch real-time facts via DuckDuckGo/Bing directly from your PC.", styles['Bullet']))
    story.append(Paragraph("<b>Image Generation in Chat</b>: Request the assistant to render illustrations directly inside the conversation.", styles['Bullet']))
    story.append(Paragraph("<b>Context Compaction</b>: Automatically or manually compact earlier conversation turns without losing chat history.", styles['Bullet']))
    story.append(Spacer(1, 14))

    # =========================================================================
    # CHAPTER 4: MANAGING MODELS
    # =========================================================================
    story.append(Paragraph("4. Managing Models", styles['ChapterH1']))
    story.append(HRFlowable(width="100%", thickness=1, color=INDIGO_ACCENT, spaceBefore=2, spaceAfter=8))

    story.append(Paragraph("Model Folders & File Placement", styles['SectionH2']))
    model_data = [
        [Paragraph("Folder Name", styles['TableHead']), Paragraph("Purpose & Content", styles['TableHead']), Paragraph("Typical Formats", styles['TableHead'])],
        [Paragraph("models/checkpoints/", styles['TableCellBold']), Paragraph("All-in-one models containing UNet/DiT, text encoder & VAE.", styles['TableCell']), Paragraph(".safetensors", styles['TableCell'])],
        [Paragraph("models/diffusion_models/", styles['TableCellBold']), Paragraph("Split diffusion weights (e.g. Krea 2, Anima).", styles['TableCell']), Paragraph(".safetensors", styles['TableCell'])],
        [Paragraph("models/text_encoders/", styles['TableCellBold']), Paragraph("Text encoders for split models (CLIP-L, CLIP-G, T5-XXL).", styles['TableCell']), Paragraph(".safetensors", styles['TableCell'])],
        [Paragraph("models/vae/", styles['TableCellBold']), Paragraph("Decoders that convert latent representations to final PNGs.", styles['TableCell']), Paragraph(".safetensors", styles['TableCell'])],
        [Paragraph("models/loras/", styles['TableCellBold']), Paragraph("Low-Rank Adaptation layers for styles, concepts, or characters.", styles['TableCell']), Paragraph(".safetensors", styles['TableCell'])],
        [Paragraph("models/llm/", styles['TableCellBold']), Paragraph("Quantized chat models and multimodal vision projectors.", styles['TableCell']), Paragraph(".gguf, .mmproj", styles['TableCell'])],
        [Paragraph("models/upscale_models/", styles['TableCellBold']), Paragraph("Super-resolution models (RealESRGAN, 4x-UltraSharp).", styles['TableCell']), Paragraph(".pth, .safetensors", styles['TableCell'])],
    ]
    t_model = Table(model_data, colWidths=[120, content_w - 210, 90])
    t_model.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), NAVY_PRIMARY),
        ('BOX', (0, 0), (-1, -1), 0.5, BORDER_LIGHT),
        ('INNERGRID', (0, 0), (-1, -1), 0.5, BORDER_LIGHT),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, BG_LIGHT]),
        ('TOPPADDING', (0, 0), (-1, -1), 4.5),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 4.5),
        ('LEFTPADDING', (0, 0), (-1, -1), 6),
        ('RIGHTPADDING', (0, 0), (-1, -1), 6),
    ]))
    story.append(t_model)
    story.append(Spacer(1, 8))

    story.append(create_callout(
        "<b>Using Existing ComfyUI Models Without Duplication:</b> In <code>config.json</code>, set "
        "<code>\"models_path\": \"E:/SomeWhere/ComfyUI/models\"</code>. AI Studio Portable reads your models "
        "in-place read-only. It never copies, moves, or alters your external model library.",
        kind="tip", styles=styles
    ))
    story.append(Spacer(1, 14))

    # =========================================================================
    # CHAPTER 5: HARDWARE TUNING & VRAM ALLOCATION
    # =========================================================================
    story.append(Paragraph("5. Hardware Tuning & VRAM Allocation", styles['ChapterH1']))
    story.append(HRFlowable(width="100%", thickness=1, color=INDIGO_ACCENT, spaceBefore=2, spaceAfter=8))

    story.append(Paragraph("VRAM Operating Modes", styles['SectionH2']))
    vram_data = [
        [Paragraph("Mode", styles['TableHead']), Paragraph("Target Hardware", styles['TableHead']), Paragraph("Behavior & Offloading Strategy", styles['TableHead'])],
        [Paragraph("auto (Default)", styles['TableCellBold']), Paragraph("All Systems", styles['TableCell']), Paragraph("Detects GPU memory automatically at launch and applies the optimal profile.", styles['TableCell'])],
        [Paragraph("high", styles['TableCellBold']), Paragraph("16 GB - 24 GB+", styles['TableCell']), Paragraph("Keeps models pinned in VRAM for maximum speed and sub-second generation starts.", styles['TableCell'])],
        [Paragraph("normal", styles['TableCellBold']), Paragraph("12 GB GPUs", styles['TableCell']), Paragraph("Standard balanced profile. Unloads latent blocks cleanly between generations.", styles['TableCell'])],
        [Paragraph("low", styles['TableCellBold']), Paragraph("8 GB GPUs", styles['TableCell']), Paragraph("Aggressive model offloading to system RAM. Prevents CUDA out-of-memory errors.", styles['TableCell'])],
        [Paragraph("minimum", styles['TableCellBold']), Paragraph("Constrained GPUs", styles['TableCell']), Paragraph("Strict sequential layer execution. Slower, but guarantees successful rendering.", styles['TableCell'])],
    ]
    t_vram = Table(vram_data, colWidths=[85, 100, content_w - 185])
    t_vram.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), NAVY_PRIMARY),
        ('BOX', (0, 0), (-1, -1), 0.5, BORDER_LIGHT),
        ('INNERGRID', (0, 0), (-1, -1), 0.5, BORDER_LIGHT),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, BG_LIGHT]),
        ('TOPPADDING', (0, 0), (-1, -1), 4.5),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 4.5),
        ('LEFTPADDING', (0, 0), (-1, -1), 6),
        ('RIGHTPADDING', (0, 0), (-1, -1), 6),
    ]))
    story.append(t_vram)
    story.append(Spacer(1, 8))

    story.append(Paragraph("Dual-Engine Arbitration & Collision Avoidance", styles['SectionH2']))
    story.append(Paragraph(
        "To prevent VRAM contention on 8 GB to 12 GB GPUs, the backend server dynamically coordinates engines: when "
        "switching from Chat to Image Generation, the chat model is paused or offloaded so ComfyUI has full GPU access. "
        "If you have a 16 GB+ card and desire instant chat responses at all times, set <code>\"keep_chat_loaded\": true</code>.",
        styles['Body']
    ))
    story.append(Spacer(1, 14))

    # =========================================================================
    # CHAPTER 6: CONFIGURATION, PRIVACY & SECURITY
    # =========================================================================
    story.append(Paragraph("6. Configuration, Privacy & Security", styles['ChapterH1']))
    story.append(HRFlowable(width="100%", thickness=1, color=INDIGO_ACCENT, spaceBefore=2, spaceAfter=8))

    story.append(Paragraph("In-App Settings vs config.json", styles['SectionH2']))
    story.append(Paragraph(
        "Click the <b>gear icon</b> in the top navigation bar to open the Settings panel. From here, you can switch to the "
        "new <b>Help & Manual</b> section to open this PDF guide directly in your browser, adjust VRAM profiles, select default "
        "chat models, set image retention limits, or customize themes. Settings modified in the UI are cleanly saved into <code>config.json</code>.",
        styles['Body']
    ))

    story.append(Paragraph("Encrypted Storage (ASP1 Envelope)", styles['SectionH2']))
    story.append(Paragraph(
        "If you share your computer or synchronize your drive with cloud storage, enable storage encryption by setting "
        "<code>\"encrypt_storage\": true</code> in <code>config.json</code>. At startup, the studio will prompt for your Studio Access Key. "
        "Images, prompts, drafts, and conversations are encrypted on disk using authenticated AES-GCM.",
        styles['Body']
    ))
    story.append(create_callout(
        "There is no password recovery backdoor. If you encrypt your storage and lose your Studio Access Key, "
        "the data on disk cannot be decrypted.",
        kind="warning", styles=styles
    ))
    story.append(Spacer(1, 14))

    # =========================================================================
    # CHAPTER 7: UPDATES, BACKUPS & MAINTENANCE
    # =========================================================================
    story.append(Paragraph("7. Updates, Backups & Maintenance", styles['ChapterH1']))
    story.append(HRFlowable(width="100%", thickness=1, color=INDIGO_ACCENT, spaceBefore=2, spaceAfter=8))

    story.append(Paragraph("Single-Integer Build Numbering", styles['SectionH2']))
    story.append(Paragraph(
        "AI Studio Portable uses simple sequential build numbers (Build 1, Build 2, Build 16...) with no decimals. "
        "Your current build number is displayed faintly in the bottom-right corner of the interface. Clicking it opens the "
        "Version Log detailing exactly what changed in each release, which also includes a direct button to open this User Manual.",
        styles['Body']
    ))
    story.append(Paragraph("Safe, Non-Destructive In-Place Updates", styles['SectionH2']))
    story.append(Paragraph(
        "Updates are verified against cryptographic SHA-256 checksums and unpacked through a staging directory. "
        "The updater replaces only application binaries and frontend code. Your personal files (images in <code>data/</code>, "
        "databases, and downloaded weights in <code>models/</code>) are never overwritten.",
        styles['Body']
    ))
    story.append(Spacer(1, 14))

    # =========================================================================
    # CHAPTER 8: TROUBLESHOOTING & TECHNICAL REFERENCE
    # =========================================================================
    story.append(Paragraph("8. Troubleshooting & Technical Reference", styles['ChapterH1']))
    story.append(HRFlowable(width="100%", thickness=1, color=INDIGO_ACCENT, spaceBefore=2, spaceAfter=8))

    trouble_data = [
        [Paragraph("Symptom / Error", styles['TableHead']), Paragraph("Probable Cause", styles['TableHead']), Paragraph("Verified Solution", styles['TableHead'])],
        [Paragraph("CUDA out of memory", styles['TableCellBold']), Paragraph("Resolution too high or VRAM exhausted.", styles['TableCell']), Paragraph("Set VRAM Mode to 'Low' in Settings. Lower image dimensions (e.g. 896x896) and disable excess LoRAs.", styles['TableCell'])],
        [Paragraph("Port collision / refused", styles['TableCellBold']), Paragraph("Port 8760, 8189, or 8080 held by stale process.", styles['TableCell']), Paragraph("Close duplicate terminal instances. Check Task Manager for orphaned llama-server.exe or python.exe.", styles['TableCell'])],
        [Paragraph("Model missing from UI", styles['TableCellBold']), Paragraph("File placed while running or wrong folder.", styles['TableCell']), Paragraph("Click 'Rescan' in the Models panel. Ensure the file is not an incomplete .crdownload file.", styles['TableCell'])],
        [Paragraph("Burnt / oversaturated image", styles['TableCellBold']), Paragraph("CFG guidance scale set too high.", styles['TableCell']), Paragraph("Reduce CFG scale to 4.5 - 6.5 (or 1.0 - 1.5 if using Lightning/Turbo models).", styles['TableCell'])],
        [Paragraph("Black or distorted output", styles['TableCellBold']), Paragraph("Missing required VAE decoder.", styles['TableCell']), Paragraph("Place the model's required VAE (e.g. sdxl_vae.safetensors) into models/vae/.", styles['TableCell'])],
    ]
    t_trouble = Table(trouble_data, colWidths=[110, 115, content_w - 225])
    t_trouble.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), NAVY_PRIMARY),
        ('BOX', (0, 0), (-1, -1), 0.5, BORDER_LIGHT),
        ('INNERGRID', (0, 0), (-1, -1), 0.5, BORDER_LIGHT),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, BG_LIGHT]),
        ('TOPPADDING', (0, 0), (-1, -1), 4.5),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 4.5),
        ('LEFTPADDING', (0, 0), (-1, -1), 6),
        ('RIGHTPADDING', (0, 0), (-1, -1), 6),
    ]))
    story.append(t_trouble)
    story.append(Spacer(1, 10))

    story.append(Paragraph("Reporting a Problem & Privacy Scrubber", styles['SectionH2']))
    story.append(Paragraph(
        "If you encounter an unexpected issue, click the <b>Report a problem</b> button in the header bar. "
        "The studio generates a clean diagnostic zip containing recent engine logs and hardware telemetry. "
        "Before writing to disk, the diagnostic reporter automatically scrubs all personal usernames, machine names, "
        "and file paths so you can safely share the report for technical assistance.",
        styles['Body']
    ))
    story.append(Spacer(1, 6))

    story.append(Paragraph("Safety & Content Boundaries", styles['SectionH2']))
    story.append(Paragraph(
        "AI Studio Portable does not impose moralizing filters, censorship, or external moderation relays on adult creative work. "
        "However, the application contains strict, locally enforced code blocks prohibiting sexual material involving minors (CSAM). "
        "Prompts violating this absolute standard are refused immediately on your machine before reaching any engine.",
        styles['Body']
    ))

    # Build the document
    doc.build(story, canvasmaker=NumberedCanvas)
    print(f"Successfully generated publication-grade PDF manual: {target}")
    return target


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate AI Studio Portable User Manual PDF")
    parser.add_argument("--output", "-o", help="Optional output PDF path")
    args = parser.parse_args()

    build_manual_pdf(args.output)

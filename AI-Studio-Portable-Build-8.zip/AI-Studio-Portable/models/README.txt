Drop model files in here.

Each folder matches what ComfyUI calls that kind of model, apart from llm, which
is the studio's own. Put a file in checkpoints or loras and the studio picks it
up on the next rescan - use Rescan in the Models panel, or just restart.

A checkpoint you drop in appears in the model picker under your own name for it.
The studio cannot tell from the file which pipeline it wants - SDXL, SD 1.5,
Pony and Illustrious are all "a checkpoint" - so it assumes SDXL and lets you
change that in the Models panel. If an anime model comes out looking wrong,
that is the setting to change.

The other folders hold the parts of models rather than whole ones, and are read
by whichever checkpoint needs them rather than being offered on their own.

  checkpoints        all-in-one models (SDXL, Illustrious, and similar)
  diffusion_models   models that come split from their text encoder
  text_encoders      the text half of a split model
  vae                decoders
  loras              LoRA layers
  upscale_models     upscalers
  controlnet         ControlNet models
  embeddings         textual inversions
  clip_vision        vision encoders
  llm                chat models (.gguf), and their mmproj file if they see

The folders themselves ship empty. Nothing you put in them is ever committed or
included in a release, so what you drop here stays yours.

You can also use models you already have somewhere else without moving them.
In config.json:

  "models_path": "E:/SomeWhere/ComfyUI/models"

That folder is only ever read from. Nothing is written, moved or renamed there.

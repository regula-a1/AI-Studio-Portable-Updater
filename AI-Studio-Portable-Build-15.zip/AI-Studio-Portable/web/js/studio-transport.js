(function () {
    'use strict';
    const form = document.querySelector('#studio-form');
    const generateBtns = form.querySelectorAll('.generate');
    const note = document.querySelector('#connection-note');
    const badge = document.querySelector('#remote-connection');
    const unlock = document.querySelector('#unlock-panel');
    const status = document.querySelector('#generation-status');
    const list = document.querySelector('#generation-list');
    const promptDialog = document.querySelector('#prompt-dialog');
    const promptDialogText = document.querySelector('#prompt-dialog-text');
    const promptDialogNegative = document.querySelector('#prompt-dialog-negative');
    const promptDialogNegativeText = document.querySelector('#prompt-dialog-negative-text');
    const promptDialogModel = document.querySelector('#prompt-dialog-model');
    const promptDialogImageLink = document.querySelector('#prompt-dialog-image-link');
    const promptDialogImage = document.querySelector('#prompt-dialog-image');
    const copyStatus = document.querySelector('#prompt-copy-status');
    const dialogInpaintBtn = document.querySelector('#dialog-inpaint-btn');
    const dialogImg2imgBtn = document.querySelector('#dialog-img2img-btn');
    const outputStageActions = document.querySelector('#output-stage-actions');
    const outputToInpaint = document.querySelector('#output-to-inpaint');
    const outputToImg2img = document.querySelector('#output-to-img2img');
    const limitWarning = document.querySelector('#image-limit-warning');
    const studioMain = document.querySelector('#studio-main');
    const reorderButton = document.querySelector('#reorder-queue');
    const queueAnnouncement = document.querySelector('#queue-announcement');
    let online = false, submitting = false, busy = false, timer, jobs = [], selected = null, fingerprint = '', retention = 168, maxRecentImages = 100;
    let reorderMode = false, reorderSaving = false, reorderDragging = false;
    const submission = window.StudioState.createSubmission();
    let awaitedJob = null, liteActive = false;
    let openPrompt = '', openNegativePrompt = '', openJob = null, promptRequest = 0, dismissedOldestId = null, dismissedApproaching = false;

    // Polling pace. A tab left open used to ask the server for the whole gallery
    // every 8 seconds forever, which is most of a day's D1 row budget for a page
    // nobody is looking at. While a job is queued or running nothing changes; the
    // rest of the time the gap grows until the page is only checking once a
    // minute, and once a background tab has settled it drops to five. Any job
    // starting, or the tab coming back to the front, snaps it back to 8s.
    const POLL_ACTIVE_MS = 4000;
    const POLL_IDLE_MS = 8000;
    const POLL_IDLE_MAX_MS = 60000;
    const POLL_HIDDEN_MS = 300000;
    let idlePolls = 0;
    function nextPollDelay() {
        if (jobs.some(job => ['queued', 'running'].includes(job.status)) || liteActive) {
            idlePolls = 0;
            return POLL_ACTIVE_MS;
        }
        idlePolls += 1;
        if (document.hidden) return POLL_HIDDEN_MS;
        return Math.min(POLL_IDLE_MAX_MS, Math.round(POLL_IDLE_MS * Math.pow(1.5, idlePolls - 1)));
    }

    // Prompts and images are sealed here and opened here. The website receives a
    // hash of the Studio key, never the key, so it stores what it cannot read.
    const STORE = 'studio-studio-key';
    const encoder = new TextEncoder(), decoder = new TextDecoder();
    const ENVELOPE = 'ASP1';
    let contentKey = null;
    // Told to us by the server at startup; see loadStorageMode(). Assume off, so
    // a server that cannot answer still gives a usable studio rather than an
    // unlock screen nobody can get past.
    let encryptionOn = false;
    const images = new Map();
    const thumbnails = new Map();
    const jobProgress = new Map();
    const thumbnailObserver = 'IntersectionObserver' in window ? new IntersectionObserver(entries => {
        entries.filter(entry => entry.isIntersecting).forEach(entry => {
            const image = entry.target;
            thumbnailObserver.unobserve(image);
            thumbnailFor(image.studioJob).then(url => {
                if (image.isConnected) image.src = url;
            }).catch(() => image.closest('.generation-card')?.classList.add('unreadable'));
        });
    }, { rootMargin: '300px' }) : null;
    const bytesToBase64 = bytes => {
        let binary = '';
        const chunkSize = 0x8000;
        for (let i = 0; i < bytes.length; i += chunkSize) {
            binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunkSize));
        }
        return btoa(binary);
    };
    const base64ToBytes = text => {
        const binary = atob(text);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) {
            bytes[i] = binary.charCodeAt(i);
        }
        return bytes;
    };
    const hex = bytes => [...bytes].map(byte => byte.toString(16).padStart(2, '0')).join('');
    async function derive(label, key) {
        return new Uint8Array(await crypto.subtle.digest('SHA-256', encoder.encode(`${label}|${key}`)));
    }
    async function useKey(key) {
        contentKey = await crypto.subtle.importKey('raw', await derive('studio-content-v1', key), 'AES-GCM', false, ['encrypt', 'decrypt']);
        window.dispatchEvent(new CustomEvent('studio-unlocked'));
    }
    function remember(key, shouldRemember = true) {
        try {
            if (shouldRemember) {
                localStorage.setItem(STORE, key);
                sessionStorage.removeItem(STORE);
            } else {
                localStorage.removeItem(STORE);
                sessionStorage.setItem(STORE, key);
            }
        } catch (error) { /* private window */ }
    }
    function remembered() {
        let key = null;
        try { key = localStorage.getItem(STORE); } catch (_) {}
        if (!key) { try { key = sessionStorage.getItem(STORE); } catch (_) {} }
        return key;
    }
    async function seal(bytes) {
        // Encryption off is the default: the studio is local, and a passphrase
        // kept beside the files it protects is not protecting them. Sealing stays
        // on every path rather than being torn out of ~85 call sites, so the
        // switch costs a branch instead of a rewrite.
        if (!encryptionOn) return bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
        const iv = crypto.getRandomValues(new Uint8Array(12));
        const body = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, contentKey, bytes));
        const sealed = new Uint8Array(17 + body.length);
        sealed.set(encoder.encode(ENVELOPE), 0); sealed.set(iv, 5); sealed.set(body, 17);
        return sealed;
    }
    async function unseal(sealed) {
        // Opens a sealed payload whenever it is given one, whatever the setting.
        // Switching encryption off must not orphan images made while it was on.
        const looksSealed = sealed.length >= 18 && decoder.decode(sealed.slice(0, 5)) === ENVELOPE;
        if (!looksSealed) {
            if (encryptionOn) throw new Error('Not a sealed payload');
            return sealed;
        }
        if (!contentKey) throw new Error('Studio is locked');
        return new Uint8Array(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: sealed.slice(5, 17) }, contentKey, sealed.slice(17)));
    }
    async function readPrompt(sealed) {
        try { return decoder.decode(await unseal(base64ToBytes(sealed))); }
        catch (error) { return 'Sealed with a different Studio key.'; }
    }

    window.StudioCrypto = {
        isUnlocked: () => Boolean(contentKey) || !encryptionOn,
        // Whether anything on disk is actually sealed. Callers that sniff for an
        // envelope need this: with encryption off a value is still base64, it
        // just has no envelope to recognise.
        encryptionEnabled: () => encryptionOn,
        sealText: async (text) => {
            if (!contentKey && encryptionOn) throw new Error('Studio is locked');
            const sealed = await seal(encoder.encode(text));
            return bytesToBase64(sealed);
        },
        unsealText: async (base64) => {
            if (!contentKey && encryptionOn) throw new Error('Studio is locked');
            const bytes = base64ToBytes(base64);
            const unsealed = await unseal(bytes);
            return decoder.decode(unsealed);
        },
        fetchCloudPresets: async () => {
            if (!contentKey && encryptionOn) return null;
            const res = await api('presets');
            if (!res?.payload) return null;
            const text = await window.StudioCrypto.unsealText(res.payload);
            return JSON.parse(text);
        },
        saveCloudPresets: async (presets) => {
            if (!contentKey && encryptionOn) return false;
            const text = JSON.stringify(presets);
            const payload = await window.StudioCrypto.sealText(text);
            await api('save-presets', { payload });
            return true;
        },
        sealBinary: async (bytes) => {
            if (!contentKey && encryptionOn) throw new Error('Studio is locked');
            return await seal(bytes);
        },
        unsealBinary: async (bytes) => {
            if (!contentKey && encryptionOn) throw new Error('Studio is locked');
            return await unseal(bytes);
        },
        imageFor: (job) => {
            return imageFor(job);
        }
    };
    // Images arrive sealed, so they cannot be an <img src> until they are opened.
    function imageFor(job) {
        if (!images.has(job.id)) {
            const pending = (async () => {
                const response = await fetch(`/api/studio?action=image&id=${encodeURIComponent(job.id)}`, { cache: 'no-store' });
                if (!response.ok) throw new Error('Image not ready');
                const bytes = await unseal(new Uint8Array(await response.arrayBuffer()));
                return URL.createObjectURL(new Blob([bytes], { type: 'image/png' }));
            })();
            images.set(job.id, pending);
            // A just-finished image can take a few seconds to become readable, so let it be retried.
            pending.catch(() => images.delete(job.id));
        }
        return images.get(job.id);
    }

    function thumbnailFor(job) {
        if (!job.has_thumbnail) return Promise.reject(new Error('Thumbnail unavailable'));
        if (!thumbnails.has(job.id)) {
            const pending = (async () => {
                const response = await fetch(`/api/studio?action=thumbnail&id=${encodeURIComponent(job.id)}`, { cache: 'no-store' });
                if (!response.ok) throw new Error('Thumbnail not ready');
                const bytes = await unseal(new Uint8Array(await response.arrayBuffer()));
                return URL.createObjectURL(new Blob([bytes], { type: 'image/webp' }));
            })();
            thumbnails.set(job.id, pending);
            pending.catch(() => thumbnails.delete(job.id));
        }
        return thumbnails.get(job.id);
    }

    function openFullImage(job) {
        const imageTab = window.open('about:blank', '_blank');
        if (!imageTab) {
            status.textContent = 'Allow pop-ups for this site to open the full-resolution image.';
            return;
        }
        imageTab.opener = null;
        imageTab.document.title = 'Loading full-resolution image…';
        imageTab.document.body.textContent = 'Loading full-resolution image…';
        imageFor(job).then(url => imageTab.location.replace(url)).catch(() => {
            imageTab.close();
            status.textContent = 'Could not open the full-resolution image. Refresh and try again.';
        });
    }

    // Opened images live in this tab's memory only, so drop the ones no longer shown.
    async function forgetImages(keep) {
        for (const [id, pending] of [...images]) {
            if (keep && keep.has(id)) continue;
            images.delete(id);
            jobProgress.delete(id);
            try { URL.revokeObjectURL(await pending); } catch (error) { /* never opened */ }
        }
        for (const [id, pending] of [...thumbnails]) {
            if (keep && keep.has(id)) continue;
            thumbnails.delete(id);
            try { URL.revokeObjectURL(await pending); } catch (error) { /* never opened */ }
        }
    }
    function buttons() {
        const mode = window.StudioInpaint?.getMode?.() || 'txt2img';
        let disabled = !online || submitting || !form.elements.prompt.value.trim();
        if (!disabled) {
            if (mode === 'img2img' && !window.StudioInpaint?.hasInputImage?.()) {
                disabled = true;
            } else if (mode === 'inpaint' && (!window.StudioInpaint?.hasInputImage?.() || !window.StudioInpaint?.hasMask?.())) {
                disabled = true;
            }
        }
        generateBtns.forEach(btn => { btn.disabled = disabled; });
    }
    function retentionLabel() {
        return retention >= 48 && retention % 24 === 0 ? `${retention / 24} days` : `${retention} hours`;
    }
    function modelName(model) {
        // Shipped checkpoints only. Anything the user installs themselves falls
        // through to its own id until the model registry supplies a label.
        return ({
            krea2_turbo: 'Krea 2 Turbo',
            sdxl_cyberrealistic: 'CyberRealistic XL',
            anima_base: 'Anima Base',
            illustrious_base: 'Illustrious Base'
        })[model] || model || 'Unknown model';
    }
    function loraSummary(job) {
        // No LoRAs ship with this build; labels come from the local registry, and a
        // LoRA with no registered label is shown by its own id.
        const names = {};
        let layers = job?.loras;
        if (typeof layers === 'string') { try { layers = JSON.parse(layers); } catch { layers = []; } }
        if (!Array.isArray(layers)) return [];
        return layers.map(layer => {
            const id = layer?.id;
            if (!id) return null;
            return window.StudioComposer?.getLoraLabel?.(id)
                || names[id]
                || id.replace(/[_-]/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
        }).filter(Boolean);
    }
    async function showPrompt(job) {
        const request = ++promptRequest;
        openJob = job;
        openPrompt = job.text;
        openNegativePrompt = job.negativeText || '';
        promptDialogText.textContent = openPrompt;
        promptDialogNegative.hidden = !openNegativePrompt;
        promptDialogNegativeText.textContent = openNegativePrompt;
        const resLabel = ({
            'draft': 'Draft',
            'preview': 'Draft',
            '1mp': '1MP',
            '2mp': '2MP',
            '3mp': '3MP',
            '4mp': '4MP',
            '8mp_ultra': '8MP Ultra',
            '8mp': '8MP Ultra',
            'hd': '2MP',
            'fast': '1MP'
        })[job.resolution] || (job.resolution ? job.resolution.toUpperCase() : '1MP');
        const layers = loraSummary(job);
        const seedTag = job.seed ? ` · Seed: ${job.seed}` : '';
        promptDialogModel.textContent = `Model: ${modelName(job.model)}${layers.length ? ` · ${layers.join(' + ')}` : ''} · Resolution: ${resLabel}${job.upscale ? ' · AI Upscaled' : ''}${seedTag}`;
        promptDialogImageLink.hidden = true;
        promptDialogImageLink.removeAttribute('href');
        promptDialogImageLink.onclick = null;
        promptDialogImage.removeAttribute('src');
        promptDialogImage.alt = '';
        copyStatus.textContent = '';
        if (dialogInpaintBtn && dialogImg2imgBtn) {
            if (job.status === 'complete') {
                dialogInpaintBtn.hidden = false;
                dialogImg2imgBtn.hidden = false;
                dialogInpaintBtn.onclick = async () => {
                    promptDialog.close();
                    try {
                        const url = await imageFor(job);
                        window.StudioInpaint?.setMode?.('inpaint');
                        await window.StudioInpaint?.loadImage?.(url);
                        form.elements.prompt.value = job.text;
                        if (form.elements.negativePrompt) {
                            form.elements.negativePrompt.value = job.negativeText || '';
                        }
                        form.dispatchEvent(new Event('input', { bubbles: true }));
                        if (window.innerWidth <= 760) {
                            document.querySelector('#studio-stage')?.scrollIntoView({ behavior: 'smooth' });
                        }
                    } catch (e) {
                        status.textContent = 'Could not load image for inpainting.';
                    }
                };
                dialogImg2imgBtn.onclick = async () => {
                    promptDialog.close();
                    try {
                        const url = await imageFor(job);
                        window.StudioInpaint?.setMode?.('img2img');
                        await window.StudioInpaint?.loadImage?.(url);
                        form.elements.prompt.value = job.text;
                        if (form.elements.negativePrompt) {
                            form.elements.negativePrompt.value = job.negativeText || '';
                        }
                        form.dispatchEvent(new Event('input', { bubbles: true }));
                        if (window.innerWidth <= 760) {
                            document.querySelector('#studio-stage')?.scrollIntoView({ behavior: 'smooth' });
                        }
                    } catch (e) {
                        status.textContent = 'Could not load image for img2img.';
                    }
                };
            } else {
                dialogInpaintBtn.hidden = true;
                dialogImg2imgBtn.hidden = true;
            }
        }
        promptDialog.showModal();
        if (job.status !== 'complete') return;
        promptDialogImageLink.onclick = event => { event.preventDefault(); openFullImage(job); };
        try {
            const url = await thumbnailFor(job);
            if (request !== promptRequest || !promptDialog.open) return;
            promptDialogImage.src = url;
            promptDialogImage.alt = job.text;
            promptDialogImageLink.href = '#';
            promptDialogImageLink.title = 'Open full resolution in a new tab';
            promptDialogImageLink.setAttribute('aria-label', 'Open full resolution image in a new tab');
            promptDialogImageLink.hidden = false;
        } catch (error) {
            if (request === promptRequest) copyStatus.textContent = 'The image could not be opened. The prompt is still available below.';
        }
    }
    function updateLimitWarning() {
        const completed = jobs.filter(job => job.status === 'complete');
        const mobileHistoryBadge = document.querySelector('#mobile-history-badge');
        if (mobileHistoryBadge) {
            const count = completed.length;
            mobileHistoryBadge.textContent = String(count);
            mobileHistoryBadge.hidden = count === 0;
        }
        const approachingThreshold = Math.max(1, maxRecentImages - 4);
        if (completed.length < approachingThreshold) {
            dismissedApproaching = false;
            dismissedOldestId = null;
            limitWarning.hidden = true;
            return;
        }
        const titleEl = limitWarning.querySelector('strong');
        const textEl = limitWarning.querySelector('p');
        if (completed.length >= maxRecentImages) {
            if (titleEl) titleEl.textContent = 'Recent Images is full';
            if (textEl) textEl.textContent = 'Your oldest image will be deleted when the next image is generated. Download anything you want to keep.';
            const oldestId = completed[completed.length - 1].id;
            limitWarning.hidden = dismissedOldestId === oldestId;
        } else {
            if (titleEl) titleEl.textContent = 'Recent Images limit approaching';
            if (textEl) textEl.textContent = `You have ${completed.length} of ${maxRecentImages} recent images stored. Once ${maxRecentImages} is reached, older images will be deleted as new ones are generated. Download anything you want to keep.`;
            limitWarning.hidden = dismissedApproaching;
        }
    }
    async function api(action, data) {
        const response = await fetch(`/api/studio?action=${action}`, {
            method: data ? 'POST' : 'GET', cache: 'no-store',
            headers: data ? { 'Content-Type': 'application/json' } : {},
            body: data ? JSON.stringify(data) : undefined, signal: AbortSignal.timeout(20000)
        });
        const text = await response.text();
        let result;
        try { result = JSON.parse(text); }
        catch { throw new Error(`Image-generation service returned an invalid response (${response.status}). Reload the page and try again.`); }
        if (!response.ok) { const error = new Error(result.error || (result.locked ? 'Unlock your studio to continue.' : 'Connection unavailable.')); error.status = response.status; error.code = result.code; error.result = result; throw error; }
        return result;
    }
    const queuedIds = () => jobs.filter(job => job.status === 'queued').map(job => job.id);
    function applyQueuedOrder(order) {
        const byId = new Map(jobs.filter(job => job.status === 'queued').map(job => [job.id, job]));
        let index = 0;
        jobs = jobs.map(job => job.status === 'queued' ? byId.get(order[index++]) : job);
    }
    async function saveQueueOrder(order, expectedOrder) {
        if (reorderSaving || JSON.stringify(order) === JSON.stringify(expectedOrder)) return;
        reorderSaving = true; reorderButton.disabled = true;
        list.querySelectorAll('.queue-handle, .queue-move').forEach(button => { button.disabled = true; });
        try {
            await api('reorder', { order, expectedOrder });
            queueAnnouncement.textContent = 'Queue order saved and synced.';
            status.textContent = 'Queue order saved. Other devices will update automatically.';
        } catch (error) {
            queueAnnouncement.textContent = error.message; status.textContent = error.message;
            fingerprint = ''; await refresh();
        } finally {
            reorderSaving = false; reorderButton.disabled = false;
            list.querySelectorAll('.queue-handle, .queue-move').forEach(button => { button.disabled = false; });
            fingerprint = ''; renderJobs();
        }
    }
    function moveQueued(id, offset) {
        if (reorderSaving) return;
        const expected = queuedIds(), order = [...expected], from = order.indexOf(id), to = from + offset;
        if (from < 0 || to < 0 || to >= order.length) return;
        order.splice(to, 0, order.splice(from, 1)[0]);
        applyQueuedOrder(order); fingerprint = ''; renderJobs();
        queueAnnouncement.textContent = `Moved queued image to position ${to + 1} of ${order.length}.`;
        saveQueueOrder(order, expected);
    }
    function resetCanvas() {
        selected = null;
        const frame = document.querySelector('#canvas-frame');
        frame.classList.remove('has-image');
        frame.innerHTML = '<h3>No image selected</h3><p>Generated images appear here.</p>';
        document.querySelector('#canvas-title').textContent = 'Output';
        document.querySelector('.stage-caption').textContent = 'No output';
        document.querySelector('#download-image').hidden = true;
        if (outputStageActions) outputStageActions.hidden = true;
    }
    // The session cookie, not the Studio key, has expired. Nothing on this page
    // works without it, and every API call would repeat the same 401, so send
    // the owner to sign in again rather than blaming their access key.
    let leaving = false;
    function signedOut(error) {
        if (!error || error.code !== 'signed-out' || leaving) return false;
        leaving = true;
        location.replace('/login/?returnTo=' + encodeURIComponent(location.pathname + location.search));
        return true;
    }
    function locked(message) {
        contentKey = null; forgetImages();
        window.dispatchEvent(new CustomEvent('studio-locked'));
        if (studioMain) studioMain.hidden = true;
        unlock.hidden = false; note.textContent = message;
        badge.dataset.online = 'false'; badge.querySelector('span').textContent = 'Studio locked';
        jobs = []; list.replaceChildren(); fingerprint = ''; online = false;
        dismissedApproaching = false; dismissedOldestId = null; limitWarning.hidden = true;
        if (promptDialog.open) promptDialog.close();
        resetCanvas();
    }
    async function showImage(job, attempt = 0) {
        if (job.status !== 'complete') return;
        selected = job.id;
        const frame = document.querySelector('#canvas-frame');
        document.querySelector('#canvas-title').textContent = 'Your image';
        const resTag = job.resolution ? ` · ${job.resolution === '8mp_ultra' ? '8MP ULTRA DETAIL' : job.resolution.toUpperCase()}` : '';
        const modeTag = job.mode === 'inpaint' ? ' · Inpainted' : (job.mode === 'img2img' ? ' · Img2Img' : '');
        document.querySelector('.stage-caption').textContent = `Seed ${job.seed} · ${job.ratio}${resTag}${modeTag}`;
        try {
            const url = await imageFor(job);
            if (selected !== job.id) return;
            frame.classList.add('has-image'); frame.replaceChildren();
            const link = document.createElement('a');
            link.className = 'canvas-image-link';
            link.href = url;
            link.target = '_blank';
            link.rel = 'noreferrer';
            link.title = 'Open full resolution in a new tab';
            link.setAttribute('aria-label', `Open full resolution image in new tab: ${job.text.slice(0, 80)}`);
            const image = document.createElement('img');
            image.alt = job.text; image.src = url;
            link.append(image);
            frame.append(link);
            const download = document.querySelector('#download-image');
            download.hidden = false; download.href = url; download.setAttribute('download', `AIStudio-${job.id}.png`);
            if (outputStageActions) outputStageActions.hidden = false;
            window.StudioInpaint?.showOutputView?.();
        } catch (error) {
            if (selected !== job.id) return;
            if (attempt < 4) { setTimeout(() => showImage(job, attempt + 1), 3000); return; }
            status.textContent = 'Could not open this image. Refresh to check your Studio access.';
        }
    }
    async function deleteJob(job) {
        const card = list.querySelector(`[data-job-id="${job.id}"]`);
        if (card) card.classList.add('deleting');
        try {
            await api('delete', { id: job.id });
            if (images.has(job.id)) {
                try { URL.revokeObjectURL(await images.get(job.id)); } catch (e) {}
                images.delete(job.id);
            }
            if (thumbnails.has(job.id)) {
                try { URL.revokeObjectURL(await thumbnails.get(job.id)); } catch (e) {}
                thumbnails.delete(job.id);
            }
            jobs = jobs.filter(j => j.id !== job.id);
            fingerprint = '';
            if (awaitedJob === job.id) awaitedJob = null;
            updateLimitWarning();
            if (selected === job.id) {
                resetCanvas();
            }
            const active = jobs.filter(j => ['queued', 'running'].includes(j.status));
            status.textContent = active.length 
                ? `${active.length} active ${active.length === 1 ? 'job' : 'jobs'}. You can leave this page and come back for the result.` 
                : (jobs.length 
                    ? `Your latest images. Storage is temporary — they are deleted after ${retentionLabel()}, oldest first. Download what you want to keep.`
                    : 'No image jobs.');
            renderJobs();
        } catch (error) {
            if (error.status === 404) {
                jobs = jobs.filter(j => j.id !== job.id);
                fingerprint = '';
                if (awaitedJob === job.id) awaitedJob = null;
                updateLimitWarning();
                renderJobs();
                return;
            }
            if (card) card.classList.remove('deleting');
            status.textContent = error.message || (job.status === 'running'
                ? 'Could not cancel generation. Please try again.'
                : (job.status === 'queued' ? 'Could not remove job from queue. Please try again.' : 'Could not delete generation. Please try again.'));
        }
    }
    function renderJobs() {
        const signature = JSON.stringify(jobs.map(({ updated, ...job }) => job));
        if (signature === fingerprint) return;
        fingerprint = signature; thumbnailObserver?.disconnect(); list.replaceChildren();
        forgetImages(new Set(jobs.map(job => job.id)));
        const queue = jobs.filter(job => job.status === 'queued');
        if (queue.length < 2) { reorderMode = false; reorderButton.textContent = 'Reorder queue'; }
        reorderButton.hidden = queue.length < 2;
        list.classList.toggle('reorder-mode', reorderMode);
        jobs.forEach(job => {
            const card = document.createElement('article');
            card.className = 'generation-card';
            card.dataset.jobId = job.id;
            card.dataset.status = job.status;
            const label = document.createElement('p');
            label.textContent = job.text;
            const state = document.createElement('span');
            state.className = 'generation-state';
            const resBadge = job.resolution ? ` · ${job.resolution === '8mp_ultra' ? '8MP ULTRA' : job.resolution.toUpperCase()}` : '';
            const hasProgress = job.status === 'running' && Number.isFinite(job.progress) && Number.isFinite(job.progress_total) && job.progress_total > 0;
            let percent = hasProgress ? Math.min(100, Math.max(0, Math.round(job.progress / job.progress_total * 100))) : null;
            if (percent !== null) {
                const prev = jobProgress.get(job.id) || 0;
                percent = Math.max(prev, percent);
                jobProgress.set(job.id, percent);
            }
            const etaText = Number.isFinite(job.eta_seconds) && job.eta_seconds > 0
                ? ` · about ${job.eta_seconds < 60 ? `${job.eta_seconds}s` : `${Math.ceil(job.eta_seconds / 60)}m`} left` : '';
            // Without a step count there is no percentage to show, but the stage
            // is still known. Saying "Starting…" for the whole render is what made
            // a working generation look like a hung one.
            const stageLabel = { queued: 'Queued on the PC…', generating: 'Generating…',
                finishing: 'Finishing…', swapping: 'Loading the model…',
                starting_engine: 'Starting the image engine…' }[job.progress_stage];
            const runningLabel = job.progress_stage === 'finishing'
                ? (percent ? `Finishing… · ${percent}%` : 'Finishing…')
                : (hasProgress ? `Generating · ${percent}%${etaText}` : (stageLabel || 'Starting…'));
            const layerCount = loraSummary(job).length;
            const queueIndex = queue.findIndex(item => item.id === job.id);
            const queuedLabel = queueIndex === 0 ? 'Queued · Up next' : `Queued · #${queueIndex + 1}`;
            const modeTag = job.mode === 'inpaint' ? ' · Inpainted' : (job.mode === 'img2img' ? ' · Img2Img' : '');
            state.textContent = `${({queued:queuedLabel, running:runningLabel, complete:'Ready', failed:'Failed'})[job.status] || job.status}${modeTag}${resBadge} · ${modelName(job.model)}${layerCount ? ` · ${layerCount} LoRA${layerCount === 1 ? '' : 's'}` : ''}`;
            card.append(state, label);
            card.tabIndex = 0;
            card.setAttribute('role', 'button');
            card.setAttribute('aria-label', `View full prompt: ${job.text.slice(0, 80)}`);
            card.title = 'View full prompt';
            card.addEventListener('click', () => {
                showImage(job);
                showPrompt(job);
            });
            card.addEventListener('keydown', event => {
                if (event.target === card && (event.key === 'Enter' || event.key === ' ')) {
                    event.preventDefault();
                    showImage(job);
                    showPrompt(job);
                }
            });
            if (job.status === 'queued') {
                const controls = document.createElement('div'); controls.className = 'queue-controls';
                const handle = document.createElement('button'); handle.type = 'button'; handle.className = 'queue-handle'; handle.textContent = '⠿';
                handle.title = 'Drag to reorder'; handle.setAttribute('aria-label', `Drag queued image ${queueIndex + 1} of ${queue.length}`);
                const up = document.createElement('button'); up.type = 'button'; up.className = 'queue-move'; up.textContent = '↑ Earlier'; up.disabled = queueIndex === 0; up.setAttribute('aria-label', 'Move earlier');
                const down = document.createElement('button'); down.type = 'button'; down.className = 'queue-move'; down.textContent = 'Later ↓'; down.disabled = queueIndex === queue.length - 1; down.setAttribute('aria-label', 'Move later');
                [handle, up, down].forEach(button => button.addEventListener('click', event => event.stopPropagation()));
                up.addEventListener('click', () => moveQueued(job.id, -1)); down.addEventListener('click', () => moveQueued(job.id, 1));
                handle.addEventListener('pointerdown', event => {
                    if (reorderSaving || reorderDragging || event.button !== 0 || event.pointerType === 'touch') return;
                    event.preventDefault(); event.stopPropagation();
                    reorderDragging = true;
                    const expected = queuedIds();
                    const pointerId = event.pointerId;
                    const startX = event.clientX, startY = event.clientY;
                    const box = card.getBoundingClientRect();
                    const ghost = card.cloneNode(true);
                    ghost.classList.add('queue-drag-ghost');
                    ghost.classList.remove('queue-placeholder');
                    ghost.removeAttribute('id');
                    ghost.setAttribute('aria-hidden', 'true');
                    Object.assign(ghost.style, {
                        left: `${box.left}px`, top: `${box.top}px`, width: `${box.width}px`, height: `${box.height}px`
                    });
                    document.body.append(ghost);
                    card.classList.add('queue-placeholder');
                    document.body.classList.add('queue-is-dragging');
                    handle.setPointerCapture(pointerId);
                    const move = moveEvent => {
                        if (moveEvent.pointerId !== pointerId) return;
                        moveEvent.preventDefault();
                        ghost.style.transform = `translate3d(${moveEvent.clientX - startX}px, ${moveEvent.clientY - startY}px, 0)`;
                        const target = document.elementsFromPoint(moveEvent.clientX, moveEvent.clientY)
                            .map(element => element.closest?.('.generation-card[data-status="queued"]'))
                            .find(element => element && element !== card && !element.classList.contains('queue-drag-ghost'));
                        if (!target || target === card || target.dataset.status !== 'queued') return;
                        const targetBox = target.getBoundingClientRect();
                        const draggedBox = card.getBoundingClientRect();
                        const sameRow = Math.abs(targetBox.top - draggedBox.top) < Math.min(targetBox.height, draggedBox.height) / 2;
                        const before = sameRow ? moveEvent.clientX < targetBox.left + targetBox.width / 2 : moveEvent.clientY < targetBox.top + targetBox.height / 2;
                        const reference = before ? target : target.nextSibling;
                        if (reference !== card && card.nextSibling !== reference) list.insertBefore(card, reference);
                        const edge = 64;
                        if (moveEvent.clientY < edge) window.scrollBy(0, -12);
                        else if (moveEvent.clientY > window.innerHeight - edge) window.scrollBy(0, 12);
                    };
                    const finish = finishEvent => {
                        if (finishEvent.pointerId !== pointerId) return;
                        finishEvent.preventDefault(); finishEvent.stopPropagation();
                        reorderDragging = false;
                        window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', finish); window.removeEventListener('pointercancel', finish);
                        document.body.classList.remove('queue-is-dragging');
                        ghost.remove(); card.classList.remove('queue-placeholder');
                        const dropped = finishEvent.type === 'pointerup';
                        const order = dropped
                            ? [...list.querySelectorAll('.generation-card[data-status="queued"]')].map(item => item.dataset.jobId)
                            : expected;
                        applyQueuedOrder(order); fingerprint = ''; renderJobs(); saveQueueOrder(order, expected);
                    };
                    window.addEventListener('pointermove', move, { passive: false });
                    window.addEventListener('pointerup', finish, { passive: false });
                    window.addEventListener('pointercancel', finish, { passive: false });
                });
                controls.append(handle, up, down); card.append(controls);
            }
            if (job.status === 'running') {
                const progress = document.createElement('div');
                progress.className = `generation-progress${hasProgress ? '' : ' indeterminate'}`;
                progress.setAttribute('role', 'progressbar');
                progress.setAttribute('aria-label', 'Image generation progress');
                if (hasProgress) {
                    progress.setAttribute('aria-valuenow', String(percent));
                    progress.setAttribute('aria-valuemin', '0');
                    progress.setAttribute('aria-valuemax', '100');
                }
                const fill = document.createElement('span');
                if (hasProgress) fill.style.width = `${percent}%`;
                progress.append(fill);
                card.append(progress);
            }
            if (job.status === 'complete') {
                const preview = document.createElement('button');
                preview.type = 'button';
                preview.className = 'generation-preview';
                preview.title = 'Open full resolution in a new tab';
                preview.setAttribute('aria-label', `Open full resolution image in a new tab: ${job.text.slice(0, 80)}`);
                preview.addEventListener('click', event => {
                    event.preventDefault();
                    event.stopPropagation();
                    openFullImage(job);
                });
                const image = document.createElement('img');
                image.alt = '';
                image.loading = 'lazy';
                if (job.has_thumbnail) {
                    image.studioJob = job;
                    if (thumbnailObserver) thumbnailObserver.observe(image);
                    else thumbnailFor(job).then(url => { image.src = url; }).catch(() => card.classList.add('unreadable'));
                } else {
                    card.classList.add('thumbnail-unavailable');
                }
                preview.append(image);
                card.prepend(preview);
            }
            const deleteBtn = document.createElement('button');
            deleteBtn.type = 'button';
            deleteBtn.className = 'generation-delete';
            const actionLabel = job.status === 'running' 
                ? 'Cancel generation' 
                : (job.status === 'queued' ? 'Remove from queue' : 'Delete generation');
            deleteBtn.title = actionLabel;
            deleteBtn.setAttribute('aria-label', `${actionLabel}: ${job.text.slice(0, 80)}`);
            deleteBtn.innerHTML = '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>';
            deleteBtn.addEventListener('click', async (event) => {
                event.preventDefault();
                event.stopPropagation();
                await deleteJob(job);
            });
            card.append(deleteBtn);
            if (job.error) {
                const error = document.createElement('small');
                error.textContent = job.error;
                card.append(error);
            }
            list.append(card);
        });
        updateLimitWarning();
        const finished = awaitedJob && jobs.find(job => job.id === awaitedJob && job.status === 'complete');
        if (finished) { showImage(finished); awaitedJob = null; }
    }
    let serverBoot = null;

    async function refresh() {
        if (reorderDragging) { clearTimeout(timer); timer = setTimeout(refresh, 1000); return; }
        if (busy) return;
        busy = true; clearTimeout(timer);
        try {
            if (!contentKey && encryptionOn) { locked('Enter your Studio key to unlock this browser.'); return; }
            const result = await api('status'); online = result.online;
            // The server restarted, so this page is running code the server has
            // replaced. Reload once rather than leaving someone looking at a bug
            // that was fixed, which is exactly what happened during testing.
            if (result.serverBoot) {
                if (!serverBoot) serverBoot = result.serverBoot;
                else if (serverBoot !== result.serverBoot) { location.reload(); return; }
            }
            // The server watches for releases and puts what it found here, so
            // update.js learns about one through a poll that was happening
            // anyway rather than reaching for the network itself.
            window.dispatchEvent(new CustomEvent('studio-update-info',
                                                 { detail: result.update || null }));
            jobs = await Promise.all(result.jobs.map(async job => {
                const text = await readPrompt(job.prompt);
                const negativeText = job.negative_prompt ? await readPrompt(job.negative_prompt) : '';
                return {
                    ...job,
                    encryptedPrompt: job.prompt,
                    encryptedNegativePrompt: job.negative_prompt,
                    prompt: text,
                    negativePrompt: negativeText,
                    text,
                    negativeText
                };
            }));
            if (result.retentionHours) retention = result.retentionHours;
            if (result.retentionImages) maxRecentImages = result.retentionImages;
            unlock.hidden = true;
            if (studioMain) studioMain.hidden = false;
            const hostState = result.hostState || (online ? 'ready' : 'offline');
            liteActive = Boolean(result.liteQueueActive || result.liteJobRunning);
            const active = jobs.filter(job => ['queued','running'].includes(job.status));
            const myRunningJob = active.find(job => job.status === 'running');
            const badgeText = badge?.querySelector('span');

            const upscale = Boolean(form.elements.upscale?.checked);
            const resolution = form.elements.resolution?.value || '1mp';
            const standardNote = resolution === 'draft'
                ? 'Connected. Draft renders ultra-fast for testing prompts.'
                : (upscale && resolution !== '1mp'
                    ? 'Connected. SeedVR2 upscaling is enabled for this larger output and takes longer.'
                    : (resolution === '8mp_ultra'
                        ? 'Connected. Ultra Detail uses a second tiled refinement pass and takes longer.'
                        : 'Connected. Generation usually takes 1–2 minutes.'));

            if (!online || hostState === 'offline') {
                badge.dataset.online = 'false';
                if (badgeText) badgeText.textContent = 'PC offline';
                note.textContent = 'Image generation is offline. Start it on your PC to generate images.';
            } else if (hostState === 'busy_gaming') {
                badge.dataset.online = 'busy';
                if (badgeText) badgeText.textContent = 'Host PC Under Load';
                note.textContent = 'Host PC is currently under heavy load. Generations are paused and will resume when idle.';
            } else if (active.length > 0) {
                badge.dataset.online = 'busy';
                if (badgeText) badgeText.textContent = myRunningJob ? 'Generating…' : 'Queue Active';
                note.textContent = myRunningJob ? 'Your image is generating now on your PC…' : 'Your generations are queued on your PC.';
            } else if (result.liteJobRunning) {
                badge.dataset.online = 'busy';
                if (badgeText) badgeText.textContent = 'Lite Studio Generating';
                note.textContent = 'A Lite Studio generation is in progress on your PC. Any generation you submit will take priority.';
            } else if (result.liteQueueActive) {
                badge.dataset.online = 'busy';
                if (badgeText) badgeText.textContent = 'Lite Queue Active';
                note.textContent = 'Lite Studio generations are queued on your PC. Any generation you submit will take priority.';
            } else {
                badge.dataset.online = 'true';
                if (badgeText) badgeText.textContent = 'PC connected';
                note.textContent = standardNote;
            }

            status.textContent = active.length ? `${active.length} active ${active.length === 1 ? 'job' : 'jobs'}. You can leave this page and come back for the result.` : `Your latest images. Storage is temporary — they are deleted after ${retentionLabel()}, oldest first. Download what you want to keep.`;
            renderJobs();
        } catch (error) {
            online = false; badge.dataset.online = 'false';
            badge.querySelector('span').textContent = error.status === 401 ? 'Studio locked' : 'Not connected';
            if (signedOut(error)) return;
            if (error.status === 401 || error.status === 403) locked(error.message);
            else { unlock.hidden = true; note.textContent = error.message; }
        } finally { busy = false; buttons(); timer = setTimeout(refresh, nextPollDelay()); }
    }
    let initialized = false;
    // Which storage mode the server is in. Asked once, before anything tries to
    // read a job, because the answer decides whether there is an unlock step at
    // all. A server that does not answer leaves encryption off: an unlock screen
    // that cannot be satisfied is a worse failure than a readable file.
    async function loadStorageMode() {
        try {
            const response = await fetch('/api/studio?action=config', { cache: 'no-store' });
            if (!response.ok) return;
            const config = await response.json();
            encryptionOn = Boolean(config.encryption);
        } catch (error) {
            encryptionOn = false;
        }
        if (!encryptionOn && unlock) unlock.hidden = true;
        // Lock Studio belongs to the encryption feature and does nothing without
        // it: with encryption off there is no key to forget, so pressing it
        // reloaded the page and left the studio wide open - a button promising
        // to lock something, next to everything it had not locked. Storage
        // encryption ships off, so for most people the honest thing is for the
        // button not to be there.
        const lockButton = document.querySelector('#lock-studio');
        if (lockButton) lockButton.hidden = !encryptionOn;
    }

    async function initializeRemote() {
        if (initialized) return;
        initialized = true;
        reorderButton.addEventListener('click', () => {
            reorderMode = !reorderMode;
            reorderButton.textContent = reorderMode ? 'Done reordering' : 'Reorder queue';
            fingerprint = ''; renderJobs();
            status.textContent = reorderMode ? 'Use Earlier and Later to arrange the pending jobs. Changes save automatically.' : 'Queue order saved.';
            if (reorderMode) list.querySelector('.queue-handle:not([hidden]), .queue-move:not(:disabled)')?.focus();
        });
        document.querySelector('#lock-studio')?.addEventListener('click', async () => {
            try { await api('lock'); } catch (e) {}
            try { localStorage.removeItem(STORE); } catch (e) {}
            try { sessionStorage.removeItem(STORE); } catch (e) {}
            window.location.reload();
        });
        document.querySelector('#prompt-dialog-close')?.addEventListener('click', () => promptDialog?.close());
        promptDialog?.addEventListener('click', event => {
            if (event.target === promptDialog) {
                const rect = promptDialog.getBoundingClientRect();
                const clickedInDialog = (
                    rect.top <= event.clientY &&
                    event.clientY <= rect.top + rect.height &&
                    rect.left <= event.clientX &&
                    event.clientX <= rect.left + rect.width
                );
                if (!clickedInDialog) {
                    promptDialog.close();
                }
            }
        });
        document.querySelector('#copy-prompt').addEventListener('click', async () => {
            try {
                await navigator.clipboard.writeText(openPrompt);
                copyStatus.textContent = 'Copied to clipboard.';
            } catch (error) {
                const range = document.createRange();
                range.selectNodeContents(promptDialogText);
                const selection = window.getSelection();
                selection.removeAllRanges();
                selection.addRange(range);
                copyStatus.textContent = 'Could not copy automatically. The prompt is selected for you.';
            }
        });
        document.querySelector('#use-prompt')?.addEventListener('click', () => {
            if (openJob && window.StudioComposer?.applyConfig) {
                window.StudioComposer.applyConfig({
                    ...openJob,
                    seed: "",
                    prompt: openJob.text || openPrompt,
                    negativePrompt: openJob.negativeText !== undefined ? openJob.negativeText : openNegativePrompt
                });
            } else {
                form.elements.prompt.value = openPrompt;
                if (form.elements.negativePrompt) form.elements.negativePrompt.value = openNegativePrompt;
                form.dispatchEvent(new Event('input', { bubbles: true }));
            }
            promptDialog.close();
            form.elements.prompt.focus();
        });
        document.querySelector('#dialog-save-preset-btn')?.addEventListener('click', async () => {
            if (!openJob) return;
            if (window.StudioComposer?.saveCustomPresetFromConfig) {
                const saved = await window.StudioComposer.saveCustomPresetFromConfig({
                    ...openJob,
                    prompt: openJob.text || openPrompt,
                    negativePrompt: openJob.negativeText !== undefined ? openJob.negativeText : openNegativePrompt
                });
                if (saved && copyStatus) {
                    copyStatus.textContent = 'Saved as custom preset!';
                }
            }
        });
        document.querySelector('#image-limit-warning-close').addEventListener('click', () => {
            const completed = jobs.filter(job => job.status === 'complete');
            const approachingThreshold = Math.max(1, maxRecentImages - 4);
            if (completed.length >= maxRecentImages) {
                dismissedOldestId = completed[completed.length - 1].id;
            } else if (completed.length >= approachingThreshold) {
                dismissedApproaching = true;
            }
            limitWarning.hidden = true;
        });
        window.addEventListener('studio-mode-change', () => { buttons(); refresh(); });
        window.addEventListener('studio-input-change', buttons);
        window.addEventListener('studio-jobs-changed', () => { refresh(); });
        outputToInpaint?.addEventListener('click', async () => {
            if (!selected) return;
            const job = jobs.find(j => j.id === selected);
            if (!job) return;
            try {
                const url = await imageFor(job);
                window.StudioInpaint?.setMode?.('inpaint');
                await window.StudioInpaint?.loadImage?.(url);
                form.elements.prompt.value = job.text;
                if (form.elements.negativePrompt) {
                    form.elements.negativePrompt.value = job.negativeText || '';
                }
                form.dispatchEvent(new Event('input', { bubbles: true }));
                if (window.innerWidth <= 760) {
                    document.querySelector('#studio-stage')?.scrollIntoView({ behavior: 'smooth' });
                }
            } catch (e) {
                status.textContent = 'Could not load output image for inpainting.';
            }
        });
        outputToImg2img?.addEventListener('click', async () => {
            if (!selected) return;
            const job = jobs.find(j => j.id === selected);
            if (!job) return;
            try {
                const url = await imageFor(job);
                window.StudioInpaint?.setMode?.('img2img');
                await window.StudioInpaint?.loadImage?.(url);
                form.elements.prompt.value = job.text;
                if (form.elements.negativePrompt) {
                    form.elements.negativePrompt.value = job.negativeText || '';
                }
                form.dispatchEvent(new Event('input', { bubbles: true }));
                if (window.innerWidth <= 760) {
                    document.querySelector('#studio-stage')?.scrollIntoView({ behavior: 'smooth' });
                }
            } catch (e) {
                status.textContent = 'Could not load output image for img2img.';
            }
        });
        form.addEventListener('input', buttons); form.addEventListener('change', buttons);
        // Starter buttons change the prompt without firing an input event.
        form.addEventListener('click', () => queueMicrotask(buttons));
        form.addEventListener('submit', async event => {
            event.preventDefault(); if (generateBtns[0]?.disabled) return;
            if (!form.elements.seed.validity.valid) { document.querySelector('#advanced-settings').open = true; form.elements.seed.reportValidity(); return; }
            if (form.elements.steps && !form.elements.steps.validity.valid) { document.querySelector('#advanced-settings').open = true; form.elements.steps.reportValidity(); return; }
            if (form.elements.guidance && !form.elements.guidance.validity.valid) { document.querySelector('#advanced-settings').open = true; form.elements.guidance.reportValidity(); return; }
            const negativeSettings = document.querySelector('#negative-settings');
            const mode = window.StudioInpaint?.getMode?.() || 'txt2img';
            const selectedModel = form.elements.model?.value || 'krea2_turbo';
            // Masked edits are Krea 2 only, but the checkpoint is the user's choice now -
            // the server redirects anything without a LanPaint graph of its own.
            const isStudio2 = (mode === 'inpaint') || selectedModel.startsWith('krea2_');
            const settings = {
                mode,
                prompt: form.elements.prompt.value,
                negativePrompt: negativeSettings?.hidden ? '' : (form.elements.negativePrompt?.value || ''),
                seed: form.elements.seed.value,
                ratio: form.elements.ratio?.value || 'square',
                resolution: form.elements.resolution?.value || '1mp',
                model: (mode === 'inpaint' && !selectedModel.startsWith('krea2_')) ? 'krea2_turbo' : selectedModel,
                loras: window.StudioComposer?.getLoras?.() || [],
                upscale: Boolean(form.elements.upscale?.checked),
                promptEnhance: Boolean(form.elements['prompt-enhance']?.checked && isStudio2)
            };
            if (mode === 'img2img' || mode === 'inpaint') {
                settings.denoise = window.StudioInpaint?.getDenoise?.() ?? 0.65;
            }
            if (mode === 'inpaint') {
                settings.growMask = window.StudioInpaint?.getGrowMask?.() ?? 6;
            }
            const stepsVal = form.elements.steps?.value?.trim();
            if (stepsVal && /^\d+$/.test(stepsVal)) settings.steps = parseInt(stepsVal, 10);
            const guidanceVal = form.elements.guidance?.value?.trim();
            if (guidanceVal && !isNaN(parseFloat(guidanceVal))) settings.guidance = parseFloat(guidanceVal);
            const samplerVal = form.elements.sampler?.value?.trim();
            if (samplerVal) settings.sampler = samplerVal;
            // Same limit the backend enforces before the engine starts. Checked here
            // too so a refused prompt never becomes a queued job at all - just
            // faster feedback, not a replacement for that check.
            const guardRefusal = window.StudioContentGuard?.unsafeImagePrompt(settings.prompt, settings.negativePrompt, settings.mode);
            if (guardRefusal) { note.textContent = guardRefusal; return; }
            submitting = true; buttons(); note.textContent = 'Adding job to queue…';
            try {
                const prepared = await submission.prepare(settings, window.StudioInpaint, async (id, type, bytes) => {
                    note.textContent = type === 'mask' ? 'Encrypting & uploading inpaint mask…' : 'Encrypting & uploading input image…';
                    const sealedAsset = await seal(bytes);
                    const response = await fetch(`/api/studio?action=upload-asset&id=${encodeURIComponent(id)}&type=${type}`, {
                        method: 'POST', body: sealedAsset, headers: { 'Content-Type': 'application/octet-stream' }
                    });
                    // An upload is the request most likely to be answered by a Cloudflare
                    // HTML error page rather than by us, so never assume the body parses.
                    const result = await response.json().catch(() => ({}));
                    if (!response.ok || !result.key) throw new Error(result.error || 'Failed to upload image asset.');
                    return result.key;
                });
                const { id: jobId, ...assetKeys } = prepared;
                Object.assign(settings, assetKeys);

                const sealed = bytesToBase64(await seal(encoder.encode(settings.prompt)));
                const sealedNegative = settings.negativePrompt ? bytesToBase64(await seal(encoder.encode(settings.negativePrompt))) : '';
                note.textContent = 'Queueing generation…';
                const accepted = await api('generate', { ...settings, prompt: sealed, negativePrompt: sealedNegative, id: jobId });
                awaitedJob = accepted.id; submission.accepted();
                await refresh();
            } catch (error) { note.textContent = error.message; }
            finally { submitting = false; buttons(); }
        });
        document.querySelector('#unlock-form').addEventListener('submit', async event => {
            event.preventDefault(); const button = event.currentTarget.querySelector('button'); button.disabled = true;
            const field = document.querySelector('#studio-key'); const message = document.querySelector('#unlock-message');
            const rememberBox = document.querySelector('#studio-remember');
            const shouldRemember = rememberBox ? rememberBox.checked : true;
            const key = field.value.trim();
            try {
                await api('unlock', { verifier: hex(await derive('studio-verify-v1', key)), remember: shouldRemember });
                await useKey(key); remember(key, shouldRemember);
                field.value = ''; message.textContent = ''; images.clear(); thumbnails.clear();
                await refresh();
            }
            catch (error) { if (!signedOut(error)) message.textContent = error.message; }
            finally { button.disabled = false; }
        });
        document.addEventListener('visibilitychange', () => { if (!document.hidden) { idlePolls = 0; refresh(); } });
        // Alt-tabbing between apps does not always fire visibilitychange. Poll
        // straight away rather than only shortening the next wait: coming back to
        // the window is exactly when a restarted server has to be noticed, and
        // waiting out a five-minute hidden backoff first defeats the point.
        window.addEventListener('focus', () => { idlePolls = 0; refresh(); });
        await loadStorageMode();
        const stored = remembered();
        if (stored) await useKey(stored);
        refresh();
    }
    window.addEventListener('studio-ready', initializeRemote, { once: true });
    // The composer may finish before this script arrives from the network/cache.
    if (window.StudioReady) initializeRemote();
}());

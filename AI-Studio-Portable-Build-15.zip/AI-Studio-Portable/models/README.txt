Drop model files in here.

Each folder matches what ComfyUI calls that kind of model, apart from llm, which
is the studio's own. Drop a model in and the studio picks it up on the next
rescan - use Rescan in the Models panel, or just restart.

Models come in two shapes and it works out which yours is by reading the file,
so either folder will do:

  checkpoints        one file with everything in it (SDXL, Illustrious, Pony)
  diffusion_models   the model only, sharing a text encoder and a VAE that
                     live in their own folders (Krea 2, Anima)

Plenty of Krea 2 models are published with "checkpoint" in the filename, which
is why the folder is not taken as the answer. What it cannot work out is the
exact pipeline within a shape - an anime model and a photographic one look the
same - so if results come out wrong, the Models panel lets you change that per
file.

The other folders hold the parts of models rather than whole ones, and are read
by whichever checkpoint needs them rather than being offered on their own.

  checkpoints        all-in-one models (SDXL, Illustrious, and similar)
  diffusion_models   models that come split from their text encoder
  text_encoders      the text half of a split model
  vae                decoders
  loras              LoRA layers
  upscale_models     upscalers
  controlnet         ControlNet models
  embeddings         textual inversions
  clip_vision        vision encoders
  llm                chat models (.gguf), and their mmproj file if they see

The folders themselves ship empty. Nothing you put in them is ever committed or
included in a release, so what you drop here stays yours.

You can also use models you already have somewhere else without moving them.
In config.json:

  "models_path": "E:/SomeWhere/ComfyUI/models"

That folder is only ever read from. Nothing is written, moved or renamed there.

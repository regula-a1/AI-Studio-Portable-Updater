# Version log

Builds are numbered from 1 and count up by one, forever. There are no decimals
and no major or minor versions - Build 7 came after Build 6, and that is the
whole system. The number you are running is shown faintly in the corner of the
studio; click it to read this list.

Every build published adds an entry here first. The entry is what the studio
shows you when you restart after an update, so if it is not written down, you
were not told.

## Build 13 - 2026-09-18

- Stronger protection against child sexual abuse material. This was already
  refused in chat; it is now refused in image generation as well.
- Adult work is unaffected. Nothing else is restricted, filtered or logged.
- The README and the licence state the limit plainly.

## Build 12 - 2026-09-18

- There is a settings page. The gear button beside Report a problem opens it.
  Most of what it holds could only be changed before by finding config.json and
  editing it by hand, which meant in practice nobody changed anything.
- **Which chat model to start with** is now yours to pick, under Models.
  Automatic still chooses the best one whose weights are actually here, and a
  model you pick is skipped if its file has gone rather than failing the
  conversation.
- **Video memory use** is the one worth knowing about. The image engine was
  never told how much of your graphics card it could use, so it guessed - and
  on an 8 GB card, with a 13 GB model, guessing badly means generation that
  crawls or fails. Auto now decides from your card, and you can override it.
  If images fail or the machine locks up while rendering, try Low.
- Also there: how long images are kept, whether to check for new builds and
  where from, whether the studio opens your browser, which graphics card type
  the installer assumes, both engine ports, and the borrowed models folder.
  Models and colour schemes are reached from the same place.
- A setting left at its default is no longer written to config.json, so that
  file stays a record of what you chose rather than a frozen copy of every
  default that then cannot follow a later change.
- Errors from the studio's own interface now say what went wrong. Any
  unexpected error used to arrive as a dropped connection with no message at
  all, because the code that reported it had a fault of its own.

## Build 11 - 2026-09-17

- The studio works out what a model is by reading it, instead of guessing from
  which folder it is in. Plenty of Krea 2 models are published with the word
  "checkpoint" in their filename, so they get put in the checkpoints folder and
  were being offered as SDXL - which would have produced nothing usable. They
  are recognised as Krea 2 now wherever you put them, and the engine loads them
  from either folder. You should not have to know the difference between the
  two to use your own models.

## Build 10 - 2026-09-17

- The studio could be told a new build did not exist, and believe it. It asks
  GitHub two different ways and both answers are cached without saying so, so
  one of them could still be reporting the previous build minutes after a new
  one went out - and the studio trusted whichever it asked first. It now asks
  both and believes the newer one. This is why Build 9 appeared not to arrive.
- You can check for updates yourself. Click the build number in the corner and
  the version log now says when it last looked and whether anything is waiting,
  with a button to look again right now. It checks every five minutes on its
  own and used to say nothing in between, so there was no way to tell a slow
  update from a broken one.

## Build 9 - 2026-09-17

- Krea 2 models you drop in are found. Build 6 only looked in the checkpoints
  folder, which holds one-file models like SDXL - but a Krea 2 model is the
  diffusion half on its own and belongs in diffusion_models, so dropping one in
  the right place showed nothing at all. Both folders are scanned now, and a
  Krea 2 model appears under Krea 2 rather than being offered as SDXL. It
  borrows Turbo's text encoder and VAE, which are shared.
- The Models panel names both folders and says which kind of file goes in each,
  because putting a model in the other one is exactly how it ends up invisible.

## Build 8 - 2026-09-17

- Moving the studio folder now works properly. The file telling the image
  engine where this install keeps its models held the full path and was only
  written once, during setup - so after moving the folder to another drive, or
  out of a synced folder like OneDrive, your own checkpoints and LoRAs would be
  listed but fail to load when you actually generated. The studio notices it
  has moved when it starts and puts that right. Nothing else needs doing:
  close it, move the folder, run Start.bat from the new location.

## Build 7 - 2026-09-17

- The Models panel says where to put your own checkpoints, and lists the exact
  folders it just checked. A file that was never found and a folder you did not
  mean to use look the same from the outside; now the panel tells you which.
- A problem reading one model folder no longer empties the whole Models panel.
  Anything that went wrong while checking what is installed used to leave the
  panel saying nothing at all, which looks identical to having no models.

## Build 6 - 2026-09-17

- Checkpoints you drop in are found. Putting a .safetensors file into
  models/checkpoints did nothing at all before this: the studio checked whether
  four specific files were present rather than looking at what was in the
  folder, so your own model was invisible however many times you rescanned or
  restarted - while the note in that folder promised the opposite.
  Drop one in, press Rescan, and it appears in the model picker under its own
  filename.
- Because nothing in a checkpoint file says which pipeline it wants - SDXL,
  SD 1.5, Pony and Illustrious all look the same from outside - the studio
  assumes SDXL and lets you change it per file in the Models panel. If an anime
  model comes out looking washed out or overcooked, that is the setting to
  change; it also picks the right step count and guidance for you.

## Build 5 - 2026-09-17

- Updates show up faster. The studio was reading its release information
  through a cache that holds a file for about five minutes, so a build could
  sit published for that long before anything noticed it. It now reads from an
  address that is not cached, and falls back to the old one if that is
  unavailable. A new build should reach you within a few minutes of being
  published rather than up to ten.

## Build 4 - 2026-09-17

- The bracketed prompt template has been dropped. The library ships the one
  worked example and nothing else; it is meant to fill up with your own saved
  settings rather than ours.

## Build 3 - 2026-09-17

- Pressing Generate twice on the same prompt makes a second image. It used to
  finish in about two seconds and hand back the first one: an unchanged prompt
  with no seed set produced an identical request, and ComfyUI answers an
  identical request out of its cache. Leaving the seed box empty now means a
  new random seed each time, which is what it always looked like it meant.
  Typing a seed in still repeats exactly, which is what that is for.
- The Models panel lists what you have rather than what you do not. It used to
  show three checkpoints permanently marked "Missing", naming files the studio
  never ships and you were never asked to fetch.
- The preset library ships with two starters instead of ten assorted examples,
  both filed under "Starter Prompts". One is a character prompt written out in
  full; the other is the same thing with its parts named and left blank. Open
  the template, keep the example beside it, and it is clear what belongs in
  each bracket. Your own saved presets are untouched.
- Updates appear on their own. The studio used to look for a new build once,
  a few seconds after the page opened, and never again - so one left open
  never noticed, and you had to reload before it would tell you. It now checks
  every few minutes in the background and the button appears by itself,
  usually within a minute or so of a build being published.

## Build 2 - 2026-09-17

Chat works properly now. Build 1 answered everything with the same nonsense
phrase on purpose, to prove an update could reach you; this is the build that
was being proved.

- Chat is on: Qwen3 1.7B, with memory, document reading and optional web
  search. Ask it something.
- The assistant is uncensored and will not lecture you, with one exception it
  will not be talked out of: it does not write sexual content involving anyone
  under 18. That is now enforced by the studio itself rather than left to the
  model's judgement, so it holds regardless of how a request is phrased.
- Better answers to short messages. Saying "hi" used to get "hi" back.
- The model pickers only list models you actually have. They used to show
  every model the studio supports, most of them marked "not installed", which
  on a fresh install meant a list of four things you cannot use and one you
  can. Anything you add later appears on its own. The Models panel still
  shows the full list, including what is missing, because that is a list to
  read rather than a menu to choose from.
- AMD and Intel graphics cards are installed for correctly. Before this, the
  installer only recognised NVIDIA cards and quietly assumed one when it found
  nothing, so an AMD or Intel PC downloaded about 22 GB of NVIDIA-only engines
  and then could not start. If your card is somehow still not recognised, set
  "gpu_vendor" in config.json to nvidia, amd, intel or cpu.

## Build 1 - 2026-09-17

The first release.

- Four modes in one window: text to image, image to image, inpainting, and chat.
- Everything runs on your own machine. No prompt, image or conversation is ever
  sent anywhere - generation and chat happen entirely on your own hardware, and
  the studio works with the network unplugged once it is installed. Three things
  do use the network, all of them visible: turning on web search sends that
  query to Bing or DuckDuckGo, installing a model downloads it from that model's
  own host, and the studio checks once at startup whether a newer build exists.
  You can switch the update check off in config.json.
- One folder holds all of it. The installer puts ComfyUI, llama.cpp, Python and
  the models inside the studio folder rather than anywhere else on your PC, so
  moving it means moving the folder and removing it means deleting the folder.
- Models you already have elsewhere are found and used where they are, and the
  studio only ever reads them.
- Krea 2 Turbo for images, with LoRA support, an upscaler, and a masked editor
  for changing part of an image instead of regenerating it.
- Chat is deliberately disabled in this build. It answers everything with the
  same nonsense phrase on purpose: this build exists to prove the update
  pipeline works from end to end, and the clearest way to see an update land is
  for the before and after to be impossible to confuse. The next build turns
  chat on properly - Qwen3 1.7B, with memory, document reading and optional web
  search.
- Sixteen colour schemes and a light/dark switch.
- A problem report you can read in full before it is saved, which never contains
  your prompts, images, conversations or file paths.
- Updates arrive by themselves: the studio notices a new build, asks before
  downloading anything, and never touches your images, models or settings.

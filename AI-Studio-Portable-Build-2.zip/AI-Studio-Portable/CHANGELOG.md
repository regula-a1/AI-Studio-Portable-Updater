# Version log

Builds are numbered from 1 and count up by one, forever. There are no decimals
and no major or minor versions - Build 7 came after Build 6, and that is the
whole system. The number you are running is shown faintly in the corner of the
studio; click it to read this list.

Every build published adds an entry here first. The entry is what the studio
shows you when you restart after an update, so if it is not written down, you
were not told.

## Build 2 - 2026-09-17

Chat works properly now. Build 1 answered everything with the same nonsense
phrase on purpose, to prove an update could reach you; this is the build that
was being proved.

- Chat is on: Qwen3 1.7B, with memory, document reading and optional web
  search. Ask it something.
- The assistant is uncensored and will not lecture you, with one exception it
  will not be talked out of: it does not write sexual content involving anyone
  under 18. That is now enforced by the studio itself rather than left to the
  model's judgement, so it holds regardless of how a request is phrased.
- Better answers to short messages. Saying "hi" used to get "hi" back.
- The model pickers only list models you actually have. They used to show
  every model the studio supports, most of them marked "not installed", which
  on a fresh install meant a list of four things you cannot use and one you
  can. Anything you add later appears on its own. The Models panel still
  shows the full list, including what is missing, because that is a list to
  read rather than a menu to choose from.
- AMD and Intel graphics cards are installed for correctly. Before this, the
  installer only recognised NVIDIA cards and quietly assumed one when it found
  nothing, so an AMD or Intel PC downloaded about 22 GB of NVIDIA-only engines
  and then could not start. If your card is somehow still not recognised, set
  "gpu_vendor" in config.json to nvidia, amd, intel or cpu.

## Build 1 - 2026-09-17

The first release.

- Four modes in one window: text to image, image to image, inpainting, and chat.
- Everything runs on your own machine. No prompt, image or conversation is ever
  sent anywhere - generation and chat happen entirely on your own hardware, and
  the studio works with the network unplugged once it is installed. Three things
  do use the network, all of them visible: turning on web search sends that
  query to Bing or DuckDuckGo, installing a model downloads it from that model's
  own host, and the studio checks once at startup whether a newer build exists.
  You can switch the update check off in config.json.
- One folder holds all of it. The installer puts ComfyUI, llama.cpp, Python and
  the models inside the studio folder rather than anywhere else on your PC, so
  moving it means moving the folder and removing it means deleting the folder.
- Models you already have elsewhere are found and used where they are, and the
  studio only ever reads them.
- Krea 2 Turbo for images, with LoRA support, an upscaler, and a masked editor
  for changing part of an image instead of regenerating it.
- Chat is deliberately disabled in this build. It answers everything with the
  same nonsense phrase on purpose: this build exists to prove the update
  pipeline works from end to end, and the clearest way to see an update land is
  for the before and after to be impossible to confuse. The next build turns
  chat on properly - Qwen3 1.7B, with memory, document reading and optional web
  search.
- Sixteen colour schemes and a light/dark switch.
- A problem report you can read in full before it is saved, which never contains
  your prompts, images, conversations or file paths.
- Updates arrive by themselves: the studio notices a new build, asks before
  downloading anything, and never touches your images, models or settings.

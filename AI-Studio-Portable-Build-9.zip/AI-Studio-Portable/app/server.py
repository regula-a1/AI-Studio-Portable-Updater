"""The local server: serves the interface and answers what it already calls.

This is the piece that replaced the cloud relay. The original posted jobs to a
Pages Function, parked them in D1, and had a worker poll for them over HTTPS.
On one machine all of that is dead weight, so this process is both ends at once:
it serves web/, owns the SQLite database and the image folder, and runs the
orchestrator in a thread instead of handing work to a remote poller.

Design notes, because they constrain everything below:

- **Standard library only.** The product ships to people who may not have Python
  at all, and the launcher installs a private runtime. Every dependency is one
  more thing that install has to get right, so the server itself takes none.
  ThreadingHTTPServer is comfortably enough for one user on localhost.

- **The wire contract is fixed.** web/ has no build step and is edited directly;
  its fetches were written against the cloud API and are not changing. Action
  names, parameter names and response field names below are copied from the
  client, not invented. web/js/ is the specification; this file follows it.

- **The server never sees plaintext.** Prompts, chat messages, draft metadata and
  image bytes all arrive sealed by the browser under the ASP1 envelope. Anything
  named `sealed_*`, plus prompts and draft assets, is an opaque blob here. The
  orchestrator holds the key because it has to; this layer does not.

- **One job at a time.** Kept from the original deliberately: the GPU is a single
  resource and the arbitration around it is load-bearing. `active-job.json` marks
  the job currently in flight so an ungraceful exit can fail it on restart rather
  than leaving it 'running' for ever.
"""
import json
import mimetypes
import os
import secrets
import sqlite3
import sys
import threading
import time
import logging
import traceback
import uuid

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

HERE = Path(__file__).resolve().parent

# Put this folder on the import path before importing anything beside it.
#
# Ordinary Python adds a script's own directory automatically. The embeddable
# build does not: its sys.path comes entirely from the ._pth file beside the
# executable, where "." means the interpreter's folder, not the script's. So
# `import local_agent` worked under a system Python and failed under the one the
# studio installs for itself - which is to say it worked everywhere except on a
# real user's machine.
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import local_agent                                          # noqa: E402
import tuning                                               # noqa: E402
import diagnostics                                          # noqa: E402
import update as updater                                    # noqa: E402
import version as build_version                             # noqa: E402
ROOT = HERE.parent
WEB_DIR = ROOT / 'web'
DATA_DIR = ROOT / 'data'
IMAGES_DIR = DATA_DIR / 'images'
DRAFTS_DIR = DATA_DIR / 'drafts'
DB_PATH = DATA_DIR / 'studio.db'
ACTIVE_JOB = DATA_DIR / 'active-job.json'

# One local user. The original authenticated against the website; there is no
# account here, and the owner column exists only so the schema did not have to
# change and so a future multi-profile build has somewhere to put a second name.
OWNER = 'local'

DEFAULTS = {
    'host': '127.0.0.1',
    'port': 8760,
    'open_browser': True,
    # Retention mirrors what the interface shows the user. Both are advertised in
    # the status response; the client renders its own warnings from them.
    'retention_hours': 72,
    'retention_images': 40,
    # Where updates come from: a manifest file in the update repo, with the zip
    # sitting beside it. A plain file rather than the releases API, so
    # publishing a build is a push. Set to '' to turn updating off.
    'update_url': 'https://raw.githubusercontent.com/regula-a1/AI-Studio-Portable-Updater/main/latest.json',
    # Checking is a network request to a third party, so it is asked for rather
    # than assumed. Nothing is downloaded or installed without a second press.
    'check_updates': True,
}


def load_config():
    """Config file over defaults. Absent file is the normal first-run case."""
    config = dict(DEFAULTS)
    for name in ('config.json', 'config.local.json'):
        path = ROOT / name
        if not path.exists():
            continue
        try:
            config.update(json.loads(path.read_text(encoding='utf-8')))
        except (OSError, json.JSONDecodeError) as exc:
            print(f'  ! ignoring {name}: {exc}')
    return config


CONFIG = load_config()


# --------------------------------------------------------------------- db ---

_local = threading.local()


def db():
    """One connection per thread; sqlite3 objects are not shareable across them."""
    conn = getattr(_local, 'conn', None)
    if conn is None:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(DB_PATH, timeout=30)
        conn.row_factory = sqlite3.Row
        # WAL lets the job thread write progress while a request reads status,
        # which is the whole access pattern here.
        conn.execute('PRAGMA journal_mode=WAL')
        conn.execute('PRAGMA foreign_keys=ON')
        _local.conn = conn
    return conn


def init_db():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    IMAGES_DIR.mkdir(parents=True, exist_ok=True)
    DRAFTS_DIR.mkdir(parents=True, exist_ok=True)
    schema = (HERE / 'schema.sql').read_text(encoding='utf-8')
    conn = db()
    conn.executescript(schema)
    conn.commit()
    migrate(conn)


# Columns added to studio_jobs after the first release. CREATE TABLE IF NOT EXISTS
# does nothing to a table that already exists, so a database made before a column
# was added needs it adding by hand or every insert naming it fails.
MIGRATIONS = (
    ('studio_jobs', 'worker_payload', 'TEXT'),
    ('studio_jobs', 'client_pubkey', 'TEXT'),
)


def migrate(conn):
    for table, column, kind in MIGRATIONS:
        existing = {row['name'] for row in conn.execute('PRAGMA table_info(' + table + ')')}
        if column not in existing:
            conn.execute('ALTER TABLE ' + table + ' ADD COLUMN ' + column + ' ' + kind)
            print('  migrated: ' + table + '.' + column)
    conn.commit()


def recover_active_job():
    """Fail whatever was mid-flight when the process last died.

    Without this a job killed by a crash or a power cut stays 'running' for ever
    and the queue never moves again, which is indistinguishable to the user from
    the app being broken.
    """
    if not ACTIVE_JOB.exists():
        return
    try:
        marker = json.loads(ACTIVE_JOB.read_text(encoding='utf-8'))
        job_id = marker.get('id')
    except (OSError, json.JSONDecodeError):
        job_id = None
    if job_id:
        conn = db()
        conn.execute(
            "UPDATE studio_jobs SET status='error', error=?, updated=? "
            "WHERE id=? AND status IN ('running','queued')",
            ('Interrupted - the studio closed while this job was running.',
             int(time.time()), job_id))
        conn.commit()
        print(f'  recovered interrupted job {job_id}')
    ACTIVE_JOB.unlink(missing_ok=True)


# ----------------------------------------------------------------- engine ---

class Engine:
    """Lazy handle on the orchestrator.

    Imported on first use rather than at startup so the server still boots, still
    serves the interface, and can say what is missing when the runtime is not
    installed yet. A hard import here would turn a missing dependency into a
    process that will not start at all, which is the least debuggable failure the
    first-run user could meet.
    """

    def __init__(self):
        self.module = None
        self.error = None
        self._lock = threading.Lock()

    def load(self):
        with self._lock:
            if self.module or self.error:
                return self.module
            try:
                sys.path.insert(0, str(HERE))
                import orchestrator
                self.module = orchestrator
            except Exception as exc:                       # noqa: BLE001 - reported
                self.error = f'{type(exc).__name__}: {exc}'
                print(f'  ! orchestrator unavailable: {self.error}')
            return self.module

    @property
    def ready(self):
        return self.load() is not None


ENGINE = Engine()


# ------------------------------------------------------------- job runner ---

class JobRunner(threading.Thread):
    """Runs queued jobs one at a time, in queue order.

    This replaces Agent.run()'s five-second claim loop against D1. The single-job
    discipline is kept: the GPU is one resource, and the orchestrator's
    arbitration around ComfyUI and llama-server assumes nothing else of ours is
    competing for it.
    """

    def __init__(self):
        super().__init__(name='job-runner', daemon=True)
        self.wake = threading.Event()
        self.current = None
        self.stop_requested = set()
        self.agent = None
        self.store = None

    def engine(self):
        """The orchestrator, composed with the local storage seam.

        Built once, on the first job rather than at startup: constructing it reads
        config and touches the filesystem, and a server that cannot generate
        should still serve the interface and say why.
        """
        if self.agent is not None:
            return self.agent
        orchestrator = ENGINE.load()
        if orchestrator is None:
            raise RuntimeError(ENGINE.error or 'The generation engine is not installed.')
        # Only needed when storage is encrypted: otherwise nothing is sealed and
        # the value is never used, so requiring one would be ceremony.
        passphrase = CONFIG.get('studio_key') or ''
        if CONFIG.get('encrypt_storage') and not passphrase:
            raise RuntimeError(
                'Storage encryption is on but no studio key is set. The engine has to '
                'open the sealed prompt to build a graph, so config.json needs '
                '`studio_key` set to the same phrase you unlock the browser with.')
        apply_profile(orchestrator)
        local_agent.write_runtime_config(HERE, passphrase)
        self.store = local_agent.LocalStore(db, IMAGES_DIR, OWNER)
        self.agent = local_agent.build_agent(orchestrator, self.store)
        return self.agent

    def nudge(self):
        self.wake.set()

    def run(self):
        while True:
            self.wake.wait(timeout=5)
            self.wake.clear()
            try:
                self.drain()
            except Exception:                              # noqa: BLE001 - keep serving
                traceback.print_exc()

    def drain(self):
        while True:
            job = self.next_job()
            if job is None:
                return
            self.execute(job)

    def next_job(self):
        row = db().execute(
            "SELECT * FROM studio_jobs WHERE status='queued' "
            "ORDER BY priority DESC, queue_position, created LIMIT 1").fetchone()
        return dict(row) if row else None

    def execute(self, job):
        job_id = job['id']
        now = int(time.time())
        conn = db()
        conn.execute("UPDATE studio_jobs SET status='running', updated=? WHERE id=?", (now, job_id))
        conn.commit()
        ACTIVE_JOB.write_text(json.dumps({'id': job_id, 'started': now}), encoding='utf-8')
        self.current = job_id
        try:
            if not ENGINE.ready:
                raise RuntimeError(
                    'The generation engine is not available yet. '
                    + (ENGINE.error or 'Run the setup wizard to install the runtime.'))
            if job.get('app') == 'chat':
                self.run_chat_job(job)
            else:
                self.run_image_job(job)
        except Exception as exc:                           # noqa: BLE001 - surfaced to the user
            traceback.print_exc()
            # Into the log as well, with the traceback. The message stored on the
            # job is one line and reaches the user; the log is what gets sent in a
            # report. A failure that logged nothing left the log showing a job
            # starting and then silence, which is how one 404 took an hour to find.
            logging.exception('Job %s failed: %s', job_id, exc)
            conn.execute("UPDATE studio_jobs SET status='error', error=?, updated=? WHERE id=?",
                         (str(exc)[:500], int(time.time()), job_id))
            conn.commit()
        finally:
            self.current = None
            self.stop_requested.discard(job_id)
            ACTIVE_JOB.unlink(missing_ok=True)

    # How long to wait for one image before giving up on it. Generous: an 8MP
    # tiled refinement on a busy card is minutes, not seconds.
    IMAGE_TIMEOUT = 20 * 60
    # Cold start: importing torch and every custom node. Generous because the
    # first run of all is the slowest, reading several GB off a disk that has
    # never cached any of it.
    ENGINE_TIMEOUT = 5 * 60

    def run_chat_job(self, job):
        """Hand one chat turn to the orchestrator.

        Unlike an image job this one blocks: run_chat_job streams the whole reply
        before returning, reporting each token through post_chat_api, which the
        local seam writes into studio_chat_chunks for the stream endpoint to
        serve. So there is nothing to poll - it either returns having delivered a
        reply, or raises.
        """
        agent = self.engine()
        prepared = local_agent.job_for_agent(job)
        self.store.pending_job = prepared
        agent.run_chat_job(prepared)
        row = db().execute('SELECT status FROM studio_jobs WHERE id=?', (job['id'],)).fetchone()
        if row and row['status'] == 'running':
            # The engine reports its own completion through worker-done. Reaching
            # here still running means it returned without ever saying so.
            db().execute("UPDATE studio_jobs SET status='complete', updated=? WHERE id=?",
                         (now(), job['id']))
            db().commit()

    def report_stage(self, agent, job):
        """Say truthfully where the job is, without inventing a percentage.

        Step-level progress reaches the orchestrator over ComfyUI's websocket, and
        websocket-client is an optional import: without it the stage stays at
        whatever was set when the job began, and the card reads "Starting..." for
        the whole render. That is indistinguishable from a hang, which is what it
        was mistaken for.

        ComfyUI's HTTP API cannot supply a step count, so this does not pretend to
        one - no fabricated bar, no guessed ETA. It reports the three transitions
        it can actually observe, which is enough to tell a working studio from a
        stuck one. Install websocket-client and the real percentage comes back on
        its own; phase 5's launcher puts it in the bundled runtime.
        """
        orchestrator = ENGINE.module
        try:
            local_id = agent.local_job_id(job)
            queue = orchestrator.request(orchestrator.LOCAL + '/queue')
            pending = queue.get('queue_pending') or []
            running = queue.get('queue_running') or []
            if any(str(item[1]) == str(local_id) for item in running):
                stage = 'generating'
            elif any(str(item[1]) == str(local_id) for item in pending):
                stage = 'queued'
            else:
                # Gone from both: ComfyUI has finished and the result is being
                # fetched, decoded and written.
                stage = 'finishing'
        except Exception:                                  # noqa: BLE001 - never fail a job over a label
            return
        self.set_stage(job, stage)

    @staticmethod
    def set_stage(job, stage):
        conn = db()
        conn.execute('UPDATE studio_jobs SET progress_stage=?, updated=? WHERE id=? '
                     "AND status='running'", (stage, now(), job['id']))
        conn.commit()

    def await_engine(self, job):
        """Wait for ComfyUI, which local_ready() starts as a side effect.

        local_ready() is not the question it looks like. When ComfyUI is not up it
        launches it and returns False, expecting to be asked again a few seconds
        later - the same shape as run_job below.

        run_image_job asked once and raised on the first False. ComfyUI is only
        started when an image is wanted and takes the better part of a minute to
        import torch and its custom nodes, so the first generation after every
        restart failed with 'ComfyUI is not responding', pointing at config.json.
        The configuration was correct; the engine was simply still starting.
        """
        agent = self.engine()
        if agent.local_ready():
            return
        # Say so, or a minute of normal startup looks like a hung job.
        self.set_stage(job, 'starting_engine')
        deadline = time.time() + self.ENGINE_TIMEOUT
        while time.time() < deadline:
            if job['id'] in self.stop_requested:
                return
            time.sleep(3)
            if agent.local_ready():
                return
        raise RuntimeError(
            'The image engine did not start within '
            + str(self.ENGINE_TIMEOUT // 60) + ' minutes. See data/logs for what '
            'ComfyUI reported.')

    def run_image_job(self, job):
        """Drive one image job to completion.

        run_job is not a call that blocks until there is an image. It was written
        for a worker that polled a cloud queue every few seconds: one pass builds
        the graph and submits it, returns, and a *later* pass finds the finished
        render in ComfyUI's history and delivers it. Calling it once and expecting
        a result fails every time, which is exactly what it did here first.

        So this polls it the way the original loop did, passing the same job dict
        back each time - run_job marks it submitted, and that flag is what stops
        the next pass from queueing the render a second time.
        """
        agent = self.engine()
        # The engine validates a job's layers against LORA_SPECS, which ships
        # empty and is filled from the user's own folders. Refreshed per job so a
        # LoRA configured in the Models panel works without restarting.
        ENGINE.module.LORA_SPECS = lora_specs()
        prepared = local_agent.job_for_agent(job)
        self.await_engine(job)
        if job['id'] in self.stop_requested:
            return
        deadline = time.time() + self.IMAGE_TIMEOUT
        while time.time() < deadline:
            if job['id'] in self.stop_requested:
                agent.cancel(prepared)
                return
            self.store.pending_job = prepared
            agent.run_job(prepared)
            self.report_stage(agent, prepared)
            row = db().execute('SELECT status FROM studio_jobs WHERE id=?',
                               (job['id'],)).fetchone()
            if not row or row['status'] != 'running':
                return
            time.sleep(2)
        raise TimeoutError('The image did not finish within '
                           + str(self.IMAGE_TIMEOUT // 60) + ' minutes.')


RUNNER = JobRunner()


# ------------------------------------------------------------------ utils ---

def now():
    return int(time.time())


def json_body(handler):
    length = int(handler.headers.get('Content-Length') or 0)
    if not length:
        return {}
    raw = handler.rfile.read(length)
    try:
        return json.loads(raw.decode('utf-8'))
    except (UnicodeDecodeError, json.JSONDecodeError):
        raise ApiError('Malformed request body.', 400)


def raw_body(handler):
    length = int(handler.headers.get('Content-Length') or 0)
    return handler.rfile.read(length) if length else b''


class ApiError(Exception):
    def __init__(self, message, status=400, code=None):
        super().__init__(message)
        self.message = message
        self.status = status
        self.code = code


def bounded(value, default, low, high):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return default
    return max(low, min(high, number))


def setting(key, default=None):
    row = db().execute('SELECT value FROM studio_settings WHERE key=?', (key,)).fetchone()
    return row['value'] if row else default


def set_setting(key, value):
    conn = db()
    conn.execute('INSERT INTO studio_settings(key, value, updated) VALUES(?,?,?) '
                 'ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated=excluded.updated',
                 (key, value, now()))
    conn.commit()


# ------------------------------------------------------------- studio api ---
#
# Every action name, parameter and response field below is taken from the client.
# Where a field looks redundant or oddly named, it is because web/js/ already
# reads it that way.

BOOT_ID = str(uuid.uuid4())


def studio_status(query):
    """What the whole interface polls.

    The shape is dictated by refresh() in web/js/studio-transport.js, down to the
    camelCase retention keys sitting next to snake_case job columns.
    """
    app = query.get('app', ['studio'])[0]
    cutoff = now() - int(CONFIG['retention_hours']) * 3600
    rows = db().execute(
        'SELECT * FROM studio_jobs WHERE owner=? AND app=? AND (created>=? OR '
        "status IN ('queued','running')) ORDER BY created DESC LIMIT 200",
        (OWNER, app, cutoff)).fetchall()
    jobs = []
    for row in rows:
        job = dict(row)
        # Derived, not stored. The cloud API computed this from whether an object
        # existed in the bucket; the client gates the whole thumbnail fetch on it
        # and silently falls back to "tap to load" when it is missing, which is
        # indistinguishable from a broken image.
        job['has_thumbnail'] = bool(job.get('thumbnail_key'))
        jobs.append(job)
    running = any(job['status'] == 'running' for job in jobs)
    return {
        'online': True,
        'hostState': 'busy' if running else 'ready',
        'jobs': jobs,
        'retentionHours': CONFIG['retention_hours'],
        'retentionImages': CONFIG['retention_images'],
        'liteQueueActive': False,
        'liteJobRunning': False,
        # Not part of the original contract. The interface ignores unknown keys,
        # and a first-run user needs some way to see that the engine is missing.
        'engineReady': ENGINE.ready,
        'engineError': ENGINE.error,
        # Changes every time the server starts. The interface reloads itself when
        # it sees a new one, because the page has no other way to know its own
        # code is out of date - and the studio reopening the browser often just
        # focuses the tab that is already there, without reloading it. That is
        # how a fix can be installed, running, and apparently absent.
        'serverBoot': BOOT_ID,
        # Set once the watcher has seen a newer build. The page shows the pill
        # from this rather than asking the release server itself, so an open
        # studio notices a release without anyone reloading anything.
        'update': cached_update(),
    }


def studio_config():
    """What the browser needs before it can read anything. No key required.

    Only the storage mode, deliberately: this is the one endpoint answered before
    any unlock step exists, so it says as little as possible.
    """
    return {
        'encryption': bool(CONFIG.get('encrypt_storage', False)),
        'engineReady': ENGINE.ready,
    }


# --------------------------------------------------------------- registry ---
#
# What is actually installed, as opposed to what the interface knows how to ask
# for. Until this existed the dropdowns offered every shipped checkpoint whether
# or not its weights were on disk, and picking an absent one failed inside
# ComfyUI with an error the user never saw.
#
# The file list per model is derived from the graph that model actually builds,
# not from a table kept alongside it. A table is a second copy of a fact that
# already lives in the builders, and it goes stale the first time someone changes
# which file a branch loads - the same trap as the capability lists the interface
# used to restate.

# ComfyUI resolves each loader against its own folder, and renamed two of them:
# text_encoders was clip, diffusion_models was unet. Both spellings are searched
# because an install of either vintage may be pointed at.
LOADER_FOLDERS = {
    'UNETLoader': ('diffusion_models', 'unet'),
    'CheckpointLoaderSimple': ('checkpoints',),
    'CLIPLoader': ('text_encoders', 'clip'),
    'DualCLIPLoader': ('text_encoders', 'clip'),
    'VAELoader': ('vae',),
    'LoraLoader': ('loras',),
    'UpscaleModelLoader': ('upscale_models',),
}
# The input each loader names its file in.
FILE_INPUTS = ('unet_name', 'ckpt_name', 'clip_name', 'clip_name1', 'clip_name2',
               'vae_name', 'lora_name', 'model_name')

SHIPPED_CHECKPOINTS = ('krea2_turbo', 'sdxl_cyberrealistic', 'anima_base', 'illustrious_base')


def model_files(orchestrator, model):
    """Every weight file the graph for this checkpoint loads.

    Built for a plain txt2img job: the edit modes add nodes but no new loaders,
    and building one graph per mode would triple the work for the same answer.
    """
    job = {'id': 'registry-probe', 'prompt': 'probe', 'ratio': 'square', 'seed': '1',
           'model': model, 'mode': 'txt2img', 'resolution': '1mp', 'upscale': False}
    try:
        graph = orchestrator.build_workflow(job)
    except Exception as exc:                               # noqa: BLE001 - reported per model
        return None, str(exc)
    wanted = []
    for node in graph.values():
        folders = LOADER_FOLDERS.get(str(node.get('class_type')))
        if not folders:
            continue
        for key in FILE_INPUTS:
            name = node.get('inputs', {}).get(key)
            if isinstance(name, str) and name:
                wanted.append((folders, name))
    return wanted, None


def model_roots(orchestrator):
    """(label, folder, writable) for every models folder ComfyUI reads.

    Mirrors what setup writes into extra_model_paths.yaml, because the panel
    saying a checkpoint is missing while ComfyUI loads it happily is worse than
    either being wrong on its own.

    Three things were being missed. The portable bundle keeps its models under
    ComfyUI/, not beside it, so on every portable install - which is what setup
    produces - the one path checked did not exist. The studio's own drop-in
    folder was not consulted at all. Neither was a borrowed folder, which is how
    a machine with an existing ComfyUI gets its weights, and the reason Krea 2
    Turbo read as "not installed" on a machine that had just generated with it.
    """
    candidates = [
        ('studio', ROOT / 'models', True),
        ('comfyui', orchestrator.COMFY_DIR / 'ComfyUI' / 'models', False),
        ('comfyui', orchestrator.COMFY_DIR / 'models', False),
    ]
    borrowed = CONFIG.get('models_path')
    if borrowed:
        candidates.append(('borrowed', Path(borrowed).expanduser(), False))
    roots, seen = [], set()
    for label, folder, writable in candidates:
        try:
            key = folder.resolve()
        except OSError:
            key = folder
        if key in seen:
            continue
        seen.add(key)
        roots.append((label, folder, writable))
    return roots


def find_weight(orchestrator, folders, name):
    """Where this file is, or None. Every folder ComfyUI would look in."""
    for _, root, _ in model_roots(orchestrator):
        for folder in folders:
            candidate = root / folder / name
            if candidate.exists():
                return candidate
    return None


def scan_checkpoints(orchestrator):
    entries = {}
    for model in SHIPPED_CHECKPOINTS:
        wanted, error = model_files(orchestrator, model)
        if wanted is None:
            entries[model] = {'available': False, 'missing': [], 'error': error}
            continue
        missing = [name for folders, name in wanted
                   if not find_weight(orchestrator, folders, name)]
        entries[model] = {
            'available': not missing,
            'missing': missing,
            'requires': [name for _, name in wanted],
        }
    return entries


CHECKPOINT_ARCH_KEY = 'checkpoint-arch:'


def checkpoint_architecture(orchestrator, stem, kind):
    """Which architecture the user has filed a dropped-in checkpoint under.

    Kept in studio_settings rather than a table of its own: it is one string
    per file, and the file may well be deleted tomorrow.

    Takes the orchestrator rather than reaching for ENGINE.module, because this
    runs while the registry is being built and anything that raises in there is
    swallowed into ready:false - which empties the whole panel rather than
    losing one row, and gives no hint which of a dozen scans went wrong.
    """
    chosen = setting(CHECKPOINT_ARCH_KEY + stem)
    if chosen in orchestrator.architectures_for(kind):
        return chosen
    return orchestrator.default_architecture_for(kind)


def scan_discovered_checkpoints(orchestrator):
    """Checkpoints the user dropped in, keyed the way a job would name them.

    The studio cannot tell from the file which architecture it wants - SDXL,
    SD 1.5, Pony and Illustrious are all "a checkpoint" - so it assumes SDXL,
    which is what most all-in-one checkpoints published today are, and the
    choice is changeable per file.
    """
    entries = {}
    try:
        discovered = orchestrator.discovered_checkpoints()
    except Exception:                                      # noqa: BLE001 - never 500 the registry
        logging.exception('Scanning for dropped-in checkpoints failed')
        return entries
    for stem, found in discovered.items():
        architecture = checkpoint_architecture(orchestrator, stem, found['kind'])
        key = orchestrator.checkpoint_key(architecture, stem)
        entries[key] = {
            'available': True,
            'custom': True,
            'label': stem,
            'stem': stem,
            'file': found['file'],
            'sizeMb': found['sizeMb'],
            'architecture': architecture,
            # Which pair of architectures this file can be filed under. A
            # one-file checkpoint and a diffusion model are not interchangeable,
            # so the panel offers only the pair that matches the folder it was
            # found in.
            'kind': found['kind'],
            'architectureOptions': list(orchestrator.architectures_for(found['kind'])),
            'missing': [],
        }
    return entries


def studio_checkpoint_arch(body):
    """Re-file a dropped-in checkpoint under a different architecture."""
    stem = (body.get('stem') or '').strip()
    architecture = (body.get('architecture') or '').strip()
    orchestrator = ENGINE.module
    if not orchestrator:
        raise ApiError('The engine is not available.')
    if not stem:
        raise ApiError('No checkpoint given.')
    found = orchestrator.discovered_checkpoints().get(stem)
    if not found:
        raise ApiError('No such model on this PC.')
    if architecture not in orchestrator.architectures_for(found['kind']):
        raise ApiError('That architecture does not match where this file lives.')
    set_setting(CHECKPOINT_ARCH_KEY + stem, architecture)
    return {'ok': True, 'stem': stem, 'architecture': architecture,
            'key': orchestrator.checkpoint_key(architecture, stem)}


def scan_chat_models(orchestrator):
    """Which chat tiers have their weights, and the numbers the meter needs.

    ctx and image_tokens are published rather than restated in the HTML. The
    option elements carry data-ctx and data-image-tokens attributes that have to
    agree with CHAT_MODELS or the context meter misreports how full a
    conversation is - two hand-maintained copies of one fact.
    """
    entries = {}
    for key, spec in getattr(orchestrator, 'CHAT_MODELS', {}).items():
        weights = orchestrator.chat_model_path(spec['file'])
        projector = spec.get('mmproj')
        missing = []
        if not weights.exists():
            missing.append(spec['file'])
        # Vision degrades to text-only with nothing but a log line if the
        # projector is absent, so it is reported rather than inferred.
        vision = bool(projector)
        if projector and not orchestrator.chat_model_path(projector).exists():
            vision = False
            missing.append(projector)
        entries[key] = {
            'available': weights.exists(),
            'label': spec.get('label') or key,
            'ctx': spec.get('ctx'),
            'image_tokens': spec.get('image_tokens'),
            'vision': vision,
            'missing': missing,
        }
    return entries


# ------------------------------------------------------------------ loras ---
#
# Two sources, and the difference matters.
#
# `models/loras` inside the studio is ours: writable, drag-and-drop, gitignored so
# nothing a user drops there is ever committed or shipped. Folders listed in
# `lora_paths` are theirs: read from, never written to, never renamed, never
# moved. That is the same rule the install follows for ComfyUI itself - the
# install is cheap and the models are expensive, so borrow the expensive thing by
# reference and own the cheap one.
#
# One consequence worth knowing before wiring the Models panel to it: ComfyUI
# resolves lora_name against its own folders, so a file in the studio's folder is
# only loadable once ComfyUI has been told that folder exists. With the studio's
# own ComfyUI that is ours to configure. With a borrowed one it is not, and
# editing someone's extra_model_paths.yaml to make it work would be exactly the
# destructive coexistence this product rejected. So a LoRA ComfyUI cannot
# currently resolve is reported as such rather than offered and failed.

def lora_sources(orchestrator):
    """(label, folder, writable) for every place LoRAs are read from.

    De-duplicated by resolved path. Pointing lora_paths at the ComfyUI folder the
    studio already reads is the obvious thing for a user to do - setup writes
    exactly that when borrowing an existing install - and without this every LoRA
    would be found twice and half of them reported as shadowing the other half.
    """
    candidates = [(label, root / 'loras', writable)
                  for label, root, writable in model_roots(orchestrator)]
    for extra in CONFIG.get('lora_paths') or []:
        candidates.append(('external', Path(extra).expanduser(), False))
    sources, seen = [], set()
    for label, folder, writable in candidates:
        try:
            key = folder.resolve()
        except OSError:
            key = folder
        if key in seen:
            continue
        seen.add(key)
        sources.append((label, folder, writable))
    return sources


def scan_loras(orchestrator):
    """Every LoRA file found, merged with whatever the user has told us about it.

    Keyed by the file stem, which is also what ComfyUI is given as lora_name. Two
    files with the same stem in different folders collide; the first source wins
    and the loser is reported, because silently picking one would make a layer
    apply weights the user did not choose.
    """
    metadata = {row['id']: dict(row) for row in
                db().execute('SELECT * FROM studio_loras').fetchall()}
    found, shadowed = {}, []
    for source, folder, writable in lora_sources(orchestrator):
        if not folder.is_dir():
            continue
        for path in sorted(folder.rglob('*.safetensors')):
            key = path.stem
            if key in found:
                shadowed.append({'id': key, 'source': source, 'path': str(path)})
                continue
            meta = metadata.get(key) or {}
            # What ComfyUI is given as lora_name, and whether it can resolve it.
            #
            # Every folder in extra_model_paths.yaml is loadable: the studio's
            # own, ComfyUI's, and a borrowed one. A folder listed only in
            # lora_paths is not - it is visible to the panel and invisible to the
            # engine, so it is reported as such rather than offered and then
            # failed halfway through a job.
            loadable = source != 'external'
            try:
                lora_name = str(path.relative_to(folder)).replace(chr(92), '/')
            except ValueError:
                lora_name, loadable = path.name, False
            found[key] = {
                'id': key,
                'label': meta.get('label') or key.replace('_', ' ').replace('-', ' ').strip(),
                'architecture': meta.get('architecture'),
                'triggers': meta.get('triggers') or '',
                'implied': meta.get('implied') or '',
                'defaultStrength': meta.get('default_strength', 0.8),
                'enabled': bool(meta.get('enabled', 1)),
                'configured': bool(meta.get('architecture')),
                'source': source,
                'writable': writable,
                'loadable': loadable,
                'loraName': lora_name,
                'sizeMb': round(path.stat().st_size / (1024 * 1024), 1),
            }
    return found, shadowed


def studio_loras_save(body):
    """Record what the user told us about one LoRA."""
    lora_id = body.get('id')
    if not lora_id:
        raise ApiError('No LoRA given.')
    architecture = body.get('architecture') or None
    known = ('krea2', 'sdxl', 'anima', 'illustrious')
    if architecture and architecture not in known:
        raise ApiError('Unknown architecture: ' + str(architecture))
    strength = bounded(body.get('defaultStrength'), 0.8, 0.1, 1.5)
    conn = db()
    conn.execute(
        'INSERT INTO studio_loras(id, label, architecture, triggers, implied, '
        'default_strength, enabled, updated) VALUES(?,?,?,?,?,?,?,?) '
        'ON CONFLICT(id) DO UPDATE SET label=excluded.label, '
        'architecture=excluded.architecture, triggers=excluded.triggers, '
        'implied=excluded.implied, default_strength=excluded.default_strength, '
        'enabled=excluded.enabled, updated=excluded.updated',
        (lora_id, body.get('label') or None, architecture,
         (body.get('triggers') or '').strip(), (body.get('implied') or '').strip(),
         strength, 1 if body.get('enabled', True) else 0, now()))
    conn.commit()
    return {'ok': True, 'id': lora_id}


def studio_loras_forget(body):
    """Drop the metadata for a LoRA. Never touches the file."""
    conn = db()
    conn.execute('DELETE FROM studio_loras WHERE id=?', (body.get('id'),))
    conn.commit()
    return {'ok': True}


def lora_specs():
    """The registry the orchestrator validates a job's LoRA list against.

    Only configured, enabled layers whose file ComfyUI can actually load. An
    unconfigured one has no architecture, and selected_loras compares against
    exactly that - so offering it would fail the job rather than the selection.
    """
    orchestrator = ENGINE.load()
    if orchestrator is None:
        return {}
    found, _ = scan_loras(orchestrator)
    specs = {}
    for key, entry in found.items():
        if not (entry['configured'] and entry['enabled'] and entry['loadable']):
            continue
        # Field names are the engine's, not ours: add_trigger_words reads
        # spec['trigger'] - singular, and a comma-separated string - while
        # 'implied' is iterated as a sequence of terms. Getting either shape wrong
        # loses the trigger words silently, which looks like a LoRA that does
        # nothing rather than like a bug.
        specs[key] = {
            'arch': entry['architecture'],
            'file': entry['loraName'],
            'strength': entry['defaultStrength'],
            'trigger': entry['triggers'],
            'implied': [t.strip() for t in entry['implied'].split(',') if t.strip()],
        }
    return specs


_PROFILE = {'value': None}


def hardware_profile(orchestrator, refresh=False):
    """What this machine can run. Computed once; the card does not change.

    Cached because probing shells out to nvidia-smi and the registry is fetched
    on every page load. Rescan forces it, which is also the escape hatch for
    someone who has just swapped a GPU.
    """
    if _PROFILE['value'] is None or refresh:
        _PROFILE['value'] = tuning.build_profile(
            getattr(orchestrator, 'CHAT_MODELS', {}),
            default_model=getattr(orchestrator, 'DEFAULT_CHAT_MODEL', None))
    return _PROFILE['value']


def apply_profile(orchestrator):
    """Replace the constants that were measurements of one particular card.

    SAFE_VRAM_MB decides whether there is room to load a model at all, and was
    9500 because that is what fit on the machine this was written on. On a 24 GB
    card it refuses work it could do; on an 8 GB card it attempts work it cannot.
    """
    profile = hardware_profile(orchestrator)
    safe = profile.get('safeVramMib')
    if safe:
        orchestrator.SAFE_VRAM_MB = int(safe)

    # Apply the shortened windows to the engine's own table, not only to what the
    # interface displays. Without this the picker would say "shorter memory on
    # this GPU" while llama-server was still launched at the full window and
    # failed to allocate - the tuning would be a label rather than a change.
    #
    # Only ever downward. A card with room to spare does not get a longer window
    # than the tier was measured at, because ctx affects output quality and the
    # figure was chosen deliberately.
    for key, tier in (profile.get('tiers') or {}).items():
        spec = orchestrator.CHAT_MODELS.get(key)
        if not spec or not tier.get('fits') or not tier.get('ctx'):
            continue
        if tier['ctx'] < (spec.get('ctx') or 0):
            spec['ctx'] = int(tier['ctx'])
    print('  hardware ' + tuning.describe(profile))
    for note in profile.get('notes') or []:
        print('           ' + note)
    return profile


def studio_registry():
    """What this machine can actually run right now."""
    orchestrator = ENGINE.load()
    if orchestrator is None:
        return {'ready': False, 'error': ENGINE.error, 'checkpoints': {},
                'chatModels': {}, 'loras': {}}
    try:
        loras, shadowed = scan_loras(orchestrator)
        return {
            'ready': True,
            'profile': hardware_profile(orchestrator),
            'comfyDir': str(orchestrator.COMFY_DIR),
            'modelsDir': str(orchestrator.MODELS_DIR),
            'checkpoints': dict(scan_checkpoints(orchestrator),
                                **scan_discovered_checkpoints(orchestrator)),
            'chatModels': scan_chat_models(orchestrator),
            'loras': loras,
            'shadowedLoras': shadowed,
            'res4lyfAvailable': orchestrator.res4lyf_available(),
            # Where a dropped-in checkpoint is looked for. Published so the
            # panel can print it: a folder nobody put anything in and a scan
            # that quietly failed look identical from the outside.
            'checkpointFolders': [str(folder) for folder in orchestrator.checkpoint_folders()],
            'modelFolders': [{'kind': kind, 'path': str(folder)}
                             for kind, folder in orchestrator.model_folders()],
        }
    except Exception as exc:                               # noqa: BLE001 - never 500 the page
        traceback.print_exc()
        return {'ready': False, 'error': str(exc), 'checkpoints': {},
                'chatModels': {}, 'loras': {}}


def studio_version():
    """Which build this is, and the whole version log.

    Answered without a key and without touching the network: it reads two files
    that shipped with the build. The interface asks once, on load, and shows the
    number faintly in the corner.
    """
    return build_version.describe()


# The update check runs here, on a timer, rather than in the browser.
#
# It used to be one fetch six seconds after the page loaded, and never again.
# A studio left open did not notice a release until somebody reloaded the tab,
# which is not something to ask of the people this is for - and the publish
# script cheerfully claimed every studio would offer it "within a few minutes",
# which was simply untrue.
#
# Doing it in the server means one request per machine no matter how many tabs
# are open, and the browser learns about it through the status poll it already
# makes every few seconds. So nothing new is fetched by the page at all, and
# the pill appears on its own.
UPDATE_EVERY = 300
UPDATE_STATE = {'info': None, 'checked': 0.0}


def update_watcher():
    """Ask the release server what the newest build is, forever, quietly."""
    first = True
    while True:
        # A little after startup rather than during it: the first seconds are
        # busy with the database, the engine and the browser opening, and this
        # is the least urgent thing the studio does.
        time.sleep(20 if first else UPDATE_EVERY)
        first = False
        try:
            info = updater.check(CONFIG.get('update_url'))
            UPDATE_STATE['info'] = info
            UPDATE_STATE['checked'] = time.time()
            if info.get('available'):
                logging.info('Update available: %s', info.get('version') or info.get('latest'))
        except Exception as exc:                           # noqa: BLE001 - offline is normal
            # Offline, rate limited, DNS down, laptop asleep. None of it is the
            # user's problem and none of it is worth a banner; the next pass in
            # five minutes will try again.
            logging.debug('Update check failed: %s', exc)


def cached_update():
    """What the watcher last saw, for anything that should not block on a fetch."""
    if not CONFIG.get('check_updates', True):
        return None
    return UPDATE_STATE['info']


def studio_update_check():
    """What the latest release is. Reads only; installs nothing.

    Answers from the watcher's last look rather than fetching, so the browser
    can ask as often as it likes without a request leaving the machine. Only a
    studio whose watcher has not run yet goes to the network here.
    """
    if not CONFIG.get('check_updates', True):
        return {'configured': False, 'available': False,
                'reason': 'Update checking is turned off in config.json.'}
    cached = UPDATE_STATE['info']
    if cached is not None:
        return dict(cached, checkedAgo=int(time.time() - UPDATE_STATE['checked']))
    try:
        info = updater.check(CONFIG.get('update_url'))
        UPDATE_STATE['info'] = info
        UPDATE_STATE['checked'] = time.time()
        return info
    except updater.UpdateError as exc:
        raise ApiError(str(exc))
    except Exception as exc:                               # noqa: BLE001 - network
        # Not being able to reach a release server is ordinary, and not a reason
        # to show somebody a traceback.
        logging.warning('Update check failed: %s', exc)
        raise ApiError('Could not reach the update server. ' + str(exc)[:160])


def studio_update_apply():
    """Download, verify, stage and install the latest release.

    Deliberately not restarting afterwards. Replacing the files is safe while
    the server runs - Python read them at import and closed them - but a process
    that relaunches itself has to get that exactly right on a machine nobody can
    see, and getting it wrong leaves somebody with nothing running.
    """
    if not CONFIG.get('check_updates', True):
        raise ApiError('Update checking is turned off in config.json.')
    try:
        info = updater.check(CONFIG.get('update_url'))
        if not info.get('available'):
            return {'ok': False, 'reason': 'There is no newer release than this build.'}
        logging.info('Updating from %s to %s', info.get('installed'), info.get('latest'))
        archive = updater.download(info)
        staged, count = updater.stage(archive)
        written = updater.apply(staged)
        updater.cleanup()
        logging.info('Update applied: %d file(s) from %s', written, info.get('version'))
        return {'ok': True, 'version': info.get('version'), 'files': written,
                'staged': count,
                'restart': 'Close the studio window and run Start.bat again to finish.'}
    except updater.UpdateError as exc:
        logging.error('Update refused: %s', exc)
        raise ApiError(str(exc))
    except Exception as exc:                               # noqa: BLE001 - reported
        logging.exception('Update failed')
        raise ApiError('The update did not finish: ' + str(exc)[:200])


def studio_report_preview(body):
    """Build a report and hand back exactly the text that would be saved.

    The preview is the point. Everything here is collected from the machine
    rather than supplied by the user, so the only way for them to know what is
    in it is to read it - and a payload nobody reads is a privacy promise
    nobody can check. So the endpoint returns the finished text, not a summary
    of it.
    """
    errors = [row['error'] for row in db().execute(
        "SELECT error FROM studio_jobs WHERE status='error' AND error IS NOT NULL "
        'ORDER BY updated DESC LIMIT 20').fetchall()]
    report = diagnostics.build_report(note=body.get('note'), recent_errors=errors)
    return {'text': diagnostics.render_report(report),
            'neverCollected': list(diagnostics.NEVER_COLLECTED)}


def studio_report_save(body):
    """Write the report to data/reports and say where it went.

    Nothing is transmitted. The user sends the file wherever they choose, which
    is why this returns the folder as well as the file - they have to be able to
    find it.
    """
    errors = [row['error'] for row in db().execute(
        "SELECT error FROM studio_jobs WHERE status='error' AND error IS NOT NULL "
        'ORDER BY updated DESC LIMIT 20').fetchall()]
    report = diagnostics.build_report(note=body.get('note'), recent_errors=errors)
    path = diagnostics.write_report(report)
    # Open the folder with the file already selected. The point of a report is
    # to be sent, and asking somebody to find a path they were shown in a dialog
    # is where that stops happening - they can drag it straight out of the
    # window that opens.
    revealed = diagnostics.reveal(path)
    return {'ok': True, 'path': str(path), 'folder': str(path.parent),
            'name': path.name, 'revealed': revealed}


def studio_report_reveal():
    """Show the newest report in the file manager again.

    Takes no path. The browser is trusted to ask, not to choose: an endpoint
    that opened whatever it was handed would be a way to launch Explorer
    anywhere on the machine.
    """
    path = diagnostics.latest_report()
    if not path:
        raise ApiError('There is no saved report yet.')
    return {'ok': diagnostics.reveal(path), 'path': str(path)}


def resolved_seed(given):
    """The seed for one job: the one asked for, or a fresh random one.

    An empty seed box means "surprise me", and it used to become the literal
    number 0. Every job with an unchanged prompt therefore built a byte for
    byte identical graph, and ComfyUI answers an identical graph out of its
    cache: pressing Generate twice returned the first image in about two
    seconds, looking like the job had finished instantly.

    It is resolved here rather than in the graph builder so the number is
    stored on the job. A seed nobody can read back is not reproducible, and
    "make me another one like that" is most of what seeds are for.

    secrets rather than random: the seed is part of what makes two images
    differ, and a predictable sequence across restarts is exactly the thing
    being fixed.
    """
    text = str(given if given is not None else '').strip()
    if text.isdigit():
        value = int(text)
        # 0 stays 0 when it is asked for on purpose - it is a legitimate seed,
        # and repeating a generation deliberately is a real thing to want.
        if 0 <= value < 10 ** 15:
            return str(value)
    return str(secrets.randbelow(10 ** 15))


def studio_generate(query, body):
    """Queue one job. The prompt arrives sealed and is stored exactly as sent."""
    job_id = str(body.get('id') or uuid.uuid4())
    if not isinstance(body.get('prompt'), str) or not body['prompt']:
        raise ApiError('A prompt is required.')
    app = body.get('app') or query.get('app', ['studio'])[0]
    position = db().execute(
        'SELECT COALESCE(MAX(queue_position), 0) + 1 AS next FROM studio_jobs '
        "WHERE status='queued'").fetchone()['next']
    guidance = body.get('guidance')
    denoise = body.get('denoise')
    fields = {
        'id': job_id, 'owner': OWNER, 'app': app,
        'prompt': body['prompt'], 'negative_prompt': body.get('negativePrompt') or None,
        'ratio': body.get('ratio') or 'square',
        'resolution': body.get('resolution') or '1mp',
        'seed': resolved_seed(body.get('seed')),
        'model': body.get('model') or 'krea2_turbo',
        'status': 'queued', 'created': now(), 'updated': now(),
        'workflow': body.get('workflow') or 'standard',
        'prompt_enhance': 1 if body.get('promptEnhance') else 0,
        'enhancer_strength': bounded(body.get('enhancerStrength'), 1.5, 0, 5),
        'variance_strength': bounded(body.get('varianceStrength'), 1.0, 0, 5),
        'variance_percent': int(bounded(body.get('variancePercent'), 50, 0, 100)),
        'variance_mode': body.get('varianceMode') or 'values',
        'upscale': 1 if body.get('upscale', True) else 0,
        'sampler': body.get('sampler') or 'euler',
        'steps': int(bounded(body.get('steps'), 0, 0, 150)) or None,
        'guidance': bounded(guidance, None, 0, 30) if guidance is not None else None,
        'loras': json.dumps(body['loras']) if body.get('loras') else None,
        'mode': body.get('mode') or 'txt2img',
        'denoise': bounded(denoise, None, 0.05, 1.0) if denoise is not None else None,
        'input_image_key': body.get('inputImageKey'),
        'mask_image_key': body.get('maskImageKey'),
        'grow_mask': int(bounded(body.get('growMask'), 6, 0, 64)),
        'queue_position': position, 'priority': 10,
        'chat_id': body.get('chat_id'),
    }
    columns = ', '.join(fields)
    marks = ', '.join('?' for _ in fields)
    conn = db()
    conn.execute('INSERT INTO studio_jobs(' + columns + ') VALUES(' + marks + ')',
                 tuple(fields.values()))
    conn.commit()
    RUNNER.nudge()
    return {'id': job_id, 'queued': True}


def studio_delete(body):
    job_id = body.get('id')
    if not job_id:
        raise ApiError('No job id given.')
    row = db().execute('SELECT image_key, thumbnail_key FROM studio_jobs WHERE id=? AND owner=?',
                       (job_id, OWNER)).fetchone()
    if row:
        for key in (row['image_key'], row['thumbnail_key']):
            if key:
                safe_image_path(key).unlink(missing_ok=True)
    conn = db()
    conn.execute('DELETE FROM studio_jobs WHERE id=? AND owner=?', (job_id, OWNER))
    conn.commit()
    return {'ok': True}


def studio_reorder(body):
    """Reposition queued jobs. expectedOrder guards against a stale drag."""
    order = body.get('order') or []
    expected = body.get('expectedOrder')
    current = [row['id'] for row in db().execute(
        "SELECT id FROM studio_jobs WHERE status='queued' AND owner=? "
        'ORDER BY priority DESC, queue_position, created', (OWNER,)).fetchall()]
    if expected is not None and list(expected) != current:
        raise ApiError('The queue changed while you were dragging. Nothing was moved.', 409)
    conn = db()
    for position, job_id in enumerate(order, start=1):
        conn.execute('UPDATE studio_jobs SET queue_position=?, updated=? WHERE id=? '
                     "AND status='queued'", (position, now(), job_id))
    conn.commit()
    return {'ok': True, 'order': order}


def studio_presets():
    row = db().execute('SELECT payload FROM studio_user_presets WHERE owner=?', (OWNER,)).fetchone()
    return {'payload': json.loads(row['payload']) if row else None}


def studio_save_presets(body):
    conn = db()
    conn.execute('INSERT INTO studio_user_presets(owner, payload, updated) VALUES(?,?,?) '
                 'ON CONFLICT(owner) DO UPDATE SET payload=excluded.payload, '
                 'updated=excluded.updated',
                 (OWNER, json.dumps(body.get('payload')), now()))
    conn.commit()
    return {'ok': True}


def studio_unlock(body):
    """First unlock sets the passphrase; later ones are checked against it.

    The server only ever sees a verifier derived from the key, never the key
    itself, so it can tell a wrong passphrase from a right one without being able
    to open anything sealed under it. Losing the key means losing the images -
    that is the design, not an oversight, and the setup wizard has to say so.
    """
    verifier = body.get('verifier')
    if not verifier:
        raise ApiError('No key given.')
    stored = setting('unlock_verifier')
    if stored is None:
        set_setting('unlock_verifier', verifier)
        return {'ok': True, 'firstRun': True}
    if stored != verifier:
        raise ApiError('That key does not match the one this studio was set up with.', 403)
    return {'ok': True}


# --------------------------------------------------------------- assets ---

def content_type_of(data):
    """Label bytes by what they are, not by what the extension claims.

    Thumbnails are WebP and full images are PNG, so neither a fixed type nor the
    filename is trustworthy. Sealed bytes stay octet-stream: calling ciphertext
    an image invites something in the chain to try to render it.
    """
    signatures = (
        (bytes.fromhex('41535031'), 'application/octet-stream'),   # ASP1
        (bytes.fromhex('89504e470d0a1a0a'), 'image/png'),
        (bytes.fromhex('ffd8ff'), 'image/jpeg'),
        (bytes.fromhex('47494638'), 'image/gif'),
    )
    for magic, kind in signatures:
        if data[:len(magic)] == magic:
            return kind
    if data[:4] == b'RIFF' and data[8:12] == b'WEBP':
        return 'image/webp'
    return 'application/octet-stream'


def safe_image_path(key):
    """Resolve a storage key inside the images folder, or refuse.

    Keys reach us from the client. Anything that escapes the folder is a path
    traversal, so the resolved path is checked rather than the key trusted.
    """
    candidate = (IMAGES_DIR / str(key)).resolve()
    if not str(candidate).startswith(str(IMAGES_DIR.resolve())):
        raise ApiError('Bad asset key.', 400)
    return candidate


def studio_upload_asset(query, data):
    """Store a sealed input image or mask and return the key that names it."""
    job_id = (query.get('id') or [''])[0]
    kind = (query.get('type') or ['input'])[0]
    if not job_id:
        raise ApiError('No job id given.')
    if kind not in ('input', 'mask'):
        raise ApiError('Unknown asset type.')
    if not data:
        raise ApiError('Empty upload.')
    key = job_id + '_' + kind + '.bin'
    safe_image_path(key).write_bytes(data)
    column = 'input_image_key' if kind == 'input' else 'mask_image_key'
    conn = db()
    conn.execute('UPDATE studio_jobs SET ' + column + '=?, updated=? WHERE id=?',
                 (key, now(), job_id))
    conn.commit()
    return {'key': key}


def studio_asset_bytes(query, which):
    """Serve a finished image or its thumbnail, still sealed.

    The browser decrypts. Content-Type is deliberately octet-stream rather than
    image/png: what is on disk is ASP1 ciphertext, and labelling it as an image
    would invite something in the chain to try to render it.
    """
    job_id = (query.get('id') or [''])[0]
    if not job_id:
        raise ApiError('No job id given.')
    column = 'image_key' if which == 'image' else 'thumbnail_key'
    row = db().execute('SELECT ' + column + ' AS k FROM studio_jobs WHERE id=? AND owner=?',
                       (job_id, OWNER)).fetchone()
    if not row or not row['k']:
        raise ApiError('That image is not ready yet.', 404)
    path = safe_image_path(row['k'])
    if not path.exists():
        raise ApiError('That image is no longer stored.', 404)
    data = path.read_bytes()
    return (data, content_type_of(data))


# --------------------------------------------------------------- drafts ---
#
# The editor keeps the authoritative copy in IndexedDB and syncs here so a draft
# survives a cleared browser. Assets are content-addressed by digest, and the
# manifest naming them is published only after every asset is acknowledged, so a
# reader never sees a revision it cannot fully load.

def draft_asset_path(mode, kind, digest):
    safe = ''.join(ch for ch in str(digest) if ch.isalnum())
    if not safe:
        raise ApiError('Bad asset digest.', 400)
    return DRAFTS_DIR / (str(mode) + '_' + str(kind) + '_' + safe + '.bin')


def studio_drafts(query):
    app = (query.get('app') or ['studio'])[0]
    rows = db().execute('SELECT * FROM studio_drafts WHERE owner=? AND app=?',
                        (OWNER, app)).fetchall()
    drafts = []
    for row in rows:
        meta = json.loads(row['meta']) if row['meta'] else {}
        drafts.append({
            'mode': row['mode'], 'state': row['state'], 'revision': row['revision'],
            'updated': row['updated'], 'client': row['client'],
            'image': row['image_key'], 'mask': row['mask_key'],
            'imageReceipt': meta.get('imageReceipt'),
            'maskReceipt': meta.get('maskReceipt'),
            'meta': meta.get('meta'),
        })
    return {'drafts': drafts}


def studio_draft_asset_put(query, data):
    mode = (query.get('mode') or [''])[0]
    kind = (query.get('type') or [''])[0]
    digest = (query.get('digest') or [''])[0]
    if not (mode and kind and digest):
        raise ApiError('Incomplete asset reference.')
    if not data:
        raise ApiError('Empty upload.')
    draft_asset_path(mode, kind, digest).write_bytes(data)
    # The receipt is what the manifest cites. Content addressing means the digest
    # already identifies the bytes, so it doubles as the receipt.
    return {'receipt': digest}


def studio_draft_asset_get(query):
    mode = (query.get('mode') or [''])[0]
    kind = (query.get('type') or [''])[0]
    digest = (query.get('digest') or [''])[0]
    path = draft_asset_path(mode, kind, digest)
    if not path.exists():
        raise ApiError('No such draft asset.', 404)
    return path.read_bytes()


def studio_draft_publish(query, body):
    """Publish a manifest. `base` is the revision the client edited from."""
    app = (query.get('app') or ['studio'])[0]
    mode = body.get('mode')
    if not mode:
        raise ApiError('No mode given.')
    row = db().execute('SELECT revision FROM studio_drafts WHERE owner=? AND app=? AND mode=?',
                       (OWNER, app, mode)).fetchone()
    current = row['revision'] if row else 0
    base = int(body.get('base') or 0)
    if row and base < current:
        # Someone else moved it on. The client reconciles and republishes.
        raise ApiError('This draft changed elsewhere.', 409, code='stale-draft')
    revision = current + 1
    meta = json.dumps({
        'imageReceipt': body.get('imageReceipt'),
        'maskReceipt': body.get('maskReceipt'),
        'meta': body.get('meta'),
    })
    conn = db()
    conn.execute(
        'INSERT INTO studio_drafts(owner, app, mode, revision, state, image_key, mask_key, '
        'meta, client, updated) VALUES(?,?,?,?,?,?,?,?,?,?) '
        'ON CONFLICT(owner, app, mode) DO UPDATE SET revision=excluded.revision, '
        'state=excluded.state, image_key=excluded.image_key, mask_key=excluded.mask_key, '
        'meta=excluded.meta, client=excluded.client, updated=excluded.updated',
        (OWNER, app, mode, revision, body.get('state') or 'active', body.get('image'),
         body.get('mask'), meta, body.get('client'), now()))
    conn.commit()
    return {'revision': revision}


# ----------------------------------------------------------------- chat ---
#
# Conversations, messages and memories are plain storage: everything the user
# wrote arrives sealed and is handed back sealed. Generating a reply is not
# implemented here - that needs the orchestrator's chat loop and the model paths
# that phase 3 replaces, so `send` and `stream` say so rather than pretending.

def chat_list():
    rows = db().execute('SELECT id, title, model, created, updated FROM studio_chats '
                        'WHERE owner=? ORDER BY updated DESC LIMIT 200', (OWNER,)).fetchall()
    return {'chats': [dict(row) for row in rows]}


def chat_get(query):
    chat_id = (query.get('chat_id') or [''])[0]
    if not chat_id:
        raise ApiError('No conversation given.')
    chat = db().execute('SELECT * FROM studio_chats WHERE id=? AND owner=?',
                        (chat_id, OWNER)).fetchone()
    if not chat:
        raise ApiError('No such conversation.', 404)
    rows = db().execute('SELECT id, role, seq, sealed_content, sealed_reasoning, sealed_usage, '
                        'job_id, created FROM studio_messages WHERE chat_id=? ORDER BY seq',
                        (chat_id,)).fetchall()
    return {'chat': dict(chat), 'messages': [dict(row) for row in rows]}


def chat_save_message(body):
    """Insert or update one message. The client owns the id, so this is an upsert."""
    chat_id = body.get('chat_id')
    message_id = body.get('message_id')
    if not (chat_id and message_id):
        raise ApiError('A conversation and message id are required.')
    conn = db()
    conn.execute('INSERT INTO studio_chats(id, owner, title, model, created, updated) '
                 'VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET updated=excluded.updated',
                 (chat_id, OWNER, body.get('title'), body.get('model'), now(), now()))
    seq = conn.execute('SELECT COALESCE(MAX(seq), 0) + 1 AS next FROM studio_messages '
                       'WHERE chat_id=?', (chat_id,)).fetchone()['next']
    conn.execute(
        'INSERT INTO studio_messages(id, chat_id, owner, role, seq, sealed_content, '
        'sealed_reasoning, sealed_usage, job_id, created) VALUES(?,?,?,?,?,?,?,?,?,?) '
        'ON CONFLICT(id) DO UPDATE SET sealed_content=excluded.sealed_content, '
        'sealed_reasoning=excluded.sealed_reasoning, sealed_usage=excluded.sealed_usage',
        (message_id, chat_id, OWNER, body.get('role') or 'user', seq,
         body.get('sealed_content'), body.get('sealed_reasoning'),
         body.get('sealed_usage'), body.get('job_id'), now()))
    conn.commit()
    return {'ok': True, 'id': message_id, 'seq': seq}


def chat_rename(body):
    conn = db()
    conn.execute('UPDATE studio_chats SET title=?, updated=? WHERE id=? AND owner=?',
                 (body.get('title'), now(), body.get('chat_id'), OWNER))
    conn.commit()
    return {'ok': True}


def chat_delete(body):
    conn = db()
    conn.execute('DELETE FROM studio_messages WHERE chat_id=?', (body.get('chat_id'),))
    conn.execute('DELETE FROM studio_chats WHERE id=? AND owner=?', (body.get('chat_id'), OWNER))
    conn.commit()
    return {'ok': True}


def chat_delete_message(body):
    conn = db()
    conn.execute('DELETE FROM studio_messages WHERE id=? AND chat_id=?',
                 (body.get('message_id'), body.get('chat_id')))
    conn.commit()
    return {'ok': True}


def chat_trim(body):
    """Drop this message and everything after it - the rewind an edit performs."""
    chat_id = body.get('chat_id')
    from_id = body.get('from_message_id')
    row = db().execute('SELECT seq FROM studio_messages WHERE id=? AND chat_id=?',
                       (from_id, chat_id)).fetchone()
    if not row:
        return {'ok': True, 'removed': 0}
    conn = db()
    cursor = conn.execute('DELETE FROM studio_messages WHERE chat_id=? AND seq>=?',
                          (chat_id, row['seq']))
    conn.commit()
    return {'ok': True, 'removed': cursor.rowcount}


def chat_sync(query):
    """The chat equivalent of status: what changed since the client last looked."""
    chat_id = (query.get('active_chat_id') or [''])[0]
    rows = db().execute('SELECT id, title, model, created, updated FROM studio_chats '
                        'WHERE owner=? ORDER BY updated DESC LIMIT 200', (OWNER,)).fetchall()
    payload = {
        'chats': [dict(row) for row in rows],
        'host_state': 'busy' if RUNNER.current else 'ready',
        'active_jobs': [],
    }
    if chat_id:
        messages = db().execute(
            'SELECT id, role, seq, sealed_content, sealed_reasoning, sealed_usage, job_id, '
            'created FROM studio_messages WHERE chat_id=? ORDER BY seq', (chat_id,)).fetchall()
        payload['active_chat_id'] = chat_id
        payload['message_ids'] = [row['id'] for row in messages]
        last = (query.get('last_msg_id') or [''])[0]
        if last:
            seen = False
            fresh = []
            for row in messages:
                if seen:
                    fresh.append(dict(row))
                if row['id'] == last:
                    seen = True
            payload['new_messages'] = fresh if seen else [dict(r) for r in messages]
        else:
            payload['new_messages'] = [dict(row) for row in messages]
    return payload


def chat_memories_list():
    rows = db().execute('SELECT id, sealed_content, created, updated FROM studio_memories '
                        'WHERE owner=? ORDER BY created', (OWNER,)).fetchall()
    return {'memories': [dict(row) for row in rows]}


def chat_memory_save(body):
    memory_id = body.get('id') or str(uuid.uuid4())
    conn = db()
    conn.execute('INSERT INTO studio_memories(id, owner, sealed_content, created, updated) '
                 'VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET '
                 'sealed_content=excluded.sealed_content, updated=excluded.updated',
                 (memory_id, OWNER, body.get('sealed_content'), now(), now()))
    conn.commit()
    return {'ok': True, 'id': memory_id}


def chat_memory_delete(body):
    conn = db()
    conn.execute('DELETE FROM studio_memories WHERE id=? AND owner=?', (body.get('id'), OWNER))
    conn.commit()
    return {'ok': True}


def chat_memories_clear():
    conn = db()
    conn.execute('DELETE FROM studio_memories WHERE owner=?', (OWNER,))
    conn.commit()
    return {'ok': True}


def chat_stop(body):
    job_id = body.get('job_id')
    if job_id:
        RUNNER.stop_requested.add(job_id)
        conn = db()
        conn.execute("UPDATE studio_jobs SET status='cancelled', updated=? WHERE id=? "
                     "AND status IN ('queued','running')", (now(), job_id))
        conn.commit()
    return {'ok': True}


def chat_cancel_queued(body):
    conn = db()
    if body.get('chat_id'):
        cursor = conn.execute("UPDATE studio_jobs SET status='cancelled', updated=? "
                              "WHERE chat_id=? AND status='queued'", (now(), body['chat_id']))
    else:
        cursor = conn.execute("UPDATE studio_jobs SET status='cancelled', updated=? "
                              "WHERE owner=? AND status='queued'", (now(), OWNER))
    conn.commit()
    return {'ok': True, 'cancelled': cursor.rowcount}


def chat_send(body):
    """Queue one chat turn and return the job that will answer it.

    The conversation itself is in worker_payload, sealed by the browser. This
    layer stores it and never opens it; the engine unseals it to build the prompt
    because it has to. Chat jobs share studio_jobs with image jobs so that one
    queue and one runner arbitrate the GPU, which is the whole reason the original
    kept a single-job discipline.
    """
    chat_id = body.get('chat_id')
    if not chat_id:
        raise ApiError('No conversation given.')
    if not body.get('worker_payload'):
        raise ApiError('Nothing to send.')
    job_id = str(uuid.uuid4())
    conn = db()
    conn.execute('INSERT INTO studio_chats(id, owner, title, model, created, updated) '
                 'VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET updated=excluded.updated',
                 (chat_id, OWNER, body.get('title'), body.get('model'), now(), now()))
    # Chat outranks image work in the queue. A person waiting on a reply notices a
    # thirty-second delay; a picture finishing a minute later is not felt the same
    # way, and the original ordered them this way for that reason.
    conn.execute(
        'INSERT INTO studio_jobs(id, owner, app, prompt, ratio, seed, model, status, created, '
        'updated, workflow, mode, chat_id, worker_payload, client_pubkey, priority, '
        'queue_position) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
        (job_id, OWNER, 'chat', '', 'square', '0', body.get('model') or 'auto', 'queued',
         now(), now(), 'compaction' if body.get('is_compaction') else 'chat', 'chat',
         chat_id, body.get('worker_payload'), body.get('client_pubkey'), 20,
         conn.execute('SELECT COALESCE(MAX(queue_position), 0) + 1 AS n FROM studio_jobs '
                      "WHERE status='queued'").fetchone()['n']))
    # The message the user just typed, so it survives a reload before the reply.
    if body.get('message_id'):
        seq = conn.execute('SELECT COALESCE(MAX(seq), 0) + 1 AS n FROM studio_messages '
                           'WHERE chat_id=?', (chat_id,)).fetchone()['n']
        conn.execute(
            'INSERT INTO studio_messages(id, chat_id, owner, role, seq, sealed_content, '
            'job_id, created) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(id) DO NOTHING',
            (body['message_id'], chat_id, OWNER, 'user', seq, body.get('sealed_content'),
             job_id, now()))
    conn.commit()
    RUNNER.nudge()
    return {'job_id': job_id, 'queued': True}


def queue_position(job_id):
    """Where this job sits in the queue, counting from 1.

    The job being worked on right now is 1, not 0: the client prints this as an
    ordinal and "0th in line" reads as badly as the undefined it replaces.
    """
    if RUNNER.current == job_id:
        return 1
    rows = db().execute(
        "SELECT id FROM studio_jobs WHERE status='queued' "
        'ORDER BY priority DESC, queue_position, created').fetchall()
    ahead = 1 if RUNNER.current else 0
    for index, row in enumerate(rows):
        if row['id'] == job_id:
            return index + 1 + ahead
    return 1


def chat_stream(handler, query):
    """Replay a reply as it is produced, resuming from `from_seq`.

    The client reconnects with the last sequence number it saw and expects to
    carry on exactly there, so chunks are read from the table rather than pushed:
    a dropped connection loses nothing, and a second tab can watch the same reply.

    Framed as server-sent events because that is what the client parses, but it is
    a database tail, not a live pipe. Writes the response itself and returns None,
    since the reply is streamed rather than returned.
    """
    job_id = (query.get('job_id') or [''])[0]
    if not job_id:
        raise ApiError('No job given.')
    try:
        last_seq = int((query.get('from_seq') or ['0'])[0])
    except ValueError:
        last_seq = 0

    handler.send_response(200)
    handler.send_header('Content-Type', 'text/event-stream')
    handler.send_header('Cache-Control', 'no-store')
    handler.send_header('X-Accel-Buffering', 'no')
    handler.end_headers()

    def emit(payload):
        handler.wfile.write(('data: ' + json.dumps(payload) + '\n\n').encode('utf-8'))
        handler.wfile.flush()

    deadline = time.time() + 15 * 60
    idle_since = time.time()
    try:
        while time.time() < deadline:
            rows = db().execute(
                'SELECT seq, kind, payload FROM studio_chat_chunks WHERE job_id=? AND seq>? '
                'ORDER BY seq', (job_id, last_seq)).fetchall()
            for row in rows:
                last_seq = row['seq']
                try:
                    chunk = json.loads(row['payload']) if row['payload'] else {}
                except json.JSONDecodeError:
                    continue
                chunk['seq'] = row['seq']
                emit(chunk)
                idle_since = time.time()

            job = db().execute('SELECT status, error FROM studio_jobs WHERE id=?',
                               (job_id,)).fetchone()
            if job and job['status'] in ('complete', 'error', 'cancelled'):
                # Drain anything written between the read above and now, or the
                # last words of a reply are lost exactly when the job finishes.
                tail = db().execute(
                    'SELECT seq, kind, payload FROM studio_chat_chunks WHERE job_id=? AND '
                    'seq>? ORDER BY seq', (job_id, last_seq)).fetchall()
                for row in tail:
                    last_seq = row['seq']
                    try:
                        chunk = json.loads(row['payload']) if row['payload'] else {}
                    except json.JSONDecodeError:
                        continue
                    chunk['seq'] = row['seq']
                    emit(chunk)
                if job['status'] == 'error':
                    emit({'error': job['error'] or 'The reply failed.'})
                else:
                    emit({'done': True, 'seq': last_seq})
                return None

            # A queued turn is still news: it tells the client the PC has the job
            # and is working through the queue, rather than leaving it silent.
            #
            # position is not optional. The client renders it as an ordinal, so
            # omitting it produced "Queued - undefinedth in line". 1 means next.
            if time.time() - idle_since > 4:
                idle_since = time.time()
                emit({'queued': {
                    'host_state': 'busy' if RUNNER.current else 'ready',
                    'position': queue_position(job_id),
                }})
            time.sleep(0.4)
    except (BrokenPipeError, ConnectionResetError):
        # The reader went away - a closed tab, or the client reconnecting with a
        # later from_seq. Nothing is lost; the chunks are still in the table.
        return None
    emit({'error': 'The reply took too long and the connection was closed.'})
    return None


# ------------------------------------------------------------- routing ---

def route_studio(handler, query, method):
    action = (query.get('action') or [''])[0]
    if method == 'GET':
        if action == 'status':
            return studio_status(query)
        if action == 'config':
            return studio_config()
        if action == 'registry':
            return studio_registry()
        if action == 'version':
            return studio_version()
        if action == 'update-check':
            return studio_update_check()
        if action == 'presets':
            return studio_presets()
        if action in ('image', 'thumbnail'):
            return studio_asset_bytes(query, action)
        if action == 'drafts':
            return studio_drafts(query)
        if action == 'draft-asset':
            return studio_draft_asset_get(query)
        raise ApiError('Unknown action: ' + (action or '(none)'), 404)

    if action == 'upload-asset':
        return studio_upload_asset(query, raw_body(handler))
    if action == 'draft-asset':
        return studio_draft_asset_put(query, raw_body(handler))
    body = json_body(handler)
    if action == 'generate':
        return studio_generate(query, body)
    if action == 'delete':
        return studio_delete(body)
    if action == 'reorder':
        return studio_reorder(body)
    if action == 'save-presets':
        return studio_save_presets(body)
    if action == 'save-lora':
        return studio_loras_save(body)
    if action == 'checkpoint-arch':
        return studio_checkpoint_arch(body)
    if action == 'forget-lora':
        return studio_loras_forget(body)
    if action == 'unlock':
        return studio_unlock(body)
    if action == 'lock':
        return {'ok': True}
    if action == 'draft-publish':
        return studio_draft_publish(query, body)
    if action == 'report-preview':
        return studio_report_preview(body)
    if action == 'report-save':
        return studio_report_save(body)
    if action == 'report-reveal':
        return studio_report_reveal()
    if action == 'update-apply':
        return studio_update_apply()
    raise ApiError('Unknown action: ' + (action or '(none)'), 404)


def route_chat(handler, query, method):
    action = (query.get('action') or [''])[0]
    if method == 'GET':
        if action == 'list-chats':
            return chat_list()
        if action == 'get-chat':
            return chat_get(query)
        if action == 'sync':
            return chat_sync(query)
        if action == 'list-memories':
            return chat_memories_list()
        if action == 'stream':
            return chat_stream(handler, query)
        raise ApiError('Unknown action: ' + (action or '(none)'), 404)

    body = json_body(handler)
    if action == 'save-message':
        return chat_save_message(body)
    if action == 'rename-chat':
        return chat_rename(body)
    if action == 'delete-chat':
        return chat_delete(body)
    if action == 'delete-message':
        return chat_delete_message(body)
    if action == 'trim-messages':
        return chat_trim(body)
    if action == 'save-memory':
        return chat_memory_save(body)
    if action == 'delete-memory':
        return chat_memory_delete(body)
    if action == 'clear-memories':
        return chat_memories_clear()
    if action == 'stop':
        return chat_stop(body)
    if action == 'cancel-queued':
        return chat_cancel_queued(body)
    if action == 'send':
        return chat_send(body)
    raise ApiError('Unknown action: ' + (action or '(none)'), 404)


# ---------------------------------------------------------------- http ---

class Handler(BaseHTTPRequestHandler):
    server_version = 'AIStudioPortable'
    sys_version = ''

    # Polled several times a second by an idle page. Logging every one buries
    # anything that matters under a wall of identical 200s.
    QUIET_ACTIONS = ('status', 'sync', 'config', 'list-chats', 'list-memories',
                     'presets', 'drafts', 'image', 'thumbnail', 'get-chat')

    def log_message(self, fmt, *args):
        line = str(args[0] if args else '')
        if '/api/' not in line:
            return
        status = str(args[1]) if len(args) > 1 else ''
        if status.startswith('2'):
            action = ''
            if 'action=' in line:
                action = line.split('action=', 1)[1].split('&', 1)[0].split(' ', 1)[0]
            if action in self.QUIET_ACTIONS:
                return
        sys.stderr.write('  ' + (fmt % args) + chr(10))

    def do_GET(self):
        self.dispatch('GET')

    def do_POST(self):
        self.dispatch('POST')

    def dispatch(self, method):
        parsed = urlparse(self.path)
        query = parse_qs(parsed.query)
        try:
            if parsed.path == '/api/studio':
                self.finish_api(route_studio(self, query, method))
                return
            if parsed.path == '/api/chat':
                self.finish_api(route_chat(self, query, method))
                return
            if method == 'GET':
                self.serve_static(parsed.path)
                return
            self.send_error(404)
        except ApiError as exc:
            self.finish_json({'error': exc.message, 'code': exc.code}, exc.status)
        except BrokenPipeError:
            pass
        except Exception as exc:                           # noqa: BLE001 - keep serving
            traceback.print_exc()
            logging.exception('Unhandled error in /api/studio action %r', action)
            self.finish_json({'error': 'The studio hit an unexpected error: ' + str(exc)}, 500)

    def finish_api(self, result):
        # chat_stream writes its own response and returns None. Anything else
        # here would append a second set of headers to a finished stream.
        if result is None:
            return
        content_type = 'application/octet-stream'
        if isinstance(result, tuple) and len(result) == 2:
            result, content_type = result
        if isinstance(result, (bytes, bytearray)):
            self.send_response(200)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(result)))
            self.send_header('Cache-Control', 'no-store')
            self.end_headers()
            self.wfile.write(result)
            return
        self.finish_json(result, 200)

    def finish_json(self, payload, status):
        body = json.dumps(payload).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(body)

    def serve_static(self, path):
        """Serve web/. Paths are resolved and checked, never trusted."""
        relative = path.lstrip('/') or 'index.html'
        target = (WEB_DIR / relative).resolve()
        if not str(target).startswith(str(WEB_DIR.resolve())):
            self.send_error(403)
            return
        if target.is_dir():
            target = target / 'index.html'
        if not target.exists():
            self.send_error(404)
            return
        kind = mimetypes.guess_type(str(target))[0] or 'application/octet-stream'
        data = target.read_bytes()
        self.send_response(200)
        self.send_header('Content-Type', kind)
        self.send_header('Content-Length', str(len(data)))
        # No caching while the interface is edited directly and has no build step;
        # a stale studio.js is a confusing way to lose an afternoon.
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(data)


def main():
    log_file = diagnostics.start_logging()
    diagnostics.log_environment({'port': CONFIG['port'],
                                 'comfy_port': CONFIG.get('comfy_port'),
                                 'encrypt_storage': bool(CONFIG.get('encrypt_storage'))})
    # The studio can be moved - a different drive, off a synced folder - and
    # the file telling ComfyUI where this install's models live holds an
    # absolute path written once, during setup. Put it right before anything
    # tries to generate.
    try:
        import setup as installer
        moved = installer.refresh_extra_model_paths()
        if moved:
            print('  moved   this folder has moved; model paths rewritten')
            logging.info('Studio folder moved; rewrote %s', moved)
    except Exception as exc:                               # noqa: BLE001 - never fatal
        logging.warning('Could not check the model paths file: %s', exc)

    init_db()
    recover_active_job()
    RUNNER.start()
    if CONFIG.get('check_updates', True) and CONFIG.get('update_url'):
        threading.Thread(target=update_watcher, name='update-watcher',
                         daemon=True).start()
    host, port = CONFIG['host'], int(CONFIG['port'])
    server = ThreadingHTTPServer((host, port), Handler)
    url = 'http://' + host + ':' + str(port) + '/'
    print('AI Studio Portable')
    print('  serving ' + str(WEB_DIR))
    print('  database ' + str(DB_PATH))
    print('  log      ' + str(log_file))
    print('  engine   ' + ('ready' if ENGINE.ready else 'not available - ' + str(ENGINE.error)))
    # Report the machine at startup rather than on the first job: it is the line
    # that explains why a model is missing from the picker, and a user who hits
    # that is looking at this window before they have run anything.
    if ENGINE.ready:
        apply_profile(ENGINE.module)
    print('  open     ' + url)
    if CONFIG.get('open_browser') and os.environ.get('STUDIO_NO_BROWSER') != '1':
        # Say so when this fails. webbrowser.open returns False rather than
        # raising when it cannot find a browser, so the old silent try/except
        # could not have reported it even in principle - and a studio that looks
        # like it did nothing is indistinguishable from one that crashed.
        opened = False
        try:
            import webbrowser
            opened = webbrowser.open(url)
        except Exception as exc:                           # noqa: BLE001 - never fatal
            print('  ! could not open a browser: ' + str(exc))
        if not opened:
            print('  ! could not open a browser for you - open the address above')
    print('  ready. Ctrl+C to stop.')
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print('\n  stopped')


if __name__ == '__main__':
    main()

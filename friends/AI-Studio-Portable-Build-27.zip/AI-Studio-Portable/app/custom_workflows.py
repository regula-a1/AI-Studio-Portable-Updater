"""Workflows the user brings: stored, inspected, and filled in for one job.

A ComfyUI workflow exported in API format is a graph the studio can submit
as it is. What it cannot do on its own is take the prompt typed into the
composer, the seed, the chosen size or the picture being edited - those are
baked into the file. So each upload is inspected once for where they go, and
every job writes them into a copy of the graph before it is sent.

Where they go is found two ways. A placeholder the user wrote into the graph -
`{{prompt}}`, `{{negative}}`, `{{seed}}`, `{{width}}`, `{{height}}`,
`{{image}}` - always wins, because it is the user saying so. Without one, the
studio follows the sampler's positive and negative inputs back to the text box
that feeds each, which is right for almost every workflow people share, and
says what it found so a wrong guess is visible before a job is spent on it.

Pure data in, data out: nothing here talks to ComfyUI or imports any of it.
"""
import copy
import json
import re
import struct
import time
from pathlib import Path

PLACEHOLDERS = ('prompt', 'negative', 'seed', 'width', 'height', 'image')
_PLACEHOLDER_RE = re.compile(r'\{\{\s*(' + '|'.join(PLACEHOLDERS) + r')\s*\}\}')

# Inputs that hold prompt text, on the text encoders people actually use.
TEXT_INPUTS = ('text', 'text_g', 'text_l', 't5xxl', 'clip_l', 'prompt', 'string', 'value')
SEED_INPUTS = ('seed', 'noise_seed')
# Never walked through when tracing conditioning back to its text: these lead
# to the model, not the prompt, and every encoder takes a clip.
NOT_CONDITIONING = ('clip', 'model', 'vae', 'image', 'pixels', 'mask', 'samples', 'latent_image')

# Which ComfyUI model folder a loader's input names a file in. Only used to
# say a file is missing; ComfyUI itself is the final word when the job runs.
MODEL_INPUTS = {
    'ckpt_name': ('checkpoints',),
    'unet_name': ('diffusion_models', 'unet'),
    'lora_name': ('loras',),
    'vae_name': ('vae',),
    'clip_name': ('text_encoders', 'clip'),
    'clip_name1': ('text_encoders', 'clip'),
    'clip_name2': ('text_encoders', 'clip'),
    'clip_name3': ('text_encoders', 'clip'),
    'control_net_name': ('controlnet',),
    'model_name': ('upscale_models',),
}
MODEL_EXTENSIONS = ('.safetensors', '.ckpt', '.pt', '.pth', '.bin', '.gguf', '.sft')

MAX_UPLOAD = 4 * 1024 * 1024
MAX_NODES = 2000


class WorkflowError(ValueError):
    """An upload the studio cannot use, with a sentence saying why."""


# ------------------------------------------------------------- reading ---

def _png_prompt(data):
    """The API-format graph ComfyUI writes into every PNG it saves, or None."""
    if not data.startswith(b'\x89PNG\r\n\x1a\n'):
        return None
    at = 8
    while at + 8 <= len(data):
        length, kind = struct.unpack('>I4s', data[at:at + 8])
        body = data[at + 8:at + 8 + length]
        at += 12 + length
        if kind == b'tEXt' and b'\x00' in body:
            key, _, value = body.partition(b'\x00')
            if key == b'prompt':
                return value.decode('latin-1')
        if kind == b'IEND':
            break
    return None


def parse_upload(data):
    """An API-format graph from uploaded bytes, or WorkflowError.

    Takes a .json export or a PNG ComfyUI saved. The editor's own format -
    nodes and links, what Save writes - is refused with directions rather
    than converted: turning it into a runnable graph needs every node's
    definition, which only a running ComfyUI has, and a half-right conversion
    fails later in a way nobody can read.
    """
    if not data:
        raise WorkflowError('The file is empty.')
    if len(data) > MAX_UPLOAD:
        raise WorkflowError('That file is too large to be a workflow.')
    text = _png_prompt(data)
    if text is None and data.startswith(b'\x89PNG'):
        raise WorkflowError('This picture has no workflow in it. Only images saved by '
                            'ComfyUI carry one.')
    if text is None:
        text = data.decode('utf-8-sig', 'replace')
    try:
        graph = json.loads(text)
    except json.JSONDecodeError:
        raise WorkflowError('This is not a workflow file - it could not be read as JSON.')
    if isinstance(graph, dict) and isinstance(graph.get('prompt'), dict):
        graph = graph['prompt']
    if isinstance(graph, dict) and 'nodes' in graph and 'links' in graph:
        raise WorkflowError('This is the editor format. In ComfyUI, open the workflow and '
                            'use Workflow > Export (API), then upload that file.')
    if not isinstance(graph, dict) or not graph:
        raise WorkflowError('This file does not contain a workflow.')
    if len(graph) > MAX_NODES:
        raise WorkflowError('This workflow has more nodes than the studio will run.')
    for node_id, node in graph.items():
        if not isinstance(node, dict) or not isinstance(node.get('class_type'), str) \
                or not isinstance(node.get('inputs', {}), dict):
            raise WorkflowError('This file does not look like a ComfyUI workflow '
                                '(node ' + str(node_id)[:20] + ' is not a node).')
        node.setdefault('inputs', {})
    if not any(_is_output(node) for node in graph.values()):
        raise WorkflowError('This workflow never saves an image. Add a Save Image node '
                            'and export it again.')
    return graph


def _is_output(node):
    kind = node['class_type']
    return kind in ('SaveImage', 'PreviewImage') or kind.startswith('SaveImage')


def _is_link(value):
    return (isinstance(value, list) and len(value) == 2
            and isinstance(value[0], (str, int)) and isinstance(value[1], int))


# ---------------------------------------------------------- inspecting ---

def _placeholders(graph):
    found = {}
    for node_id, node in graph.items():
        for name, value in node['inputs'].items():
            if isinstance(value, str):
                for match in _PLACEHOLDER_RE.finditer(value):
                    found.setdefault(match.group(1), []).append([node_id, name])
    return found


def _text_target(graph, start, depth=12):
    """Follow a conditioning link back to the text box that feeds it."""
    queue, seen = [str(start)], set()
    while queue and depth > 0:
        depth -= 1
        node_id = queue.pop(0)
        if node_id in seen or node_id not in graph:
            continue
        seen.add(node_id)
        inputs = graph[node_id]['inputs']
        for name in TEXT_INPUTS:
            value = inputs.get(name)
            if isinstance(value, str):
                return [node_id, name]
            if _is_link(value):
                # A text box wired in from a separate string node.
                queue.insert(0, str(value[0]))
        for name, value in inputs.items():
            if _is_link(value) and name not in NOT_CONDITIONING:
                queue.append(str(value[0]))
    return None


def _traced_prompts(graph):
    positive, negative = [], []
    for node in graph.values():
        inputs = node['inputs']
        roots = [('positive', inputs.get('positive')), ('negative', inputs.get('negative'))]
        if 'Guider' in node['class_type'] and 'positive' not in inputs:
            roots.append(('positive', inputs.get('conditioning')))
        for side, value in roots:
            if not _is_link(value):
                continue
            target = _text_target(graph, value[0])
            bucket = positive if side == 'positive' else negative
            if target and target not in bucket:
                bucket.append(target)
    # A negative traced back to the positive's own text - Krea 2 and Flux zero
    # out the positive for theirs - is not a negative prompt.
    negative = [target for target in negative if target not in positive]
    if not positive:
        encoders = [[node_id, 'text'] for node_id, node in graph.items()
                    if node['class_type'] == 'CLIPTextEncode'
                    and isinstance(node['inputs'].get('text'), str)]
        if len(encoders) == 1:
            positive = encoders
    return positive, negative


def inspect(graph):
    """Where this graph takes each thing the studio supplies.

    Each binding is a list of [node_id, input_name]. A prompt binding from a
    placeholder replaces the placeholder only; one found by tracing replaces
    the whole text box.
    """
    marked = _placeholders(graph)
    bindings = {'placeholders': sorted(marked)}
    if 'prompt' in marked:
        bindings['prompt'] = marked['prompt']
        bindings['negative'] = marked.get('negative', [])
    else:
        bindings['prompt'], bindings['negative'] = _traced_prompts(graph)
        if 'negative' in marked:
            bindings['negative'] = marked['negative']
    bindings['seed'] = marked.get('seed') or [
        [node_id, name] for node_id, node in graph.items()
        for name in SEED_INPUTS if isinstance(node['inputs'].get(name), int)]
    if 'width' in marked or 'height' in marked:
        bindings['width'] = marked.get('width', [])
        bindings['height'] = marked.get('height', [])
    else:
        sized = [node_id for node_id, node in graph.items()
                 if 'Latent' in node['class_type']
                 and isinstance(node['inputs'].get('width'), int)
                 and isinstance(node['inputs'].get('height'), int)]
        bindings['width'] = [[node_id, 'width'] for node_id in sized]
        bindings['height'] = [[node_id, 'height'] for node_id in sized]
    if 'image' in marked:
        bindings['image'] = marked['image']
    else:
        loaders = sorted((node_id for node_id, node in graph.items()
                          if node['class_type'] == 'LoadImage'), key=_node_order)
        bindings['image'] = [[loaders[0], 'image']] if loaders else []
    return bindings


def _node_order(node_id):
    text = str(node_id)
    return (0, int(text), '') if text.isdigit() else (1, 0, text)


def model_files(graph):
    """(folders, filename) for every model file the graph loads."""
    wanted = []
    for node in graph.values():
        for name, value in node['inputs'].items():
            if name in MODEL_INPUTS and isinstance(value, str) \
                    and value.lower().endswith(MODEL_EXTENSIONS):
                pair = (MODEL_INPUTS[name], value)
                if pair not in wanted:
                    wanted.append(pair)
    return wanted


def summary(graph, bindings):
    """What the studio will fill in, in words, for the panel and the picker."""
    takes = []
    if bindings.get('prompt'):
        takes.append('prompt')
    if bindings.get('negative'):
        takes.append('negative prompt')
    if bindings.get('seed'):
        takes.append('seed')
    if bindings.get('width') or bindings.get('height'):
        takes.append('size')
    if bindings.get('image'):
        takes.append('input image')
    return takes


# ------------------------------------------------------------- filling ---

def bind(graph, bindings, values):
    """A copy of the graph with this job's values written in.

    `values` holds prompt, negative, seed, width, height and image; any left
    out leaves the workflow's own value where it is.
    """
    out = copy.deepcopy(graph)
    for key in PLACEHOLDERS:
        if values.get(key) is None:
            continue
        for node_id, name in bindings.get(key) or []:
            inputs = out.get(node_id, {}).get('inputs', {})
            current = inputs.get(name)
            value = values[key]
            if isinstance(current, str) and _PLACEHOLDER_RE.search(current):
                whole = _PLACEHOLDER_RE.fullmatch(current.strip())
                if whole and key in ('seed', 'width', 'height'):
                    inputs[name] = int(value)
                else:
                    inputs[name] = re.sub(r'\{\{\s*' + key + r'\s*\}\}',
                                          lambda _m: str(value), current)
            else:
                inputs[name] = value
    # A placeholder the job had no value for would reach ComfyUI as literal
    # braces - an empty negative is the usual one.
    for node in out.values():
        for name, current in node['inputs'].items():
            if isinstance(current, str) and _PLACEHOLDER_RE.search(current):
                node['inputs'][name] = _PLACEHOLDER_RE.sub('', current)
    return out


def texts(graph, bindings):
    """(positive, negative) words written into the graph itself.

    The prompt the user typed is only part of what a workflow paints from:
    text can be baked into the file, and an empty composer prompt over a
    graph that carries its own is still a prompt. So the content check reads
    this as well as the composer's.
    """
    negative_at = {tuple(target) for target in bindings.get('negative') or []}
    positive, negative = [], []
    for node_id, node in graph.items():
        for name, value in node['inputs'].items():
            if not isinstance(value, str) or not value.strip():
                continue
            if value.lower().endswith(MODEL_EXTENSIONS):
                continue
            text = _PLACEHOLDER_RE.sub(' ', value)
            (negative if (node_id, name) in negative_at else positive).append(text)
    return ' '.join(positive), ' '.join(negative)


# ------------------------------------------------------------- storage ---

def _slug(name):
    slug = re.sub(r'[^a-z0-9]+', '-', name.lower()).strip('-')[:40]
    return slug or 'workflow'


class Store:
    """One JSON file per workflow under data/workflows."""

    def __init__(self, folder):
        self.folder = Path(folder)

    def _path(self, workflow_id):
        if not re.fullmatch(r'[a-z0-9-]{1,48}', str(workflow_id or '')):
            raise WorkflowError('No such workflow.')
        return self.folder / (workflow_id + '.json')

    def all(self):
        found = []
        if not self.folder.is_dir():
            return found
        for path in sorted(self.folder.glob('*.json')):
            try:
                record = json.loads(path.read_text(encoding='utf-8'))
                record['id'] = path.stem
                found.append(record)
            except (OSError, json.JSONDecodeError, TypeError):
                continue
        return found

    def get(self, workflow_id):
        path = self._path(workflow_id)
        try:
            record = json.loads(path.read_text(encoding='utf-8'))
        except (OSError, json.JSONDecodeError):
            raise WorkflowError('That workflow is no longer in the studio. Upload it again '
                                'or choose another model.')
        record['id'] = workflow_id
        return record

    def save(self, name, graph):
        name = (name or '').strip()[:80] or 'Workflow'
        self.folder.mkdir(parents=True, exist_ok=True)
        base = _slug(name)
        workflow_id, n = base, 2
        while (self.folder / (workflow_id + '.json')).exists():
            workflow_id = base + '-' + str(n)
            n += 1
        record = {'name': name, 'uploaded': int(time.time()), 'graph': graph}
        self._path(workflow_id).write_text(json.dumps(record), encoding='utf-8')
        record['id'] = workflow_id
        return record

    def rename(self, workflow_id, name):
        record = self.get(workflow_id)
        record['name'] = (name or '').strip()[:80] or record['name']
        record.pop('id', None)
        self._path(workflow_id).write_text(json.dumps(record), encoding='utf-8')
        return record

    def delete(self, workflow_id):
        self._path(workflow_id).unlink(missing_ok=True)

"""Tie the engines' lifetime to the studio's.

ComfyUI and llama-server are started hidden, as separate processes. Closing the
studio's window kills Python and nothing else, so before this existed the
engines outlived it: invisible, holding gigabytes of RAM and video memory until
the next reboot. A game launched on top of that is launched on a machine that
has already been spent.

Two pieces, and they are deliberately independent:

`adopt` puts a process in a Windows job object that kills its members when the
last handle to the job closes. That handle belongs to this process, so however
the studio dies - window closed, Task Manager, a crash - the engines go with it.
Only the engines are adopted. Putting the studio itself in the job would drag
the user's browser in with it, since the browser is launched from here.

`idle_expired` is the clock for letting the engines go while the studio stays
up, so a finished render does not keep 13 GB resident for the rest of the day.
"""
import ctypes
import logging
import os
import threading

_job = None
_lock = threading.Lock()

JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE = 0x2000
JOB_OBJECT_EXTENDED_LIMIT_INFORMATION_CLASS = 9
PROCESS_SET_QUOTA = 0x0100
PROCESS_TERMINATE = 0x0001


def idle_expired(idle_since, now, minutes):
    """Whether the studio has been idle long enough to release the engines.

    Zero or less means never. The setting declares its own bounds, so a bad
    value here would be a hand-edited config.json, and "never" is the safe
    reading of one: it is how the studio behaved before there was a setting.
    """
    try:
        limit = float(minutes) * 60
    except (TypeError, ValueError):
        return False
    return limit > 0 and (now - idle_since) >= limit


def _create_job():
    from ctypes import wintypes

    class BasicLimits(ctypes.Structure):
        _fields_ = [('PerProcessUserTimeLimit', ctypes.c_int64),
                    ('PerJobUserTimeLimit', ctypes.c_int64),
                    ('LimitFlags', wintypes.DWORD),
                    ('MinimumWorkingSetSize', ctypes.c_size_t),
                    ('MaximumWorkingSetSize', ctypes.c_size_t),
                    ('ActiveProcessLimit', wintypes.DWORD),
                    ('Affinity', ctypes.c_size_t),
                    ('PriorityClass', wintypes.DWORD),
                    ('SchedulingClass', wintypes.DWORD)]

    class IoCounters(ctypes.Structure):
        _fields_ = [(name, ctypes.c_uint64) for name in (
            'ReadOperationCount', 'WriteOperationCount', 'OtherOperationCount',
            'ReadTransferCount', 'WriteTransferCount', 'OtherTransferCount')]

    class ExtendedLimits(ctypes.Structure):
        _fields_ = [('BasicLimitInformation', BasicLimits),
                    ('IoInfo', IoCounters),
                    ('ProcessMemoryLimit', ctypes.c_size_t),
                    ('JobMemoryLimit', ctypes.c_size_t),
                    ('PeakProcessMemoryUsed', ctypes.c_size_t),
                    ('PeakJobMemoryUsed', ctypes.c_size_t)]

    kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel32.CreateJobObjectW.restype = wintypes.HANDLE
    kernel32.CreateJobObjectW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
    kernel32.SetInformationJobObject.argtypes = [
        wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
    kernel32.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
    kernel32.OpenProcess.restype = wintypes.HANDLE
    kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]

    handle = kernel32.CreateJobObjectW(None, None)
    if not handle:
        raise ctypes.WinError(ctypes.get_last_error())
    limits = ExtendedLimits()
    limits.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
    if not kernel32.SetInformationJobObject(
            handle, JOB_OBJECT_EXTENDED_LIMIT_INFORMATION_CLASS,
            ctypes.byref(limits), ctypes.sizeof(limits)):
        raise ctypes.WinError(ctypes.get_last_error())
    return kernel32, handle


def adopt(process):
    """Make `process` die with this one. True if that is now guaranteed.

    Never raises: failing to adopt costs the guarantee, not the job. The caller
    still has the idle release and the shutdown path to fall back on.
    """
    global _job
    if os.name != 'nt' or process is None:
        return False
    try:
        with _lock:
            if _job is None:
                _job = _create_job()
            kernel32, job = _job
        handle = kernel32.OpenProcess(PROCESS_SET_QUOTA | PROCESS_TERMINATE,
                                      False, process.pid)
        if not handle:
            raise ctypes.WinError(ctypes.get_last_error())
        try:
            if not kernel32.AssignProcessToJobObject(job, handle):
                raise ctypes.WinError(ctypes.get_last_error())
        finally:
            kernel32.CloseHandle(handle)
        return True
    except Exception as exc:                               # noqa: BLE001 - never fatal
        logging.warning('Could not tie pid %s to the studio (%s); it will not stop '
                        'on its own if the studio is killed.',
                        getattr(process, 'pid', '?'), exc)
        return False

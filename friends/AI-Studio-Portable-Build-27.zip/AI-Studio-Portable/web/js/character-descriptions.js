/* Per-character appearance descriptions for AI Studio Portable.
 * Stored as "desc_<id>" entries in studio_portraits and sealed automatically
 * when storage encryption is enabled. Injected right after trigger words when
 * the composer's appearance description toggle is enabled.
 */
(() => {
    'use strict';
    const PREFIX = 'desc_', MAX_LENGTH = 1500;
    const validId = id => typeof id === 'string' && /^[a-z0-9_]{1,90}$/.test(id);
    function create(owner = 'local', changed = () => {}) {
        const storeKey = `aistudio-character-descriptions:${owner}`;
        let state = { since: 0, items: {} };
        try {
            const saved = JSON.parse(localStorage.getItem(storeKey));
            if (saved && saved.items && typeof saved.items === 'object') state = { since: Number(saved.since) || 0, items: saved.items };
        } catch { /* nothing saved yet */ }
        const persist = () => { try { localStorage.setItem(storeKey, JSON.stringify(state)); } catch { /* memory only */ } };
        const crypto_ = () => window.StudioCrypto;
        const unlocked = () => Boolean(crypto_()?.isUnlocked?.());
        const plain = new Map();
        let syncing = null;
        async function open() {
            plain.clear();
            if (!unlocked()) return;
            for (const [id, item] of Object.entries(state.items)) {
                if (item.deleted || !item.sealed) continue;
                try { plain.set(id, await crypto_().unsealText(item.sealed)); } catch { /* sealed under another key */ }
            }
        }
        async function sync() {
            if (!unlocked()) return false;
            if (syncing) return syncing;
            syncing = (async () => {
                let touched = false;
                try {
                    for (const [id, item] of Object.entries(state.items)) {
                        if (!item.dirty) continue;
                        const updated = await crypto_().savePortrait(PREFIX + id, item.deleted ? '' : item.sealed);
                        const latest = state.items[id];
                        if (latest && latest.rev === item.rev) { state.items[id] = { ...latest, dirty: false, updated }; persist(); }
                    }
                    for (let page = 0; page < 5; page += 1) {
                        const rows = await crypto_().fetchPortraits(state.since);
                        let high = state.since;
                        for (const row of rows || []) {
                            high = Math.max(high, row.updated);
                            if (!String(row.character).startsWith(PREFIX)) continue;
                            const id = row.character.slice(PREFIX.length);
                            if (!validId(id)) continue;
                            const local = state.items[id];
                            if (local && (local.dirty || local.updated >= row.updated)) continue;
                            state.items[id] = { sealed: row.payload || '', deleted: !row.payload, updated: row.updated, dirty: false, rev: 0 };
                            touched = true;
                        }
                        const advanced = high > state.since;
                        state.since = high; persist();
                        if (!advanced || (rows || []).length < 200) break;
                    }
                    if (touched) await open();
                } catch { /* offline or locked: retried on next sync */ }
                finally { syncing = null; }
                if (touched) changed();
                return true;
            })();
            return syncing;
        }
        window.addEventListener('studio-unlocked', async () => { await open(); changed(); sync(); });
        window.addEventListener('studio-locked', () => { plain.clear(); changed(); });
        document.addEventListener('visibilitychange', () => { if (!document.hidden) sync(); });
        if (unlocked()) open().then(() => { changed(); sync(); });
        return {
            isUnlocked: unlocked,
            maxLength: MAX_LENGTH,
            get: id => plain.get(id) || '',
            async set(id, text) {
                if (!validId(id)) throw new Error('Invalid character.');
                if (!unlocked()) throw new Error('Unlock Studio first.');
                const value = String(text || '').replace(/\s+/g, ' ').trim();
                if (value.length > MAX_LENGTH) throw new Error(`Keep the description under ${MAX_LENGTH} characters.`);
                const previous = state.items[id];
                const rev = (previous?.rev || 0) + 1;
                if (value) {
                    state.items[id] = { sealed: await crypto_().sealText(value), deleted: false, updated: previous?.updated || 0, dirty: true, rev };
                    plain.set(id, value);
                } else {
                    state.items[id] = { sealed: '', deleted: true, updated: previous?.updated || 0, dirty: true, rev };
                    plain.delete(id);
                }
                persist(); changed(); sync();
            },
            sync
        };
    }
    window.StudioCharacterDescriptions = { create };
})();

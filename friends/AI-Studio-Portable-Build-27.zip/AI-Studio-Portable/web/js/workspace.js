/* Presentation enhancement only: move existing controls without cloning them,
   changing their form owner, or touching authentication, storage or requests. */
(() => {
    const form = document.getElementById('studio-form');
    if (!form) return;
    const get = selector => form.querySelector(selector);
    const bar = document.createElement('div');
    bar.className = 'studio-settings-bar';
    const groups = [];
    function group(label, nodes, name) {
        const details = document.createElement('details');
        details.className = `studio-setting-group studio-setting-${name}`;
        const summary = document.createElement('summary');
        summary.textContent = label;
        const content = document.createElement('div');
        content.className = 'studio-setting-content';
        content.setAttribute('role', 'region');
        content.setAttribute('aria-label', `${label} settings`);
        const header = document.createElement('div');
        header.className = 'studio-setting-heading';
        const title = document.createElement('strong');
        title.textContent = label;
        const close = document.createElement('button');
        close.type = 'button';
        close.className = 'text-button';
        close.textContent = 'Done';
        close.setAttribute('aria-label', `Close ${label} settings`);
        close.addEventListener('click', () => { details.open = false; summary.focus(); });
        header.append(title, close);
        content.append(header);
        nodes.filter(Boolean).forEach(node => content.append(node));
        details.append(summary, content);
        bar.append(details);
        groups.push(details);
        details.addEventListener('toggle', () => {
            if (details.open) {
                groups.forEach(other => { if (other !== details) other.open = false; });
                if (!window.matchMedia('(max-width: 760px)').matches) content.scrollIntoView({ block: 'nearest', behavior: 'instant' });
            }
        });
        return summary;
    }
    const prompt = document.createElement('div');
    prompt.className = 'studio-prompt-block';
    [get('.prompt-header'), get('#prompt'), get('#prompt-count')?.closest('.field-caption')].filter(Boolean).forEach(node => prompt.append(node));
    const promptPair = document.createElement('div');
    promptPair.className = 'studio-prompt-pair';
    promptPair.append(prompt);
    const negative = get('#negative-settings');
    if (negative) {
        negative.open = true;
        const summary = negative.querySelector('summary');
        const label = document.createElement('strong');
        label.textContent = 'Negative prompt';
        const optional = document.createElement('small');
        optional.textContent = 'Optional';
        const chevron = document.createElement('span');
        chevron.textContent = '⌄';
        chevron.setAttribute('aria-hidden', 'true');
        summary.replaceChildren(label, optional, chevron);
        promptPair.append(negative);
    }
    const modelSummary = group('Model', [get('label[for="architecture"]'), get('#architecture'), get('label[for="model"]'), get('#model'), get('#model-note'), get('#prompt-enhance-wrapper')], 'model');
    const characterSummary = get('.character-fieldset') ? group('Character', [get('.character-fieldset')], 'character') : null;
    const styleSummary = group('Style & LoRAs', [get('.lora-fieldset:not(.character-fieldset)') || get('.lora-fieldset')], 'style');
    const canvasSummary = group('Canvas', [...form.querySelectorAll('.ratio-fieldset')], 'canvas');
    const presetAction = get('.studio-preset-library-action');
    if (presetAction) {
        bar.append(presetAction);
        presetAction.addEventListener('click', () => groups.forEach(group => { group.open = false; }));
    } else if (get('.preset-launcher-bar')) {
        group('Presets', [get('.preset-launcher-bar')], 'presets');
    }
    group('Advanced', [get('#advanced-settings')], 'advanced');
    const advanced = bar.querySelector('#advanced-settings');
    if (advanced) advanced.open = true;
    const sliders = get('#composer-mode-sliders');
    const generate = get('.generate-bar');
    form.prepend(promptPair, bar);
    const sourceAction = document.createElement('button');
    sourceAction.type = 'button';
    sourceAction.className = 'button studio-source-action';
    sourceAction.textContent = 'Choose source image';
    sourceAction.hidden = true;
    let sourceMode = 'txt2img';
    function updateSourceAction() {
        sourceAction.hidden = !['img2img', 'inpaint'].includes(sourceMode);
        if (sourceAction.hidden) return;
        const viewport = document.getElementById(sourceMode === 'inpaint' ? 'inpaint-viewport' : 'img2img-viewport');
        sourceAction.textContent = viewport && !viewport.hidden ? 'Change source image' : 'Choose source image';
    }
    sourceAction.addEventListener('click', () => {
        document.getElementById(sourceMode === 'inpaint' ? 'inpaint-file-input' : 'img2img-file-input')?.click();
    });
    form.prepend(sourceAction);
    if (sliders) bar.after(sliders);
    if (generate) form.append(generate);
    const heading = document.getElementById('compose-title');
    if (heading) heading.textContent = 'What do you want to create?';
    function updateSummary() {
        const model = get('#model');
        modelSummary.textContent = model?.selectedOptions[0]?.textContent || 'Model';
        const ratio = get('input[name="ratio"]:checked');
        const resolution = get('input[name="resolution"]:checked');
        canvasSummary.textContent = `${ratio?.closest('label')?.querySelector('strong')?.textContent || 'Canvas'} · ${resolution?.closest('label')?.querySelector('strong')?.textContent || 'Resolution'}`;
        const count = get('#lora-count');
        styleSummary.textContent = `Style & LoRAs${count?.textContent ? ' · ' + count.textContent : ''}`;
        if (characterSummary) {
            const picked = get('#character-count');
            characterSummary.textContent = picked && picked.dataset.selected !== '0' ? `Character · ${picked.textContent}` : 'Character';
        }
    }
    form.addEventListener('change', updateSummary);
    if (get('#model')) new MutationObserver(updateSummary).observe(get('#model'), { childList: true, subtree: true, characterData: true });
    if (get('#lora-count')) new MutationObserver(updateSummary).observe(get('#lora-count'), { childList: true, subtree: true, characterData: true });
    if (characterSummary && get('#character-count')) {
        new MutationObserver(updateSummary).observe(get('#character-count'), { childList: true, subtree: true, characterData: true, attributes: true });
    }
    ['img2img-viewport', 'inpaint-viewport'].forEach(id => {
        const el = document.getElementById(id);
        if (el) new MutationObserver(updateSourceAction).observe(el, { attributes: true, attributeFilter: ['hidden'] });
    });
    // Native validation must be able to reveal a control inside a closed group.
    form.addEventListener('invalid', event => {
        const parent = event.target.closest('.studio-setting-group');
        if (parent) parent.open = true;
    }, true);
    document.addEventListener('pointerdown', event => {
        if (!bar.contains(event.target)) groups.forEach(group => { group.open = false; });
    });
    // WebKit focuses the tabindex=-1 settings panel when a bar button is pressed; Tab never lands there.
    bar.addEventListener('focusout', event => {
        if (event.relatedTarget && event.relatedTarget.tabIndex >= 0 && !bar.contains(event.relatedTarget) && !event.relatedTarget.closest('dialog')) {
            groups.forEach(group => { group.open = false; });
        }
    });
    const promptInput = get('#prompt');
    if (promptInput) {
        promptInput.setAttribute('aria-label', 'Prompt');
        promptInput.setAttribute('aria-describedby', 'prompt-count');
        promptInput.setAttribute('aria-keyshortcuts', 'Control+Enter Meta+Enter');
        const shortcutHint = get('#prompt-count')?.previousElementSibling;
        if (shortcutHint) shortcutHint.textContent = /Mac|iPhone|iPad/.test(navigator.platform) ? '⌘ Enter to generate' : 'Ctrl + Enter to generate';
        const submitOnModEnter = event => {
            if (event.key !== 'Enter' || !(event.ctrlKey || event.metaKey) || event.isComposing) return;
            event.preventDefault();
            const submit = form.querySelector('.generate-bar button[type="submit"]');
            if (submit && !submit.disabled && !document.querySelector('dialog[open]')) form.requestSubmit(submit);
        };
        promptInput.addEventListener('keydown', submitOnModEnter);
        get('#negative-prompt')?.addEventListener('keydown', submitOnModEnter);
    }
    document.addEventListener('keydown', event => {
        if (event.key !== 'Escape' || event.defaultPrevented || event.target.closest('dialog[open]')) return;
        const open = groups.find(group => group.open);
        if (open) { open.open = false; open.querySelector('summary').focus(); }
    });
    window.addEventListener('studio-mode-change', event => {
        sourceMode = event.detail?.mode || 'txt2img';
        updateSourceAction();
        groups.forEach(group => { group.open = false; });
        updateSummary();
    });
    window.addEventListener('studio-input-change', updateSourceAction);
    // Keep the existing mode buttons and handlers, now in a persistent app rail.
    const icons = {
        txt2img: 'M12 3l2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5Z',
        img2img: 'M4 4h16v16H4Z M4 16l5-5 4 4 3-3 4 4 M15 8h.01',
        inpaint: 'M14 5l5 5 M5 19l4-1 11-11-4-4L5 14Z M4 21h16',
        chat: 'M21 11a9 9 0 0 1-9 9H4l-2 2V11a9 9 0 0 1 19 0Z'
    };
    const names = { txt2img: 'Create', img2img: 'Transform', inpaint: 'Inpaint', chat: 'Chat' };
    document.querySelectorAll('.generator-mode-tabs .mode-tab').forEach(tab => {
        const icon = document.createElement('span');
        icon.className = 'studio-nav-icon';
        icon.setAttribute('aria-hidden', 'true');
        const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.setAttribute('viewBox', '0 0 24 24');
        svg.setAttribute('fill', 'none');
        svg.setAttribute('stroke', 'currentColor');
        svg.setAttribute('stroke-width', '1.6');
        svg.setAttribute('stroke-linejoin', 'round');
        const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        path.setAttribute('d', icons[tab.dataset.mode] || icons.txt2img);
        svg.append(path);
        icon.append(svg);
        tab.prepend(icon);
        const strong = tab.querySelector('strong');
        if (strong && names[tab.dataset.mode]) strong.textContent = names[tab.dataset.mode];
        tab.title = { txt2img: 'Text to image', img2img: 'Image to image', inpaint: 'Paint selected areas', chat: 'AI chat' }[tab.dataset.mode] || '';
    });
    document.body.classList.add('studio-workspace-v2');
    updateSummary();
})();

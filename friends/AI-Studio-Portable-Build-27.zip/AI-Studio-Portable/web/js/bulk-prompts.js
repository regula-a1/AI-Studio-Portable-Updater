// Bulk prompt paste and sequential queue submission for AI Studio Portable.
//
// Paste an entire LLM reply and every fenced code block in it becomes one
// queued prompt. Everything outside the fences (numbering, headers, chatter)
// is ignored. The studio registers an adapter with BulkPrompts.attach() that
// submits one prompt through its own pipeline; this module owns parsing, the
// preview dialog, per-character cast expansion, and the feeder loop.
(function () {
    "use strict";

    // CommonMark-style fences: 3+ backticks or tildes, an optional info string
    // ("text", "markdown"...), closed by the same character at least as long.
    // Indentation is tolerated because chat UIs nest fences inside lists.
    const OPEN = /^[ \t]*(`{3,}|~{3,})[ \t]*([^`]*?)[ \t]*$/;

    function parse(raw) {
        const lines = String(raw || "").replace(/\r\n?/g, "\n").split("\n");
        const prompts = [];
        let fence = null, body = [];
        const flush = unclosed => {
            const text = body.join("\n").trim();
            if (text) prompts.push({ text, unclosed });
            fence = null;
            body = [];
        };
        for (const line of lines) {
            if (!fence) {
                const m = OPEN.exec(line);
                if (m) fence = { char: m[1][0], len: m[1].length };
                continue;
            }
            const close = /^[ \t]*(`{3,}|~{3,})[ \t]*$/.exec(line);
            if (close && close[1][0] === fence.char && close[1].length >= fence.len) flush(false);
            else body.push(line);
        }
        if (fence) flush(true);
        return prompts;
    }

    const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

    // Character-major job order: every prompt for the first character, then every
    // prompt for the second. Without characters it is just the prompts in order.
    // `done` holds keys already queued so a retry sends only what is left.
    const jobKey = (character, prompt) => (character ? character.id : "") + "\u0000" + prompt.text;
    function plan(prompts, characters, done) {
        const jobs = [];
        for (const character of characters && characters.length ? characters : [null]) {
            for (const prompt of prompts) {
                if (!done || !done.has(jobKey(character, prompt))) jobs.push({ prompt, character });
            }
        }
        return jobs;
    }

    const PER_CHARACTER_KEY = "aistudio-bulk-per-character";
    function loadPerCharacter() { try { return localStorage.getItem(PER_CHARACTER_KEY) === "1"; } catch { return false; } }
    function savePerCharacter(on) { try { localStorage.setItem(PER_CHARACTER_KEY, on ? "1" : "0"); } catch { /* per-device convenience only */ } }

    function attach(options) {
        const promptInput = document.querySelector(options.promptSelector || "#prompt");
        if (!promptInput) return;
        const maxLength = Number(promptInput.getAttribute("maxlength")) || 4000;

        const dialog = document.createElement("dialog");
        dialog.className = "bulk-dialog";
        dialog.setAttribute("aria-labelledby", "bulk-title");
        dialog.innerHTML = `
            <form method="dialog" class="bulk-body">
                <div class="bulk-heading">
                    <h2 id="bulk-title">Bulk prompts</h2>
                    <button class="bulk-close" type="button" aria-label="Close">&times;</button>
                </div>
                <p class="bulk-help">Paste a whole message from your LLM. Only the text inside code blocks is queued; numbering, headers and chatter are ignored. Uses your current model, size and settings.</p>
                <textarea class="bulk-text" rows="6" spellcheck="false" aria-label="Pasted message" placeholder="\`\`\`\nFirst prompt here...\n\`\`\`\n\n\`\`\`\nSecond prompt here...\n\`\`\`"></textarea>
                <label class="per-character-toggle" hidden><input type="checkbox" class="bulk-per-character"><span></span></label>
                <p class="bulk-summary" role="status" aria-live="polite"></p>
                <ol class="bulk-list"></ol>
                <p class="bulk-progress" role="status" aria-live="polite"></p>
                <div class="bulk-actions">
                    <button class="button" type="button" data-bulk="cancel">Close</button>
                    <button class="button primary" type="button" data-bulk="go" disabled>Queue prompts</button>
                </div>
            </form>`;
        document.body.append(dialog);
        const $ = sel => dialog.querySelector(sel);
        const text = $(".bulk-text"), summary = $(".bulk-summary"), list = $(".bulk-list");
        const progress = $(".bulk-progress"), go = $('[data-bulk="go"]'), cancel = $('[data-bulk="cancel"]');
        const perCharacterBox = $(".bulk-per-character"), perCharacterLabel = $(".per-character-toggle");
        let parsed = [], running = false, stopRequested = false;
        let doneKeys = new Set(), doneSignature = "", summaryBase = "", castSeen = "";
        perCharacterBox.checked = loadPerCharacter();

        const selectedCharacters = () => {
            if (!options.characters) return [];
            const cast = options.characters() || [];
            perCharacterLabel.hidden = cast.length < 1;
            if (cast.length < 1) return [];
            const signature = cast.map(c => c.id).join("|");
            if (cast.fromLibrary && signature !== castSeen) perCharacterBox.checked = true;
            castSeen = signature;
            const names = cast.length > 4 ? `${cast.slice(0, 3).map(c => c.label).join(", ")} and ${cast.length - 3} more` : cast.map(c => c.label).join(", ");
            perCharacterBox.nextElementSibling.textContent = cast.fromLibrary
                ? `Run each of the ${cast.length} ticked characters separately, one after another (${names})`
                : `Run each selected character separately, in the order picked (${names})`;
            return perCharacterBox.checked ? cast : [];
        };

        function pending() {
            const cast = selectedCharacters();
            const signature = cast.map(c => c.id).join("|");
            if (signature !== doneSignature) { doneKeys = new Set(); doneSignature = signature; }
            return { cast, jobs: plan(checked(), cast, doneKeys) };
        }

        const checked = () => parsed.filter((_, i) => list.querySelector(`input[data-i="${i}"]`)?.checked);
        function updateGo() {
            const { cast, jobs } = pending();
            const n = jobs.length;
            go.disabled = running || !n;
            go.textContent = n ? `Queue ${n} prompt${n === 1 ? "" : "s"}` : "Queue prompts";
            const prompts = checked().length;
            const split = cast.length && prompts
                ? ` ${cast.length} characters × ${prompts} prompt${prompts === 1 ? "" : "s"} = ${prompts * cast.length} jobs${n < prompts * cast.length ? `, ${n} left to queue` : ""}.`
                : "";
            summary.textContent = summaryBase + split;
        }
        function render() {
            parsed = parse(text.value);
            list.replaceChildren();
            parsed.forEach((p, i) => {
                const li = document.createElement("li");
                const label = document.createElement("label");
                const box = document.createElement("input");
                box.type = "checkbox";
                box.dataset.i = String(i);
                box.checked = p.text.length <= maxLength;
                box.disabled = p.text.length > maxLength;
                box.addEventListener("change", updateGo);
                const span = document.createElement("span");
                const flat = p.text.replace(/\s+/g, " ");
                let note = "";
                if (p.text.length > maxLength) note = ` (too long: ${p.text.length}/${maxLength})`;
                else if (p.unclosed) note = " (code block was never closed)";
                span.textContent = (flat.length > 140 ? flat.slice(0, 140) + "…" : flat) + note;
                label.append(box, span);
                li.append(label);
                list.append(li);
            });
            summaryBase = !text.value.trim() ? ""
                : parsed.length ? `Found ${parsed.length} code block${parsed.length === 1 ? "" : "s"}.`
                : "No code blocks found. Prompts must be wrapped in ``` fences.";
            updateGo();
        }
        text.addEventListener("input", render);
        perCharacterBox.addEventListener("change", () => { savePerCharacter(perCharacterBox.checked); render(); });

        function open(raw) {
            if (running) { if (!dialog.open) dialog.showModal(); return; }
            if (typeof raw === "string") text.value = raw;
            progress.textContent = "";
            render();
            if (!dialog.open) dialog.showModal();
        }

        function closeIfIdle() {
            if (running) { stopRequested = true; progress.textContent = "Stopping after the current prompt…"; return; }
            dialog.close();
        }
        cancel.addEventListener("click", closeIfIdle);
        $(".bulk-close").addEventListener("click", closeIfIdle);
        dialog.addEventListener("cancel", event => { if (running) { event.preventDefault(); closeIfIdle(); } });

        go.addEventListener("click", async () => {
            const todo = checked();
            if (!todo.length || running) return;
            const { cast, jobs } = pending();
            if (!jobs.length) return;
            if (cast.length && jobs.length > 60 && !window.confirm(`This queues ${jobs.length} jobs (${cast.length} characters). Continue?`)) return;
            const blocked = options.canStart?.();
            if (blocked) { progress.textContent = blocked; return; }
            running = true; stopRequested = false;
            text.disabled = true;
            list.querySelectorAll("input").forEach(box => { box.disabled = true; });
            cancel.textContent = "Stop";
            updateGo();
            let done = 0, failure = "";
            for (const { prompt, character } of jobs) {
                if (stopRequested) break;
                const who = character ? ` (${character.label})` : "";
                progress.textContent = `Queued ${done} of ${jobs.length}${who}…`;
                const result = await options.submit(prompt.text, {
                    character,
                    shouldStop: () => stopRequested,
                    onWait: message => { progress.textContent = `Queued ${done} of ${jobs.length}. ${message}`; }
                });
                if (result?.error) { failure = result.error; break; }
                doneKeys.add(jobKey(character, prompt));
                done += 1;
            }
            running = false;
            text.disabled = false;
            cancel.textContent = "Close";
            progress.textContent = failure
                ? `Queued ${done} of ${jobs.length}. Stopped: ${failure}`
                : stopRequested ? `Stopped. Queued ${done} of ${jobs.length}.`
                : `Queued all ${done} prompt${done === 1 ? "" : "s"}.`;
            const left = plan(todo, selectedCharacters(), doneKeys);
            const remaining = todo.filter(p => left.some(job => job.prompt === p));
            if (!remaining.length) doneKeys = new Set();
            text.value = remaining.map(p => "```\n" + p.text + "\n```").join("\n\n");
            render();
            try { options.afterRun?.(done); } catch { /* cosmetic only */ }
        });

        // Dropping a multi-prompt message into the prompt box opens the dialog
        // instead of dumping fences into a single prompt.
        promptInput.addEventListener("paste", event => {
            const pasted = event.clipboardData?.getData("text/plain") || "";
            if (parse(pasted).length < 2) return;
            event.preventDefault();
            open(pasted);
        });

        const caption = promptInput.closest(".field, .prompt-field, div")?.querySelector(".field-caption") || null;
        const trigger = document.createElement("button");
        trigger.type = "button";
        trigger.className = "button text-button bulk-open";
        trigger.textContent = "Bulk prompts";
        trigger.title = "Paste an LLM message and queue every code-block prompt in it";
        trigger.addEventListener("click", () => open());
        if (caption) caption.append(trigger); else promptInput.after(trigger);
    }

    window.BulkPrompts = { parse, attach, sleep, plan };
})();

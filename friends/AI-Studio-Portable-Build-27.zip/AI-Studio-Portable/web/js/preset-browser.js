/* Preset browser and bulk preset manager for AI Studio Portable. */
(() => {
    "use strict";
    const PER_CHARACTER_KEY = "aistudio-bulk-per-character";

    window.StudioPresetBrowser = {
        requestName(defaultName = "") {
            return new Promise(resolve => {
                const launcher = document.activeElement;
                const dialog = document.createElement('dialog');
                dialog.className = 'prompt-dialog preset-name-dialog';
                dialog.setAttribute('aria-labelledby', 'preset-name-heading');
                dialog.innerHTML = `<form class="prompt-dialog-content">
                    <div class="prompt-dialog-heading"><h2 id="preset-name-heading">Save preset</h2></div>
                    <label for="preset-name-input">Preset name</label>
                    <input id="preset-name-input" type="text" required maxlength="80" autocomplete="off" autofocus>
                    <div class="prompt-dialog-actions">
                        <button class="button" type="button">Cancel</button>
                        <button class="button primary" type="submit">Save preset</button>
                    </div>
                </form>`;
                const input = dialog.querySelector('input');
                input.value = defaultName.slice(0, 80);
                let name = null;
                dialog.querySelector('form').addEventListener('submit', event => {
                    event.preventDefault();
                    if (!input.value.trim()) {
                        input.setCustomValidity('Enter a preset name.');
                        input.reportValidity();
                        return;
                    }
                    name = input.value.trim();
                    dialog.close();
                });
                input.addEventListener('input', () => input.setCustomValidity(''));
                dialog.querySelector('button[type="button"]').addEventListener('click', () => dialog.close());
                dialog.addEventListener('close', () => {
                    dialog.remove();
                    launcher?.focus({ preventScroll: true });
                    resolve(name);
                }, { once: true });
                document.body.append(dialog);
                dialog.showModal();
                input.select();
            });
        },
        create({ storageKey, renderDetail, apply, modelLabel, editPresets, renameCategory, queue }) {
            const dialog = document.querySelector("#preset-library-dialog");
            const list = document.querySelector("#preset-library-grid");
            const detail = document.querySelector("#preset-library-preview");
            const categories = document.querySelector("#preset-category-tabs");
            const collectionSelect = document.querySelector("#preset-collection-select");
            const search = document.querySelector("#preset-search");
            const sort = document.querySelector("#preset-sort");
            const count = document.querySelector("#preset-results-count");
            const randomMatch = dialog?.querySelector("#preset-random-match");
            let saved = {};
            try { saved = JSON.parse(localStorage.getItem(storageKey) || "{}") || {}; } catch { /* A damaged preference must not hide presets. */ }
            const state = {
                collection: typeof saved.collection === "string" ? saved.collection : "all",
                query: typeof saved.query === "string" ? saved.query : "",
                sort: saved.sort === "updated" ? "updated" : "name",
                selected: typeof saved.selected === "string" ? saved.selected : null,
                favorites: Array.isArray(saved.favorites) ? saved.favorites.filter(id => typeof id === "string") : [],
                recent: Array.isArray(saved.recent) ? saved.recent.filter(id => typeof id === "string") : [],
                scroll: Number.isFinite(saved.scroll) ? saved.scroll : 0,
                characterLocked: saved.characterLocked === true,
            };
            let all = [], activeId = null, filtered = [];
            const checked = new Set();
            let selectionBar, selectAll, selectionCount, editSelected, clearSelected, renameButton, queueSelected;
            let queueRunning = false, queueStop = false;
            let queueDone = new Set(), queueSignature = "";
            let perCharacterLabel, perCharacterBox, castSeen = '';
            const queueKey = (character, preset) => (character ? character.id : "") + "\u0000" + preset.id;
            const queueSelectionEdited = () => { queueDone = new Set(); };
            if (editPresets) {
                selectionBar = el('div', 'preset-selection-bar');
                selectAll = document.createElement('input');
                selectAll.type = 'checkbox';
                selectAll.id = 'preset-select-all';
                selectAll.setAttribute('aria-label', 'Select every preset in the current view');
                selectAll.addEventListener('change', () => {
                    filtered.forEach(p => selectAll.checked ? checked.add(p.id) : checked.delete(p.id));
                    queueSelectionEdited();
                    syncSelection();
                });
                const countLine = el('div', 'preset-results-select');
                count.replaceWith(countLine);
                countLine.append(selectAll, count);
                selectionCount = el('span', 'preset-selection-count');
                selectionCount.setAttribute('role', 'status');
                editSelected = button('button', 'Edit selected', null, () => editPresets(all.filter(p => checked.has(p.id))));
                editSelected.id = 'preset-edit-selected';
                clearSelected = button('button', 'Clear', 'Clear selection', () => { checked.clear(); queueSelectionEdited(); syncSelection(); });
                renameButton = button('button', 'Rename category', null, async () => {
                    const category = state.collection.slice(9);
                    const name = await renameCategory(category);
                    if (name) { state.collection = `category:${name}`; resetView(); }
                });
                renameButton.id = 'preset-rename-category';
                selectionBar.append(selectionCount);
                if (queue) {
                    queueSelected = button('button primary', 'Queue selected', null, runQueue);
                    queueSelected.id = 'preset-queue-selected';
                    selectionBar.append(queueSelected);
                    if (queue.characters) {
                        perCharacterLabel = el('label', 'per-character-toggle');
                        perCharacterLabel.hidden = true;
                        perCharacterBox = document.createElement('input');
                        perCharacterBox.type = 'checkbox';
                        perCharacterBox.className = 'preset-per-character';
                        try { perCharacterBox.checked = localStorage.getItem(PER_CHARACTER_KEY) === '1'; } catch { /* per-device convenience only */ }
                        perCharacterBox.addEventListener('change', () => {
                            try { localStorage.setItem(PER_CHARACTER_KEY, perCharacterBox.checked ? '1' : '0'); } catch { /* ignore */ }
                            syncSelection();
                        });
                        perCharacterLabel.append(perCharacterBox, el('span'));
                        selectionBar.append(perCharacterLabel);
                    }
                }
                selectionBar.append(editSelected, clearSelected, renameButton);
                dialog.querySelector('.preset-library-controls').after(selectionBar);
            }
            function castToRun() {
                if (!perCharacterLabel) return [];
                const cast = queue.characters() || [];
                perCharacterLabel.hidden = cast.length < 1;
                if (cast.length < 1) return [];
                const signature = cast.map(c => c.id).join('|');
                if (cast.fromLibrary && signature !== castSeen) perCharacterBox.checked = true;
                castSeen = signature;
                const names = cast.length > 4 ? `${cast.slice(0, 3).map(c => c.label).join(', ')} and ${cast.length - 3} more` : cast.map(c => c.label).join(', ');
                perCharacterLabel.querySelector('span').textContent = cast.fromLibrary
                    ? `Run each of the ${cast.length} ticked characters separately, one after another (${names})`
                    : `Run each selected character separately, in the order picked (${names})`;
                return perCharacterBox.checked ? cast : [];
            }
            function syncSelection() {
                if (!selectionBar) return;
                const visibleSelected = filtered.filter(p => checked.has(p.id)).length;
                selectAll.checked = filtered.length > 0 && visibleSelected === filtered.length;
                selectAll.indeterminate = visibleSelected > 0 && visibleSelected < filtered.length;
                selectAll.disabled = !filtered.length;
                selectAll.title = selectAll.checked ? 'Uncheck every preset in the current view.' : 'Check every preset in the current view. Search and collection filters apply.';
                selectionCount.textContent = `${checked.size} selected`;
                editSelected.disabled = clearSelected.disabled = checked.size === 0 || queueRunning;
                if (queueSelected) {
                    queueSelected.disabled = !queueRunning && checked.size === 0;
                    const cast = castToRun();
                    queueSelected.textContent = queueRunning ? 'Stop'
                        : checked.size && cast.length ? `Queue ${checked.size} × ${cast.length} characters`
                        : checked.size ? `Queue ${checked.size} selected` : 'Queue selected';
                    queueSelected.title = cast.length
                        ? 'Queue every selected preset once per selected character, finishing one character before starting the next.'
                        : state.characterLocked
                        ? 'Queue every selected preset with its own saved settings, keeping your locked characters.'
                        : 'Queue every selected preset with its own saved settings, including its own characters.';
                }
                const categoryHasCustom = state.collection.startsWith('category:')
                    && all.some(p => p.isCustom && (p.category || 'General') === state.collection.slice(9));
                renameButton.hidden = !renameCategory || !categoryHasCustom;
                list.querySelectorAll('.preset-row-checkbox').forEach(input => {
                    input.checked = checked.has(input.closest('[data-preset-id]').dataset.presetId);
                });
            }
            async function runQueue() {
                const status = dialog.querySelector('#preset-library-status');
                const say = text => { if (status) status.textContent = text; };
                if (queueRunning) { queueStop = true; say('Stopping after the current preset…'); return; }
                const todo = all.filter(p => checked.has(p.id));
                if (!todo.length) return;
                const blocked = queue.canStart();
                if (blocked) { say(blocked); return; }
                const cast = castToRun();
                const signature = cast.map(c => c.id).join('|');
                if (signature !== queueSignature) { queueDone = new Set(); queueSignature = signature; }
                const passes = cast.length ? cast : [null];
                const jobs = [];
                for (const character of passes) for (const preset of todo) if (!queueDone.has(queueKey(character, preset))) jobs.push({ preset, character });
                if (!jobs.length) return;
                if (cast.length && jobs.length > 60 && !window.confirm(`This queues ${jobs.length} jobs (${cast.length} characters). Continue?`)) return;
                queueRunning = true; queueStop = false;
                syncSelection();
                let done = 0, failure = '';
                const skipped = new Set();
                try {
                    for (const { preset, character } of jobs) {
                        if (queueStop) break;
                        say(`Queued ${done} of ${jobs.length}${character ? ` (${character.label})` : ''}…`);
                        const built = queue.job(preset, character);
                        if (built.error) { skipped.add(built.error); queueDone.add(queueKey(character, preset)); continue; }
                        const result = await queue.submit(built.job);
                        if (result?.error) { failure = result.error; break; }
                        done += 1;
                        queueDone.add(queueKey(character, preset));
                        state.recent = [preset.id, ...state.recent.filter(id => id !== preset.id)].slice(0, 30);
                    }
                } catch (error) {
                    failure = error?.message || 'Could not queue the selected presets.';
                } finally {
                    for (const preset of todo) if (passes.every(character => queueDone.has(queueKey(character, preset)))) checked.delete(preset.id);
                    if (!checked.size) queueDone = new Set();
                    queueRunning = false;
                    try { queue.finish(); } catch { /* cosmetic only */ }
                    save();
                    dialog.dispatchEvent(new Event('preset-shortcuts-change'));
                    syncSelection();
                }
                const noun = `${cast.length ? 'job' : 'preset'}${done === 1 ? '' : 's'}`;
                const skippedNote = skipped.size ? ` Skipped ${skipped.size}: ${[...skipped][0]}` : '';
                say(failure ? `Queued ${done} of ${jobs.length}. Stopped: ${failure}${skippedNote}`
                    : queueStop ? `Stopped. Queued ${done} ${noun}.${skippedNote}`
                    : `Queued ${done} ${noun}.${skippedNote}`);
            }
            const clearSearch = button('preset-search-clear', '×', 'Clear preset search', () => {
                search.value = '';
                state.query = '';
                resetView();
                search.focus();
            });
            search.parentElement.append(clearSearch);
            search.value = state.query;
            sort.value = state.sort;
            const save = () => { try { localStorage.setItem(storageKey, JSON.stringify(state)); } catch { /* Browsing still works without storage. */ } };
            const lockButtons = () => Array.from(document.querySelectorAll('[data-character-lock]'));
            function syncCharacterLock() {
                lockButtons().forEach(btn => {
                    btn.textContent = state.characterLocked ? '🔒' : '🔓';
                    btn.setAttribute('aria-pressed', String(state.characterLocked));
                    btn.setAttribute('aria-label', 'Keep character when loading presets');
                    btn.title = state.characterLocked
                        ? 'Character locked: presets keep your selected characters, strengths, and versions. An incompatible preset keeps your current model.'
                        : 'Lock character: keep your selected characters when loading presets.';
                });
            }
            document.addEventListener('click', event => {
                const lockBtn = event.target.closest?.('[data-character-lock]');
                if (!lockBtn) return;
                state.characterLocked = !state.characterLocked;
                syncCharacterLock();
                syncSelection();
                save();
            });
            syncCharacterLock();
            function el(tag, className, text) {
                const node = document.createElement(tag);
                if (className) node.className = className;
                if (text !== undefined) node.textContent = text;
                return node;
            }
            function button(className, text, label, action) {
                const node = el("button", className, text);
                node.type = "button";
                if (label) { node.setAttribute("aria-label", label); node.title = label; }
                node.addEventListener("click", action);
                return node;
            }
            function showDetail(preset, mobile = false) {
                mobile = mobile && window.matchMedia('(max-width: 900px)').matches;
                state.selected = preset.id;
                save();
                detail.replaceChildren();
                const back = button("preset-preview-back", "← Back to presets", null, () => {
                    dialog.classList.remove("preset-show-detail");
                    list.querySelector(`[data-preset-id="${CSS.escape(preset.id)}"] .preset-row-select`)?.focus();
                });
                detail.append(back);
                renderDetail(preset, detail);
                if (mobile) dialog.classList.add("preset-show-detail");
                list.querySelectorAll(".preset-row-select").forEach(row => {
                    row.setAttribute("aria-pressed", String(row.parentElement.dataset.presetId === preset.id));
                });
                if (mobile) back.focus({ preventScroll: true });
            }
            function resetView() {
                state.scroll = 0;
                dialog.classList.remove("preset-show-detail");
                save();
                render();
            }
            function renderCollections() {
                const counts = new Map();
                all.forEach(p => { const category = p.category || "General"; counts.set(category, (counts.get(category) || 0) + 1); });
                const collections = [
                    ["all", "All presets", all.length],
                    ["favorites", "Favorites", all.filter(p => state.favorites.includes(p.id)).length],
                    ["recent", "Recently used", all.filter(p => state.recent.includes(p.id)).length],
                    ...Array.from(counts).sort(([a], [b]) => a.localeCompare(b)).map(([name, total]) => [`category:${name}`, name, total]),
                ];
                if (!collections.some(([id]) => id === state.collection)) state.collection = "all";
                categories.replaceChildren();
                collectionSelect.replaceChildren();
                collections.forEach(([id, name, total], index) => {
                    if (index === 3) categories.append(el("p", "preset-collections-label", "Collections"));
                    const tab = button("preset-tab-btn", null, null, () => { state.collection = id; resetView(); });
                    tab.dataset.collectionId = id;
                    tab.dataset.active = String(state.collection === id);
                    tab.setAttribute("aria-pressed", String(state.collection === id));
                    tab.append(el("span", "", name), el("span", "preset-tab-count", String(total)));
                    categories.append(tab);
                    const option = el("option", "", `${name} (${total})`);
                    option.value = id;
                    collectionSelect.append(option);
                });
                collectionSelect.value = state.collection;
            }
            function render() {
                const focused = document.activeElement;
                const focusedCollection = focused?.dataset.collectionId;
                const focusedId = focused?.closest(".preset-card")?.dataset.presetId;
                const focusedClass = focused?.classList.contains("preset-favorite-btn") ? ".preset-favorite-btn" : ".preset-row-select";
                clearSearch.hidden = !state.query;
                renderCollections();
                const query = state.query.trim().toLowerCase();
                const words = query.split(/\s+/).filter(Boolean);
                filtered = all.filter(p => {
                    if (state.collection === "favorites" && !state.favorites.includes(p.id)) return false;
                    if (state.collection === "recent" && !state.recent.includes(p.id)) return false;
                    if (state.collection.startsWith("category:") && (p.category || "General") !== state.collection.slice(9)) return false;
                    const text = [p.title, p.category, p.prompt, p.negativePrompt, p.architecture, p.model, modelLabel(p), ...(p.tags || [])].join(" ").toLowerCase();
                    return words.every(word => text.includes(word));
                });
                const score = p => {
                    const title = (p.title || "").toLowerCase();
                    return query && title === query ? 3 : query && title.startsWith(query) ? 2 : query && words.every(word => title.includes(word)) ? 1 : 0;
                };
                const timestamp = p => typeof p.updatedAt === "number" ? p.updatedAt : Date.parse(p.updatedAt || p.createdAt || "") || 0;
                filtered.sort((a, b) => score(b) - score(a)
                    || (state.collection === "recent" ? state.recent.indexOf(a.id) - state.recent.indexOf(b.id) : 0)
                    || (state.sort === "updated" ? timestamp(b) - timestamp(a) : 0)
                    || (a.title || "").localeCompare(b.title || "", undefined, { sensitivity: "base", numeric: true }));
                count.textContent = `${filtered.length} of ${all.length} presets`;
                if (randomMatch) randomMatch.disabled = filtered.length === 0;
                list.replaceChildren();
                filtered.forEach(p => {
                    const row = el("div", "preset-card preset-row");
                    row.dataset.presetId = p.id;
                    row.dataset.active = String(p.id === activeId);
                    const favorite = state.favorites.includes(p.id);
                    const star = button("preset-favorite-btn", favorite ? "★" : "☆", `${favorite ? "Unfavorite" : "Favorite"} ${p.title}`, () => {
                        state.favorites = favorite ? state.favorites.filter(id => id !== p.id) : [...state.favorites, p.id];
                        save(); render();
                        dialog.dispatchEvent(new Event("preset-shortcuts-change"));
                    });
                    star.setAttribute("aria-pressed", String(favorite));
                    const select = button("preset-row-select", null, `Preview ${p.title}`, () => showDetail(p, true));
                    select.setAttribute("aria-pressed", String(state.selected === p.id));
                    const meta = el('span', 'preset-row-meta');
                    meta.append(el('span', 'preset-row-category', `${p.category || 'General'} · `), el('span', 'preset-row-model', modelLabel(p) || p.architecture || 'Preset'));
                    select.append(el("span", "preset-row-title", p.title || "Untitled preset"), meta);
                    const use = button("preset-apply-btn preset-row-use", p.id === activeId ? "Active" : "Use", `Use ${p.title}`, () => apply(p));
                    if (editPresets) {
                        row.classList.add('preset-row-checkable');
                        const checkbox = document.createElement('input');
                        checkbox.type = 'checkbox';
                        checkbox.className = 'preset-row-checkbox';
                        checkbox.setAttribute('aria-label', `Select ${p.title || 'Untitled preset'}`);
                        checkbox.addEventListener('change', () => {
                            if (checkbox.checked) checked.add(p.id); else checked.delete(p.id);
                            queueSelectionEdited();
                            syncSelection();
                        });
                        row.append(checkbox);
                    }
                    row.append(star, select, use);
                    list.append(row);
                });
                if (!filtered.length) {
                    const empty = el("div", "preset-library-empty");
                    empty.append(el("h3", "", state.collection === "favorites" ? "No favorites here yet" : state.collection === "recent" ? "No recently used presets" : "No presets found"));
                    empty.append(el("p", "", state.collection === "favorites" ? "Star presets to keep your go-to prompts together." : state.collection === "recent" ? "Presets you use will appear here." : all.length ? "Try another search or collection." : "Save your current settings to create your first preset."));
                    if (query || state.collection !== "all") empty.append(button("button", "Show all presets", null, () => { state.collection = "all"; state.query = ""; search.value = ""; resetView(); search.focus(); }));
                    list.append(empty);
                    detail.replaceChildren(el("p", "preset-preview-empty", "Select a preset to preview its prompt and settings."));
                    dialog.classList.remove("preset-show-detail");
                } else {
                    const selected = filtered.find(p => p.id === state.selected) || filtered[0];
                    showDetail(selected);
                }
                list.scrollTop = state.scroll;
                syncSelection();
                if (focusedId) {
                    const nextFocus = list.querySelector(`[data-preset-id="${CSS.escape(focusedId)}"] ${focusedClass}`)
                        || list.querySelector(".preset-row-select, .preset-library-empty button");
                    nextFocus?.focus({ preventScroll: true });
                }
                if (focusedCollection) categories.querySelector(`[data-collection-id="${CSS.escape(focusedCollection)}"]`)?.focus({ preventScroll: true });
                save();
            }
            randomMatch?.addEventListener("click", () => {
                if (!filtered.length) return;
                const alternatives = filtered.filter(p => p.id !== activeId);
                const choices = alternatives.length ? alternatives : filtered;
                apply(choices[Math.floor(Math.random() * choices.length)]);
            });
            list.addEventListener("scroll", () => { state.scroll = list.scrollTop; save(); }, { passive: true });
            list.addEventListener("keydown", event => {
                if (!event.target.classList.contains("preset-row-select")) return;
                const rows = Array.from(list.querySelectorAll(".preset-row-select"));
                const index = rows.indexOf(event.target);
                const next = event.key === "ArrowDown" ? Math.min(index + 1, rows.length - 1) : event.key === "ArrowUp" ? Math.max(index - 1, 0) : event.key === "Home" ? 0 : event.key === "End" ? rows.length - 1 : -1;
                if (next >= 0) { event.preventDefault(); showDetail(filtered[next]); rows[next].focus(); }
            });
            search.addEventListener("input", () => { state.query = search.value; resetView(); });
            search.addEventListener("keydown", event => {
                if (event.key === 'Escape' && search.value) {
                    event.preventDefault();
                    event.stopPropagation();
                    clearSearch.click();
                    return;
                }
                if ((event.key === "ArrowDown" || event.key === "Enter") && filtered.length) {
                    event.preventDefault();
                    showDetail(filtered[0], event.key === "Enter");
                    if (event.key === "ArrowDown") list.querySelector(".preset-row-select")?.focus();
                }
            });
            sort.addEventListener("change", () => { state.sort = sort.value; resetView(); });
            collectionSelect.addEventListener("change", () => { state.collection = collectionSelect.value; resetView(); });
            dialog.addEventListener("close", () => {
                dialog.classList.remove("preset-show-detail");
                save();
                const launcher = document.querySelector('#open-preset-library');
                const group = launcher?.closest('details');
                (group && !group.open ? group.querySelector('summary') : launcher)?.focus();
            });
            const toolsMenu = dialog.querySelector('.preset-library-tools');
            dialog.addEventListener('click', event => {
                if (toolsMenu?.open && !toolsMenu.contains(event.target)) toolsMenu.open = false;
            });
            dialog.addEventListener('keydown', event => {
                if (event.key === 'Escape' && toolsMenu?.open) {
                    event.preventDefault();
                    toolsMenu.open = false;
                    toolsMenu.querySelector('summary').focus();
                } else if (event.key === 'Escape' && dialog.classList.contains('preset-show-detail')) {
                    event.preventDefault();
                    dialog.querySelector('.preset-preview-back')?.click();
                }
            });
            return {
                isCharacterLocked() { return state.characterLocked; },
                syncCharacterLock,
                selectedPresets() { return all.filter(p => checked.has(p.id)); },
                resolvePreset(preset, { layers, architecture, model, catalog, presetArchitecture, force = false }) {
                    if (!state.characterLocked && !force) return preset;
                    const isCharacter = id => catalog[id]?.role === 'Character';
                    const characters = layers.filter(layer => isCharacter(layer.id)).map(layer => ({ ...layer }));
                    let incoming = preset.loras;
                    if (typeof incoming === 'string') { try { incoming = JSON.parse(incoming); } catch { incoming = []; } }
                    const source = Array.isArray(incoming) ? incoming
                        : incoming && typeof incoming === 'object' ? Object.entries(incoming).map(([id, strength]) => ({ id, strength }))
                        : layers;
                    const keepModel = characters.some(layer => catalog[layer.id]?.architecture !== presetArchitecture);
                    const targetArchitecture = keepModel ? architecture : presetArchitecture;
                    // Put the locked cast first so the eight-layer limit cannot discard it.
                    const loras = [...characters, ...source.filter(layer => !isCharacter(layer?.id) && catalog[layer?.id]?.architecture === targetArchitecture)].slice(0, 8);
                    return { ...preset, loras, ...(keepModel ? { architecture, model } : {}) };
                },
                render(presets, currentId) {
                    all = presets; activeId = currentId;
                    for (const id of checked) if (!all.some(p => p.id === id)) checked.delete(id);
                    render();
                },
                open() {
                    dialog.classList.remove("preset-show-detail");
                    if (toolsMenu) toolsMenu.open = false;
                    syncCharacterLock();
                    if (window.matchMedia('(max-width: 900px)').matches) dialog.querySelector('#preset-library-close')?.focus({ preventScroll: true });
                    else { search.focus(); search.select(); }
                    list.scrollTop = state.scroll;
                },
                record(id) { state.selected = id; state.recent = [id, ...state.recent.filter(item => item !== id)].slice(0, 30); save(); },
                shortcuts(presets) {
                    const ids = [...new Set([...state.favorites, ...state.recent])];
                    return ids.map(id => presets.find(p => p.id === id)).filter(Boolean).slice(0, 8);
                },
            };
        },
    };
})();

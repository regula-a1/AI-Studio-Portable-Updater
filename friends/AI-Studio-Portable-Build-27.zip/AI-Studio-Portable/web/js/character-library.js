/* Character Library browser, portrait manager, appearance description editor,
 * and bulk metadata organizer for AI Studio Portable. */
(() => {
    'use strict';
    const normalize = text => String(text || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
    function rank(detail, query) {
        const name = normalize(detail.label), aliases = (detail.aliases || []).map(normalize);
        if (name === query || aliases.includes(query)) return 0;
        if (name.startsWith(query) || aliases.some(alias => alias.startsWith(query))) return 1;
        if (name.includes(query) || aliases.some(alias => alias.includes(query))) return 2;
        const haystack = normalize([detail.label, ...(detail.aliases || []), ...(detail.tags || []), detail.trigger, detail.group, detail.category].join(' '));
        return query.split(' ').every(word => haystack.includes(word)) ? 3 : Infinity;
    }
    function filter(cast, options) {
        const query = normalize(options.query);
        return cast.filter(([id, detail]) => {
            if (options.tab === 'favorites' && !options.favorites.includes(id)) return false;
            if (options.tab === 'recent' && !options.recent[id]) return false;
            if (options.group && detail.group !== options.group) return false;
            if (options.category === '__none' ? detail.category : options.category && normalize(detail.category) !== normalize(options.category)) return false;
            if (options.tag && !(detail.tags || []).some(tag => normalize(tag) === normalize(options.tag))) return false;
            return !query || Number.isFinite(rank(detail, query));
        }).sort(([aid, a], [bid, b]) => {
            if (query) {
                const difference = rank(a, query) - rank(b, query);
                if (difference) return difference;
            }
            if (options.sort === 'recent' || options.tab === 'recent') {
                const difference = (options.recent[bid] || 0) - (options.recent[aid] || 0);
                if (difference) return difference;
            }
            if (options.sort === 'newest') {
                const difference = (Date.parse(b.createdAt) || 0) - (Date.parse(a.createdAt) || 0);
                if (difference) return difference;
            }
            return a.label.localeCompare(b.label, undefined, { sensitivity: 'base', numeric: true }) || aid.localeCompare(bid);
        });
    }
    const element = (tag, className, text) => {
        const node = document.createElement(tag);
        if (className) node.className = className;
        if (text !== undefined) node.textContent = text;
        return node;
    };
    function button(text, action, className = 'button') {
        const node = element('button', className, text);
        node.type = 'button'; node.addEventListener('click', action);
        return node;
    }
    function create(config) {
        const fieldset = document.querySelector('.character-fieldset');
        if (!fieldset || !window.StudioPortraitVault) return null;
        const grid = fieldset.querySelector('#character-grid');
        const search = fieldset.querySelector('#character-search');
        const picks = fieldset.querySelector('#character-picks');
        const selectedDetails = element('details', 'character-library-selected');
        const selectedSummary = element('summary', '', 'Selected characters');
        picks.before(selectedDetails); selectedDetails.append(selectedSummary, picks); selectedDetails.open = true;
        const owner = 'local';
        const prefKey = `aistudio-character-library:${owner}:v1`;
        let preferences = { favorites: [], recent: {}, sort: 'name', tab: 'all', group: '' };
        try {
            const saved = JSON.parse(localStorage.getItem(prefKey));
            if (saved && Array.isArray(saved.favorites) && typeof saved.recent === 'object' && saved.recent) preferences = { ...preferences, ...saved };
        } catch { /* browsing preferences are optional */ }
        if (!['all', 'recent', 'favorites'].includes(preferences.tab)) preferences.tab = 'all';
        if (!['name', 'recent', 'newest'].includes(preferences.sort)) preferences.sort = 'name';
        if (!['', 'IRL', 'OC', 'Commission', 'Celeb'].includes(preferences.group)) preferences.group = '';
        let tab = preferences.tab, limit = 24, full = false, stack = false, query = '', group = preferences.group, category = '', tag = '';
        const checked = new Set();
        let shownIds = [];
        let cast = [], chosen = [], detailId = null, vaultBusy = false;
        const save = () => { try { localStorage.setItem(prefKey, JSON.stringify(preferences)); } catch { /* memory only */ } };
        const announcement = element('p', 'character-results-note');
        announcement.setAttribute('role', 'status'); announcement.setAttribute('aria-live', 'polite');
        search.hidden = false;
        search.placeholder = 'Search names, aliases or tags';
        const tabs = element('div', 'character-tabs'); tabs.setAttribute('aria-label', 'Character views');
        const tabButtons = new Map();
        for (const [id, label] of [['all', 'All'], ['favorites', 'Favorites'], ['recent', 'Recent']]) {
            const node = button(label, () => { tab = id; preferences.tab = id; limit = full ? 48 : 24; save(); render(); }, 'character-tab');
            node.dataset.view = id; tabButtons.set(id, node); tabs.append(node);
        }
        const filters = element('div', 'character-filters');
        const groupTabs = element('div', 'character-group-tabs');
        groupTabs.setAttribute('role', 'group'); groupTabs.setAttribute('aria-label', 'Character type');
        groupTabs.id = 'character-type-filter';
        const groupButtons = new Map();
        for (const [id, label] of [['', 'All'], ['IRL', 'IRL'], ['OC', 'OCs'], ['Commission', 'Commissions'], ['Celeb', 'Celebs / Models']]) {
            const node = button(label, () => { group = id; preferences.group = id; limit = full ? 48 : 24; save(); render(); }, 'character-group-tab');
            node.dataset.group = id; groupButtons.set(id, node); groupTabs.append(node);
        }
        function select(id, label, options) {
            const wrap = element('label', 'character-filter');
            const control = element('select'); control.id = id;
            wrap.append(element('span', '', label), control); filters.append(wrap);
            options.forEach(([value, labelText]) => control.append(new Option(labelText, value)));
            return control;
        }
        const sortSelect = select('character-sort', 'Sort', [['name', 'Name A–Z'], ['recent', 'Recently selected'], ['newest', 'Newest added']]);
        sortSelect.value = preferences.sort;
        const categorySelect = select('character-category-filter', 'Category', [['', 'All categories']]);
        const tagSelect = select('character-tag-filter', 'Tag', [['', 'All tags']]);
        categorySelect.addEventListener('change', () => { category = categorySelect.value; limit = full ? 48 : 24; render(); });
        tagSelect.addEventListener('change', () => { tag = tagSelect.value; limit = full ? 48 : 24; render(); });
        const optionsRow = element('div', 'character-options');
        const stackLabel = element('label', 'character-stack');
        const stackInput = element('input'); stackInput.type = 'checkbox'; stackInput.id = 'character-multi-select';
        stackInput.addEventListener('change', () => { stack = stackInput.checked; render(); });
        stackLabel.append(stackInput, document.createTextNode(' Add alongside selected'));
        const actionGroup = element('div', 'character-options-actions');
        const newCharBtn = button('+ New character', () => config.openManager?.(), 'button');
        newCharBtn.id = 'character-new-btn';
        const browse = button('Browse library', () => openLibrary(), 'button character-browse'); browse.id = 'character-browse';
        if (config.openManager) actionGroup.append(newCharBtn);
        actionGroup.append(browse);
        optionsRow.append(stackLabel, actionGroup);
        const toolbar = element('div', 'character-library-toolbar');
        const selectionBar = element('div', 'character-selection-bar');
        const selectAll = element('input'); selectAll.type = 'checkbox'; selectAll.id = 'character-select-all';
        selectAll.setAttribute('aria-label', 'Select every character in the current view');
        const pushCast = () => config.setBulkCast?.([...shownIds.filter(id => checked.has(id)), ...[...checked].filter(id => !shownIds.includes(id))]);
        selectAll.addEventListener('change', () => {
            shownIds.forEach(id => selectAll.checked ? checked.add(id) : checked.delete(id));
            pushCast();
            syncSelection();
        });
        const selectionCount = element('span', 'character-selection-count'); selectionCount.setAttribute('role', 'status');
        const editSelected = button('Edit selected', () => openBulk([...checked]), 'button primary'); editSelected.id = 'character-edit-selected';
        const clearSelected = button('Clear', () => { checked.clear(); pushCast(); syncSelection(); }); clearSelected.id = 'character-clear-selected';
        const castHint = element('p', 'character-selection-hint', 'Ticked characters are queued one after another by Bulk prompts and Queue selected, each with every prompt before the next.');
        selectionBar.append(element('label', 'character-select-all', ''), selectionCount, editSelected, clearSelected, castHint);
        selectionBar.firstChild.append(selectAll, document.createTextNode(' Select all in view'));
        toolbar.append(tabs, search, groupTabs, filters, optionsRow, announcement, selectionBar);
        function syncSelection() {
            const inView = shownIds.filter(id => checked.has(id)).length;
            selectAll.checked = shownIds.length > 0 && inView === shownIds.length;
            selectAll.indeterminate = inView > 0 && inView < shownIds.length;
            selectAll.disabled = !shownIds.length;
            selectionCount.textContent = `${checked.size} selected`;
            editSelected.disabled = clearSelected.disabled = checked.size === 0;
            castHint.hidden = checked.size === 0;
            grid.querySelectorAll('.character-select').forEach(input => { input.checked = checked.has(input.closest('[data-character-id]').dataset.characterId); });
        }
        grid.before(toolbar);
        const more = button('Show more', () => { limit += full ? 48 : 24; render(); }); more.id = 'character-show-more'; grid.after(more);
        const libraryDialog = element('dialog', 'character-library-dialog'); libraryDialog.id = 'character-library-dialog';
        libraryDialog.setAttribute('aria-labelledby', 'character-library-title');
        const libraryHead = element('div', 'character-dialog-heading');
        const heading = element('h2', '', 'Character library'); heading.id = 'character-library-title';
        const libraryHeadActions = element('div', 'character-dialog-head-actions');
        if (config.openManager) libraryHeadActions.append(button('+ New character', () => config.openManager?.(), 'button primary'));
        libraryHeadActions.append(button('Close', () => libraryDialog.close()));
        libraryHead.append(heading, libraryHeadActions);
        const libraryBody = element('div', 'character-library-body');
        libraryDialog.append(libraryHead, libraryBody); config.form.append(libraryDialog);
        let returnFocus;
        function openLibrary() {
            if (libraryDialog.open) return;
            returnFocus = document.activeElement;
            full = true; limit = 48; browse.hidden = true; selectedDetails.open = false;
            checked.clear(); (config.getBulkCast?.() || []).forEach(id => checked.add(id));
            libraryBody.append(fieldset); libraryDialog.showModal(); render(); search.focus();
        }
        const placeholder = document.createComment('Character picker location'); fieldset.before(placeholder);
        libraryDialog.addEventListener('close', () => {
            placeholder.after(fieldset); full = false; limit = 24; browse.hidden = false; selectedDetails.open = true; render();
            const settings = fieldset.closest('details'); if (settings) settings.open = true;
            returnFocus?.focus();
        });
        libraryDialog.addEventListener('click', event => { if (event.target === libraryDialog) libraryDialog.close(); });
        libraryDialog.addEventListener('keydown', event => { if (event.key === 'Escape') event.stopPropagation(); });

        const details = element('dialog', 'character-detail-dialog'); details.id = 'character-detail-dialog';
        details.setAttribute('aria-labelledby', 'character-detail-title');
        const detailsHead = element('div', 'character-dialog-heading');
        const detailsTitle = element('h2'); detailsTitle.id = 'character-detail-title';
        detailsHead.append(detailsTitle, button('Close', () => details.close()));
        const detailsBody = element('div', 'character-detail-body');
        const detailPreview = element('div', 'character-detail-preview');
        const description = element('p', 'setting-note');
        const metadata = element('p', 'setting-note');
        const use = button('Use character', () => { choose(detailId); details.close(); }, 'button primary'); use.id = 'character-detail-use';
        const favorite = button('Favorite', () => { toggleFavorite(detailId); updateDetail(); }); favorite.id = 'character-detail-favorite';
        const editMeta = button('Tags & category', () => openBulk([detailId])); editMeta.id = 'character-detail-meta';
        const editConfig = button('Edit LoRA & settings', () => { const id = detailId; details.close(); config.openManager?.(id); });
        editConfig.id = 'character-detail-manage';
        const detailActions = element('div', 'character-detail-actions');
        detailActions.append(use, favorite, editMeta);
        if (config.openManager) detailActions.append(editConfig);
        const photoInput = element('input'); photoInput.type = 'file'; photoInput.accept = 'image/jpeg,image/png,image/webp'; photoInput.id = 'character-portrait-file'; photoInput.hidden = true;
        const upload = button('Upload portrait', () => photoInput.click(), 'button primary'); upload.id = 'character-portrait-upload';
        const remove = button('Remove portrait', () => run(async () => { await vault.remove(detailId); notify('Portrait removed.'); })); remove.id = 'character-portrait-remove';
        const vaultStatus = element('p', 'character-vault-status'); vaultStatus.id = 'character-vault-status'; vaultStatus.setAttribute('role', 'status');
        const privacy = element('section', 'character-vault');
        const vaultActions = element('div', 'character-vault-actions'); vaultActions.append(upload, remove, photoInput);
        privacy.append(element('h3', '', 'Portrait'), vaultActions, element('p', 'setting-note',
            'JPEG, PNG or WebP, up to 12 MB. Center-cropped to a 256 × 256 square and stored locally in this studio.'), vaultStatus);
        const appearance = element('section', 'character-appearance');
        const appearanceText = element('textarea', 'character-appearance-text'); appearanceText.id = 'character-appearance-text';
        appearanceText.rows = 6; appearanceText.setAttribute('aria-label', 'Appearance description');
        appearanceText.placeholder = 'e.g. A tall woman in her early 30s with shoulder-length auburn waves, hazel eyes, subtle freckles, silver hoop earrings, and tailored linen blazer.';
        const appearanceSave = button('Save description', () => saveAppearance(appearanceText.value), 'button primary'); appearanceSave.id = 'character-appearance-save';
        const appearanceClear = button('Clear', () => { appearanceText.value = ''; saveAppearance(''); }); appearanceClear.id = 'character-appearance-clear';
        const appearanceStatus = element('p', 'character-vault-status'); appearanceStatus.id = 'character-appearance-status'; appearanceStatus.setAttribute('role', 'status');
        const appearanceActions = element('div', 'character-vault-actions'); appearanceActions.append(appearanceSave, appearanceClear);
        appearance.append(element('h3', '', 'Appearance description'), element('p', 'setting-note',
            'Added to the prompt right after this character’s trigger word whenever appearance descriptions are enabled, so you never have to retype recurring physical details.'),
            appearanceText, appearanceActions, appearanceStatus);
        detailsBody.append(detailPreview, description, metadata, detailActions, appearance, privacy);
        details.append(detailsHead, detailsBody); config.form.append(details);
        details.addEventListener('keydown', event => { if (event.key === 'Escape') event.stopPropagation(); });
        details.addEventListener('click', event => { if (event.target === details) details.close(); });
        const vault = window.StudioPortraitVault.create(owner, () => { render(); if (details.open) updateDetail(); });
        function notify(message) { vaultStatus.textContent = message; }
        const descriptions = window.StudioCharacterDescriptions?.create(owner, () => {
            syncAppearanceControls(); config.onDescriptionsChanged?.();
        });
        function syncAppearanceControls() {
            const locked = !descriptions?.isUnlocked();
            appearanceText.disabled = appearanceSave.disabled = appearanceClear.disabled = !descriptions || locked;
            appearance.hidden = !descriptions;
            if (detailId && details.open && document.activeElement !== appearanceText) appearanceText.value = descriptions?.get(detailId) || '';
            if (locked && descriptions) appearanceStatus.textContent = 'Unlock Studio to view or edit descriptions.';
        }
        async function saveAppearance(value) {
            if (!descriptions) return;
            appearanceSave.disabled = appearanceClear.disabled = true; appearanceStatus.textContent = 'Saving…';
            try {
                await descriptions.set(detailId, value);
                appearanceText.value = descriptions.get(detailId);
                appearanceStatus.textContent = appearanceText.value ? 'Description saved. It will be added to this character’s prompts.' : 'Description cleared.';
            } catch (error) { appearanceStatus.textContent = error.message || 'Could not save the description.'; }
            finally { syncAppearanceControls(); }
        }
        async function run(action) {
            if (vaultBusy) return;
            vaultBusy = true; upload.disabled = remove.disabled = true; notify('Working…');
            try { await action(); } catch (error) { notify(error.message || 'Portrait operation failed.'); }
            finally { vaultBusy = false; upload.disabled = remove.disabled = false; }
        }
        photoInput.addEventListener('change', () => {
            const file = photoInput.files[0], id = detailId; photoInput.value = '';
            if (file) run(async () => { await vault.put(id, file); notify('Portrait saved.'); });
        });

        const meta = window.StudioCharacterMeta?.create(owner, () => {
            render(); if (details.open) updateDetail(); if (bulk.open) bulkStatus.textContent = '';
            config.onMetaChanged?.();
        });
        function withMeta(id, detail) {
            const mine = meta?.get(id);
            if (!mine || (!mine.tags.length && !mine.category && !mine.group)) return detail;
            const mergedTags = [...new Set([...(detail.tags || []), ...mine.tags])];
            return { ...detail, group: mine.group || detail.group, category: mine.category || detail.category, tags: mergedTags };
        }
        const groupLabel = value => ({ OC: 'Original', Commission: 'Commission', Celeb: 'Celeb / Model' })[value] || value || '';

        const bulk = element('dialog', 'character-bulk-dialog'); bulk.id = 'character-bulk-dialog';
        bulk.setAttribute('aria-labelledby', 'character-bulk-title');
        const bulkTitle = element('h2'); bulkTitle.id = 'character-bulk-title';
        const bulkHead = element('div', 'character-dialog-heading'); bulkHead.append(bulkTitle, button('Close', () => bulk.close()));
        const bulkBody = element('div', 'character-detail-body');
        const bulkNote = element('p', 'setting-note');
        const field = (label, control, hint) => {
            const wrap = element('label', 'character-bulk-field'); wrap.append(element('span', '', label), control);
            if (hint) wrap.append(element('small', '', hint));
            return wrap;
        };
        const bulkGroup = element('select'); bulkGroup.id = 'character-bulk-group';
        const bulkCategory = element('input'); bulkCategory.type = 'text'; bulkCategory.id = 'character-bulk-category';
        bulkCategory.maxLength = 40; bulkCategory.setAttribute('list', 'character-bulk-categories'); bulkCategory.autocomplete = 'off';
        const bulkAdd = element('input'); bulkAdd.type = 'text'; bulkAdd.id = 'character-bulk-add-tags';
        bulkAdd.setAttribute('list', 'character-bulk-tag-options'); bulkAdd.autocomplete = 'off'; bulkAdd.placeholder = 'e.g. portrait, favorite, studio';
        const categoryList = element('datalist'); categoryList.id = 'character-bulk-categories';
        const tagList = element('datalist'); tagList.id = 'character-bulk-tag-options';
        const bulkRemove = element('div', 'character-bulk-chips'); bulkRemove.id = 'character-bulk-remove-tags';
        const removeField = element('fieldset', 'character-bulk-remove');
        removeField.append(element('legend', '', 'Remove tags'), bulkRemove);
        const bulkStatus = element('p', 'character-vault-status'); bulkStatus.id = 'character-bulk-status'; bulkStatus.setAttribute('role', 'status');
        const bulkSave = button('Save', () => saveBulk(), 'button primary'); bulkSave.id = 'character-bulk-save';
        const bulkActions = element('div', 'character-detail-actions'); bulkActions.append(bulkSave, button('Cancel', () => bulk.close()));
        bulkBody.append(bulkNote,
            field('Type', bulkGroup),
            field('Category', bulkCategory, 'One category per character. Leave it alone to keep each one; clear the box to remove it.'),
            field('Add tags', bulkAdd, 'Comma separated. Added to every selected character.'),
            removeField, categoryList, tagList, bulkActions, bulkStatus);
        bulk.append(bulkHead, bulkBody); config.form.append(bulk);
        bulk.addEventListener('keydown', event => {
            if (event.key === 'Escape') event.stopPropagation();
            if (event.key === 'Enter' && event.target.tagName === 'INPUT') { event.preventDefault(); saveBulk(); }
        });
        bulk.addEventListener('click', event => { if (event.target === bulk) bulk.close(); });
        let bulkIds = [], categoryTouched = false;
        bulkCategory.addEventListener('input', () => { categoryTouched = true; });
        function openBulk(ids) {
            ids = ids.filter(id => cast.some(([castId]) => castId === id));
            if (!ids.length || !meta) return;
            if (!meta.isUnlocked()) { bulkNote.textContent = 'Unlock Studio to edit tags and categories.'; }
            bulkIds = ids; categoryTouched = false;
            const label = id => cast.find(([castId]) => castId === id)[1].label;
            const mine = ids.map(id => meta.get(id));
            const groups = new Set(ids.map(id => withMeta(id, cast.find(([castId]) => castId === id)[1]).group));
            const categories = new Set(mine.map(entry => entry.category));
            bulkTitle.textContent = ids.length === 1 ? `Tags & category · ${label(ids[0])}` : `Edit ${ids.length} characters`;
            bulkNote.textContent = ids.length === 1 ? 'Your own tags and category for this character.'
                : 'Only what you change applies to every selected character. Anything you leave alone stays as it is on each one.';
            bulkGroup.replaceChildren(new Option(`Keep current (${groups.size === 1 ? groupLabel([...groups][0]) || 'none' : 'mixed'})`, ''),
                ...window.StudioCharacterMeta.GROUPS.map(value => new Option(groupLabel(value), value)),
                new Option('Reset to original type', '__reset'));
            bulkCategory.value = categories.size === 1 ? [...categories][0] : '';
            bulkCategory.placeholder = categories.size === 1 ? 'No category' : 'Mixed. Unchanged unless edited';
            bulkAdd.value = '';
            const known = new Map(), counts = new Map();
            for (const [id, detail] of cast) {
                const merged = withMeta(id, detail);
                if (merged.category && !known.has('c:' + normalize(merged.category))) known.set('c:' + normalize(merged.category), merged.category);
                for (const name of merged.tags || []) if (!known.has('t:' + normalize(name))) known.set('t:' + normalize(name), name);
            }
            categoryList.replaceChildren(...[...known].filter(([key]) => key[0] === 'c').map(([, name]) => new Option(name)));
            tagList.replaceChildren(...[...known].filter(([key]) => key[0] === 't').map(([, name]) => new Option(name)));
            mine.forEach(entry => entry.tags.forEach(name => counts.set(name.toLowerCase(), { name, count: (counts.get(name.toLowerCase())?.count || 0) + 1 })));
            bulkRemove.replaceChildren(...[...counts.values()].sort((a, b) => a.name.localeCompare(b.name)).map(({ name, count }) => {
                const chip = element('button', 'character-bulk-chip', ids.length > 1 ? `${name} · ${count}` : name);
                chip.type = 'button'; chip.dataset.tag = name; chip.setAttribute('aria-pressed', 'false');
                chip.title = 'Click to remove this tag when you save';
                chip.addEventListener('click', () => chip.setAttribute('aria-pressed', String(chip.getAttribute('aria-pressed') !== 'true')));
                return chip;
            }));
            removeField.hidden = !counts.size;
            bulkStatus.textContent = '';
            bulkSave.disabled = !meta.isUnlocked();
            if (!bulk.open) bulk.showModal();
        }
        function saveBulk() {
            const patch = {};
            if (categoryTouched) patch.category = bulkCategory.value;
            if (bulkGroup.value) patch.group = bulkGroup.value === '__reset' ? '' : bulkGroup.value;
            const added = window.StudioCharacterMeta.parseTags(bulkAdd.value);
            if (added.length) patch.addTags = added;
            const removed = [...bulkRemove.querySelectorAll('[aria-pressed="true"]')].map(chip => chip.dataset.tag);
            if (removed.length) patch.removeTags = removed;
            if (!Object.keys(patch).length) { bulkStatus.textContent = 'Nothing to change yet.'; return; }
            try { meta.update(bulkIds, patch); } catch (error) { bulkStatus.textContent = error.message; return; }
            const count = bulkIds.length;
            bulk.close();
            selectionCount.textContent = `Updated ${count} character${count === 1 ? '' : 's'}`;
        }

        const imageObserver = 'IntersectionObserver' in window ? new IntersectionObserver(entries => {
            entries.forEach(entry => { if (entry.isIntersecting) { imageObserver.unobserve(entry.target); hydrate(entry.target); } });
        }, { rootMargin: '100px' }) : null;
        let renderRevision = 0;
        function avatar(id, detail) {
            const node = element('span', 'character-avatar'); node.setAttribute('aria-hidden', 'true'); node.dataset.portraitId = id;
            const words = (detail.label || id).split(/\s+/).filter(Boolean);
            node.textContent = (words.length > 1 ? words[0][0] + words.at(-1)[0] : (detail.label || id).slice(0, 2)).toUpperCase();
            if (imageObserver) imageObserver.observe(node); else setTimeout(() => hydrate(node), 0);
            return node;
        }
        async function hydrate(node) {
            const revision = renderRevision;
            try {
                const url = await vault.url(node.dataset.portraitId);
                if (!url || !node.isConnected || revision !== renderRevision) return;
                const img = element('img'); img.src = url; img.alt = ''; img.decoding = 'async';
                node.replaceChildren(img);
            } catch { /* unreadable portraits retain initials */ }
        }
        function toggleFavorite(id) {
            preferences.favorites = preferences.favorites.includes(id) ? preferences.favorites.filter(value => value !== id) : [...preferences.favorites, id];
            save(); render();
        }
        function choose(id, modified = false) {
            if (!chosen.some(layer => layer.id === id)) { preferences.recent[id] = Date.now(); save(); }
            config.pick(id, stack || modified);
        }
        function updateDetail() {
            const base = config.getCatalog().find(([id]) => id === detailId)?.[1];
            if (!base) return;
            const detail = withMeta(detailId, base);
            detailsTitle.textContent = detail.label;
            detailPreview.replaceChildren(avatar(detailId, detail));
            description.textContent = detail.description || '';
            metadata.textContent = [detail.group === 'OC' ? 'Original character' : detail.group, detail.category && `Category: ${detail.category}`, detail.trigger && `Trigger: ${detail.trigger}`, ...(detail.tags || [])].filter(Boolean).join(' · ');
            editMeta.hidden = !meta;
            favorite.textContent = preferences.favorites.includes(detailId) ? '★ Favorited' : '☆ Favorite';
            favorite.setAttribute('aria-pressed', String(preferences.favorites.includes(detailId)));
            use.textContent = chosen.some(layer => layer.id === detailId) ? 'Remove from selection' : stack ? 'Add to selection' : 'Use character';
        }
        function openDetail(id) {
            detailId = id; notify(''); appearanceStatus.textContent = ''; updateDetail(); details.showModal();
            appearanceText.value = descriptions?.get(id) || ''; syncAppearanceControls();
        }
        search.addEventListener('input', () => { query = search.value; limit = full ? 48 : 24; render(); });
        search.addEventListener('keydown', event => {
            if (event.key === 'Enter') {
                event.preventDefault();
                const first = grid.querySelector('.character-card');
                if (first && first.getAttribute('aria-pressed') !== 'true') choose(first.dataset.characterId, event.shiftKey || event.ctrlKey || event.metaKey);
            }
            if (event.key === 'ArrowDown') { event.preventDefault(); grid.querySelector('.character-card')?.focus(); }
            if (event.key === 'Escape' && query) { event.preventDefault(); event.stopPropagation(); search.value = query = ''; render(); }
        });
        grid.addEventListener('keydown', event => {
            const cards = [...grid.querySelectorAll('.character-card')], index = cards.indexOf(document.activeElement);
            if (index < 0) return;
            let next;
            if (event.key === 'ArrowDown' || event.key === 'ArrowRight') next = Math.min(index + 1, cards.length - 1);
            if (event.key === 'ArrowUp' || event.key === 'ArrowLeft') next = Math.max(index - 1, 0);
            if (event.key === 'Home') next = 0;
            if (event.key === 'End') next = cards.length - 1;
            if (next !== undefined) { event.preventDefault(); cards[next]?.focus(); }
        });
        sortSelect.addEventListener('change', () => { preferences.sort = sortSelect.value; save(); render(); });
        function clearFilters() { search.value = query = group = category = tag = ''; preferences.group = ''; tab = 'all'; preferences.tab = tab; save(); render(); }
        function render() {
            renderRevision += 1;
            selectedDetails.hidden = chosen.length === 0;
            selectedSummary.textContent = chosen.length === 1
                ? `Selected · ${config.getCatalog().find(([id]) => id === chosen[0].id)?.[1].label || '1 character'} · settings`
                : `${chosen.length} selected · settings`;
            const active = document.activeElement;
            const focusId = grid.contains(active) ? active.closest('[data-character-id]')?.dataset.characterId : null;
            const focusAction = active?.dataset?.action;
            imageObserver?.disconnect();
            fieldset.querySelectorAll('#character-picks .character-avatar[data-portrait-id]').forEach(node => {
                const detail = config.getCatalog().find(([id]) => id === node.dataset.portraitId)?.[1];
                if (detail) node.replaceWith(avatar(node.dataset.portraitId, detail));
            });
            tabButtons.forEach((node, id) => node.setAttribute('aria-pressed', String(tab === id)));
            const view = cast.map(([id, detail]) => [id, withMeta(id, detail)]);
            const groupCounts = { '': view.length, IRL: view.filter(([, detail]) => detail.group === 'IRL').length, OC: view.filter(([, detail]) => detail.group === 'OC').length, Commission: view.filter(([, detail]) => detail.group === 'Commission').length, Celeb: view.filter(([, detail]) => detail.group === 'Celeb').length };
            const categories = new Map(), tags = new Map();
            let uncategorized = 0;
            for (const [, detail] of view) {
                if (detail.category) { const key = normalize(detail.category); categories.set(key, { name: detail.category, count: (categories.get(key)?.count || 0) + 1 }); } else uncategorized += 1;
                for (const name of new Set((detail.tags || []).map(normalize))) {
                    const shownName = detail.tags.find(item => normalize(item) === name);
                    tags.set(name, { name: shownName, count: (tags.get(name)?.count || 0) + 1 });
                }
            }
            const byName = (a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: 'base', numeric: true });
            const categoryChoices = [...categories.values()].sort(byName);
            if (category && category !== '__none' && !categoryChoices.some(item => normalize(item.name) === normalize(category))) category = '';
            categorySelect.replaceChildren(new Option(`All categories (${view.length})`, ''), ...categoryChoices.map(item => new Option(`${item.name} (${item.count})`, item.name)),
                ...(categoryChoices.length ? [new Option(`Uncategorized (${uncategorized})`, '__none')] : []));
            categorySelect.value = category;
            const tagChoices = [...tags.values()].sort(byName);
            if (tag && !tagChoices.some(item => normalize(item.name) === normalize(tag))) tag = '';
            tagSelect.replaceChildren(new Option('All tags', ''), ...tagChoices.map(item => new Option(`${item.name} (${item.count})`, item.name)));
            tagSelect.value = tag;
            selectionBar.hidden = !full || !meta;
            groupButtons.forEach((node, id) => {
                node.setAttribute('aria-pressed', String(group === id));
                node.textContent = `${{ OC: 'OCs', Commission: 'Commissions', Celeb: 'Celebs / Models' }[id] || id || 'All'} · ${groupCounts[id]}`;
            });
            const shown = filter(view, { ...preferences, query, group, tab, category, tag });
            shownIds = shown.map(([id]) => id);
            const visible = shown.slice(0, limit);
            announcement.textContent = `${shown.length} of ${view.length} characters${shown.length > visible.length ? ` · showing ${visible.length}` : ''}${query ? ' · sorted by relevance' : ''}`;
            grid.replaceChildren(); grid.classList.toggle('character-library-grid', full);
            for (const [id, detail] of visible) {
                const row = element('div', 'character-entry'); row.dataset.characterId = id;
                const selected = chosen.some(layer => layer.id === id);
                const card = button('', event => choose(id, event.shiftKey || event.ctrlKey || event.metaKey), 'character-card');
                card.dataset.characterId = id; card.dataset.action = 'pick'; card.setAttribute('aria-pressed', String(selected));
                card.setAttribute('aria-label', `${selected ? 'Remove' : stack ? 'Add' : 'Use'} ${detail.label}`);
                const name = element('span', 'character-name');
                const sub = [detail.group === 'OC' ? 'Original' : detail.group, detail.category, detail.available === false ? 'Missing file' : ''].filter(Boolean).join(' · ');
                name.append(element('strong', '', detail.label), element('small', '', sub));
                card.append(avatar(id, detail), name);
                const star = button(preferences.favorites.includes(id) ? '★' : '☆', () => toggleFavorite(id), 'character-star');
                star.dataset.action = 'favorite'; star.setAttribute('aria-label', `Favorite ${detail.label}`); star.setAttribute('aria-pressed', String(preferences.favorites.includes(id)));
                const info = button('Details', () => openDetail(id), 'character-info'); info.dataset.action = 'details'; info.setAttribute('aria-label', `Details and portrait for ${detail.label}`);
                const actions = element('div', 'character-entry-actions'), left = element('span', 'character-entry-left');
                if (full && meta) {
                    const box = element('input', 'character-select'); box.type = 'checkbox'; box.dataset.action = 'select'; box.checked = checked.has(id);
                    box.setAttribute('aria-label', `Select ${detail.label} for bulk editing`);
                    box.addEventListener('change', () => { box.checked ? checked.add(id) : checked.delete(id); pushCast(); syncSelection(); });
                    left.append(box);
                }
                left.append(star); actions.append(left, info); row.append(card, actions); grid.append(row);
            }
            if (!shown.length) {
                const empty = element('div', 'character-library-empty');
                const message = !view.length
                    ? 'No characters configured for this architecture yet. Create a character from an installed LoRA file, or switch architectures.'
                    : tab === 'favorites' && !preferences.favorites.length ? 'Star a character to keep it in Favorites.'
                    : tab === 'recent' && !Object.keys(preferences.recent).length ? 'Characters you select will appear here.' : 'No characters match these filters.';
                empty.append(element('p', '', message));
                const emptyActions = element('div', 'character-empty-actions');
                if (!view.length && config.openManager) emptyActions.append(button('+ New character', () => config.openManager?.(), 'button primary'));
                if (query || group || category || tag || tab !== 'all') emptyActions.append(button('Clear filters', clearFilters));
                if (emptyActions.childElementCount) empty.append(emptyActions);
                grid.append(empty);
            }
            more.hidden = shown.length <= limit;
            syncSelection();
            if (focusId) {
                const row = [...grid.children].find(node => node.dataset.characterId === focusId);
                row?.querySelector(`[data-action="${focusAction || 'pick'}"]`)?.focus();
            }
        }
        return {
            render(nextCast, nextChosen) { cast = nextCast; chosen = nextChosen; render(); if (details.open) updateDetail(); },
            avatar, open: openLibrary, openDetail,
            description: id => descriptions?.get(id) || '',
            setDescription: (id, value) => descriptions?.set(id, value),
            putPortrait: (id, file) => vault.put(id, file),
            removePortrait: id => vault.remove(id),
            portraitUrl: id => vault.url(id),
        };
    }
    window.StudioCharacterLibrary = { create, filter, normalize };
})();

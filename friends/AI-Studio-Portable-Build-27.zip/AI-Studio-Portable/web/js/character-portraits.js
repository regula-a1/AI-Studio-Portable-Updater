/* Character portrait storage for AI Studio Portable.
 * Each portrait is center-cropped to a 256 x 256 WebP square, sealed when
 * storage encryption is enabled (StudioCrypto), cached in IndexedDB for fast
 * display, and persisted to the local studio database.
 */
(() => {
    'use strict';
    const MAX_IMAGE = 12 * 1024 * 1024, MAX_PORTRAIT = 256 * 1024;
    const validId = id => typeof id === 'string' && /^[a-z0-9_]{1,100}$/.test(id);
    const toBase64 = bytes => {
        let out = '';
        for (let i = 0; i < bytes.length; i += 8192) out += String.fromCharCode(...bytes.subarray(i, i + 8192));
        return btoa(out);
    };
    const fromBase64 = text => Uint8Array.from(atob(text), char => char.charCodeAt(0));
    function database() {
        return new Promise((resolve, reject) => {
            const req = indexedDB.open('aistudio-character-portraits', 1);
            req.onupgradeneeded = () => req.result.createObjectStore('portraits', { keyPath: 'id' });
            req.onsuccess = () => resolve(req.result);
            req.onerror = () => reject(req.error);
            req.onblocked = () => reject(new Error('Close other Studio tabs and try again.'));
        });
    }
    function request(db, mode, run) {
        return new Promise((resolve, reject) => {
            const tx = db.transaction('portraits', mode);
            let result;
            tx.oncomplete = () => resolve(result);
            tx.onerror = () => reject(tx.error);
            tx.onabort = () => reject(tx.error || new Error('Portrait storage was interrupted.'));
            const req = run(tx.objectStore('portraits'));
            req.onsuccess = () => { result = req.result; };
        });
    }
    // Canvas re-encoding strips metadata and bounds storage to a 256 x 256 square.
    async function thumbnail(file) {
        if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) throw new Error('Choose a JPEG, PNG or WebP image. Convert HEIC photos to JPEG first.');
        if (!file.size || file.size > MAX_IMAGE) throw new Error('Choose an image smaller than 12 MB.');
        const source = URL.createObjectURL(file);
        const img = new Image();
        try {
            img.src = source;
            await img.decode();
            if (!img.naturalWidth || !img.naturalHeight || img.naturalWidth * img.naturalHeight > 50000000) throw new Error('This image is too large to process.');
            const canvas = document.createElement('canvas');
            canvas.width = canvas.height = 256;
            const side = Math.min(img.naturalWidth, img.naturalHeight);
            canvas.getContext('2d').drawImage(img, (img.naturalWidth - side) / 2, (img.naturalHeight - side) / 2, side, side, 0, 0, 256, 256);
            const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/webp', .82));
            canvas.width = canvas.height = 0;
            if (!blob || blob.size > MAX_PORTRAIT) throw new Error('Could not create a portrait preview.');
            return new Uint8Array(await blob.arrayBuffer());
        } finally { img.src = ''; URL.revokeObjectURL(source); }
    }
    function create(owner = 'local', changed = () => {}) {
        let dbPromise, syncing = null, lastSyncAttempt = 0;
        const urls = new Map(), pending = new Map();
        const syncKey = `aistudio-portrait-sync:${owner}`;
        const crypto_ = () => window.StudioCrypto;
        const unlocked = () => Boolean(crypto_()?.isUnlocked?.());
        const db = () => dbPromise ||= database();
        const recordId = id => `${owner}|${id}`;
        const getSince = () => { try { return Number(localStorage.getItem(syncKey)) || 0; } catch { return 0; } };
        const setSince = value => { try { localStorage.setItem(syncKey, String(value)); } catch { /* re-pulls next time */ } };
        const mine = async () => (await request(await db(), 'readonly', store => store.getAll())).filter(record => record.owner === owner);
        const get = async id => request(await db(), 'readonly', store => store.get(recordId(id)));
        const put = async record => request(await db(), 'readwrite', store => store.put(record));
        function clearUrl(id) {
            if (urls.has(id)) URL.revokeObjectURL(urls.get(id));
            urls.delete(id);
        }
        function clearAllUrls() { for (const id of [...urls.keys()]) clearUrl(id); pending.clear(); }
        async function sync() {
            if (!unlocked()) return false;
            if (syncing) return syncing;
            lastSyncAttempt = Date.now();
            syncing = (async () => {
                let touched = false;
                try {
                    for (const record of (await mine()).filter(item => item.dirty)) {
                        const updated = await crypto_().savePortrait(record.character, record.deleted ? '' : record.sealed);
                        const latest = await get(record.character);
                        if (latest && latest.rev === record.rev) {
                            await put({ ...latest, dirty: false, updated });
                            touched = true;
                        }
                    }
                    const since = getSince();
                    const rows = await crypto_().fetchPortraits(since);
                    let high = since;
                    for (const row of rows || []) {
                        high = Math.max(high, row.updated);
                        if (!validId(row.character) || /^(desc|meta)_/.test(row.character)) continue;
                        const local = await get(row.character);
                        if (local && (local.dirty || local.updated >= row.updated)) continue;
                        clearUrl(row.character);
                        await put({ id: recordId(row.character), owner, character: row.character, sealed: row.payload || '', deleted: !row.payload, updated: row.updated, dirty: false, rev: 0 });
                        touched = true;
                    }
                    setSince(high);
                } catch { /* offline or locked: retried on next sync */ }
                finally { syncing = null; }
                if (touched) changed();
                return true;
            })();
            return syncing;
        }
        function syncSoon() { if (Date.now() - lastSyncAttempt > 60000) sync(); }
        window.addEventListener('studio-unlocked', () => { sync(); changed(); });
        window.addEventListener('studio-locked', () => { clearAllUrls(); changed(); });
        document.addEventListener('visibilitychange', () => { if (!document.hidden) syncSoon(); });
        if (unlocked()) sync();
        return {
            isUnlocked: unlocked,
            sync,
            async put(id, file) {
                if (!validId(id)) throw new Error('Invalid character.');
                if (!unlocked()) throw new Error('Unlock Studio first.');
                const sealed = toBase64(await crypto_().sealBinary(await thumbnail(file)));
                const previous = await get(id);
                await put({ id: recordId(id), owner, character: id, sealed, deleted: false, updated: previous?.updated || 0, dirty: true, rev: (previous?.rev || 0) + 1 });
                clearUrl(id); changed();
                sync();
            },
            async remove(id) {
                if (!validId(id)) throw new Error('Invalid character.');
                const previous = await get(id);
                await put({ id: recordId(id), owner, character: id, sealed: '', deleted: true, updated: previous?.updated || 0, dirty: true, rev: (previous?.rev || 0) + 1 });
                clearUrl(id); changed();
                sync();
            },
            async url(id) {
                if (!validId(id) || !unlocked()) return null;
                if (urls.has(id)) return urls.get(id);
                if (pending.has(id)) return pending.get(id);
                const work = (async () => {
                    const record = await get(id);
                    if (!record || record.deleted || !record.sealed) return null;
                    const pixels = await crypto_().unsealBinary(fromBase64(record.sealed));
                    if (!unlocked()) return null;
                    const url = URL.createObjectURL(new Blob([pixels], { type: 'image/webp' }));
                    urls.set(id, url);
                    return url;
                })().finally(() => { if (pending.get(id) === work) pending.delete(id); });
                pending.set(id, work);
                return work;
            }
        };
    }
    window.StudioPortraitVault = { create };
})();

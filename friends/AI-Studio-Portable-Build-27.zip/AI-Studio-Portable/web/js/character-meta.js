/* Per-character user tags, category, and type overrides for AI Studio Portable.
 * Stored as one record ("meta_all") in studio_portraits so bulk edits save in a
 * single round-trip. Sealed automatically when storage encryption is enabled.
 */
(() => {
    'use strict';
    const ROW = 'meta_all', MAX_TAGS = 20, MAX_TEXT = 40;
    const GROUPS = ['IRL', 'OC', 'Commission', 'Celeb'];
    const clean = text => String(text || '').replace(/\s+/g, ' ').trim().slice(0, MAX_TEXT);
    const same = (a, b) => a.toLowerCase() === b.toLowerCase();
    function tagList(values) {
        const out = [];
        for (const value of values || []) {
            const tag = clean(value);
            if (tag && !out.some(have => same(have, tag))) out.push(tag);
        }
        return out.slice(0, MAX_TAGS);
    }
    const parseTags = text => tagList(String(text || '').split(','));
    const tidy = item => ({
        tags: tagList(item?.tags), category: clean(item?.category),
        group: GROUPS.includes(item?.group) ? item.group : '', t: Number(item?.t) || 0
    });
    function create(owner = 'local', changed = () => {}) {
        const storeKey = `aistudio-character-meta:${owner}`;
        let state = { sealed: '', updated: 0, dirty: false, rev: 0 };
        try {
            const saved = JSON.parse(localStorage.getItem(storeKey));
            if (saved && typeof saved.sealed === 'string') state = { sealed: saved.sealed, updated: Number(saved.updated) || 0, dirty: saved.dirty === true, rev: Number(saved.rev) || 0 };
        } catch { /* nothing saved yet */ }
        const persist = () => { try { localStorage.setItem(storeKey, JSON.stringify(state)); } catch { /* memory only */ } };
        const crypto_ = () => window.StudioCrypto;
        const unlocked = () => Boolean(crypto_()?.isUnlocked?.());
        let items = {}, syncing = null;
        async function unpack(sealed) {
            const parsed = JSON.parse(await crypto_().unsealText(sealed));
            const out = {};
            for (const [id, item] of Object.entries(parsed?.items || {})) if (/^[a-z0-9_]{1,90}$/.test(id)) out[id] = tidy(item);
            return out;
        }
        async function open() {
            items = {};
            if (!unlocked() || !state.sealed) return;
            try { items = await unpack(state.sealed); } catch { /* sealed under another key */ }
        }
        async function sync() {
            if (!unlocked()) return false;
            if (syncing) return syncing;
            syncing = (async () => {
                let touched = false;
                try {
                    let cursor = state.updated, remote = null;
                    for (let page = 0; page < 5; page += 1) {
                        const rows = await crypto_().fetchPortraits(cursor) || [];
                        remote = rows.find(row => row.character === ROW) || remote;
                        const high = Math.max(cursor, ...rows.map(row => row.updated));
                        if (high === cursor || rows.length < 200) break;
                        cursor = high;
                    }
                    if (remote && remote.updated > state.updated && remote.payload) {
                        const theirs = await unpack(remote.payload);
                        for (const [id, item] of Object.entries(theirs)) {
                            if (!items[id] || item.t > items[id].t) { items[id] = item; touched = true; }
                        }
                        if (!state.dirty) { state.sealed = remote.payload; }
                        state.updated = remote.updated; persist();
                    }
                    if (state.dirty) {
                        const rev = state.rev;
                        const payload = await crypto_().sealText(JSON.stringify({ v: 1, items }));
                        const updated = await crypto_().savePortrait(ROW, payload);
                        if (state.rev === rev) { state.sealed = payload; state.updated = updated; state.dirty = false; persist(); }
                    }
                } catch { /* offline or locked: retried on next sync */ }
                finally { syncing = null; }
                if (touched) changed();
                return true;
            })();
            return syncing;
        }
        const read = id => items[id] || { tags: [], category: '', group: '', t: 0 };
        function commit() { state.dirty = true; state.rev += 1; persist(); changed(); sync(); }
        window.addEventListener('studio-unlocked', async () => { await open(); changed(); sync(); });
        window.addEventListener('studio-locked', () => { items = {}; changed(); });
        document.addEventListener('visibilitychange', () => { if (!document.hidden) sync(); });
        if (unlocked()) open().then(() => { changed(); sync(); });
        return {
            isUnlocked: unlocked,
            maxTags: MAX_TAGS, maxText: MAX_TEXT, parseTags,
            get: id => { const item = read(id); return { tags: [...item.tags], category: item.category, group: item.group }; },
            all: () => Object.fromEntries(Object.entries(items).map(([id, item]) => [id, { tags: item.tags, category: item.category, group: item.group }])),
            update(ids, patch) {
                if (!unlocked()) throw new Error('Unlock Studio first.');
                const now = Date.now();
                for (const id of ids) {
                    if (!/^[a-z0-9_]{1,90}$/.test(id)) continue;
                    const next = { ...read(id), tags: [...read(id).tags], t: now };
                    if (patch.removeTags?.length) next.tags = next.tags.filter(tag => !patch.removeTags.some(gone => same(gone, tag)));
                    if (patch.addTags?.length) next.tags = tagList([...next.tags, ...patch.addTags]);
                    if (patch.category !== undefined) {
                        const typed = clean(patch.category);
                        next.category = Object.values(items).map(item => item.category).find(have => have && same(have, typed)) || typed;
                    }
                    if (patch.group !== undefined) next.group = GROUPS.includes(patch.group) ? patch.group : '';
                    items[id] = next;
                }
                commit();
            },
            sync
        };
    }
    window.StudioCharacterMeta = { create, parseTags, GROUPS };
})();

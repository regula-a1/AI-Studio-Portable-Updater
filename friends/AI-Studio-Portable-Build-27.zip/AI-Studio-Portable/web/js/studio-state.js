(function () {
    'use strict';

    // Deleted IDs remain in the synchronized list so an older device cannot
    // mistake their absence for a locally-created preset.
    function mergePresets(...lists) {
        const byId = new Map();
        for (const item of lists.flat()) {
            if (!item?.id) continue;
            const previous = byId.get(item.id);
            if (!previous || (item.updatedAt || 0) > (previous.updatedAt || 0)
                || ((item.updatedAt || 0) === (previous.updatedAt || 0) && item.deleted)) {
                byId.set(item.id, item);
            }
        }
        return [...byId.values()].sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
    }

    // A backup or synced copy is either a bare list or { resetAt, presets }.
    function readPresetLibrary(data) {
        if (Array.isArray(data)) return { resetAt: 0, presets: data };
        if (data && Array.isArray(data.presets)) return { resetAt: Number(data.resetAt) || 0, presets: data.presets };
        return null;
    }

    function reconcilePresets(remote, local, seenResetAt) {
        const keep = remote.resetAt > (seenResetAt || 0)
            ? local.filter(item => (item?.updatedAt || 0) > remote.resetAt)
            : local;
        return mergePresets(remote.presets, keep);
    }

    function createSubmission() {
        let pending = null;
        return {
            async prepare(settings, editor, upload) {
                const assets = [];
                if (settings.mode === 'img2img' || settings.mode === 'inpaint') {
                    const input = await editor.getInputBlob();
                    if (!input) throw new Error('Please select or drop an input image.');
                    assets.push(['input', input]);
                }
                if (settings.mode === 'inpaint') {
                    const mask = await editor.getMaskBlob();
                    if (!mask) throw new Error('Please paint a mask over the area you want to change.');
                    assets.push(['mask', mask]);
                }
                const bytes = await Promise.all(assets.map(async ([type, blob]) => [type, new Uint8Array(await blob.arrayBuffer())]));
                const hashes = await Promise.all(bytes.map(async ([type, value]) => [type,
                    Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', value)), b => b.toString(16).padStart(2, '0')).join('')]));
                const signature = JSON.stringify([settings, hashes]);
                if (!pending || pending.signature !== signature) pending = { signature, id: crypto.randomUUID(), keys: {} };
                for (const [type, value] of bytes) {
                    if (!pending.keys[type]) pending.keys[type] = await upload(pending.id, type, value);
                }
                return { id: pending.id,
                    ...(pending.keys.input ? { inputImageKey: pending.keys.input } : {}),
                    ...(pending.keys.mask ? { maskImageKey: pending.keys.mask } : {}) };
            },
            accepted() { pending = null; }
        };
    }
    window.StudioState = { mergePresets, readPresetLibrary, reconcilePresets, createSubmission };
})();

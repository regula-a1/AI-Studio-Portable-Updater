# AI Studio Portable

A single-folder desktop studio for local image generation and chat. It provides
the interface; ComfyUI and llama.cpp do the work, both running on your own
machine. Generation and chat inference happen entirely locally - your prompts
and conversations are not sent anywhere for that. A few things do reach the
network: turning on web search sends your query to Bing or DuckDuckGo, the
studio can check for a newer release if you enable it (see
[Updates](#updates)), and installing a model
contacts that model's own host directly.

Four modes in one workspace:

- **Text to image** — prompt, presets, LoRA layers, sampler and resolution control
- **Image to image** — denoise-controlled variation from a reference
- **Inpaint** — masked edits with a brush editor, powered by LanPaint
- **Chat** — a local uncensored assistant with vision, memory, web search and the
  ability to generate images into the conversation

**Status: pre-alpha.** The interface, the orchestrator and the local server that
connects them all work, and the studio installs and runs on a clean Windows
machine. What has not been proven is a full install followed by a real
generation on a PC with a GPU and nothing else on it.

Every build is numbered - Build 1, Build 2, and so on, with no decimals. The
number is shown faintly in the bottom corner of the studio, and clicking it
opens [CHANGELOG.md](CHANGELOG.md), the log of what changed in each one.

For a full guide to the interface, modes, model management, hardware tuning and configuration, see the [User Manual (PDF)](USER_MANUAL.pdf) or [MANUAL.md](MANUAL.md).

## Getting started

Double-click **`Start.bat`**.

That is the whole prerequisite list. You do not need Python, git, or anything
else installed first — the studio fetches its own private Python (about 60 MB)
the first time it runs, and everything it installs lives inside this folder.

The first run explains what it is about to download and asks before starting.
After that, `Start.bat` is the only thing you ever need: it sets up if setting up
is needed, then opens the studio. Every step can be interrupted and resumed, so a
download that dies at 80% picks up from 80% next time.

There are three ways to get models, and you can mix them:

- let the installer download them
- point the studio at a folder you already have, read-only
- drop files straight into `models\` - there is a folder for each kind and a
  README in there saying what goes where

## Requirements

- Windows 10 or 11
- An NVIDIA GPU. 12 GB VRAM is the reference configuration; 8 GB restricts which
  chat models can load, and image generation above 2 MP gets tight. The studio
  measures your card at startup and offers only what will actually fit
- ~10 GB of disk for the application, plus whatever the models you choose need
  (a minimal image-only setup is around 20 GB; a full one exceeds 100 GB)

AMD and Apple Silicon are not supported and are not planned.

## Already have ComfyUI?

It will not be touched. AI Studio Portable installs its own private ComfyUI and
its own Python environment, then asks where your model folders are and reads them
where they sit — read-only, never copied, never moved. Your existing install, its
custom nodes and its outputs are left exactly as they are.

Sharing an install rather than a model folder is what breaks people's setups, so
this build does not offer it.

## Layout

```
AIStudioPortable/
├─ app/           server, orchestrator, model registry, setup wizard
├─ web/           the interface — plain HTML, CSS and JS, no build step
├─ workflows/     ComfyUI API-format graph templates
├─ scripts/       the installer and its bootstrap
├─ runtime/       embedded Python, torch, llama.cpp binaries   (not in git)
├─ comfy/         our private ComfyUI and its custom nodes      (not in git)
├─ models/        drop models in here, or point at a folder you have
├─ data/          database, generated images, settings          (not in git)
└─ logs/                                                        (not in git)
```

Everything in `data/` and `models/` is yours. Everything above them is replaced
wholesale by an update, which is why updates can be an unzip over the top.

## Updates

Build 18 checks the separate Build 18+ update feed by default. Older copies
continue to see Build 17 through their existing feed.
Installing is a second, deliberate press: the release is downloaded,
checked against a published SHA-256, unpacked to a staging folder and inspected
before a single file is replaced. Your images, models, settings and
conversations are never touched - a release contains only the program.

Every build is numbered - Build 1, Build 2, and so on, forever, with no
decimals. The number you are running is faint in the bottom corner; click it
for the full log of what changed in each build. The first time you open the
studio after an update, that log opens by itself so you can see what is new.

Set `update_url` to `""` in `config.json` to switch checking off entirely.

## The one thing it will not do

The assistant is uncensored and the image side is not filtered. Adult work is
what a lot of this is for, and none of it is restricted, moralised at or
logged.

There is a single exception and it is not negotiable: the studio does not
produce sexual material involving anyone under 18, in chat or in images.
Prompts asking for it are refused.

Use of this software to produce such material is prohibited, whether or not
any particular attempt is refused.

Nothing about this reaches the network. The refusal happens on your machine,
and a refused prompt is not stored or written to the log.

## Licence

Source-available, not open source — see [LICENSE](LICENSE). If you received a
copy, you keep it: the grant is perpetual for the copy you have.

Bundled third-party components keep their own licences, recorded in
[NOTICE.md](NOTICE.md). Model weights are not redistributed; you download those
yourself from their publishers.

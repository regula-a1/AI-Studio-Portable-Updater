"""The local server: serves the interface and answers what it already calls.

This is the piece that replaced the cloud relay. The original posted jobs to a
Pages Function, parked them in D1, and had a worker poll for them over HTTPS.
On one machine all of that is dead weight, so this process is both ends at once:
it serves web/, owns the SQLite database and the image folder, and runs the
orchestrator in a thread instead of handing work to a remote poller.

Design notes, because they constrain everything below:

- **Standard library only.** The product ships to people who may not have Python
  at all, and the launcher installs a private runtime. Every dependency is one
  more thing that install has to get right, so the server itself takes none.
  ThreadingHTTPServer is comfortably enough for one user on localhost.

- **The wire contract is fixed.** web/ has no build step and is edited directly;
  its fetches were written against the cloud API and are not changing. Action
  names, parameter names and response field names below are copied from the
  client, not invented. web/js/ is the specification; this file follows it.

- **The server never sees plaintext.** Prompts, chat messages, draft metadata and
  image bytes all arrive sealed by the browser under the ASP1 envelope. Anything
  named `sealed_*`, plus prompts and draft assets, is an opaque blob here. The
  orchestrator holds the key because it has to; this layer does not.

- **One job at a time.** Kept from the original deliberately: the GPU is a single
  resource and the arbitration around it is load-bearing. `active-job.json` marks
  the job currently in flight so an ungraceful exit can fail it on restart rather
  than leaving it 'running' for ever.
"""
import json
import mimetypes
import os
import re
import secrets
import sqlite3
import sys
import threading
import time
import logging
import traceback
import uuid

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

HERE = Path(__file__).resolve().parent

# Put this folder on the import path before importing anything beside it.
#
# Ordinary Python adds a script's own directory automatically. The embeddable
# build does not: its sys.path comes entirely from the ._pth file beside the
# executable, where "." means the interpreter's folder, not the script's. So
# `import local_agent` worked under a system Python and failed under the one the
# studio installs for itself - which is to say it worked everywhere except on a
# real user's machine.
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import local_agent                                          # noqa: E402
import tuning                                               # noqa: E402
import diagnostics                                          # noqa: E402
import lifecycle                                            # noqa: E402
import update as updater                                   # noqa: E402
import version as build_version                             # noqa: E402
ROOT = HERE.parent
WEB_DIR = ROOT / 'web'
DATA_DIR = ROOT / 'data'
IMAGES_DIR = DATA_DIR / 'images'
DRAFTS_DIR = DATA_DIR / 'drafts'
DB_PATH = DATA_DIR / 'studio.db'
ACTIVE_JOB = DATA_DIR / 'active-job.json'

# One local user. The original authenticated against the website; there is no
# account here, and the owner column exists only so the schema did not have to
# change and so a future multi-profile build has somewhere to put a second name.
OWNER = 'local'

DEFAULTS = {
    'host': '127.0.0.1',
    'port': 8760,
    'open_browser': True,
    # Retention mirrors what the interface shows the user. Both are advertised in
    # the status response; the client renders its own warnings from them.
    'retention_hours': 72,
    'retention_images': 40,
    # Where updates come from: a manifest file in the update repo, with the zip
    # sitting beside it. A plain file rather than the releases API, so
    # publishing a build is a push. Set to '' to turn updating off.
    'update_url': 'https://raw.githubusercontent.com/regula-a1/AI-Studio-Portable-Updater/main/friends/latest.json',
    # Checks are on by default; installing still requires a second press.
    'check_updates': True,
}


def load_config():
    """Config file over defaults. Absent file is the normal first-run case."""
    config = dict(DEFAULTS)
    for name in ('config.json', 'config.local.json'):
        path = ROOT / name
        if not path.exists():
            continue
        try:
            config.update(json.loads(path.read_text(encoding='utf-8')))
        except (OSError, json.JSONDecodeError) as exc:
            print(f'  ! ignoring {name}: {exc}')
    return config


CONFIG = load_config()


# --------------------------------------------------------------------- db ---

_local = threading.local()


def db():
    """One connection per thread; sqlite3 objects are not shareable across them."""
    conn = getattr(_local, 'conn', None)
    if conn is None:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(DB_PATH, timeout=30)
        conn.row_factory = sqlite3.Row
        # WAL lets the job thread write progress while a request reads status,
        # which is the whole access pattern here.
        conn.execute('PRAGMA journal_mode=WAL')
        conn.execute('PRAGMA foreign_keys=ON')
        _local.conn = conn
    return conn


def init_db():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    IMAGES_DIR.mkdir(parents=True, exist_ok=True)
    DRAFTS_DIR.mkdir(parents=True, exist_ok=True)
    schema = (HERE / 'schema.sql').read_text(encoding='utf-8')
    conn = db()
    conn.executescript(schema)
    conn.commit()
    migrate(conn)


# Columns added to studio_jobs after the first release. CREATE TABLE IF NOT EXISTS
# does nothing to a table that already exists, so a database made before a column
# was added needs it adding by hand or every insert naming it fails.
MIGRATIONS = (
    ('studio_jobs', 'worker_payload', 'TEXT'),
    ('studio_jobs', 'client_pubkey', 'TEXT'),
)


def migrate(conn):
    for table, column, kind in MIGRATIONS:
        existing = {row['name'] for row in conn.execute('PRAGMA table_info(' + table + ')')}
        if column not in existing:
            conn.execute('ALTER TABLE ' + table + ' ADD COLUMN ' + column + ' ' + kind)
            print('  migrated: ' + table + '.' + column)
    conn.commit()


def recover_active_job():
    """Fail whatever was mid-flight when the process last died.

    Without this a job killed by a crash or a power cut stays 'running' for ever
    and the queue never moves again, which is indistinguishable to the user from
    the app being broken.
    """
    if not ACTIVE_JOB.exists():
        return
    try:
        marker = json.loads(ACTIVE_JOB.read_text(encoding='utf-8'))
        job_id = marker.get('id')
    except (OSError, json.JSONDecodeError):
        job_id = None
    if job_id:
        conn = db()
        conn.execute(
            "UPDATE studio_jobs SET status='error', error=?, updated=? "
            "WHERE id=? AND status IN ('running','queued')",
            ('Interrupted - the studio closed while this job was running.',
             int(time.time()), job_id))
        conn.commit()
        print(f'  recovered interrupted job {job_id}')
    ACTIVE_JOB.unlink(missing_ok=True)


# ----------------------------------------------------------------- engine ---

class Engine:
    """Lazy handle on the orchestrator.

    Imported on first use rather than at startup so the server still boots, still
    serves the interface, and can say what is missing when the runtime is not
    installed yet. A hard import here would turn a missing dependency into a
    process that will not start at all, which is the least debuggable failure the
    first-run user could meet.
    """

    def __init__(self):
        self.module = None
        self.error = None
        self._lock = threading.Lock()

    def load(self):
        with self._lock:
            if self.module or self.error:
                return self.module
            try:
                sys.path.insert(0, str(HERE))
                import orchestrator
                self.module = orchestrator
            except Exception as exc:                       # noqa: BLE001 - reported
                self.error = f'{type(exc).__name__}: {exc}'
                print(f'  ! orchestrator unavailable: {self.error}')
            return self.module

    @property
    def ready(self):
        return self.load() is not None


ENGINE = Engine()


# ------------------------------------------------------------- job runner ---

class JobRunner(threading.Thread):
    """Runs queued jobs one at a time, in queue order.

    This replaces Agent.run()'s five-second claim loop against D1. The single-job
    discipline is kept: the GPU is one resource, and the orchestrator's
    arbitration around ComfyUI and llama-server assumes nothing else of ours is
    competing for it.
    """

    def __init__(self):
        super().__init__(name='job-runner', daemon=True)
        self.wake = threading.Event()
        self.current = None
        self.stop_requested = set()
        self.agent = None
        self.store = None
        # When the engines were last wanted, and whether they have been let go
        # since. Reset by every job, so one release per idle spell.
        self.idle_since = time.time()
        self.engines_released = False

    def release_if_idle(self):
        """Let the engines go once nothing has asked for them for a while.

        Runs on this thread between jobs, so it can never stop an engine out
        from under one. Without it a finished render left ComfyUI holding the
        model in RAM and video memory until the studio was closed.
        """
        if self.agent is None or self.current or self.engines_released:
            return
        if not lifecycle.idle_expired(self.idle_since, time.time(),
                                      CONFIG.get('idle_unload_minutes', 5)):
            return
        self.engines_released = True
        stopped = self.agent.release_engines()
        if stopped:
            logging.info('Idle for %s minutes; stopped the %s engine to free memory',
                         CONFIG.get('idle_unload_minutes', 5), ' and '.join(stopped))

    def release_engines(self):
        """Stop the engines on the way out. Safe to call twice, and before any job."""
        if self.agent is None:
            return
        try:
            self.agent.release_engines()
        except Exception:                                  # noqa: BLE001 - exiting anyway
            logging.exception('Could not stop the engines on exit')

    def engine(self):
        """The orchestrator, composed with the local storage seam.

        Built once, on the first job rather than at startup: constructing it reads
        config and touches the filesystem, and a server that cannot generate
        should still serve the interface and say why.
        """
        if self.agent is not None:
            return self.agent
        orchestrator = ENGINE.load()
        if orchestrator is None:
            raise RuntimeError(ENGINE.error or 'The generation engine is not installed.')
        # Only needed when storage is encrypted: otherwise nothing is sealed and
        # the value is never used, so requiring one would be ceremony.
        passphrase = CONFIG.get('studio_key') or ''
        if CONFIG.get('encrypt_storage') and not passphrase:
            raise RuntimeError(
                'Storage encryption is on but no studio key is set. The engine has to '
                'open the sealed prompt to build a graph, so config.json needs '
                '`studio_key` set to the same phrase you unlock the browser with.')
        apply_profile(orchestrator)
        local_agent.write_runtime_config(HERE, passphrase)
        self.store = local_agent.LocalStore(db, IMAGES_DIR, OWNER)
        self.agent = local_agent.build_agent(orchestrator, self.store)
        return self.agent

    def nudge(self):
        self.wake.set()

    def run(self):
        while True:
            self.wake.wait(timeout=5)
            self.wake.clear()
            try:
                self.drain()
                self.release_if_idle()
            except Exception:                              # noqa: BLE001 - keep serving
                traceback.print_exc()

    def drain(self):
        while True:
            job = self.next_job()
            if job is None:
                return
            self.execute(job)

    def next_job(self):
        row = db().execute(
            "SELECT * FROM studio_jobs WHERE status='queued' "
            "ORDER BY priority DESC, queue_position, created LIMIT 1").fetchone()
        return dict(row) if row else None

    def execute(self, job):
        job_id = job['id']
        now = int(time.time())
        conn = db()
        conn.execute("UPDATE studio_jobs SET status='running', updated=? WHERE id=?", (now, job_id))
        conn.commit()
        ACTIVE_JOB.write_text(json.dumps({'id': job_id, 'started': now}), encoding='utf-8')
        self.current = job_id
        self.engines_released = False
        try:
            if not ENGINE.ready:
                raise RuntimeError(
                    'The generation engine is not available yet. '
                    + (ENGINE.error or 'Run the setup wizard to install the runtime.'))
            if job.get('app') == 'chat':
                self.run_chat_job(job)
            else:
                self.run_image_job(job)
        except Exception as exc:                           # noqa: BLE001 - surfaced to the user
            traceback.print_exc()
            # Into the log as well, with the traceback. The message stored on the
            # job is one line and reaches the user; the log is what gets sent in a
            # report. A failure that logged nothing left the log showing a job
            # starting and then silence, which is how one 404 took an hour to find.
            logging.exception('Job %s failed: %s', job_id, exc)
            conn.execute("UPDATE studio_jobs SET status='error', error=?, updated=? WHERE id=?",
                         (str(exc)[:500], int(time.time()), job_id))
            conn.commit()
        finally:
            self.current = None
            self.idle_since = time.time()
            self.stop_requested.discard(job_id)
            ACTIVE_JOB.unlink(missing_ok=True)

    # How long to wait for one image before giving up on it. Generous: an 8MP
    # tiled refinement on a busy card is minutes, not seconds.
    IMAGE_TIMEOUT = 20 * 60
    # Cold start: importing torch and every custom node. Generous because the
    # first run of all is the slowest, reading several GB off a disk that has
    # never cached any of it.
    ENGINE_TIMEOUT = 5 * 60

    def run_chat_job(self, job):
        """Hand one chat turn to the orchestrator.

        Unlike an image job this one blocks: run_chat_job streams the whole reply
        before returning, reporting each token through post_chat_api, which the
        local seam writes into studio_chat_chunks for the stream endpoint to
        serve. So there is nothing to poll - it either returns having delivered a
        reply, or raises.
        """
        agent = self.engine()
        prepared = local_agent.job_for_agent(job)
        self.store.pending_job = prepared
        agent.run_chat_job(prepared)
        row = db().execute('SELECT status FROM studio_jobs WHERE id=?', (job['id'],)).fetchone()
        if row and row['status'] == 'running':
            # The engine reports its own completion through worker-done. Reaching
            # here still running means it returned without ever saying so.
            db().execute("UPDATE studio_jobs SET status='complete', updated=? WHERE id=?",
                         (now(), job['id']))
            db().commit()

    def report_stage(self, agent, job):
        """Say truthfully where the job is, without inventing a percentage.

        Step-level progress reaches the orchestrator over ComfyUI's websocket, and
        websocket-client is an optional import: without it the stage stays at
        whatever was set when the job began, and the card reads "Starting..." for
        the whole render. That is indistinguishable from a hang, which is what it
        was mistaken for.

        ComfyUI's HTTP API cannot supply a step count, so this does not pretend to
        one - no fabricated bar, no guessed ETA. It reports the three transitions
        it can actually observe, which is enough to tell a working studio from a
        stuck one. Install websocket-client and the real percentage comes back on
        its own; phase 5's launcher puts it in the bundled runtime.
        """
        orchestrator = ENGINE.module
        try:
            local_id = agent.local_job_id(job)
            queue = orchestrator.request(orchestrator.LOCAL + '/queue')
            pending = queue.get('queue_pending') or []
            running = queue.get('queue_running') or []
            if any(str(item[1]) == str(local_id) for item in running):
                stage = 'generating'
            elif any(str(item[1]) == str(local_id) for item in pending):
                stage = 'queued'
            else:
                # Gone from both: ComfyUI has finished and the result is being
                # fetched, decoded and written.
                stage = 'finishing'
        except Exception:                                  # noqa: BLE001 - never fail a job over a label
            return
        self.set_stage(job, stage)

    @staticmethod
    def set_stage(job, stage):
        conn = db()
        conn.execute('UPDATE studio_jobs SET progress_stage=?, updated=? WHERE id=? '
                     "AND status='running'", (stage, now(), job['id']))
        conn.commit()

    def await_engine(self, job):
        """Wait for ComfyUI, which local_ready() starts as a side effect.

        local_ready() is not the question it looks like. When ComfyUI is not up it
        launches it and returns False, expecting to be asked again a few seconds
        later - the same shape as run_job below.

        run_image_job asked once and raised on the first False. ComfyUI is only
        started when an image is wanted and takes the better part of a minute to
        import torch and its custom nodes, so the first generation after every
        restart failed with 'ComfyUI is not responding', pointing at config.json.
        The configuration was correct; the engine was simply still starting.
        """
        agent = self.engine()
        if agent.local_ready():
            return
        # Say so, or a minute of normal startup looks like a hung job.
        self.set_stage(job, 'starting_engine')
        deadline = time.time() + self.ENGINE_TIMEOUT
        while time.time() < deadline:
            if job['id'] in self.stop_requested:
                return
            time.sleep(3)
            if agent.local_ready():
                return
        raise RuntimeError(
            'The image engine did not start within '
            + str(self.ENGINE_TIMEOUT // 60) + ' minutes. See data/logs for what '
            'ComfyUI reported.')

    def run_image_job(self, job):
        """Drive one image job to completion.

        run_job is not a call that blocks until there is an image. It was written
        for a worker that polled a cloud queue every few seconds: one pass builds
        the graph and submits it, returns, and a *later* pass finds the finished
        render in ComfyUI's history and delivers it. Calling it once and expecting
        a result fails every time, which is exactly what it did here first.

        So this polls it the way the original loop did, passing the same job dict
        back each time - run_job marks it submitted, and that flag is what stops
        the next pass from queueing the render a second time.
        """
        agent = self.engine()
        # The engine validates a job's layers against LORA_SPECS, which ships
        # empty and is filled from the user's own folders. Refreshed per job so a
        # LoRA configured in the Models panel works without restarting.
        ENGINE.module.LORA_SPECS = lora_specs()
        prepared = local_agent.job_for_agent(job)

        # The one limit, checked before the engine is started for this job.
        #
        # Here rather than in the API: the browser seals the prompt before it is
        # sent, so the request handler that stored it never saw words. This is
        # the first point in the chain where there is text to look at.
        #
        # And before await_engine, so a refused prompt never reaches the GPU,
        # never loads thirteen gigabytes of weights, and leaves no file behind -
        # there is nothing to delete afterwards because nothing was made.
        refusal = agent.image_refusal(prepared)
        if refusal:
            # The prompt is not written to the log. Its length and digest tell
            # two refusals apart without the text outliving the job.
            logging.warning('Image job %s refused by the content check', job['id'])
            raise RuntimeError(refusal)

        self.await_engine(job)
        if job['id'] in self.stop_requested:
            return
        deadline = time.time() + self.IMAGE_TIMEOUT
        while time.time() < deadline:
            if job['id'] in self.stop_requested:
                agent.cancel(prepared)
                return
            self.store.pending_job = prepared
            agent.run_job(prepared)
            self.report_stage(agent, prepared)
            row = db().execute('SELECT status FROM studio_jobs WHERE id=?',
                               (job['id'],)).fetchone()
            if not row or row['status'] != 'running':
                return
            time.sleep(2)
        raise TimeoutError('The image did not finish within '
                           + str(self.IMAGE_TIMEOUT // 60) + ' minutes.')


RUNNER = JobRunner()


# ------------------------------------------------------------------ utils ---

def now():
    return int(time.time())


def json_body(handler):
    length = int(handler.headers.get('Content-Length') or 0)
    if not length:
        return {}
    raw = handler.rfile.read(length)
    try:
        return json.loads(raw.decode('utf-8'))
    except (UnicodeDecodeError, json.JSONDecodeError):
        raise ApiError('Malformed request body.', 400)


def raw_body(handler):
    length = int(handler.headers.get('Content-Length') or 0)
    return handler.rfile.read(length) if length else b''


class ApiError(Exception):
    def __init__(self, message, status=400, code=None):
        super().__init__(message)
        self.message = message
        self.status = status
        self.code = code


def bounded(value, default, low, high):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return default
    return max(low, min(high, number))


def setting(key, default=None):
    row = db().execute('SELECT value FROM studio_settings WHERE key=?', (key,)).fetchone()
    return row['value'] if row else default


def set_setting(key, value):
    conn = db()
    conn.execute('INSERT INTO studio_settings(key, value, updated) VALUES(?,?,?) '
                 'ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated=excluded.updated',
                 (key, value, now()))
    conn.commit()


# ------------------------------------------------------------- studio api ---
#
# Every action name, parameter and response field below is taken from the client.
# Where a field looks redundant or oddly named, it is because web/js/ already
# reads it that way.

BOOT_ID = str(uuid.uuid4())


HISTORY_PAGE_SIZE = 24


def _format_job_row(row):
    job = dict(row)
    # Derived, not stored. The cloud API computed this from whether an object
    # existed in the bucket; the client gates the whole thumbnail fetch on it
    # and silently falls back to "tap to load" when it is missing, which is
    # indistinguishable from a broken image.
    job['has_thumbnail'] = bool(job.get('thumbnail_key'))
    return job


def studio_status(query):
    """What the whole interface polls.

    The shape is dictated by refresh() in web/js/studio-transport.js, down to the
    camelCase retention keys sitting next to snake_case job columns.
    """
    app = query.get('app', ['studio'])[0]
    paged = (query.get('paged') or [''])[0] == '1'
    cutoff = now() - int(CONFIG['retention_hours']) * 3600
    conn = db()
    if paged:
        active_rows = conn.execute(
            'SELECT * FROM studio_jobs WHERE owner=? AND app=? AND '
            "status IN ('queued','running') ORDER BY created DESC, id DESC",
            (OWNER, app)).fetchall()
        terminal_rows = conn.execute(
            'SELECT * FROM studio_jobs WHERE owner=? AND app=? AND created>=? AND '
            "status NOT IN ('queued','running') ORDER BY created DESC, id DESC LIMIT ?",
            (OWNER, app, cutoff, HISTORY_PAGE_SIZE + 1)).fetchall()
        has_more = len(terminal_rows) > HISTORY_PAGE_SIZE
        page_rows = terminal_rows[:HISTORY_PAGE_SIZE]
        cursor = None
        if has_more and page_rows:
            last = page_rows[-1]
            cursor = {'beforeCreated': str(last['created']), 'beforeId': str(last['id'])}
        jobs = [_format_job_row(r) for r in active_rows] + [_format_job_row(r) for r in page_rows]
    else:
        rows = conn.execute(
            'SELECT * FROM studio_jobs WHERE owner=? AND app=? AND (created>=? OR '
            "status IN ('queued','running')) ORDER BY created DESC LIMIT 200",
            (OWNER, app, cutoff)).fetchall()
        jobs = [_format_job_row(r) for r in rows]
        has_more = False
        cursor = None

    stats = conn.execute(
        'SELECT COUNT(*) AS total, '
        "MIN(CASE WHEN status='complete' THEN updated ELSE NULL END) AS oldest_updated "
        'FROM studio_jobs WHERE owner=? AND app=? AND created>=? AND '
        "status NOT IN ('queued','running')",
        (OWNER, app, cutoff)).fetchone()
    history_count = int(stats['total'] or 0) if stats else 0
    oldest_updated = stats['oldest_updated'] if stats else None

    running = any(job['status'] == 'running' for job in jobs)
    return {
        'online': True,
        'hostState': 'busy' if running else 'ready',
        'jobs': jobs,
        'historyCursor': cursor,
        'historyHasMore': has_more,
        'historyCount': history_count,
        'historyOldestUpdated': oldest_updated,
        'retentionHours': CONFIG['retention_hours'],
        'retentionImages': CONFIG['retention_images'],
        'liteQueueActive': False,
        'liteJobRunning': False,
        # Not part of the original contract. The interface ignores unknown keys,
        # and a first-run user needs some way to see that the engine is missing.
        'engineReady': ENGINE.ready,
        'engineError': ENGINE.error,
        # Changes every time the server starts. The interface reloads itself when
        # it sees a new one, because the page has no other way to know its own
        # code is out of date - and the studio reopening the browser often just
        # focuses the tab that is already there, without reloading it. That is
        # how a fix can be installed, running, and apparently absent.
        'serverBoot': BOOT_ID,
        # Set once the watcher has seen a newer build. The page shows the pill
        # from this rather than asking the release server itself, so an open
        # studio notices a release without anyone reloading anything.
        'update': cached_update(),
    }


def studio_history(query):
    """Older terminal generations paged backward by (created, id)."""
    app = query.get('app', ['studio'])[0]
    cutoff = now() - int(CONFIG['retention_hours']) * 3600
    limit = int(bounded((query.get('limit') or ['40'])[0], 40, 1, 100))
    raw_before_created = (query.get('beforeCreated') or [''])[0]
    before_id = str((query.get('beforeId') or [''])[0] or '')
    conn = db()
    if raw_before_created and raw_before_created.lstrip('-').isdigit():
        before_created = int(raw_before_created)
        rows = conn.execute(
            'SELECT * FROM studio_jobs WHERE owner=? AND app=? AND created>=? AND '
            "status NOT IN ('queued','running') AND "
            '(created<? OR (created=? AND id<?)) '
            'ORDER BY created DESC, id DESC LIMIT ?',
            (OWNER, app, cutoff, before_created, before_created, before_id, limit + 1)).fetchall()
    else:
        rows = conn.execute(
            'SELECT * FROM studio_jobs WHERE owner=? AND app=? AND created>=? AND '
            "status NOT IN ('queued','running') "
            'ORDER BY created DESC, id DESC LIMIT ?',
            (OWNER, app, cutoff, limit + 1)).fetchall()
    has_more = len(rows) > limit
    page = [_format_job_row(r) for r in rows[:limit]]
    cursor = None
    if has_more and page:
        last = page[-1]
        cursor = {'beforeCreated': str(last['created']), 'beforeId': str(last['id'])}
    return {'jobs': page, 'hasMore': has_more, 'cursor': cursor}


def studio_config():
    """What the browser needs before it can read anything. No key required.

    Only the storage mode, deliberately: this is the one endpoint answered before
    any unlock step exists, so it says as little as possible.
    """
    return {
        'encryption': bool(CONFIG.get('encrypt_storage', False)),
        'engineReady': ENGINE.ready,
    }


# --------------------------------------------------------------- registry ---
#
# What is actually installed, as opposed to what the interface knows how to ask
# for. Until this existed the dropdowns offered every shipped checkpoint whether
# or not its weights were on disk, and picking an absent one failed inside
# ComfyUI with an error the user never saw.
#
# The file list per model is derived from the graph that model actually builds,
# not from a table kept alongside it. A table is a second copy of a fact that
# already lives in the builders, and it goes stale the first time someone changes
# which file a branch loads - the same trap as the capability lists the interface
# used to restate.

# ComfyUI resolves each loader against its own folder, and renamed two of them:
# text_encoders was clip, diffusion_models was unet. Both spellings are searched
# because an install of either vintage may be pointed at.
LOADER_FOLDERS = {
    'UNETLoader': ('diffusion_models', 'unet'),
    'CheckpointLoaderSimple': ('checkpoints',),
    'CLIPLoader': ('text_encoders', 'clip'),
    'DualCLIPLoader': ('text_encoders', 'clip'),
    'VAELoader': ('vae',),
    'LoraLoader': ('loras',),
    'UpscaleModelLoader': ('upscale_models',),
}
# The input each loader names its file in.
FILE_INPUTS = ('unet_name', 'ckpt_name', 'clip_name', 'clip_name1', 'clip_name2',
               'vae_name', 'lora_name', 'model_name')

SHIPPED_CHECKPOINTS = ('krea2_turbo', 'sdxl_cyberrealistic', 'anima_base', 'illustrious_base')


def model_files(orchestrator, model):
    """Every weight file the graph for this checkpoint loads.

    Built for a plain txt2img job: the edit modes add nodes but no new loaders,
    and building one graph per mode would triple the work for the same answer.
    """
    job = {'id': 'registry-probe', 'prompt': 'probe', 'ratio': 'square', 'seed': '1',
           'model': model, 'mode': 'txt2img', 'resolution': '1mp', 'upscale': False}
    try:
        graph = orchestrator.build_workflow(job)
    except Exception as exc:                               # noqa: BLE001 - reported per model
        return None, str(exc)
    wanted = []
    for node in graph.values():
        folders = LOADER_FOLDERS.get(str(node.get('class_type')))
        if not folders:
            continue
        for key in FILE_INPUTS:
            name = node.get('inputs', {}).get(key)
            if isinstance(name, str) and name:
                wanted.append((folders, name))
    return wanted, None


def model_roots(orchestrator):
    """(label, folder, writable) for every models folder ComfyUI reads.

    Mirrors what setup writes into extra_model_paths.yaml, because the panel
    saying a checkpoint is missing while ComfyUI loads it happily is worse than
    either being wrong on its own.

    Three things were being missed. The portable bundle keeps its models under
    ComfyUI/, not beside it, so on every portable install - which is what setup
    produces - the one path checked did not exist. The studio's own drop-in
    folder was not consulted at all. Neither was a borrowed folder, which is how
    a machine with an existing ComfyUI gets its weights, and the reason Krea 2
    Turbo read as "not installed" on a machine that had just generated with it.
    """
    candidates = [
        ('studio', ROOT / 'models', True),
        ('comfyui', orchestrator.COMFY_DIR / 'ComfyUI' / 'models', False),
        ('comfyui', orchestrator.COMFY_DIR / 'models', False),
    ]
    borrowed = CONFIG.get('models_path')
    if borrowed:
        candidates.append(('borrowed', Path(borrowed).expanduser(), False))
    roots, seen = [], set()
    for label, folder, writable in candidates:
        try:
            key = folder.resolve()
        except OSError:
            key = folder
        if key in seen:
            continue
        seen.add(key)
        roots.append((label, folder, writable))
    return roots


def find_weight(orchestrator, folders, name):
    """Where this file is, or None. Every folder ComfyUI would look in."""
    for _, root, _ in model_roots(orchestrator):
        for folder in folders:
            candidate = root / folder / name
            if candidate.exists():
                return candidate
    return None


def scan_checkpoints(orchestrator):
    entries = {}
    for model in SHIPPED_CHECKPOINTS:
        wanted, error = model_files(orchestrator, model)
        if wanted is None:
            entries[model] = {'available': False, 'missing': [], 'error': error}
            continue
        missing = [name for folders, name in wanted
                   if not find_weight(orchestrator, folders, name)]
        entries[model] = {
            'available': not missing,
            'missing': missing,
            'requires': [name for _, name in wanted],
        }
    return entries


CHECKPOINT_ARCH_KEY = 'checkpoint-arch:'


def checkpoint_architecture(orchestrator, stem, kind):
    """Which architecture the user has filed a dropped-in checkpoint under.

    Kept in studio_settings rather than a table of its own: it is one string
    per file, and the file may well be deleted tomorrow.

    Takes the orchestrator rather than reaching for ENGINE.module, because this
    runs while the registry is being built and anything that raises in there is
    swallowed into ready:false - which empties the whole panel rather than
    losing one row, and gives no hint which of a dozen scans went wrong.
    """
    chosen = setting(CHECKPOINT_ARCH_KEY + stem)
    if chosen in orchestrator.architectures_for(kind):
        return chosen
    return orchestrator.default_architecture_for(kind)


def scan_discovered_checkpoints(orchestrator):
    """Checkpoints the user dropped in, keyed the way a job would name them.

    The studio cannot tell from the file which architecture it wants - SDXL,
    SD 1.5, Pony and Illustrious are all "a checkpoint" - so it assumes SDXL,
    which is what most all-in-one checkpoints published today are, and the
    choice is changeable per file.
    """
    entries = {}
    try:
        discovered = orchestrator.discovered_checkpoints()
    except Exception:                                      # noqa: BLE001 - never 500 the registry
        logging.exception('Scanning for dropped-in checkpoints failed')
        return entries
    for stem, found in discovered.items():
        architecture = checkpoint_architecture(orchestrator, stem, found['kind'])
        key = orchestrator.checkpoint_key(architecture, stem)
        # A split model is the diffusion half only and loads the shared text
        # encoder and VAE beside it. These used to be assumed present, so a
        # model dropped into a studio that had not downloaded them was listed
        # as installed and then failed every job inside ComfyUI.
        wanted, _error = model_files(orchestrator, key)
        missing = [name for folders, name in (wanted or [])
                   if name != found['file'] and not find_weight(orchestrator, folders, name)]
        entries[key] = {
            'available': not missing,
            'custom': True,
            'label': stem,
            'stem': stem,
            'file': found['file'],
            'sizeMb': found['sizeMb'],
            'architecture': architecture,
            # Which pair of architectures this file can be filed under. A
            # one-file checkpoint and a diffusion model are not interchangeable,
            # so the panel offers only the pair that matches the folder it was
            # found in.
            'kind': found['kind'],
            'architectureOptions': list(orchestrator.architectures_for(found['kind'])),
            'missing': missing,
        }
    return entries


def studio_checkpoint_arch(body):
    """Re-file a dropped-in checkpoint under a different architecture."""
    stem = (body.get('stem') or '').strip()
    architecture = (body.get('architecture') or '').strip()
    orchestrator = ENGINE.module
    if not orchestrator:
        raise ApiError('The engine is not available.')
    if not stem:
        raise ApiError('No checkpoint given.')
    found = orchestrator.discovered_checkpoints().get(stem)
    if not found:
        raise ApiError('No such model on this PC.')
    if architecture not in orchestrator.architectures_for(found['kind']):
        raise ApiError('That architecture does not match where this file lives.')
    set_setting(CHECKPOINT_ARCH_KEY + stem, architecture)
    return {'ok': True, 'stem': stem, 'architecture': architecture,
            'key': orchestrator.checkpoint_key(architecture, stem)}


def scan_chat_models(orchestrator):
    """Which chat tiers have their weights, and the numbers the meter needs.

    ctx and image_tokens are published rather than restated in the HTML. The
    option elements carry data-ctx and data-image-tokens attributes that have to
    agree with CHAT_MODELS or the context meter misreports how full a
    conversation is - two hand-maintained copies of one fact.
    """
    entries = {}
    for key, spec in getattr(orchestrator, 'CHAT_MODELS', {}).items():
        weights = orchestrator.chat_model_path(spec['file'])
        projector = spec.get('mmproj')
        missing = []
        if not weights.exists():
            missing.append(spec['file'])
        # Vision degrades to text-only with nothing but a log line if the
        # projector is absent, so it is reported rather than inferred.
        vision = bool(projector)
        if projector and not orchestrator.chat_model_path(projector).exists():
            vision = False
            missing.append(projector)
        entries[key] = {
            'available': weights.exists(),
            'label': spec.get('label') or key,
            'ctx': spec.get('ctx'),
            'image_tokens': spec.get('image_tokens'),
            'vision': vision,
            'missing': missing,
        }
    return entries


# ------------------------------------------------------------------ loras ---
#
# Two sources, and the difference matters.
#
# `models/loras` inside the studio is ours: writable, drag-and-drop, gitignored so
# nothing a user drops there is ever committed or shipped. Folders listed in
# `lora_paths` are theirs: read from, never written to, never renamed, never
# moved. That is the same rule the install follows for ComfyUI itself - the
# install is cheap and the models are expensive, so borrow the expensive thing by
# reference and own the cheap one.
#
# One consequence worth knowing before wiring the Models panel to it: ComfyUI
# resolves lora_name against its own folders, so a file in the studio's folder is
# only loadable once ComfyUI has been told that folder exists. With the studio's
# own ComfyUI that is ours to configure. With a borrowed one it is not, and
# editing someone's extra_model_paths.yaml to make it work would be exactly the
# destructive coexistence this product rejected. So a LoRA ComfyUI cannot
# currently resolve is reported as such rather than offered and failed.

def lora_sources(orchestrator):
    """(label, folder, writable) for every place LoRAs are read from.

    De-duplicated by resolved path. Pointing lora_paths at the ComfyUI folder the
    studio already reads is the obvious thing for a user to do - setup writes
    exactly that when borrowing an existing install - and without this every LoRA
    would be found twice and half of them reported as shadowing the other half.
    """
    candidates = [(label, root / 'loras', writable)
                  for label, root, writable in model_roots(orchestrator)]
    for extra in CONFIG.get('lora_paths') or []:
        candidates.append(('external', Path(extra).expanduser(), False))
    sources, seen = [], set()
    for label, folder, writable in candidates:
        try:
            key = folder.resolve()
        except OSError:
            key = folder
        if key in seen:
            continue
        seen.add(key)
        sources.append((label, folder, writable))
    return sources


def scan_loras(orchestrator):
    """Every LoRA file found, merged with whatever the user has told us about it.

    Keyed by the file stem, which is also what ComfyUI is given as lora_name. Two
    files with the same stem in different folders collide; the first source wins
    and the loser is reported, because silently picking one would make a layer
    apply weights the user did not choose.
    """
    metadata = {row['id']: dict(row) for row in
                db().execute('SELECT * FROM studio_loras').fetchall()}
    found, shadowed = {}, []
    for source, folder, writable in lora_sources(orchestrator):
        if not folder.is_dir():
            continue
        for path in sorted(folder.rglob('*.safetensors')):
            key = path.stem
            if key in found:
                shadowed.append({'id': key, 'source': source, 'path': str(path)})
                continue
            meta = metadata.get(key) or {}
            # What ComfyUI is given as lora_name, and whether it can resolve it.
            #
            # Every folder in extra_model_paths.yaml is loadable: the studio's
            # own, ComfyUI's, and a borrowed one. A folder listed only in
            # lora_paths is not - it is visible to the panel and invisible to the
            # engine, so it is reported as such rather than offered and then
            # failed halfway through a job.
            loadable = source != 'external'
            try:
                lora_name = str(path.relative_to(folder)).replace(chr(92), '/')
            except ValueError:
                lora_name, loadable = path.name, False
            found[key] = {
                'id': key,
                'label': meta.get('label') or key.replace('_', ' ').replace('-', ' ').strip(),
                'architecture': meta.get('architecture'),
                'triggers': meta.get('triggers') or '',
                'implied': meta.get('implied') or '',
                'defaultStrength': meta.get('default_strength', 0.8),
                'enabled': bool(meta.get('enabled', 1)),
                'configured': bool(meta.get('architecture')),
                'source': source,
                'writable': writable,
                'loadable': loadable,
                'loraName': lora_name,
                'sizeMb': round(path.stat().st_size / (1024 * 1024), 1),
            }
    return found, shadowed


def studio_loras_save(body):
    """Record what the user told us about one LoRA."""
    lora_id = body.get('id')
    if not lora_id:
        raise ApiError('No LoRA given.')
    architecture = body.get('architecture') or None
    known = ('krea2', 'sdxl', 'anima', 'illustrious')
    if architecture and architecture not in known:
        raise ApiError('Unknown architecture: ' + str(architecture))
    strength = bounded(body.get('defaultStrength'), 0.8, 0.1, 1.5)
    conn = db()
    conn.execute(
        'INSERT INTO studio_loras(id, label, architecture, triggers, implied, '
        'default_strength, enabled, updated) VALUES(?,?,?,?,?,?,?,?) '
        'ON CONFLICT(id) DO UPDATE SET label=excluded.label, '
        'architecture=excluded.architecture, triggers=excluded.triggers, '
        'implied=excluded.implied, default_strength=excluded.default_strength, '
        'enabled=excluded.enabled, updated=excluded.updated',
        (lora_id, body.get('label') or None, architecture,
         (body.get('triggers') or '').strip(), (body.get('implied') or '').strip(),
         strength, 1 if body.get('enabled', True) else 0, now()))
    conn.commit()
    return {'ok': True, 'id': lora_id}


def studio_loras_forget(body):
    """Drop the metadata for a LoRA. Never touches the file."""
    conn = db()
    conn.execute('DELETE FROM studio_loras WHERE id=?', (body.get('id'),))
    conn.commit()
    return {'ok': True}


CHARACTER_GROUPS = ('OC', 'IRL', 'Commission', 'Celeb', 'Other')
KNOWN_ARCHITECTURES = ('krea2', 'sdxl', 'anima', 'illustrious')
_CHARACTER_SLUG_RE = re.compile(r'[^a-z0-9]+')
_PORTRAIT_KEY_RE = re.compile(r'^[a-z0-9_]{1,120}$')


def slugify_character_id(raw):
    slug = _CHARACTER_SLUG_RE.sub('_', str(raw or '').lower()).strip('_')[:80]
    if not slug:
        slug = 'character_' + secrets.token_hex(3)
    if slug.startswith(('desc_', 'meta_')) or slug == 'meta_all':
        slug = 'char_' + slug[:74]
    return slug


def _parse_json_list(raw):
    if isinstance(raw, list):
        return raw
    if isinstance(raw, str) and raw.strip():
        try:
            parsed = json.loads(raw)
            if isinstance(parsed, list):
                return parsed
        except json.JSONDecodeError:
            pass
    return []


def list_characters(found_loras=None):
    """All saved characters, enriched with live LoRA file resolution."""
    found = found_loras or {}
    rows = db().execute(
        'SELECT * FROM studio_characters WHERE owner=? ORDER BY label COLLATE NOCASE ASC',
        (OWNER,)).fetchall()
    characters = {}
    for row in rows:
        char_id = row['id']
        lora_id = (row['lora_id'] or '').strip()
        raw_versions = _parse_json_list(row['versions_json'])
        default_ver = (row['default_version'] or '').strip()
        versions = []
        for idx, ver in enumerate(raw_versions):
            if not isinstance(ver, dict):
                continue
            ver_lora_id = str(ver.get('loraId') or ver.get('lora_id') or '').strip()
            if not ver_lora_id:
                continue
            ver_id = _CHARACTER_SLUG_RE.sub('_', str(ver.get('id') or f'v{idx + 1}').lower()).strip('_') or f'v{idx + 1}'
            ver_label = str(ver.get('label') or ver_id).strip()
            ver_trigger = str(ver.get('trigger') or '').strip()
            lora_entry = found.get(ver_lora_id)
            versions.append({
                'id': ver_id,
                'label': ver_label,
                'loraId': ver_lora_id,
                'file': lora_entry['loraName'] if lora_entry else ver_lora_id,
                'available': bool(lora_entry and lora_entry.get('loadable')),
                'trigger': ver_trigger,
                'default': bool(ver.get('default')) or (ver_id == default_ver),
            })
        if versions and not any(v['default'] for v in versions):
            versions[0]['default'] = True
            default_ver = versions[0]['id']
        elif versions:
            default_ver = next((v['id'] for v in versions if v['default']), versions[0]['id'])

        primary_lora = found.get(lora_id) if lora_id else None
        if not lora_id and versions:
            default_entry = next((v for v in versions if v['default']), versions[0])
            lora_id = default_entry['loraId']
            primary_lora = found.get(lora_id)

        primary_available = bool(primary_lora and primary_lora.get('loadable'))
        any_ver_available = any(v['available'] for v in versions)
        available = primary_available or any_ver_available
        tags = [str(t).strip() for t in _parse_json_list(row['tags_json']) if str(t).strip()]
        aliases = [str(a).strip() for a in _parse_json_list(row['aliases_json']) if str(a).strip()]
        created_ts = int(row['created'] or row['updated'] or now())
        created_date = time.strftime('%Y-%m-%d', time.gmtime(created_ts))
        group_name = row['group_name'] if row['group_name'] in CHARACTER_GROUPS else 'OC'
        category = (row['category'] or '').strip()
        characters[char_id] = {
            'id': char_id,
            'label': row['label'] or char_id,
            'architecture': row['architecture'] or 'krea2',
            'role': 'Character',
            'group': group_name,
            'category': category,
            'collections': [category] if category else [],
            'loraId': lora_id,
            'file': primary_lora['loraName'] if primary_lora else lora_id,
            'versions': versions,
            'defaultVersion': default_ver,
            'triggers': row['triggers'] or '',
            'trigger': row['triggers'] or '',
            'implied': row['implied'] or '',
            'defaultStrength': float(row['default_strength'] or 0.9),
            'tags': tags,
            'aliases': aliases,
            'authorNote': row['author_note'] or '',
            'enabled': bool(row['enabled']),
            'available': available,
            'status': 'active' if row['enabled'] else 'archived',
            'createdAt': created_date,
            'updated': int(row['updated'] or created_ts),
        }
    return characters


def studio_characters_list():
    orchestrator = ENGINE.load()
    found = {}
    if orchestrator is not None:
        try:
            found, _ = scan_loras(orchestrator)
        except Exception:                                  # noqa: BLE001 - still list characters
            found = {}
    return {'characters': list_characters(found)}


def studio_characters_save(body):
    """Create or update a character backed by one or more local LoRA files."""
    label = str(body.get('label') or '').strip()[:80]
    if not label:
        raise ApiError('Character name is required.')
    raw_id = str(body.get('id') or '').strip()
    char_id = slugify_character_id(raw_id or label)
    architecture = str(body.get('architecture') or 'krea2').strip()
    if architecture not in KNOWN_ARCHITECTURES:
        raise ApiError('Unknown architecture: ' + architecture)
    lora_id = str(body.get('loraId') or body.get('lora_id') or '').strip()
    raw_versions = body.get('versions') if isinstance(body.get('versions'), list) else []
    cleaned_versions = []
    seen_ver_ids = set()
    for idx, ver in enumerate(raw_versions[:16]):
        if not isinstance(ver, dict):
            continue
        ver_lora = str(ver.get('loraId') or ver.get('lora_id') or '').strip()
        if not ver_lora:
            continue
        base_ver_id = _CHARACTER_SLUG_RE.sub('_', str(ver.get('id') or ver.get('label') or f'v{idx + 1}').lower()).strip('_') or f'v{idx + 1}'
        ver_id = base_ver_id[:32]
        suffix = 2
        while ver_id in seen_ver_ids:
            ver_id = f'{base_ver_id[:28]}_{suffix}'
            suffix += 1
        seen_ver_ids.add(ver_id)
        cleaned_versions.append({
            'id': ver_id,
            'label': str(ver.get('label') or ver_id).strip()[:48],
            'loraId': ver_lora,
            'trigger': str(ver.get('trigger') or '').strip()[:500],
            'default': bool(ver.get('default')),
        })
    if not lora_id and not cleaned_versions:
        raise ApiError('Choose at least one LoRA file for this character.')
    default_ver = str(body.get('defaultVersion') or '').strip()
    if cleaned_versions:
        if default_ver and any(v['id'] == default_ver for v in cleaned_versions):
            for v in cleaned_versions:
                v['default'] = (v['id'] == default_ver)
        elif not any(v['default'] for v in cleaned_versions):
            cleaned_versions[0]['default'] = True
            default_ver = cleaned_versions[0]['id']
        else:
            default_ver = next(v['id'] for v in cleaned_versions if v['default'])
        if not lora_id:
            lora_id = next((v['loraId'] for v in cleaned_versions if v['default']), cleaned_versions[0]['loraId'])
    else:
        default_ver = ''

    group_name = str(body.get('group') or 'OC').strip()
    if group_name not in CHARACTER_GROUPS:
        group_name = 'OC'
    category = str(body.get('category') or '').strip()[:40]
    raw_tags = body.get('tags')
    if isinstance(raw_tags, str):
        tags = [t.strip()[:40] for t in raw_tags.split(',') if t.strip()][:20]
    elif isinstance(raw_tags, list):
        tags = [str(t).strip()[:40] for t in raw_tags if str(t).strip()][:20]
    else:
        tags = []
    raw_aliases = body.get('aliases')
    if isinstance(raw_aliases, str):
        aliases = [a.strip()[:40] for a in raw_aliases.split(',') if a.strip()][:20]
    elif isinstance(raw_aliases, list):
        aliases = [str(a).strip()[:40] for a in raw_aliases if str(a).strip()][:20]
    else:
        aliases = []

    strength = bounded(body.get('defaultStrength'), 0.9, 0.1, 1.5)
    triggers = str(body.get('triggers') if body.get('triggers') is not None else (body.get('trigger') or '')).strip()[:500]
    implied = str(body.get('implied') or '').strip()[:500]
    author_note = str(body.get('authorNote') or '').strip()[:1000]
    enabled = 1 if body.get('enabled', True) else 0
    ts = now()
    conn = db()
    conn.execute(
        'INSERT INTO studio_characters('
        'id, owner, label, architecture, lora_id, versions_json, default_version, '
        'triggers, implied, default_strength, group_name, category, tags_json, '
        'aliases_json, author_note, enabled, created, updated'
        ') VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) '
        'ON CONFLICT(id) DO UPDATE SET '
        'label=excluded.label, architecture=excluded.architecture, lora_id=excluded.lora_id, '
        'versions_json=excluded.versions_json, default_version=excluded.default_version, '
        'triggers=excluded.triggers, implied=excluded.implied, '
        'default_strength=excluded.default_strength, group_name=excluded.group_name, '
        'category=excluded.category, tags_json=excluded.tags_json, '
        'aliases_json=excluded.aliases_json, author_note=excluded.author_note, '
        'enabled=excluded.enabled, updated=excluded.updated',
        (char_id, OWNER, label, architecture, lora_id, json.dumps(cleaned_versions),
         default_ver, triggers, implied, strength, group_name, category,
         json.dumps(tags), json.dumps(aliases), author_note, enabled, ts, ts))
    conn.commit()
    return {'ok': True, 'id': char_id}


def studio_characters_delete(body):
    """Remove a character record. Never deletes the underlying .safetensors file."""
    char_id = str(body.get('id') or '').strip()
    if not char_id:
        raise ApiError('No character id given.')
    conn = db()
    conn.execute('DELETE FROM studio_characters WHERE id=? AND owner=?', (char_id, OWNER))
    conn.execute('DELETE FROM studio_portraits WHERE owner=? AND character IN (?, ?)',
                 (OWNER, char_id, 'desc_' + char_id))
    conn.commit()
    return {'ok': True, 'id': char_id}


def studio_portraits_list(query):
    raw_since = (query.get('since') or ['0'])[0]
    try:
        since = max(0, int(float(raw_since)))
    except (TypeError, ValueError):
        since = 0
    rows = db().execute(
        'SELECT character, payload, updated FROM studio_portraits '
        'WHERE owner=? AND updated>? ORDER BY updated ASC LIMIT 200',
        (OWNER, since)).fetchall()
    return {'portraits': [dict(row) for row in rows]}


def studio_portraits_save(body):
    character = str(body.get('character') or '').strip()
    if not _PORTRAIT_KEY_RE.match(character):
        raise ApiError('Invalid portrait key.')
    payload = str(body.get('payload') or '')
    if len(payload) > 1024 * 1024:
        raise ApiError('Portrait payload is too large.')
    conn = db()
    prev = conn.execute('SELECT MAX(updated) AS max_u FROM studio_portraits WHERE owner=?',
                        (OWNER,)).fetchone()
    prev_ts = int(prev['max_u'] or 0) if prev else 0
    ts = max(int(time.time() * 1000), prev_ts + 1)
    conn.execute(
        'INSERT INTO studio_portraits(owner, character, payload, updated) VALUES(?,?,?,?) '
        'ON CONFLICT(owner, character) DO UPDATE SET payload=excluded.payload, '
        'updated=excluded.updated',
        (OWNER, character, payload, ts))
    conn.commit()
    return {'ok': True, 'updated': ts}


def lora_specs():
    """The registry the orchestrator validates a job's LoRA list against.

    Only configured, enabled layers whose file ComfyUI can actually load. An
    unconfigured one has no architecture, and selected_loras compares against
    exactly that - so offering it would fail the job rather than the selection.
    """
    orchestrator = ENGINE.load()
    if orchestrator is None:
        return {}
    found, _ = scan_loras(orchestrator)
    specs = {}
    for key, entry in found.items():
        if not (entry['configured'] and entry['enabled'] and entry['loadable']):
            continue
        # Field names are the engine's, not ours: add_trigger_words reads
        # spec['trigger'] - singular, and a comma-separated string - while
        # 'implied' is iterated as a sequence of terms. Getting either shape wrong
        # loses the trigger words silently, which looks like a LoRA that does
        # nothing rather than like a bug.
        specs[key] = {
            'arch': entry['architecture'],
            'file': entry['loraName'],
            'strength': entry['defaultStrength'],
            'trigger': entry['triggers'],
            'implied': [t.strip() for t in entry['implied'].split(',') if t.strip()],
        }

    # Include enabled characters so selected_loras resolves both single-file and
    # multi-version characters directly without requiring separate LoRA setup.
    for char_id, char in list_characters(found).items():
        if not (char['enabled'] and char['available']):
            continue
        versions_map = {}
        for ver in char.get('versions') or []:
            if ver.get('available') and ver.get('file'):
                versions_map[ver['id']] = {
                    'file': ver['file'],
                    'trigger': (ver.get('trigger') or char.get('triggers') or '').strip(),
                }
        primary_entry = found.get(char['loraId']) if char.get('loraId') else None
        primary_file = (primary_entry['loraName']
                        if (primary_entry and primary_entry.get('loadable'))
                        else (next(iter(versions_map.values()))['file'] if versions_map else None))
        if not primary_file:
            continue
        specs[char_id] = {
            'arch': char['architecture'],
            'file': primary_file,
            'strength': char['defaultStrength'],
            'trigger': char['triggers'],
            'implied': [t.strip() for t in char['implied'].split(',') if t.strip()],
            'versions': versions_map,
            'default_version': char.get('defaultVersion') or '',
        }
    return specs


_PROFILE = {'value': None}


def hardware_profile(orchestrator, refresh=False):
    """What this machine can run. Computed once; the card does not change.

    Cached because probing shells out to nvidia-smi and the registry is fetched
    on every page load. Rescan forces it, which is also the escape hatch for
    someone who has just swapped a GPU.
    """
    if _PROFILE['value'] is None or refresh:
        _PROFILE['value'] = tuning.build_profile(
            getattr(orchestrator, 'CHAT_MODELS', {}),
            default_model=getattr(orchestrator, 'DEFAULT_CHAT_MODEL', None))
    return _PROFILE['value']


def apply_profile(orchestrator):
    """Replace the constants that were measurements of one particular card.

    SAFE_VRAM_MB decides whether there is room to load a model at all, and was
    9500 because that is what fit on the machine this was written on. On a 24 GB
    card it refuses work it could do; on an 8 GB card it attempts work it cannot.
    """
    profile = hardware_profile(orchestrator)
    safe = profile.get('safeVramMib')
    if safe:
        orchestrator.SAFE_VRAM_MB = int(safe)

    # Apply the shortened windows to the engine's own table, not only to what the
    # interface displays. Without this the picker would say "shorter memory on
    # this GPU" while llama-server was still launched at the full window and
    # failed to allocate - the tuning would be a label rather than a change.
    #
    # Only ever downward. A card with room to spare does not get a longer window
    # than the tier was measured at, because ctx affects output quality and the
    # figure was chosen deliberately.
    for key, tier in (profile.get('tiers') or {}).items():
        spec = orchestrator.CHAT_MODELS.get(key)
        if not spec or not tier.get('fits') or not tier.get('ctx'):
            continue
        if tier['ctx'] < (spec.get('ctx') or 0):
            spec['ctx'] = int(tier['ctx'])
    print('  hardware ' + tuning.describe(profile))
    for note in profile.get('notes') or []:
        print('           ' + note)
    return profile


def studio_registry():
    """What this machine can actually run right now."""
    orchestrator = ENGINE.load()
    if orchestrator is None:
        return {'ready': False, 'error': ENGINE.error, 'checkpoints': {},
                'chatModels': {}, 'loras': {}, 'characters': list_characters({})}
    try:
        loras, shadowed = scan_loras(orchestrator)
        return {
            'ready': True,
            'profile': hardware_profile(orchestrator),
            'comfyDir': str(orchestrator.COMFY_DIR),
            'modelsDir': str(orchestrator.MODELS_DIR),
            'checkpoints': dict(scan_checkpoints(orchestrator),
                                **scan_discovered_checkpoints(orchestrator)),
            'chatModels': scan_chat_models(orchestrator),
            'loras': loras,
            'characters': list_characters(loras),
            'shadowedLoras': shadowed,
            'res4lyfAvailable': orchestrator.res4lyf_available(),
            # Where a dropped-in checkpoint is looked for. Published so the
            # panel can print it: a folder nobody put anything in and a scan
            # that quietly failed look identical from the outside.
            'checkpointFolders': [str(folder) for folder in orchestrator.checkpoint_folders()],
            'modelFolders': [{'kind': kind, 'path': str(folder)}
                             for kind, folder in orchestrator.model_folders()],
        }
    except Exception as exc:                               # noqa: BLE001 - never 500 the page
        traceback.print_exc()
        return {'ready': False, 'error': str(exc), 'checkpoints': {},
                'chatModels': {}, 'loras': {}, 'characters': {}}


# ------------------------------------------------------------- settings ---
#
# Everything adjustable, in one place, written to config.json.
#
# These were scattered: some in a models panel, some in a theme dialog, and the
# rest only in a file somebody had to find and edit by hand - which meant in
# practice nobody changed them, and the one that matters most on a small card
# (how much video memory the image engine may hold) could not be changed at all
# because nothing read it.
#
# Each setting declares its own type and bounds, so one list drives both the
# checking here and the controls in the browser. A setting the interface does
# not know how to draw is not a setting anybody can use.
SETTINGS = (
    # key, kind, default, bounds/options, section, label, help
    ('vram_mode', 'choice', 'auto',
     ('auto', 'high', 'normal', 'low', 'minimum'), 'performance',
     'Video memory use',
     'How much of the graphics card the image engine may hold at once. Auto '
     'decides from your card and is right for almost everyone. The lower '
     'settings trade speed for fitting in less memory - try Low if generation '
     'fails, or if the machine becomes unusable while it runs.'),
    # Options are filled in at request time from the tiers that exist, because
    # the list is the orchestrator's and restating it here would be a second
    # copy to keep in step.
    ('default_chat_model', 'choice', '', 'chat-models', 'models',
     'Chat model to start with',
     'Which model a new conversation uses. Automatic picks the best one whose '
     'weights are actually on this PC. A model you choose here is still '
     'skipped if its file is missing, rather than failing the conversation.'),
    ('keep_chat_loaded', 'bool', False, None, 'performance',
     'Keep the chat model loaded',
     'Faster replies, using video memory the image engine could have. Off '
     'means the chat model makes way when you generate an image. Ignored on a '
     'card too small to hold both at once, because the alternative is images '
     'that fail rather than chat that is quick.'),
    ('idle_unload_minutes', 'number', 5, (0, 240), 'performance',
     'Free memory when idle (minutes)',
     'After this long with nothing generating or chatting, the engines are '
     'stopped so the graphics card and RAM are free for other things, games '
     'included. The next job starts them again, which takes up to a minute. '
     '0 keeps them running until you close the studio.'),
    ('retention_hours', 'number', 72, (1, 8760), 'storage',
     'Keep images for (hours)',
     'Generated images are deleted after this long. You are warned before '
     'anything goes.'),
    ('retention_images', 'number', 40, (1, 10000), 'storage',
     'Keep at most (images)',
     'The oldest image is deleted once there are more than this.'),
    ('check_updates', 'bool', True, None, 'updates',
     'Check for new builds',
     'Asks the release server every few minutes whether a newer build exists. '
     'Nothing is downloaded or installed without you pressing the button.'),
    ('update_url', 'text', DEFAULTS['update_url'], None, 'updates',
     'Release address',
     'Where the studio looks for new builds. Leave this alone unless you were '
     'told to change it. Empty turns updating off entirely.'),
    ('open_browser', 'bool', True, None, 'general',
     'Open the studio when it starts',
     'Opens your browser on launch. Turn it off if you would rather open the '
     'address yourself.'),
    ('gpu_vendor', 'choice', '', ('', 'nvidia', 'amd', 'intel', 'cpu'),
     'advanced', 'Graphics card type',
     'Which engine builds the installer downloads. Detected automatically - '
     'set this only if that guess was wrong.'),
    ('comfy_port', 'number', 8189, (1024, 65535), 'advanced',
     'Image engine port',
     'Change only if something else on this PC already uses it.'),
    ('llm_port', 'number', 8080, (1024, 65535), 'advanced',
     'Chat engine port',
     'Change only if something else on this PC already uses it. 8080 is busy '
     'on a lot of machines.'),
    ('models_path', 'text', '', None, 'advanced',
     'Borrowed models folder',
     'A models folder belonging to another installation. Read from, never '
     'written to. Empty means use only this studio own folder.'),
)

SETTING_SECTIONS = (
    ('models', 'Models',
     'Which model the studio reaches for by default. What each model is, and '
     'which pipeline it runs on, is in the Models panel.'),
    ('performance', 'Performance',
     'How the engines use this machine. These take effect the next time an '
     'engine starts.'),
    ('storage', 'Storage', 'How long generated images are kept.'),
    ('updates', 'Updates', 'Where new builds come from, and whether to look.'),
    ('general', 'General', None),
    ('advanced', 'Advanced',
     'Rarely needed. A wrong value here can stop the studio working, and every '
     'one of them can be put back.'),
)


def chat_model_options():
    """'' plus every chat tier the orchestrator knows, for the picker."""
    orchestrator = ENGINE.module
    if not orchestrator:
        return ('',)
    return ('',) + tuple(getattr(orchestrator, 'CHAT_MODELS', {}))


def setting_options(spec):
    """What a choice setting may be set to, resolving the dynamic ones."""
    if spec[1] != 'choice':
        return None
    return chat_model_options() if spec[3] == 'chat-models' else tuple(spec[3])


def setting_spec(key):
    for spec in SETTINGS:
        if spec[0] == key:
            return spec
    return None


def coerce_setting(spec, value):
    """One submitted value, checked against what the setting says it is."""
    key, kind, bounds = spec[0], spec[1], spec[3]
    if kind == 'bool':
        return bool(value)
    if kind == 'number':
        try:
            number = int(float(value))
        except (TypeError, ValueError):
            raise ApiError(key + ' needs a number.')
        low, high = bounds
        if not low <= number <= high:
            raise ApiError('%s has to be between %d and %d.' % (key, low, high))
        return number
    if kind == 'choice':
        text = str(value or '')
        if text not in (setting_options(spec) or ()):
            raise ApiError('%s cannot be set to that.' % key)
        return text
    return str(value or '').strip()


def chat_model_labels():
    """Readable names for the chat tiers, so the picker is not raw keys."""
    orchestrator = ENGINE.module
    labels = {'': 'Automatic'}
    for key, spec in getattr(orchestrator, 'CHAT_MODELS', {}).items():
        labels[key] = spec.get('label') or key
    return labels


def studio_settings():
    """Every adjustable setting, its value now, and what it means."""
    values = {spec[0]: CONFIG.get(spec[0], spec[2]) for spec in SETTINGS}
    fields = [{'key': spec[0], 'kind': spec[1], 'default': spec[2],
               'options': list(setting_options(spec) or []) if spec[1] == 'choice' else None,
               'labels': chat_model_labels() if spec[0] == 'default_chat_model' else None,
               'min': spec[3][0] if spec[1] == 'number' else None,
               'max': spec[3][1] if spec[1] == 'number' else None,
               'section': spec[4], 'label': spec[5], 'help': spec[6]}
              for spec in SETTINGS]
    return {
        'values': values,
        'fields': fields,
        'sections': [{'key': k, 'label': l, 'help': h}
                     for k, l, h in SETTING_SECTIONS],
        # Context shown beside the controls, so a choice like video memory can
        # be made against what this machine actually has rather than guessed.
        'machine': tuning.probe_hardware(),
        'paths': {'studio': str(ROOT), 'images': str(IMAGES_DIR),
                  'config': str(ROOT / 'config.json')},
        'build': build_version.describe()['label'],
    }


def studio_save_settings(body):
    """Write changed settings to config.json, and say what needs a restart."""
    given = body.get('values')
    if not isinstance(given, dict):
        raise ApiError('No settings were sent.')

    changed = {}
    for key, value in given.items():
        spec = setting_spec(key)
        if spec:                                           # ignore anything unknown
            changed[key] = coerce_setting(spec, value)
    if not changed:
        return {'ok': True, 'saved': [], 'restartFor': []}

    path = ROOT / 'config.json'
    try:
        current = json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        current = {}
    for key, value in changed.items():
        # A setting left at its default is removed rather than written, so
        # config.json stays a record of decisions somebody made rather than a
        # frozen copy of every default that then cannot follow a later change.
        if value == setting_spec(key)[2]:
            current.pop(key, None)
        else:
            current[key] = value
    try:
        with open(path, 'w', encoding='utf-8', newline=chr(10)) as handle:
            handle.write(json.dumps(current, indent=2) + chr(10))
    except OSError as exc:
        raise ApiError('Could not write config.json: ' + str(exc)[:120])

    CONFIG.update(changed)
    # Retention is read from CONFIG per request, so it is already live. What an
    # engine reads once at launch is not, and saying so beats a setting that
    # looks applied and is not.
    needs_restart = ('vram_mode', 'comfy_port', 'llm_port', 'models_path',
                     'gpu_vendor', 'keep_chat_loaded')
    return {'ok': True, 'saved': sorted(changed),
            'restartFor': sorted(k for k in changed if k in needs_restart)}


def studio_version():
    """Which build this is, and the whole version log.

    Answered without a key and without touching the network: it reads two files
    that shipped with the build. The interface asks once, on load, and shows the
    number faintly in the corner.
    """
    return build_version.describe()


def studio_manual_pdf():
    """Serve the publication-grade User Manual PDF directly."""
    pdf_path = STUDIO / 'USER_MANUAL.pdf'
    if not pdf_path.exists():
        raise ApiError('User manual PDF not found', 404)
    return pdf_path.read_bytes(), 'application/pdf'


def studio_manual():
    """Return the raw markdown User Manual text."""
    manual_path = STUDIO / 'MANUAL.md'
    if not manual_path.exists():
        raise ApiError('User manual not found', 404)
    return {'content': manual_path.read_text(encoding='utf-8')}


# The update check runs here, on a timer, rather than in the browser.
#
# It used to be one fetch six seconds after the page loaded, and never again.
# A studio left open did not notice a release until somebody reloaded the tab,
# which is not something to ask of the people this is for - and the publish
# script cheerfully claimed every studio would offer it "within a few minutes",
# which was simply untrue.
#
# Doing it in the server means one request per machine no matter how many tabs
# are open, and the browser learns about it through the status poll it already
# makes every few seconds. So nothing new is fetched by the page at all, and
# the pill appears on its own.
UPDATE_EVERY = 300
UPDATE_STATE = {'info': None, 'checked': 0.0}


def update_watcher():
    """Ask the release server what the newest build is, forever, quietly."""
    first = True
    while True:
        # A little after startup rather than during it: the first seconds are
        # busy with the database, the engine and the browser opening, and this
        # is the least urgent thing the studio does.
        time.sleep(20 if first else UPDATE_EVERY)
        first = False
        try:
            info = updater.check(CONFIG.get('update_url'))
            UPDATE_STATE['info'] = info
            UPDATE_STATE['checked'] = time.time()
            if info.get('available'):
                logging.info('Update available: %s', info.get('version') or info.get('latest'))
        except Exception as exc:                           # noqa: BLE001 - offline is normal
            # Offline, rate limited, DNS down, laptop asleep. None of it is the
            # user's problem and none of it is worth a banner; the next pass in
            # five minutes will try again.
            logging.debug('Update check failed: %s', exc)


def cached_update():
    """What the watcher last saw, for anything that should not block on a fetch."""
    if not CONFIG.get('check_updates', True):
        return None
    return UPDATE_STATE['info']


def studio_update_now():
    """Check the release server this second, rather than waiting for the timer.

    The watcher runs every five minutes and says nothing in between, so "has it
    not arrived yet, or is something broken?" had no answer short of reading a
    log. This is the answer: press it, and the reply is what the release server
    said just now.
    """
    if not CONFIG.get('check_updates', True):
        raise ApiError('Update checking is turned off in config.json.')
    try:
        info = updater.check(CONFIG.get('update_url'))
    except updater.UpdateError as exc:
        raise ApiError(str(exc))
    except Exception as exc:                               # noqa: BLE001 - network
        logging.warning('Manual update check failed: %s', exc)
        raise ApiError('Could not reach the release server. ' + str(exc)[:160])
    UPDATE_STATE['info'] = info
    UPDATE_STATE['checked'] = time.time()
    return dict(info, checkedAgo=0)


def studio_update_check():
    """What the latest release is. Reads only; installs nothing.

    Answers from the watcher's last look rather than fetching, so the browser
    can ask as often as it likes without a request leaving the machine. Only a
    studio whose watcher has not run yet goes to the network here.
    """
    if not CONFIG.get('check_updates', True):
        return {'configured': False, 'available': False,
                'reason': 'Update checking is turned off in config.json.'}
    cached = UPDATE_STATE['info']
    if cached is not None:
        return dict(cached, checkedAgo=int(time.time() - UPDATE_STATE['checked']),
                    checkEvery=UPDATE_EVERY)
    try:
        info = updater.check(CONFIG.get('update_url'))
        UPDATE_STATE['info'] = info
        UPDATE_STATE['checked'] = time.time()
        return info
    except updater.UpdateError as exc:
        raise ApiError(str(exc))
    except Exception as exc:                               # noqa: BLE001 - network
        # Not being able to reach a release server is ordinary, and not a reason
        # to show somebody a traceback.
        logging.warning('Update check failed: %s', exc)
        raise ApiError('Could not reach the update server. ' + str(exc)[:160])


def studio_update_apply():
    """Download, verify, stage and install the latest release.

    Deliberately not restarting afterwards. Replacing the files is safe while
    the server runs - Python read them at import and closed them - but a process
    that relaunches itself has to get that exactly right on a machine nobody can
    see, and getting it wrong leaves somebody with nothing running.
    """
    if not CONFIG.get('check_updates', True):
        raise ApiError('Update checking is turned off in config.json.')
    try:
        info = updater.check(CONFIG.get('update_url'))
        if not info.get('available'):
            return {'ok': False, 'reason': 'There is no newer release than this build.'}
        logging.info('Updating from %s to %s', info.get('installed'), info.get('latest'))
        archive = updater.download(info)
        staged, count = updater.stage(archive)
        written = updater.apply(staged)
        updater.cleanup()
        logging.info('Update applied: %d file(s) from %s', written, info.get('version'))
        return {'ok': True, 'version': info.get('version'), 'files': written,
                'staged': count,
                'restart': 'Close the studio window and run Start.bat again to finish.'}
    except updater.UpdateError as exc:
        logging.error('Update refused: %s', exc)
        raise ApiError(str(exc))
    except Exception as exc:                               # noqa: BLE001 - reported
        logging.exception('Update failed')
        raise ApiError('The update did not finish: ' + str(exc)[:200])


def studio_report_preview(body):
    """Build a report and hand back exactly the text that would be saved.

    The preview is the point. Everything here is collected from the machine
    rather than supplied by the user, so the only way for them to know what is
    in it is to read it - and a payload nobody reads is a privacy promise
    nobody can check. So the endpoint returns the finished text, not a summary
    of it.
    """
    errors = [row['error'] for row in db().execute(
        "SELECT error FROM studio_jobs WHERE status='error' AND error IS NOT NULL "
        'ORDER BY updated DESC LIMIT 20').fetchall()]
    report = diagnostics.build_report(note=body.get('note'), recent_errors=errors)
    return {'text': diagnostics.render_report(report),
            'neverCollected': list(diagnostics.NEVER_COLLECTED)}


def studio_report_save(body):
    """Write the report to data/reports and say where it went.

    Nothing is transmitted. The user sends the file wherever they choose, which
    is why this returns the folder as well as the file - they have to be able to
    find it.
    """
    errors = [row['error'] for row in db().execute(
        "SELECT error FROM studio_jobs WHERE status='error' AND error IS NOT NULL "
        'ORDER BY updated DESC LIMIT 20').fetchall()]
    report = diagnostics.build_report(note=body.get('note'), recent_errors=errors)
    path = diagnostics.write_report(report)
    # Open the folder with the file already selected. The point of a report is
    # to be sent, and asking somebody to find a path they were shown in a dialog
    # is where that stops happening - they can drag it straight out of the
    # window that opens.
    revealed = diagnostics.reveal(path)
    return {'ok': True, 'path': str(path), 'folder': str(path.parent),
            'name': path.name, 'revealed': revealed}


def studio_report_reveal():
    """Show the newest report in the file manager again.

    Takes no path. The browser is trusted to ask, not to choose: an endpoint
    that opened whatever it was handed would be a way to launch Explorer
    anywhere on the machine.
    """
    path = diagnostics.latest_report()
    if not path:
        raise ApiError('There is no saved report yet.')
    return {'ok': diagnostics.reveal(path), 'path': str(path)}


def resolved_seed(given):
    """The seed for one job: the one asked for, or a fresh random one.

    An empty seed box means "surprise me", and it used to become the literal
    number 0. Every job with an unchanged prompt therefore built a byte for
    byte identical graph, and ComfyUI answers an identical graph out of its
    cache: pressing Generate twice returned the first image in about two
    seconds, looking like the job had finished instantly.

    It is resolved here rather than in the graph builder so the number is
    stored on the job. A seed nobody can read back is not reproducible, and
    "make me another one like that" is most of what seeds are for.

    secrets rather than random: the seed is part of what makes two images
    differ, and a predictable sequence across restarts is exactly the thing
    being fixed.
    """
    text = str(given if given is not None else '').strip()
    if text.isdigit():
        value = int(text)
        # 0 stays 0 when it is asked for on purpose - it is a legitimate seed,
        # and repeating a generation deliberately is a real thing to want.
        if 0 <= value < 10 ** 15:
            return str(value)
    return str(secrets.randbelow(10 ** 15))


def studio_generate(query, body):
    """Queue one job. The prompt arrives sealed and is stored exactly as sent."""
    job_id = str(body.get('id') or uuid.uuid4())
    if not isinstance(body.get('prompt'), str) or not body['prompt']:
        raise ApiError('A prompt is required.')
    app = body.get('app') or query.get('app', ['studio'])[0]
    position = db().execute(
        'SELECT COALESCE(MAX(queue_position), 0) + 1 AS next FROM studio_jobs '
        "WHERE status='queued'").fetchone()['next']
    guidance = body.get('guidance')
    denoise = body.get('denoise')
    fields = {
        'id': job_id, 'owner': OWNER, 'app': app,
        'prompt': body['prompt'], 'negative_prompt': body.get('negativePrompt') or None,
        'ratio': body.get('ratio') or 'square',
        'resolution': body.get('resolution') or '1mp',
        'seed': resolved_seed(body.get('seed')),
        'model': body.get('model') or 'krea2_turbo',
        'status': 'queued', 'created': now(), 'updated': now(),
        'workflow': body.get('workflow') or 'standard',
        'prompt_enhance': 1 if body.get('promptEnhance') else 0,
        'enhancer_strength': bounded(body.get('enhancerStrength'), 1.5, 0, 5),
        'variance_strength': bounded(body.get('varianceStrength'), 1.0, 0, 5),
        'variance_percent': int(bounded(body.get('variancePercent'), 50, 0, 100)),
        'variance_mode': body.get('varianceMode') or 'values',
        'upscale': 1 if body.get('upscale', True) else 0,
        'sampler': body.get('sampler') or 'euler',
        'steps': int(bounded(body.get('steps'), 0, 0, 150)) or None,
        'guidance': bounded(guidance, None, 0, 30) if guidance is not None else None,
        'loras': json.dumps(body['loras']) if body.get('loras') else None,
        'mode': body.get('mode') or 'txt2img',
        'denoise': bounded(denoise, None, 0.05, 1.0) if denoise is not None else None,
        'input_image_key': body.get('inputImageKey'),
        'mask_image_key': body.get('maskImageKey'),
        'grow_mask': int(bounded(body.get('growMask'), 6, 0, 64)),
        'queue_position': position, 'priority': 10,
        'chat_id': body.get('chat_id'),
    }
    columns = ', '.join(fields)
    marks = ', '.join('?' for _ in fields)
    conn = db()
    conn.execute('INSERT INTO studio_jobs(' + columns + ') VALUES(' + marks + ')',
                 tuple(fields.values()))
    conn.commit()
    RUNNER.nudge()
    return {'id': job_id, 'queued': True}


def studio_delete(body):
    job_id = body.get('id')
    if not job_id:
        raise ApiError('No job id given.')
    row = db().execute('SELECT image_key, thumbnail_key FROM studio_jobs WHERE id=? AND owner=?',
                       (job_id, OWNER)).fetchone()
    if row:
        for key in (row['image_key'], row['thumbnail_key']):
            if key:
                safe_image_path(key).unlink(missing_ok=True)
    conn = db()
    conn.execute('DELETE FROM studio_jobs WHERE id=? AND owner=?', (job_id, OWNER))
    conn.commit()
    return {'ok': True}


def studio_reorder(body):
    """Reposition queued jobs. expectedOrder guards against a stale drag."""
    order = body.get('order') or []
    expected = body.get('expectedOrder')
    current = [row['id'] for row in db().execute(
        "SELECT id FROM studio_jobs WHERE status='queued' AND owner=? "
        'ORDER BY priority DESC, queue_position, created', (OWNER,)).fetchall()]
    if expected is not None and list(expected) != current:
        raise ApiError('The queue changed while you were dragging. Nothing was moved.', 409)
    conn = db()
    for position, job_id in enumerate(order, start=1):
        conn.execute('UPDATE studio_jobs SET queue_position=?, updated=? WHERE id=? '
                     "AND status='queued'", (position, now(), job_id))
    conn.commit()
    return {'ok': True, 'order': order}


def studio_presets():
    row = db().execute('SELECT payload FROM studio_user_presets WHERE owner=?', (OWNER,)).fetchone()
    return {'payload': json.loads(row['payload']) if row else None}


def studio_save_presets(body):
    conn = db()
    conn.execute('INSERT INTO studio_user_presets(owner, payload, updated) VALUES(?,?,?) '
                 'ON CONFLICT(owner) DO UPDATE SET payload=excluded.payload, '
                 'updated=excluded.updated',
                 (OWNER, json.dumps(body.get('payload')), now()))
    conn.commit()
    return {'ok': True}


def studio_unlock(body):
    """First unlock sets the passphrase; later ones are checked against it.

    The server only ever sees a verifier derived from the key, never the key
    itself, so it can tell a wrong passphrase from a right one without being able
    to open anything sealed under it. Losing the key means losing the images -
    that is the design, not an oversight, and the setup wizard has to say so.
    """
    verifier = body.get('verifier')
    if not verifier:
        raise ApiError('No key given.')
    stored = setting('unlock_verifier')
    if stored is None:
        set_setting('unlock_verifier', verifier)
        return {'ok': True, 'firstRun': True}
    if stored != verifier:
        raise ApiError('That key does not match the one this studio was set up with.', 403)
    return {'ok': True}


# --------------------------------------------------------------- assets ---

def content_type_of(data):
    """Label bytes by what they are, not by what the extension claims.

    Thumbnails are WebP and full images are PNG, so neither a fixed type nor the
    filename is trustworthy. Sealed bytes stay octet-stream: calling ciphertext
    an image invites something in the chain to try to render it.
    """
    signatures = (
        (bytes.fromhex('41535031'), 'application/octet-stream'),   # ASP1
        (bytes.fromhex('89504e470d0a1a0a'), 'image/png'),
        (bytes.fromhex('ffd8ff'), 'image/jpeg'),
        (bytes.fromhex('47494638'), 'image/gif'),
    )
    for magic, kind in signatures:
        if data[:len(magic)] == magic:
            return kind
    if data[:4] == b'RIFF' and data[8:12] == b'WEBP':
        return 'image/webp'
    return 'application/octet-stream'


def safe_image_path(key):
    """Resolve a storage key inside the images folder, or refuse.

    Keys reach us from the client. Anything that escapes the folder is a path
    traversal, so the resolved path is checked rather than the key trusted.
    """
    candidate = (IMAGES_DIR / str(key)).resolve()
    if not str(candidate).startswith(str(IMAGES_DIR.resolve())):
        raise ApiError('Bad asset key.', 400)
    return candidate


def studio_upload_asset(query, data):
    """Store a sealed input image or mask and return the key that names it."""
    job_id = (query.get('id') or [''])[0]
    kind = (query.get('type') or ['input'])[0]
    if not job_id:
        raise ApiError('No job id given.')
    if kind not in ('input', 'mask'):
        raise ApiError('Unknown asset type.')
    if not data:
        raise ApiError('Empty upload.')
    key = job_id + '_' + kind + '.bin'
    safe_image_path(key).write_bytes(data)
    column = 'input_image_key' if kind == 'input' else 'mask_image_key'
    conn = db()
    conn.execute('UPDATE studio_jobs SET ' + column + '=?, updated=? WHERE id=?',
                 (key, now(), job_id))
    conn.commit()
    return {'key': key}


def studio_asset_bytes(query, which):
    """Serve a finished image or its thumbnail, still sealed.

    The browser decrypts. Content-Type is deliberately octet-stream rather than
    image/png: what is on disk is ASP1 ciphertext, and labelling it as an image
    would invite something in the chain to try to render it.
    """
    job_id = (query.get('id') or [''])[0]
    if not job_id:
        raise ApiError('No job id given.')
    column = 'image_key' if which == 'image' else 'thumbnail_key'
    row = db().execute('SELECT ' + column + ' AS k FROM studio_jobs WHERE id=? AND owner=?',
                       (job_id, OWNER)).fetchone()
    if not row or not row['k']:
        raise ApiError('That image is not ready yet.', 404)
    path = safe_image_path(row['k'])
    if not path.exists():
        raise ApiError('That image is no longer stored.', 404)
    data = path.read_bytes()
    return (data, content_type_of(data))


# --------------------------------------------------------------- drafts ---
#
# The editor keeps the authoritative copy in IndexedDB and syncs here so a draft
# survives a cleared browser. Assets are content-addressed by digest, and the
# manifest naming them is published only after every asset is acknowledged, so a
# reader never sees a revision it cannot fully load.

def draft_asset_path(mode, kind, digest):
    safe = ''.join(ch for ch in str(digest) if ch.isalnum())
    if not safe:
        raise ApiError('Bad asset digest.', 400)
    return DRAFTS_DIR / (str(mode) + '_' + str(kind) + '_' + safe + '.bin')


def studio_drafts(query):
    app = (query.get('app') or ['studio'])[0]
    rows = db().execute('SELECT * FROM studio_drafts WHERE owner=? AND app=?',
                        (OWNER, app)).fetchall()
    drafts = []
    for row in rows:
        meta = json.loads(row['meta']) if row['meta'] else {}
        drafts.append({
            'mode': row['mode'], 'state': row['state'], 'revision': row['revision'],
            'updated': row['updated'], 'client': row['client'],
            'image': row['image_key'], 'mask': row['mask_key'],
            'imageReceipt': meta.get('imageReceipt'),
            'maskReceipt': meta.get('maskReceipt'),
            'meta': meta.get('meta'),
        })
    return {'drafts': drafts}


def studio_draft_asset_put(query, data):
    mode = (query.get('mode') or [''])[0]
    kind = (query.get('type') or [''])[0]
    digest = (query.get('digest') or [''])[0]
    if not (mode and kind and digest):
        raise ApiError('Incomplete asset reference.')
    if not data:
        raise ApiError('Empty upload.')
    draft_asset_path(mode, kind, digest).write_bytes(data)
    # The receipt is what the manifest cites. Content addressing means the digest
    # already identifies the bytes, so it doubles as the receipt.
    return {'receipt': digest}


def studio_draft_asset_get(query):
    mode = (query.get('mode') or [''])[0]
    kind = (query.get('type') or [''])[0]
    digest = (query.get('digest') or [''])[0]
    path = draft_asset_path(mode, kind, digest)
    if not path.exists():
        raise ApiError('No such draft asset.', 404)
    return path.read_bytes()


def studio_draft_publish(query, body):
    """Publish a manifest. `base` is the revision the client edited from."""
    app = (query.get('app') or ['studio'])[0]
    mode = body.get('mode')
    if not mode:
        raise ApiError('No mode given.')
    row = db().execute('SELECT revision FROM studio_drafts WHERE owner=? AND app=? AND mode=?',
                       (OWNER, app, mode)).fetchone()
    current = row['revision'] if row else 0
    base = int(body.get('base') or 0)
    if row and base < current:
        # Someone else moved it on. The client reconciles and republishes.
        raise ApiError('This draft changed elsewhere.', 409, code='stale-draft')
    revision = current + 1
    meta = json.dumps({
        'imageReceipt': body.get('imageReceipt'),
        'maskReceipt': body.get('maskReceipt'),
        'meta': body.get('meta'),
    })
    conn = db()
    conn.execute(
        'INSERT INTO studio_drafts(owner, app, mode, revision, state, image_key, mask_key, '
        'meta, client, updated) VALUES(?,?,?,?,?,?,?,?,?,?) '
        'ON CONFLICT(owner, app, mode) DO UPDATE SET revision=excluded.revision, '
        'state=excluded.state, image_key=excluded.image_key, mask_key=excluded.mask_key, '
        'meta=excluded.meta, client=excluded.client, updated=excluded.updated',
        (OWNER, app, mode, revision, body.get('state') or 'active', body.get('image'),
         body.get('mask'), meta, body.get('client'), now()))
    conn.commit()
    return {'revision': revision}


# ----------------------------------------------------------------- chat ---
#
# Conversations, messages and memories are plain storage: everything the user
# wrote arrives sealed and is handed back sealed. Generating a reply is not
# implemented here - that needs the orchestrator's chat loop and the model paths
# that phase 3 replaces, so `send` and `stream` say so rather than pretending.

def chat_list():
    rows = db().execute('SELECT id, title, model, created, updated FROM studio_chats '
                        'WHERE owner=? ORDER BY updated DESC LIMIT 200', (OWNER,)).fetchall()
    return {'chats': [dict(row) for row in rows]}


def chat_get(query):
    chat_id = (query.get('chat_id') or [''])[0]
    if not chat_id:
        raise ApiError('No conversation given.')
    chat = db().execute('SELECT * FROM studio_chats WHERE id=? AND owner=?',
                        (chat_id, OWNER)).fetchone()
    if not chat:
        raise ApiError('No such conversation.', 404)
    rows = db().execute('SELECT id, role, seq, sealed_content, sealed_reasoning, sealed_usage, '
                        'job_id, created FROM studio_messages WHERE chat_id=? ORDER BY seq',
                        (chat_id,)).fetchall()
    return {'chat': dict(chat), 'messages': [dict(row) for row in rows]}


def chat_save_message(body):
    """Insert or update one message. The client owns the id, so this is an upsert."""
    chat_id = body.get('chat_id')
    message_id = body.get('message_id')
    if not (chat_id and message_id):
        raise ApiError('A conversation and message id are required.')
    conn = db()
    conn.execute('INSERT INTO studio_chats(id, owner, title, model, created, updated) '
                 'VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET updated=excluded.updated',
                 (chat_id, OWNER, body.get('title'), body.get('model'), now(), now()))
    seq = conn.execute('SELECT COALESCE(MAX(seq), 0) + 1 AS next FROM studio_messages '
                       'WHERE chat_id=?', (chat_id,)).fetchone()['next']
    conn.execute(
        'INSERT INTO studio_messages(id, chat_id, owner, role, seq, sealed_content, '
        'sealed_reasoning, sealed_usage, job_id, created) VALUES(?,?,?,?,?,?,?,?,?,?) '
        'ON CONFLICT(id) DO UPDATE SET sealed_content=excluded.sealed_content, '
        'sealed_reasoning=excluded.sealed_reasoning, sealed_usage=excluded.sealed_usage',
        (message_id, chat_id, OWNER, body.get('role') or 'user', seq,
         body.get('sealed_content'), body.get('sealed_reasoning'),
         body.get('sealed_usage'), body.get('job_id'), now()))
    conn.commit()
    return {'ok': True, 'id': message_id, 'seq': seq}


def chat_rename(body):
    conn = db()
    conn.execute('UPDATE studio_chats SET title=?, updated=? WHERE id=? AND owner=?',
                 (body.get('title'), now(), body.get('chat_id'), OWNER))
    conn.commit()
    return {'ok': True}


def chat_delete(body):
    conn = db()
    conn.execute('DELETE FROM studio_messages WHERE chat_id=?', (body.get('chat_id'),))
    conn.execute('DELETE FROM studio_chats WHERE id=? AND owner=?', (body.get('chat_id'), OWNER))
    conn.commit()
    return {'ok': True}


def chat_delete_message(body):
    conn = db()
    conn.execute('DELETE FROM studio_messages WHERE id=? AND chat_id=?',
                 (body.get('message_id'), body.get('chat_id')))
    conn.commit()
    return {'ok': True}


def chat_trim(body):
    """Drop this message and everything after it - the rewind an edit performs."""
    chat_id = body.get('chat_id')
    from_id = body.get('from_message_id')
    row = db().execute('SELECT seq FROM studio_messages WHERE id=? AND chat_id=?',
                       (from_id, chat_id)).fetchone()
    if not row:
        return {'ok': True, 'removed': 0}
    conn = db()
    cursor = conn.execute('DELETE FROM studio_messages WHERE chat_id=? AND seq>=?',
                          (chat_id, row['seq']))
    conn.commit()
    return {'ok': True, 'removed': cursor.rowcount}


def chat_sync(query):
    """The chat equivalent of status: what changed since the client last looked."""
    chat_id = (query.get('active_chat_id') or [''])[0]
    rows = db().execute('SELECT id, title, model, created, updated FROM studio_chats '
                        'WHERE owner=? ORDER BY updated DESC LIMIT 200', (OWNER,)).fetchall()
    payload = {
        'chats': [dict(row) for row in rows],
        'host_state': 'busy' if RUNNER.current else 'ready',
        'active_jobs': [],
    }
    if chat_id:
        messages = db().execute(
            'SELECT id, role, seq, sealed_content, sealed_reasoning, sealed_usage, job_id, '
            'created FROM studio_messages WHERE chat_id=? ORDER BY seq', (chat_id,)).fetchall()
        payload['active_chat_id'] = chat_id
        payload['message_ids'] = [row['id'] for row in messages]
        last = (query.get('last_msg_id') or [''])[0]
        if last:
            seen = False
            fresh = []
            for row in messages:
                if seen:
                    fresh.append(dict(row))
                if row['id'] == last:
                    seen = True
            payload['new_messages'] = fresh if seen else [dict(r) for r in messages]
        else:
            payload['new_messages'] = [dict(row) for row in messages]
    return payload


def chat_memories_list():
    rows = db().execute('SELECT id, sealed_content, created, updated FROM studio_memories '
                        'WHERE owner=? ORDER BY created', (OWNER,)).fetchall()
    return {'memories': [dict(row) for row in rows]}


def chat_memory_save(body):
    memory_id = body.get('id') or str(uuid.uuid4())
    conn = db()
    conn.execute('INSERT INTO studio_memories(id, owner, sealed_content, created, updated) '
                 'VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET '
                 'sealed_content=excluded.sealed_content, updated=excluded.updated',
                 (memory_id, OWNER, body.get('sealed_content'), now(), now()))
    conn.commit()
    return {'ok': True, 'id': memory_id}


def chat_memory_delete(body):
    conn = db()
    conn.execute('DELETE FROM studio_memories WHERE id=? AND owner=?', (body.get('id'), OWNER))
    conn.commit()
    return {'ok': True}


def chat_memories_clear():
    conn = db()
    conn.execute('DELETE FROM studio_memories WHERE owner=?', (OWNER,))
    conn.commit()
    return {'ok': True}


def chat_stop(body):
    job_id = body.get('job_id')
    if job_id:
        RUNNER.stop_requested.add(job_id)
        conn = db()
        conn.execute("UPDATE studio_jobs SET status='cancelled', updated=? WHERE id=? "
                     "AND status IN ('queued','running')", (now(), job_id))
        conn.commit()
    return {'ok': True}


def chat_cancel_queued(body):
    conn = db()
    if body.get('chat_id'):
        cursor = conn.execute("UPDATE studio_jobs SET status='cancelled', updated=? "
                              "WHERE chat_id=? AND status='queued'", (now(), body['chat_id']))
    else:
        cursor = conn.execute("UPDATE studio_jobs SET status='cancelled', updated=? "
                              "WHERE owner=? AND status='queued'", (now(), OWNER))
    conn.commit()
    return {'ok': True, 'cancelled': cursor.rowcount}


def chat_send(body):
    """Queue one chat turn and return the job that will answer it.

    The conversation itself is in worker_payload, sealed by the browser. This
    layer stores it and never opens it; the engine unseals it to build the prompt
    because it has to. Chat jobs share studio_jobs with image jobs so that one
    queue and one runner arbitrate the GPU, which is the whole reason the original
    kept a single-job discipline.
    """
    chat_id = body.get('chat_id')
    if not chat_id:
        raise ApiError('No conversation given.')
    if not body.get('worker_payload'):
        raise ApiError('Nothing to send.')
    job_id = str(uuid.uuid4())
    conn = db()
    conn.execute('INSERT INTO studio_chats(id, owner, title, model, created, updated) '
                 'VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET updated=excluded.updated',
                 (chat_id, OWNER, body.get('title'), body.get('model'), now(), now()))
    # Chat outranks image work in the queue. A person waiting on a reply notices a
    # thirty-second delay; a picture finishing a minute later is not felt the same
    # way, and the original ordered them this way for that reason.
    conn.execute(
        'INSERT INTO studio_jobs(id, owner, app, prompt, ratio, seed, model, status, created, '
        'updated, workflow, mode, chat_id, worker_payload, client_pubkey, priority, '
        'queue_position) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
        (job_id, OWNER, 'chat', '', 'square', '0', body.get('model') or 'auto', 'queued',
         now(), now(), 'compaction' if body.get('is_compaction') else 'chat', 'chat',
         chat_id, body.get('worker_payload'), body.get('client_pubkey'), 20,
         conn.execute('SELECT COALESCE(MAX(queue_position), 0) + 1 AS n FROM studio_jobs '
                      "WHERE status='queued'").fetchone()['n']))
    # The message the user just typed, so it survives a reload before the reply.
    if body.get('message_id'):
        seq = conn.execute('SELECT COALESCE(MAX(seq), 0) + 1 AS n FROM studio_messages '
                           'WHERE chat_id=?', (chat_id,)).fetchone()['n']
        conn.execute(
            'INSERT INTO studio_messages(id, chat_id, owner, role, seq, sealed_content, '
            'job_id, created) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(id) DO NOTHING',
            (body['message_id'], chat_id, OWNER, 'user', seq, body.get('sealed_content'),
             job_id, now()))
    conn.commit()
    RUNNER.nudge()
    return {'job_id': job_id, 'queued': True}


def queue_position(job_id):
    """Where this job sits in the queue, counting from 1.

    The job being worked on right now is 1, not 0: the client prints this as an
    ordinal and "0th in line" reads as badly as the undefined it replaces.
    """
    if RUNNER.current == job_id:
        return 1
    rows = db().execute(
        "SELECT id FROM studio_jobs WHERE status='queued' "
        'ORDER BY priority DESC, queue_position, created').fetchall()
    ahead = 1 if RUNNER.current else 0
    for index, row in enumerate(rows):
        if row['id'] == job_id:
            return index + 1 + ahead
    return 1


def chat_stream(handler, query):
    """Replay a reply as it is produced, resuming from `from_seq`.

    The client reconnects with the last sequence number it saw and expects to
    carry on exactly there, so chunks are read from the table rather than pushed:
    a dropped connection loses nothing, and a second tab can watch the same reply.

    Framed as server-sent events because that is what the client parses, but it is
    a database tail, not a live pipe. Writes the response itself and returns None,
    since the reply is streamed rather than returned.
    """
    job_id = (query.get('job_id') or [''])[0]
    if not job_id:
        raise ApiError('No job given.')
    try:
        last_seq = int((query.get('from_seq') or ['0'])[0])
    except ValueError:
        last_seq = 0

    handler.send_response(200)
    handler.send_header('Content-Type', 'text/event-stream')
    handler.send_header('Cache-Control', 'no-store')
    handler.send_header('X-Accel-Buffering', 'no')
    handler.end_headers()

    def emit(payload):
        handler.wfile.write(('data: ' + json.dumps(payload) + '\n\n').encode('utf-8'))
        handler.wfile.flush()

    deadline = time.time() + 15 * 60
    idle_since = time.time()
    try:
        while time.time() < deadline:
            rows = db().execute(
                'SELECT seq, kind, payload FROM studio_chat_chunks WHERE job_id=? AND seq>? '
                'ORDER BY seq', (job_id, last_seq)).fetchall()
            for row in rows:
                last_seq = row['seq']
                try:
                    chunk = json.loads(row['payload']) if row['payload'] else {}
                except json.JSONDecodeError:
                    continue
                chunk['seq'] = row['seq']
                emit(chunk)
                idle_since = time.time()

            job = db().execute('SELECT status, error FROM studio_jobs WHERE id=?',
                               (job_id,)).fetchone()
            if job and job['status'] in ('complete', 'error', 'cancelled'):
                # Drain anything written between the read above and now, or the
                # last words of a reply are lost exactly when the job finishes.
                tail = db().execute(
                    'SELECT seq, kind, payload FROM studio_chat_chunks WHERE job_id=? AND '
                    'seq>? ORDER BY seq', (job_id, last_seq)).fetchall()
                for row in tail:
                    last_seq = row['seq']
                    try:
                        chunk = json.loads(row['payload']) if row['payload'] else {}
                    except json.JSONDecodeError:
                        continue
                    chunk['seq'] = row['seq']
                    emit(chunk)
                if job['status'] == 'error':
                    emit({'error': job['error'] or 'The reply failed.'})
                else:
                    emit({'done': True, 'seq': last_seq})
                return None

            # A queued turn is still news: it tells the client the PC has the job
            # and is working through the queue, rather than leaving it silent.
            #
            # position is not optional. The client renders it as an ordinal, so
            # omitting it produced "Queued - undefinedth in line". 1 means next.
            if time.time() - idle_since > 4:
                idle_since = time.time()
                emit({'queued': {
                    'host_state': 'busy' if RUNNER.current else 'ready',
                    'position': queue_position(job_id),
                }})
            time.sleep(0.4)
    except (BrokenPipeError, ConnectionResetError):
        # The reader went away - a closed tab, or the client reconnecting with a
        # later from_seq. Nothing is lost; the chunks are still in the table.
        return None
    emit({'error': 'The reply took too long and the connection was closed.'})
    return None


# ------------------------------------------------------------- routing ---

def route_studio(handler, query, method):
    action = (query.get('action') or [''])[0]
    if method == 'GET':
        if action == 'status':
            return studio_status(query)
        if action == 'history':
            return studio_history(query)
        if action == 'config':
            return studio_config()
        if action == 'registry':
            return studio_registry()
        if action == 'characters':
            return studio_characters_list()
        if action == 'portraits':
            return studio_portraits_list(query)
        if action == 'settings':
            return studio_settings()
        if action == 'version':
            return studio_version()
        if action == 'manual-pdf':
            return studio_manual_pdf()
        if action == 'manual':
            return studio_manual()
        if action == 'update-check':
            return studio_update_check()
        if action == 'update-now':
            return studio_update_now()
        if action == 'presets':
            return studio_presets()
        if action in ('image', 'thumbnail'):
            return studio_asset_bytes(query, action)
        if action == 'drafts':
            return studio_drafts(query)
        if action == 'draft-asset':
            return studio_draft_asset_get(query)
        raise ApiError('Unknown action: ' + (action or '(none)'), 404)

    if action == 'upload-asset':
        return studio_upload_asset(query, raw_body(handler))
    if action == 'draft-asset':
        return studio_draft_asset_put(query, raw_body(handler))
    body = json_body(handler)
    if action == 'generate':
        return studio_generate(query, body)
    if action == 'delete':
        return studio_delete(body)
    if action == 'reorder':
        return studio_reorder(body)
    if action == 'save-presets':
        return studio_save_presets(body)
    if action == 'save-lora':
        return studio_loras_save(body)
    if action == 'save-character':
        return studio_characters_save(body)
    if action == 'delete-character':
        return studio_characters_delete(body)
    if action == 'save-portrait':
        return studio_portraits_save(body)
    if action == 'save-settings':
        return studio_save_settings(body)
    if action == 'checkpoint-arch':
        return studio_checkpoint_arch(body)
    if action == 'forget-lora':
        return studio_loras_forget(body)
    if action == 'unlock':
        return studio_unlock(body)
    if action == 'lock':
        return {'ok': True}
    if action == 'draft-publish':
        return studio_draft_publish(query, body)
    if action == 'report-preview':
        return studio_report_preview(body)
    if action == 'report-save':
        return studio_report_save(body)
    if action == 'report-reveal':
        return studio_report_reveal()
    if action == 'update-apply':
        return studio_update_apply()
    raise ApiError('Unknown action: ' + (action or '(none)'), 404)


def route_chat(handler, query, method):
    action = (query.get('action') or [''])[0]
    if method == 'GET':
        if action == 'list-chats':
            return chat_list()
        if action == 'get-chat':
            return chat_get(query)
        if action == 'sync':
            return chat_sync(query)
        if action == 'list-memories':
            return chat_memories_list()
        if action == 'stream':
            return chat_stream(handler, query)
        raise ApiError('Unknown action: ' + (action or '(none)'), 404)

    body = json_body(handler)
    if action == 'save-message':
        return chat_save_message(body)
    if action == 'rename-chat':
        return chat_rename(body)
    if action == 'delete-chat':
        return chat_delete(body)
    if action == 'delete-message':
        return chat_delete_message(body)
    if action == 'trim-messages':
        return chat_trim(body)
    if action == 'save-memory':
        return chat_memory_save(body)
    if action == 'delete-memory':
        return chat_memory_delete(body)
    if action == 'clear-memories':
        return chat_memories_clear()
    if action == 'stop':
        return chat_stop(body)
    if action == 'cancel-queued':
        return chat_cancel_queued(body)
    if action == 'send':
        return chat_send(body)
    raise ApiError('Unknown action: ' + (action or '(none)'), 404)


# ---------------------------------------------------------------- http ---

class Handler(BaseHTTPRequestHandler):
    server_version = 'AIStudioPortable'
    sys_version = ''

    # Polled several times a second by an idle page. Logging every one buries
    # anything that matters under a wall of identical 200s.
    QUIET_ACTIONS = ('status', 'history', 'sync', 'config', 'list-chats', 'list-memories',
                     'presets', 'portraits', 'characters', 'drafts', 'image', 'thumbnail', 'get-chat')

    def log_message(self, fmt, *args):
        line = str(args[0] if args else '')
        if '/api/' not in line:
            return
        status = str(args[1]) if len(args) > 1 else ''
        if status.startswith('2'):
            action = ''
            if 'action=' in line:
                action = line.split('action=', 1)[1].split('&', 1)[0].split(' ', 1)[0]
            if action in self.QUIET_ACTIONS:
                return
        sys.stderr.write('  ' + (fmt % args) + chr(10))

    def do_GET(self):
        self.dispatch('GET')

    def do_POST(self):
        self.dispatch('POST')

    def dispatch(self, method):
        parsed = urlparse(self.path)
        query = parse_qs(parsed.query)
        try:
            if parsed.path == '/api/studio':
                self.finish_api(route_studio(self, query, method))
                return
            if parsed.path == '/api/chat':
                self.finish_api(route_chat(self, query, method))
                return
            if method == 'GET':
                self.serve_static(parsed.path)
                return
            self.send_error(404)
        except ApiError as exc:
            self.finish_json({'error': exc.message, 'code': exc.code}, exc.status)
        except BrokenPipeError:
            pass
        except Exception as exc:                           # noqa: BLE001 - keep serving
            traceback.print_exc()
            # The action is read inside the route functions, not here, so it was
            # never in scope - this line raised NameError of its own and took
            # the 500 with it. Every unhandled error in the API therefore
            # reached the browser as a dropped connection with no status and no
            # message, which is the least diagnosable failure there is.
            logging.exception('Unhandled error in %s %s', method, parsed.path)
            self.finish_json({'error': 'The studio hit an unexpected error: ' + str(exc)}, 500)

    def finish_api(self, result):
        # chat_stream writes its own response and returns None. Anything else
        # here would append a second set of headers to a finished stream.
        if result is None:
            return
        content_type = 'application/octet-stream'
        if isinstance(result, tuple) and len(result) == 2:
            result, content_type = result
        if isinstance(result, (bytes, bytearray)):
            self.send_response(200)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(result)))
            self.send_header('Cache-Control', 'no-store')
            self.end_headers()
            self.wfile.write(result)
            return
        self.finish_json(result, 200)

    def finish_json(self, payload, status):
        body = json.dumps(payload).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(body)

    def serve_static(self, path):
        """Serve web/. Paths are resolved and checked, never trusted."""
        relative = path.lstrip('/') or 'index.html'
        target = (WEB_DIR / relative).resolve()
        if not str(target).startswith(str(WEB_DIR.resolve())):
            self.send_error(403)
            return
        if target.is_dir():
            target = target / 'index.html'
        if not target.exists():
            self.send_error(404)
            return
        kind = mimetypes.guess_type(str(target))[0] or 'application/octet-stream'
        data = target.read_bytes()
        self.send_response(200)
        self.send_header('Content-Type', kind)
        self.send_header('Content-Length', str(len(data)))
        # No caching while the interface is edited directly and has no build step;
        # a stale studio.js is a confusing way to lose an afternoon.
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(data)


def main():
    log_file = diagnostics.start_logging()
    diagnostics.log_environment({'port': CONFIG['port'],
                                 'comfy_port': CONFIG.get('comfy_port'),
                                 'encrypt_storage': bool(CONFIG.get('encrypt_storage'))})
    # The studio can be moved - a different drive, off a synced folder - and
    # the file telling ComfyUI where this install's models live holds an
    # absolute path written once, during setup. Put it right before anything
    # tries to generate.
    try:
        import setup as installer
        moved = installer.refresh_extra_model_paths()
        if moved:
            print('  moved   this folder has moved; model paths rewritten')
            logging.info('Studio folder moved; rewrote %s', moved)
    except Exception as exc:                               # noqa: BLE001 - never fatal
        logging.warning('Could not check the model paths file: %s', exc)

    init_db()
    recover_active_job()
    RUNNER.start()
    if CONFIG.get('check_updates', True) and CONFIG.get('update_url'):
        threading.Thread(target=update_watcher, name='update-watcher',
                         daemon=True).start()
    host, port = CONFIG['host'], int(CONFIG['port'])
    server = ThreadingHTTPServer((host, port), Handler)
    url = 'http://' + host + ':' + str(port) + '/'
    print('AI Studio Portable')
    print('  serving ' + str(WEB_DIR))
    print('  database ' + str(DB_PATH))
    print('  log      ' + str(log_file))
    print('  engine   ' + ('ready' if ENGINE.ready else 'not available - ' + str(ENGINE.error)))
    # Report the machine at startup rather than on the first job: it is the line
    # that explains why a model is missing from the picker, and a user who hits
    # that is looking at this window before they have run anything.
    if ENGINE.ready:
        apply_profile(ENGINE.module)
    print('  open     ' + url)
    if CONFIG.get('open_browser') and os.environ.get('STUDIO_NO_BROWSER') != '1':
        # Say so when this fails. webbrowser.open returns False rather than
        # raising when it cannot find a browser, so the old silent try/except
        # could not have reported it even in principle - and a studio that looks
        # like it did nothing is indistinguishable from one that crashed.
        opened = False
        try:
            import webbrowser
            opened = webbrowser.open(url)
        except Exception as exc:                           # noqa: BLE001 - never fatal
            print('  ! could not open a browser: ' + str(exc))
        if not opened:
            print('  ! could not open a browser for you - open the address above')
    print('  ready. Ctrl+C to stop.')
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print('\n  stopped')
    finally:
        # Closing the window never gets here (Windows ends the process); the job
        # object in lifecycle covers that. This is the orderly exit.
        RUNNER.release_engines()


if __name__ == '__main__':
    main()

(function () {
    'use strict';

    // One handler for every "Open folder" button. The server decides which
    // folder; the page only asks.
    document.querySelectorAll('[data-open-outputs]').forEach(button => {
        button.addEventListener('click', async () => {
            const note = document.querySelector(button.dataset.status || '');
            const say = text => { if (note) note.textContent = text; };
            try {
                const response = await fetch('/api/studio?action=open-outputs', {
                    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}'
                });
                const result = await response.json().catch(() => ({}));
                if (!response.ok) throw new Error(result.error || 'Could not open the folder.');
                if (!result.ok) say('Could not open the folder. It is at ' + result.path);
                else if (result.encrypted) say('Opened the folder. Storage encryption is on, so the files are sealed - use Download to save a copy.');
                else say('Opened the folder.');
            } catch (error) {
                say(error.message || 'Could not open the folder.');
            }
        });
    });
}());

# Version log

Builds are numbered from 1 and count up by one, forever. There are no decimals
and no major or minor versions - Build 7 came after Build 6, and that is the
whole system. The number you are running is shown faintly in the corner of the
studio; click it to read this list.

Every build published adds an entry here first. The entry is what the studio
shows you when you restart after an update, so if it is not written down, you
were not told.

## Build 29 - 2026-10-31

- Fixed videos from vertical or square pictures coming out as a cropped
  landscape clip. The starting image was cut down to a wide strip, so the video
  showed only part of the subject and then invented the rest. The clip now takes
  the shape of the starting image at the same overall size, so the whole picture
  is kept. Videos already made are not affected and have to be generated again.

## Build 28 - 2026-10-31

- Fixed video generation ending with "ComfyUI finished without saving a video".
  The clip was being rendered and saved, but the studio looked for it in the
  wrong place in ComfyUI's report. Videos now complete and appear in the Video
  tab. A video that already failed this way has to be generated again.
- Added an **Open folder** button beside the Video preview and beside Queue &
  recent images. It opens the folder where finished videos and images are saved.
- The folder finished work is saved in is now `data/media` instead of
  `data/images`, since it holds videos too. Existing images move across by
  themselves the first time this build starts.

## Build 27 - 2026-10-31

- Fixed Generate video appearing to do nothing. When it is unavailable the
  Video tab now says why - WAN 2.2 models not installed or still downloading,
  no starting image, no prompt, or the studio locked - instead of leaving the
  button greyed out.

## Build 26 - 2026-10-30

- Add local WAN 2.2 image-to-video generation with a starting-image uploader,
  motion prompt, job history, MP4 preview, and download.
- Offer the optional 38 GB WAN model pack in the update dialog and Video tab.
  Downloads resume after interruptions, reuse existing weights, check free disk
  space first, and verify each file against its SHA-256 hash.
- Keep generated videos encrypted in local history and separate from the image
  queue and gallery.

## Build 25 - 2026-10-30

- Fixed ComfyUI prompt validation failure (`VAEDecodeTiled: temporal_overlap;
  VAEDecodeTiled: temporal_size`) on cards running the Low or Minimum memory
  profiles. The required video/temporal tiling parameters are now supplied
  when converting VAE decode and encode nodes to tiled mode.

## Build 24 - 2026-10-30

- Bring your own ComfyUI workflows. Export one from ComfyUI with Workflow >
  Export (API), or use a picture ComfyUI saved, and upload it in the Models &
  LoRAs panel. It then appears under Your workflows in the Architecture list.
- The studio finds the workflow's prompt, negative prompt, seed, size and Load
  Image by itself and fills them in for every image. Type {{prompt}} (or
  {{negative}}, {{seed}}, {{width}}, {{height}}, {{image}}) into a field to
  choose the spot yourself.
- Works in Text to Image and Image to Image. Everything else - sampler, steps,
  LoRAs, upscaling - comes from the workflow. See the manual for details.

## Build 23 - 2026-10-28

- Automatic memory profiles for smaller graphics cards: tiled image processing
  on 8 GB cards, with smaller tiles and CPU prompt encoding on 4 GB cards.
  4 GB support is experimental; start with Draft and AI upscaling off.
- Fixed Normal memory mode preventing the image engine from starting. Larger
  cards retain their standard workflows and output settings.
- Chat can use a shorter conversation window on small cards. Model suggestions
  now consider installed files, and image-to-chat switching waits for memory
  to be released before deciding whether the image engine must stop.
- Added resolution guidance for small cards and bounded local engine logs to
  help diagnose startup failures and memory problems.

## Build 22 - 2026-10-27

- Bulk prompt queueing: paste multiple prompts (from code blocks, numbered
  lists, dividers, or paragraphs) to queue them automatically with live
  progress, pause, resume, and per-character cast expansion.
- 3-pane preset browser and bulk manager: full category browsing, multi-select
  editing that preserves untouched settings across presets, category renaming,
  "Use random match", "Queue selected", backup export/import (.spresets), and
  Markdown export.
- Character library and character lock: manage character profiles and
  multi-version LoRAs, automatically include appearance descriptions, and lock
  active characters across preset changes.
- Modern social aspect ratios: 4:5 Portrait (social) and 9:16 Vertical
  (vertical) across all resolution tiers.
- Output library: browse all completed generations with infinite scroll,
  instant search filtering, and one-click store-only ZIP archive download.
- UI and mobile refinements: mobile source-image button in Transform and
  Inpaint modes, direct Preset Library shortcut on the workspace bar,
  Ctrl/Cmd+Enter generation shortcut, and improved touch gestures.

## Build 21 - 2026-10-25

- Fixed a model you add yourself not appearing in the Base checkpoint list. The
  studio found the file but did not put it in the list until you switched
  architecture and back. It now appears as soon as the studio has looked.

## Build 20 - 2026-10-25

- Fixed a new install that could never finish setting up. One of the add-ons
  the studio needs could no longer be downloaded, so setup stopped at the same
  place every time and started again on every launch. That add-on now comes
  with the studio.
- First-time setup now asks what to download of the starter models: all of
  them, only the two files a Krea 2 model you bring yourself needs (about
  5 GB), or none. Before, the only way to say no was to close the window, which
  left setup unfinished. The two files can be fetched later from the studio
  folder; the manual shows how.
- A model you add that is missing files it depends on is now listed as "needs
  files" and says which ones, instead of appearing ready and then failing.
- Setup no longer downloads a starter file you have already put in your
  models folder.

## Build 19 - 2026-10-24

- The image and chat engines now always stop when you close the studio. Before,
  closing the window could leave them running out of sight, holding gigabytes of
  memory and graphics-card memory until the PC was restarted. That could make
  games, especially ones with anti-cheat, misbehave or crash.
- New setting, "Free memory when idle": after five minutes with nothing
  generating or chatting, the engines stop and give the memory back. The next
  job starts them again, which can take up to a minute. Set it to 0 to keep
  them running until you close the studio.

## Build 18 - 2026-09-23

- The studio starts normally again in this new distribution.
- Update checks use a separate Build 18+ feed. Older installations continue
  to see Build 17 in their existing update feed.

## Build 17 - 2026-09-23

- This distribution is retired. On restart, the studio displays a retirement
  notice and does not start its local server or generation engines.
- Existing images, models, settings, and conversations remain in the folder.
  Ask the person who supplied this copy for a current distribution.

## Build 16 - 2026-09-19

- Added a comprehensive, publication-grade User Manual (`USER_MANUAL.pdf` and
  `MANUAL.md`) covering all four studio modes, model management, VRAM tuning,
  configuration, and troubleshooting.
- Added direct access to the User Manual from both the Settings dialog
  (under a new Help & Manual section) and the Version log dialog.
- Added `/api/studio?action=manual-pdf` to view the manual directly in your browser.

## Build 15 - 2026-09-19

- CSAM protection has been updated and improved.
- Adult work is unaffected; nothing else was changed.

## Build 14 - 2026-09-18

- Replaces Build 13, which could fail to install. Build 13 was published
  twice, and the second copy reused the first one's filename - so for a few
  minutes the download did not match what the studio was expecting and the
  update was refused rather than applied. Nothing was wrong with the build
  itself; if you are reading this, you already have it.
- The release tooling can no longer publish over a build that is already out.
  A correction gets the next number now, which is what stops this happening
  again.

## Build 13 - 2026-09-18

- Stronger protection against child sexual abuse material. This was already
  refused in chat; it is now refused in image generation as well.
- Adult work is unaffected. Nothing else is restricted, filtered or logged.
- The README and the licence state the limit plainly.

## Build 12 - 2026-09-18

- There is a settings page. The gear button beside Report a problem opens it.
  Most of what it holds could only be changed before by finding config.json and
  editing it by hand, which meant in practice nobody changed anything.
- **Which chat model to start with** is now yours to pick, under Models.
  Automatic still chooses the best one whose weights are actually here, and a
  model you pick is skipped if its file has gone rather than failing the
  conversation.
- **Video memory use** is the one worth knowing about. The image engine was
  never told how much of your graphics card it could use, so it guessed - and
  on an 8 GB card, with a 13 GB model, guessing badly means generation that
  crawls or fails. Auto now decides from your card, and you can override it.
  If images fail or the machine locks up while rendering, try Low.
- Also there: how long images are kept, whether to check for new builds and
  where from, whether the studio opens your browser, which graphics card type
  the installer assumes, both engine ports, and the borrowed models folder.
  Models and colour schemes are reached from the same place.
- A setting left at its default is no longer written to config.json, so that
  file stays a record of what you chose rather than a frozen copy of every
  default that then cannot follow a later change.
- Errors from the studio's own interface now say what went wrong. Any
  unexpected error used to arrive as a dropped connection with no message at
  all, because the code that reported it had a fault of its own.

## Build 11 - 2026-09-17

- The studio works out what a model is by reading it, instead of guessing from
  which folder it is in. Plenty of Krea 2 models are published with the word
  "checkpoint" in their filename, so they get put in the checkpoints folder and
  were being offered as SDXL - which would have produced nothing usable. They
  are recognised as Krea 2 now wherever you put them, and the engine loads them
  from either folder. You should not have to know the difference between the
  two to use your own models.

## Build 10 - 2026-09-17

- The studio could be told a new build did not exist, and believe it. It asks
  GitHub two different ways and both answers are cached without saying so, so
  one of them could still be reporting the previous build minutes after a new
  one went out - and the studio trusted whichever it asked first. It now asks
  both and believes the newer one. This is why Build 9 appeared not to arrive.
- You can check for updates yourself. Click the build number in the corner and
  the version log now says when it last looked and whether anything is waiting,
  with a button to look again right now. It checks every five minutes on its
  own and used to say nothing in between, so there was no way to tell a slow
  update from a broken one.

## Build 9 - 2026-09-17

- Krea 2 models you drop in are found. Build 6 only looked in the checkpoints
  folder, which holds one-file models like SDXL - but a Krea 2 model is the
  diffusion half on its own and belongs in diffusion_models, so dropping one in
  the right place showed nothing at all. Both folders are scanned now, and a
  Krea 2 model appears under Krea 2 rather than being offered as SDXL. It
  borrows Turbo's text encoder and VAE, which are shared.
- The Models panel names both folders and says which kind of file goes in each,
  because putting a model in the other one is exactly how it ends up invisible.

## Build 8 - 2026-09-17

- Moving the studio folder now works properly. The file telling the image
  engine where this install keeps its models held the full path and was only
  written once, during setup - so after moving the folder to another drive, or
  out of a synced folder like OneDrive, your own checkpoints and LoRAs would be
  listed but fail to load when you actually generated. The studio notices it
  has moved when it starts and puts that right. Nothing else needs doing:
  close it, move the folder, run Start.bat from the new location.

## Build 7 - 2026-09-17

- The Models panel says where to put your own checkpoints, and lists the exact
  folders it just checked. A file that was never found and a folder you did not
  mean to use look the same from the outside; now the panel tells you which.
- A problem reading one model folder no longer empties the whole Models panel.
  Anything that went wrong while checking what is installed used to leave the
  panel saying nothing at all, which looks identical to having no models.

## Build 6 - 2026-09-17

- Checkpoints you drop in are found. Putting a .safetensors file into
  models/checkpoints did nothing at all before this: the studio checked whether
  four specific files were present rather than looking at what was in the
  folder, so your own model was invisible however many times you rescanned or
  restarted - while the note in that folder promised the opposite.
  Drop one in, press Rescan, and it appears in the model picker under its own
  filename.
- Because nothing in a checkpoint file says which pipeline it wants - SDXL,
  SD 1.5, Pony and Illustrious all look the same from outside - the studio
  assumes SDXL and lets you change it per file in the Models panel. If an anime
  model comes out looking washed out or overcooked, that is the setting to
  change; it also picks the right step count and guidance for you.

## Build 5 - 2026-09-17

- Updates show up faster. The studio was reading its release information
  through a cache that holds a file for about five minutes, so a build could
  sit published for that long before anything noticed it. It now reads from an
  address that is not cached, and falls back to the old one if that is
  unavailable. A new build should reach you within a few minutes of being
  published rather than up to ten.

## Build 4 - 2026-09-17

- The bracketed prompt template has been dropped. The library ships the one
  worked example and nothing else; it is meant to fill up with your own saved
  settings rather than ours.

## Build 3 - 2026-09-17

- Pressing Generate twice on the same prompt makes a second image. It used to
  finish in about two seconds and hand back the first one: an unchanged prompt
  with no seed set produced an identical request, and ComfyUI answers an
  identical request out of its cache. Leaving the seed box empty now means a
  new random seed each time, which is what it always looked like it meant.
  Typing a seed in still repeats exactly, which is what that is for.
- The Models panel lists what you have rather than what you do not. It used to
  show three checkpoints permanently marked "Missing", naming files the studio
  never ships and you were never asked to fetch.
- The preset library ships with two starters instead of ten assorted examples,
  both filed under "Starter Prompts". One is a character prompt written out in
  full; the other is the same thing with its parts named and left blank. Open
  the template, keep the example beside it, and it is clear what belongs in
  each bracket. Your own saved presets are untouched.
- Updates appear on their own. The studio used to look for a new build once,
  a few seconds after the page opened, and never again - so one left open
  never noticed, and you had to reload before it would tell you. It now checks
  every few minutes in the background and the button appears by itself,
  usually within a minute or so of a build being published.

## Build 2 - 2026-09-17

Chat works properly now. Build 1 answered everything with the same nonsense
phrase on purpose, to prove an update could reach you; this is the build that
was being proved.

- Chat is on: Qwen3 1.7B, with memory, document reading and optional web
  search. Ask it something.
- The assistant is uncensored and will not lecture you, with one exception it
  will not be talked out of: it does not write sexual content involving anyone
  under 18. That is now enforced by the studio itself rather than left to the
  model's judgement, so it holds regardless of how a request is phrased.
- Better answers to short messages. Saying "hi" used to get "hi" back.
- The model pickers only list models you actually have. They used to show
  every model the studio supports, most of them marked "not installed", which
  on a fresh install meant a list of four things you cannot use and one you
  can. Anything you add later appears on its own. The Models panel still
  shows the full list, including what is missing, because that is a list to
  read rather than a menu to choose from.
- AMD and Intel graphics cards are installed for correctly. Before this, the
  installer only recognised NVIDIA cards and quietly assumed one when it found
  nothing, so an AMD or Intel PC downloaded about 22 GB of NVIDIA-only engines
  and then could not start. If your card is somehow still not recognised, set
  "gpu_vendor" in config.json to nvidia, amd, intel or cpu.

## Build 1 - 2026-09-17

The first release.

- Four modes in one window: text to image, image to image, inpainting, and chat.
- Everything runs on your own machine. No prompt, image or conversation is ever
  sent anywhere - generation and chat happen entirely on your own hardware, and
  the studio works with the network unplugged once it is installed. Three things
  do use the network, all of them visible: turning on web search sends that
  query to Bing or DuckDuckGo, installing a model downloads it from that model's
  own host, and the studio checks once at startup whether a newer build exists.
  You can switch the update check off in config.json.
- One folder holds all of it. The installer puts ComfyUI, llama.cpp, Python and
  the models inside the studio folder rather than anywhere else on your PC, so
  moving it means moving the folder and removing it means deleting the folder.
- Models you already have elsewhere are found and used where they are, and the
  studio only ever reads them.
- Krea 2 Turbo for images, with LoRA support, an upscaler, and a masked editor
  for changing part of an image instead of regenerating it.
- Chat is deliberately disabled in this build. It answers everything with the
  same nonsense phrase on purpose: this build exists to prove the update
  pipeline works from end to end, and the clearest way to see an update land is
  for the before and after to be impossible to confuse. The next build turns
  chat on properly - Qwen3 1.7B, with memory, document reading and optional web
  search.
- Sixteen colour schemes and a light/dark switch.
- A problem report you can read in full before it is saved, which never contains
  your prompts, images, conversations or file paths.
- Updates arrive by themselves: the studio notices a new build, asks before
  downloading anything, and never touches your images, models or settings.

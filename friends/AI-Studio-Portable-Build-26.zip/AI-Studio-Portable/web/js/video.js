(function () {
    'use strict';

    const input = document.querySelector('#video-source');
    const drop = document.querySelector('#video-source-drop');
    const preview = document.querySelector('#video-source-preview');
    const sourcePrompt = document.querySelector('#video-source-prompt');
    const prompt = document.querySelector('#video-prompt');
    const generate = document.querySelector('#video-generate');
    const setupNote = document.querySelector('#video-setup-note');
    const modelInstallButton = document.querySelector('#video-model-install');
    const modelProgress = document.querySelector('#video-model-progress');
    const modelProgressLabel = document.querySelector('#video-model-progress-label');
    const statusNote = document.querySelector('#video-status');
    const jobsList = document.querySelector('#video-job-list');
    const output = document.querySelector('#video-output-frame');
    const download = document.querySelector('#video-download');
    let sourceFile = null;
    let modeActive = false;
    let timer = null;
    let busy = false;
    let online = false;
    let modelReady = false;
    let modelInstalling = false;
    let videos = new Map();
    let jobs = [];
    let selectedUrl = null;
    let lastGeneratedId = null;

    function updateButton() {
        generate.disabled = !online || !modelReady || modelInstalling || !sourceFile || !prompt.value.trim() || busy;
    }

    function say(message) {
        statusNote.textContent = message;
    }

    function setSource(file) {
        if (!file || !/^image\/(png|jpeg|webp)$/.test(file.type)) {
            say('Choose a PNG, JPEG, or WebP starting image.');
            return;
        }
        if (file.size > 20 * 1024 * 1024) {
            say('The starting image must be 20 MB or smaller.');
            return;
        }
        sourceFile = file;
        if (preview.dataset.objectUrl) URL.revokeObjectURL(preview.dataset.objectUrl);
        const url = URL.createObjectURL(file);
        preview.dataset.objectUrl = url;
        preview.src = url;
        preview.hidden = false;
        sourcePrompt.hidden = true;
        updateButton();
        say('Starting image ready.');
    }

    input.addEventListener('change', () => setSource(input.files?.[0]));
    prompt.addEventListener('input', updateButton);
    drop.addEventListener('dragover', event => { event.preventDefault(); drop.classList.add('dragging'); });
    drop.addEventListener('dragleave', () => drop.classList.remove('dragging'));
    drop.addEventListener('drop', event => {
        event.preventDefault();
        drop.classList.remove('dragging');
        setSource(event.dataTransfer?.files?.[0]);
    });

    function missingFilesText(missing) {
        return missing.map(item => `models/${item.folder}/${item.file}`).join('\n');
    }

    function api(action, body) {
        return fetch(`/api/studio?action=${action}`, {
            method: body ? 'POST' : 'GET',
            cache: 'no-store',
            headers: body ? { 'Content-Type': 'application/json' } : {},
            body: body ? JSON.stringify(body) : undefined,
            signal: AbortSignal.timeout(20000)
        }).then(async response => {
            const result = await response.json().catch(() => ({}));
            if (!response.ok) throw new Error(result.error || 'The studio could not complete that request.');
            return result;
        });
    }

    async function pngBytes(file) {
        const bitmap = await createImageBitmap(file);
        const scale = Math.min(1, 2048 / Math.max(bitmap.width, bitmap.height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(16, Math.round(bitmap.width * scale));
        canvas.height = Math.max(16, Math.round(bitmap.height * scale));
        const context = canvas.getContext('2d', { alpha: false });
        context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
        bitmap.close();
        const blob = await new Promise((resolve, reject) => canvas.toBlob(value =>
            value ? resolve(value) : reject(new Error('Could not prepare the starting image.')), 'image/png'));
        return new Uint8Array(await blob.arrayBuffer());
    }

    async function uploadInput(id, file) {
        const plain = await pngBytes(file);
        const sealed = await window.StudioCrypto.sealBinary(plain);
        const response = await fetch(`/api/studio?action=upload-asset&id=${encodeURIComponent(id)}&type=input`, {
            method: 'POST', body: sealed, headers: { 'Content-Type': 'application/octet-stream' }
        });
        const result = await response.json().catch(() => ({}));
        if (!response.ok || !result.key) throw new Error(result.error || 'Could not upload the starting image.');
        return result.key;
    }

    async function submit() {
        if (generate.disabled || busy) return;
        if (window.StudioCrypto?.isUnlocked && !window.StudioCrypto.isUnlocked()) {
            say('Unlock the studio before generating a video.');
            return;
        }
        const refusal = window.StudioContentGuard?.unsafeImagePrompt(prompt.value, '', 'img2vid');
        if (refusal) { say(refusal); return; }
        busy = true;
        updateButton();
        try {
            const id = crypto.randomUUID();
            say('Preparing and encrypting the starting image…');
            const inputImageKey = await uploadInput(id, sourceFile);
            say('Queueing WAN 2.2 video generation…');
            const sealedPrompt = await window.StudioCrypto.sealText(prompt.value.trim());
            const accepted = await api('generate', {
                id, mode: 'img2vid', model: 'wan22_i2v', durationFrames: 81,
                inputImageKey, prompt: sealedPrompt, negativePrompt: '',
                ratio: 'wide', resolution: '1mp', seed: ''
            });
            lastGeneratedId = accepted.id;
            say('Video queued. You can leave this tab open while it renders.');
            await refresh();
        } catch (error) {
            say(error.message || 'Could not queue the video.');
        } finally {
            busy = false;
            updateButton();
        }
    }

    generate.addEventListener('click', submit);

    modelInstallButton.addEventListener('click', async () => {
        modelInstallButton.disabled = true;
        try {
            await api('video-model-install', {});
            say('Starting the resumable WAN 2.2 model download…');
            await refresh();
        } catch (error) {
            modelInstallButton.disabled = false;
            say(error.message || 'Could not start the WAN model download.');
        }
    });

    async function videoUrl(job) {
        if (videos.has(job.id)) return videos.get(job.id);
        const pending = (async () => {
            const response = await fetch(`/api/studio?action=video&id=${encodeURIComponent(job.id)}`, { cache: 'no-store' });
            if (!response.ok) throw new Error('Video is not ready yet.');
            const sealed = new Uint8Array(await response.arrayBuffer());
            const bytes = await window.StudioCrypto.unsealBinary(sealed);
            return URL.createObjectURL(new Blob([bytes], { type: 'video/mp4' }));
        })();
        videos.set(job.id, pending);
        pending.catch(() => videos.delete(job.id));
        return pending;
    }

    async function selectJob(job) {
        if (job.status !== 'complete') return;
        say('Loading the original MP4…');
        try {
            const url = await videoUrl(job);
            const player = document.createElement('video');
            player.controls = true;
            player.playsInline = true;
            player.preload = 'metadata';
            player.src = url;
            output.replaceChildren(player);
            if (selectedUrl && selectedUrl !== url) {
                // The URL remains cached for history until the page locks or closes.
            }
            selectedUrl = url;
            download.href = url;
            download.download = `AIStudio-${job.id}.mp4`;
            download.hidden = false;
            say('Video ready.');
        } catch (error) {
            say(error.message || 'Could not open this video.');
        }
    }

    function render() {
        jobsList.replaceChildren();
        if (!jobs.length) {
            const empty = document.createElement('p');
            empty.className = 'video-history-empty';
            empty.textContent = 'No video generations yet.';
            jobsList.append(empty);
            return;
        }
        for (const job of jobs) {
            const card = document.createElement('article');
            card.className = 'video-job-card';
            card.dataset.status = job.status;
            const title = document.createElement('strong');
            title.textContent = job.status === 'complete' ? 'WAN 2.2 · 5 seconds'
                : job.status === 'error' ? 'Video failed' : (job.status === 'queued' ? 'Queued' : 'Generating');
            const detail = document.createElement('p');
            detail.textContent = job.error || job.text || job.progress_stage || job.status;
            const action = document.createElement('button');
            action.className = 'button text-button';
            action.type = 'button';
            action.textContent = job.status === 'complete' ? 'Preview' : (job.status === 'error' ? 'Remove' : 'In queue');
            action.disabled = !['complete', 'error', 'cancelled'].includes(job.status);
            action.addEventListener('click', async () => {
                if (job.status === 'complete') await selectJob(job);
                else {
                    await api('delete', { id: job.id });
                    await refresh();
                }
            });
            card.append(title, detail, action);
            jobsList.append(card);
        }
    }

    async function refresh() {
        if (busy || !window.StudioCrypto?.isUnlocked?.()) return;
        busy = true;
        try {
            const result = await api('status&paged=1');
            online = Boolean(result.online);
            const model = result.videoModel || { available: false, missing: [] };
            modelReady = Boolean(model.available);
            const install = result.videoModelInstall || {};
            modelInstalling = install.state === 'running';
            if (modelReady) {
                setupNote.textContent = 'WAN 2.2 is ready. Jobs run locally and the MP4 is saved on this PC.';
                modelInstallButton.hidden = true;
                modelProgress.hidden = true;
                modelProgressLabel.hidden = true;
            } else {
                if (modelInstalling) {
                    setupNote.textContent = 'Installing WAN 2.2 model files. Downloads resume after interruptions.';
                    modelInstallButton.hidden = true;
                    modelProgress.hidden = false;
                    modelProgress.value = Math.max(0, Math.min(100, Number(install.percent) || 0));
                    modelProgressLabel.hidden = false;
                    const amount = install.total ? ` · ${(install.downloaded / 1e9).toFixed(1)} / ${(install.total / 1e9).toFixed(1)} GB` : '';
                    modelProgressLabel.textContent = `${install.file || 'Preparing download'} · ${modelProgress.value}%${amount}`;
                } else {
                    setupNote.textContent = 'WAN 2.2 needs about 38 GB of model files. The download is optional and can be resumed:\n' + missingFilesText(model.missing || []);
                    modelInstallButton.hidden = false;
                    modelInstallButton.disabled = false;
                    modelInstallButton.textContent = install.state === 'error' ? 'Retry WAN 2.2 model download' : 'Download WAN 2.2 models · about 38 GB';
                    modelProgress.hidden = install.state !== 'error';
                    modelProgress.value = Math.max(0, Math.min(100, Number(install.percent) || 0));
                    modelProgressLabel.hidden = install.state !== 'error';
                    if (install.state === 'error') modelProgressLabel.textContent = install.error || 'Download incomplete. Partial files are kept so you can retry.';
                }
            }
            const raw = (result.jobs || []).filter(job => job.mode === 'img2vid');
            jobs = await Promise.all(raw.map(async job => {
                let text = job.prompt || '';
                try { text = await window.StudioCrypto.unsealText(job.prompt); } catch (_) { text = 'Sealed with a different Studio key.'; }
                return { ...job, text };
            }));
            jobs.sort((a, b) => (b.created || 0) - (a.created || 0));
            render();
            if (lastGeneratedId) {
                const finished = jobs.find(job => job.id === lastGeneratedId && job.status === 'complete');
                if (finished) { lastGeneratedId = null; await selectJob(finished); }
                else if (jobs.some(job => job.id === lastGeneratedId && job.status === 'error')) {
                    const failed = jobs.find(job => job.id === lastGeneratedId);
                    say(failed.error || 'Video generation failed.');
                    lastGeneratedId = null;
                }
            }
            updateButton();
        } catch (error) {
            online = false;
            updateButton();
            if (modeActive) say(error.message || 'The studio is not connected.');
        } finally {
            busy = false;
        }
    }

    function schedule() {
        clearTimeout(timer);
        if (!modeActive) return;
        timer = setTimeout(async () => { await refresh(); schedule(); }, 5000);
    }

    window.addEventListener('studio-mode-change', event => {
        modeActive = event.detail?.mode === 'video';
        if (modeActive) { refresh().finally(schedule); }
        else clearTimeout(timer);
    });
    window.addEventListener('studio-locked', () => {
        jobs = [];
        videos.clear();
        render();
        output.innerHTML = '<h3>No video selected</h3><p>Completed clips stay in your local history.</p>';
        download.hidden = true;
    });
    window.addEventListener('beforeunload', () => {
        for (const [id, pending] of videos) {
            Promise.resolve(pending).then(URL.revokeObjectURL).catch(() => {});
            videos.delete(id);
        }
        if (preview.dataset.objectUrl) URL.revokeObjectURL(preview.dataset.objectUrl);
        if (selectedUrl) URL.revokeObjectURL(selectedUrl);
    });
    updateButton();
}());

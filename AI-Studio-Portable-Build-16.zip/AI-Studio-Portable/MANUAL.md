# AI Studio Portable — User Manual

Welcome to **AI Studio Portable**, a self-contained, local desktop studio for image generation, image editing, and conversational AI.

All image rendering and language model inference happen entirely on your computer using your graphics card. Your prompts, images, conversations, and personal data are never sent to external servers or cloud services for generation.

---

## Table of Contents

1. [Introduction & How It Works](#1-introduction--how-it-works)
2. [System Requirements & Installation](#2-system-requirements--installation)
3. [Studio Modes & Workflows](#3-studio-modes--workflows)
   - [Text to Image](#mode-1-text-to-image)
   - [Image to Image](#mode-2-image-to-image)
   - [Inpaint](#mode-3-inpaint)
   - [Chat & Assistant](#mode-4-chat--assistant)
4. [Managing Models](#4-managing-models)
   - [Model Types & Folder Structure](#model-types--folder-structure)
   - [Adding Models](#adding-models)
   - [Using Existing ComfyUI Models](#using-existing-comfyui-models)
   - [The Models & LoRA Panel](#the-models--lora-panel)
5. [Hardware Tuning & Video Memory (VRAM)](#5-hardware-tuning--video-memory-vram)
   - [VRAM Allocation Modes](#vram-allocation-modes)
   - [Engine Swapping](#engine-swapping)
   - [Preventing Out-of-Memory Errors](#preventing-out-of-memory-errors)
6. [Settings & Configuration](#6-settings--configuration)
   - [In-App Settings](#in-app-settings)
   - [Advanced Configuration (`config.json`)](#advanced-configuration-configjson)
   - [Storage Encryption & Privacy](#storage-encryption--privacy)
   - [Port and Network Configuration](#port-and-network-configuration)
7. [Updates & Maintenance](#7-updates--maintenance)
   - [How Updates Work](#how-updates-work)
   - [Checking for Updates](#checking-for-updates)
   - [Backing Up Your Data](#backing-up-your-data)
8. [Troubleshooting & Diagnostics](#8-troubleshooting--diagnostics)
   - [Common Problems & Fixes](#common-problems--fixes)
   - [Reporting a Problem](#reporting-a-problem)
   - [Safety & Content Boundaries](#safety--content-boundaries)

---

## 1. Introduction & How It Works

AI Studio Portable is designed around a single principle: **complete local control without complicated installation**.

The application unifies two local engines behind a clean, modern web interface:
* **ComfyUI** (running on port `8189`): Drives image generation, diffusion models, LoRAs, and inpainting.
* **llama.cpp** (running on port `8080`): Drives local language models, multimodal vision, and conversational memory.

### What Goes Over the Network?
Generation and chat run entirely locally. The only times network connections are made are:
1. **First-run setup**: Downloading the private Python runtime, backend engines, and selected models.
2. **Update checks**: Contacting the release repository once at startup (or on demand) to check if a newer build exists.
3. **Web search in Chat**: If you deliberately toggle Web Search on in a chat, your search query is sent to DuckDuckGo or Bing to retrieve live facts.
4. **Installing new models**: Contacting the model host directly when downloading through the installer.

### Directory Structure & Data Ownership
Everything related to AI Studio Portable lives within its root directory:

```
AIStudioPortable/
├── Start.bat           # Launcher script (double-click to run)
├── MANUAL.md           # This user manual
├── README.md           # Quick start guide
├── CHANGELOG.md        # Log of changes for every build
├── config.json         # Optional custom configuration overrides
├── app/                # Server, orchestrator, and backend logic
├── web/                # Studio user interface (HTML/CSS/JS)
├── workflows/          # Graph templates for image generation
├── runtime/            # Embedded Python and engine binaries
├── comfy/              # Internal ComfyUI installation and nodes
├── models/             # Where your models and LoRAs reside
├── data/               # Your generated images, database, and settings
└── logs/               # Operational logs for diagnostics
```

Everything inside `data/` (your images, chat history, and databases) and `models/` belongs exclusively to you. When updates are downloaded and installed, they replace only the program code (`app/`, `web/`, etc.); your models, settings, and generated outputs are never overwritten or deleted.

---

## 2. System Requirements & Installation

### Requirements
* **Operating System**: Windows 10 or Windows 11 (64-bit).
* **Graphics Card**: An NVIDIA GeForce or RTX GPU.
  * **12 GB VRAM or higher**: The recommended reference configuration. Allows smooth image generation up to high resolutions while holding chat models comfortably.
  * **8 GB VRAM**: The minimum viable configuration. Supported via automatic aggressive memory offloading; higher resolutions (> 2 megapixels) and larger chat models will be constrained.
* **System Memory (RAM)**: 16 GB or higher recommended.
* **Disk Space**:
  * ~10 GB for the studio, private runtime, and engine components.
  * Additional storage for models: ~20 GB for a basic setup, 50 GB to 100+ GB for a full library of image and chat models.
  * Fast SSD storage is strongly recommended for loading model weights quickly.

> **Note on other hardware**: AMD Radeon, Intel Arc, and Apple Silicon GPUs are not supported.

### First-Time Setup
AI Studio Portable requires **no pre-installed Python, Git, Visual Studio, or CUDA toolkits**.

1. Extract or clone AI Studio Portable into a directory of your choice on a drive with ample free space (for example, on an SSD).
2. Double-click **`Start.bat`**.
3. On its first run, the installer:
   * Downloads a private, isolated Python runtime (~60 MB).
   * Sets up the internal ComfyUI engine and custom nodes.
   * Downloads the llama.cpp engine.
   * Prompts you to select your initial model package based on your GPU's detected VRAM.
4. All downloads are resumable. If a network interruption occurs, running `Start.bat` again resumes exactly where it stopped.
5. Once installation finishes, the studio server starts and automatically opens your web browser to:
   ```
   http://127.0.0.1:8760
   ```

### Daily Usage
* **To start**: Double-click `Start.bat`. It checks the environment, boots the background server, and opens the studio in your browser.
* **To stop**: Close the command prompt terminal window running `Start.bat`.

---

## 3. Studio Modes & Workflows

AI Studio Portable provides four distinct modes accessible via the top tab bar:

### Mode 1: Text to Image

Generate high-quality images from written text descriptions.

1. **Prompt**: Enter a descriptive prompt in the main prompt box. Describe the subject, environment, lighting, artistic style, and details.
2. **Negative Prompt**: Use the negative prompt field to specify elements you want the model to avoid (e.g. blurry, distorted, low quality).
3. **Aspect Ratio & Resolution**:
   * Choose from quick presets: **Square** (1:1), **Portrait** (2:3, 3:4, 9:16), or **Landscape** (3:2, 4:3, 16:9).
   * Base sizes are tuned for the selected model architecture (typically 1024x1024 or 832x1216 for modern models).
4. **LoRA Layers**:
   * Click **Add LoRA** to attach fine-tuning layers for specific characters, concepts, or artistic styles.
   * Adjust the strength slider for each layer (standard values range from `0.5` to `0.9`).
   * Trigger words associated with the LoRA are automatically integrated or displayed for reference.
5. **Generation Settings**:
   * **Steps**: The number of sampling iterations. Higher steps add detail up to a point (typically 20–30 steps for standard checkpoints; 4–8 steps for turbo/lightning models).
   * **CFG Scale (Guidance)**: How strictly the model follows your prompt. Typical range: `4.0` to `7.0`. Excessively high values cause contrast oversaturation and artifacts.
   * **Sampler & Scheduler**: Select the sampling algorithm (e.g., `Euler`, `DPM++ 2M`, `UniPC`) and schedule (e.g., `Karras`, `Exponential`).
   * **Seed**: Set to `-1` for a new randomized image every generation. Click the lock icon to lock a specific seed when making incremental prompt or LoRA adjustments.
6. **Generate**: Press the **Generate** button or press `Ctrl + Enter`.

---

### Mode 2: Image to Image

Transform or restyle an existing image while preserving its overall structure and composition.

1. **Load Reference Image**: Drag and drop an image into the reference area, or click to browse.
2. **Denoise Strength**: The primary control for transformation:
   * **Low Denoise (`0.20` – `0.35`)**: Minor styling, subtle color adjustments, and texture enhancements. The original geometry remains intact.
   * **Medium Denoise (`0.40` – `0.65`)**: Substantial transformation. The subject shifts and adapts to the prompt while preserving general poses and compositions.
   * **High Denoise (`0.70` – `0.90`)**: Radical reimagining. Only broad color blocks and coarse outlines from the original image are retained.
3. **Prompt & Guidance**: Write a prompt describing the desired outcome.
4. **Model Architecture**: Image-to-image is tuned for models with dedicated img2img pipeline support (such as Krea 2). If an unsupported model is selected, the studio alerts you before running.

---

### Mode 3: Inpaint

Edit, replace, or repair specific regions of an image using an integrated brush mask editor powered by LanPaint.

1. **Load Canvas Image**: Upload an image or send an image directly to Inpaint from your Generation History.
2. **The Masking Canvas**:
   * **Brush Tool**: Paint over the areas of the image you want to change.
   * **Brush Size**: Adjust the brush slider for fine detail or broad coverage.
   * **Eraser**: Clean up excess mask coverage.
   * **Pan & Zoom**: Hold the spacebar or use mouse controls to zoom in for pixel-accurate mask painting.
3. **Masking Best Practices**:
   * Paint slightly beyond the border of the object you want to replace. A small margin allows the diffusion model to seamlessly blend the new pixels into the surrounding image.
4. **Prompt the Change**: In the prompt box, describe what should appear inside the painted mask (for example: `"wearing a dark blue leather jacket"` or `"vintage brass pocket watch"`).
5. **Render Inpaint**: Click **Generate**. The unmasked regions are protected and kept pixel-perfect, while the masked area is redrawn and blended.

---

### Mode 4: Chat & Assistant

An uncensored, local conversational AI powered by llama.cpp that runs entirely on your own GPU.

1. **Conversations**:
   * Create new chats or browse previous discussions in the chat sidebar.
   * Conversations are saved locally in SQLite (`data/`).
2. **Multimodal Vision (Image Analysis)**:
   * Click the paperclip icon or drag and drop images directly into the chat input.
   * If your loaded model supports vision (with an active `.mmproj` projector), the assistant can inspect images, read text, identify objects, and analyze visual compositions.
3. **Document Ingestion**:
   * Attach PDF files or plain text documents to the chat. The assistant reads the content locally and allows you to summarize, search, or query the document.
4. **Web Search**:
   * Toggle the **Web Search** button next to the prompt input when you need up-to-date facts, current events, or live documentation.
   * Queries are issued directly from your machine to privacy-oriented search engines (DuckDuckGo or Bing), and results are summarized in the response.
5. **Generating Images in Chat**:
   * You can ask the assistant to generate an image as part of the conversation. The assistant constructs a suitable prompt and routes it directly to the image engine, posting the rendered image inline in your chat thread.
6. **Context Management & Compaction**:
   * Local models have finite context windows (typically 4,096 to 16,384 tokens).
   * When conversations become lengthy, click the context indicator or use the **Compact Context** option. The model summarizes earlier dialogue turns to free up memory without losing conversational history.

---

## 4. Managing Models

AI Studio Portable separates models by role to keep your installation organized.

### Model Types & Folder Structure

All models reside under the `models/` directory:

| Folder | What Goes Here | Common File Formats |
|---|---|---|
| `models/checkpoints/` | All-in-one models (SDXL, Illustrious, Pony) containing the model, text encoder, and VAE in one file. | `.safetensors` |
| `models/diffusion_models/` | Split diffusion weights (Krea 2, Anima) where text encoders and VAE are separate files. | `.safetensors` |
| `models/text_encoders/` | Text encoders for split models (CLIP-L, CLIP-G, T5-XXL). | `.safetensors` |
| `models/vae/` | Variational Autoencoders (decoders that convert latents into final images). | `.safetensors` |
| `models/loras/` | Low-Rank Adaptation layers for characters, art styles, or concepts. | `.safetensors` |
| `models/llm/` | Chat models and conversational assistants. | `.gguf` |
| `models/clip_vision/` | Vision encoders used by chat models and image reference conditioning. | `.safetensors`, `.gguf`, `.mmproj` |
| `models/upscale_models/` | Super-resolution upscalers (RealESRGAN, 4x-UltraSharp). | `.pth`, `.safetensors` |
| `models/controlnet/` | ControlNet conditioning models (Canny, Depth, OpenPose). | `.safetensors` |
| `models/embeddings/` | Textual inversions and negative embedding vectors. | `.safetensors`, `.pt` |

### Adding Models

1. Download your desired model file (`.safetensors` for image models, `.gguf` for chat models).
2. Move or copy the file into the corresponding folder inside `models/`.
3. In the studio web interface, open the **Models** panel and click **Rescan** (or simply restart `Start.bat`). The studio reads the file headers, inspects the architecture, and adds the model to your selector.

> **Tip on Checkpoint vs. Diffusion Folders**: The studio reads the inner structure of `.safetensors` files directly. If you accidentally place a split diffusion model in `models/checkpoints/`, the studio will still recognize its true architecture.

### Using Existing ComfyUI Models

If you already have a ComfyUI installation or an existing models library on another drive, **you do not need to duplicate files or waste disk space**.

You can point AI Studio Portable to your existing model folder:
1. Open the **Settings** dialog (gear icon in the top header) and find **Shared Models Folder**.
2. Alternatively, open `config.json` in a text editor and set `models_path`:
   ```json
   "models_path": "E:/SomeWhere/ComfyUI/models"
   ```
3. The studio treats this directory as **strictly read-only**. It will read checkpoints, LoRAs, and VAEs where they sit, and will never move, rename, delete, or write files in your external directory.

### The Models & LoRA Panel

Click the model selector in the image generator or navigate to the Models panel in Settings to:
* View installed models and their detected architectures.
* Assign custom default pipelines if a file's purpose is ambiguous (e.g. photorealistic vs. anime presets).
* Manage installed LoRAs, set default trigger words, and assign default activation strengths.

---

## 5. Hardware Tuning & Video Memory (VRAM)

Video RAM is the primary resource on your GPU. AI Studio Portable includes dynamic memory management to maximize performance and prevent crashes.

### VRAM Allocation Modes

You can adjust how aggressively the studio manages GPU memory in the **Settings** dialog under **Video Memory (VRAM)**, or via `"vram_mode"` in `config.json`:

* **`auto` (Default — Recommended)**: Measures your GPU's physical VRAM at startup and selects the optimal operating profile automatically.
* **`high`**: For GPUs with 16 GB to 24 GB+ VRAM. Keeps models pinned in video memory for maximum generation speed and lowest latency.
* **`normal`**: The standard balance for 12 GB VRAM cards. Unloads parts of models between generations when needed.
* **`low`**: Recommended for GPUs with **8 GB VRAM**, or if generations fail with memory errors. Uses aggressive layer offloading to system RAM.
* **`minimum`**: For constrained situations. Keeps only the currently executing calculation layer in VRAM. Slower, but allows rendering on cards that would otherwise crash.

### Engine Swapping

Because ComfyUI (images) and llama.cpp (chat) both utilize the graphics card, running both simultaneously on cards with 8 GB to 12 GB of VRAM could exceed memory limits.

* The orchestrator coordinates access: when you switch from Chat to Image Generation, the chat model is safely offloaded or placed on standby before the diffusion model loads.
* **`keep_chat_loaded`**: If you have a 16 GB or 24 GB GPU and want instantaneous chat responses even while generating images, enable `"keep_chat_loaded": true` in `config.json` or Settings.

### Preventing Out-of-Memory (OOM) Errors

If you encounter CUDA Out of Memory errors:
1. **Reduce Image Dimensions**: Lower the resolution. Generating above 1.5–2 megapixels (e.g., beyond 1280x1280) requires significant VRAM.
2. **Switch VRAM Mode**: Change your VRAM setting from `auto` or `normal` to **`low`**.
3. **Limit Active LoRAs**: Each active LoRA adds memory overhead. Disable unused LoRA layers.
4. **Close Background GPU Applications**: Close GPU-intensive 3D games, video editors, or browsers with hardware acceleration if free VRAM is tight.

---

## 6. Settings & Configuration

### In-App Settings

Click the **gear icon** in the top navigation bar to open the Settings panel. From here, you can configure:
* **Help & Manual**: Open the complete publication-grade User Manual (`USER_MANUAL.pdf`) directly in your browser, or jump to the Version Log.
* **VRAM Profile**: Set your memory allocation mode (`auto`, `high`, `normal`, `low`, `minimum`).
* **Default Chat Model**: Choose which model loads when starting a new conversation.
* **Image Retention Limits**: Set maximum image storage count and auto-cleanup hours.
* **Updates**: Check for new builds or toggle automatic startup checks.
* **Theme & Appearance**: Switch between light/dark modes or open the color scheme customizer.

### Advanced Configuration (`config.json`)

To override configuration settings programmatically or set advanced server options, create or edit `config.json` in the root folder. A full reference is available in `config.example.json`:

```json
{
  "host": "127.0.0.1",
  "port": 8760,
  "open_browser": true,
  "vram_mode": "auto",
  "default_chat_model": "",
  "keep_chat_loaded": false,
  "check_updates": true,
  "update_url": "https://raw.githubusercontent.com/regula-a1/AI-Studio-Portable-Updater/main/latest.json",
  "models_path": "",
  "retention_hours": 72,
  "retention_images": 40,
  "encrypt_storage": false,
  "studio_key": ""
}
```

> **Note on Windows paths in JSON**: Always use forward slashes (`/`) or doubled backslashes (`\\`) in path strings (e.g. `"E:/SomeWhere/ComfyUI/models"`).

### Storage Encryption & Privacy

By default, generated images are stored as standard PNG files in `data/images/`, readable by any viewer on your computer.

If you share your computer or store the studio folder on a synced drive:
1. Set `"encrypt_storage": true` in `config.json`.
2. When launching the studio, you will be prompted to enter a **Studio Access Key**.
3. Images, prompts, drafts, and conversations are encrypted on disk using the studio's cryptographic envelope (`ASP1`).
4. **Warning**: There is no password recovery. If you lose your access key, encrypted data on disk cannot be decrypted.

### Port and Network Configuration

* **`host`**: Defaults to `127.0.0.1` (localhost only). Do not expose to public networks without authentication.
* **`port`**: Web interface port (default: `8760`).
* **`comfy_port`**: Internal ComfyUI engine port (default: `8189`).
* **`llm_port`**: Internal llama-server engine port (default: `8080`). If another service on your PC already uses port 8080, change `llm_port` in `config.json`.
* **`coding_lock_port` / `coding_lock_file`**: If you run a local coding assistant or other GPU service that cannot share memory, you can configure a lock port or lock file so AI Studio Portable pauses and waits rather than competing for VRAM.

---

## 7. Updates & Maintenance

### How Updates Work
AI Studio Portable uses a clean, single-number build system: **Build 1, Build 2, Build 3...** (no confusing decimal versions).

* The build number you are currently running is displayed faintly in the bottom-right corner of the interface.
* Clicking the build number opens the **Version Log**, which shows the release date and detailed notes for every build, and includes a direct button to open the **User manual**.
* Updates are distributed as clean code archives. They replace only the engine and interface code. **Your models, images, conversations, and custom settings are never touched.**

### Checking for Updates
1. The studio automatically checks for updates once at startup (unless disabled in settings).
2. If a newer build is available, an **Update available** button appears in the top header.
3. You can also manually check by clicking the build badge in the bottom corner and clicking **Check for updates**.
4. When you choose to install an update, the studio downloads the archive, verifies its cryptographic SHA-256 hash, extracts it to a temporary staging area, and applies it cleanly.

### Backing Up Your Data
To back up your personal content, you only need to copy these items:
* `data/`: Contains your SQLite database (chat logs, prompts, generation metadata) and `data/images/`.
* `models/`: Contains your downloaded checkpoints, LoRAs, and LLM weights.
* `config.json`: Contains your custom configuration settings.

---

## 8. Troubleshooting & Diagnostics

### Common Problems & Fixes

#### 1. Generation Fails with "CUDA out of memory"
* Go to **Settings** and change **Video Memory (VRAM)** to **Low**.
* Lower your generation resolution (e.g., from 1280x1280 down to 896x896 or 768x768).
* Disable extra LoRA layers.
* Verify that no other GPU-intensive applications are running in Windows.

#### 2. The Studio Fails to Start or Shows a Connection Error
* Ensure port `8760`, `8189`, or `8080` is not being held by another program. Check `logs/` for startup messages.
* If a previous instance exited abnormally, check Task Manager for lingering `python.exe` or `llama-server.exe` processes and end them.
* Try running `Start.bat` directly from an open Command Prompt window to view any immediate console errors.

#### 3. A Downloaded Model Does Not Appear in the UI
* Verify that the model was placed into the correct subdirectory (e.g. `models/checkpoints/` or `models/loras/`).
* Ensure the file is completely downloaded and not a partial `.crdownload` or temporary file.
* Open the **Models** panel in Settings and click **Rescan**.

#### 4. Generations Are Blurry, Distorted, or All Black/White
* Check your model's required VAE. Some split models require an explicit VAE (like `sdxl_vae.safetensors`) in `models/vae/`.
* Check your CFG scale. Excessively high CFG values (e.g. > 12) cause color burning; very low CFG (< 2) causes washed-out images.
* Turbo/Lightning models require lower step counts (typically 4 to 8 steps) and low CFG (1.0 to 2.0). Check your model publisher's recommended settings.

---

### Reporting a Problem

If you encounter a bug or unexpected error:
1. Click the **Report a problem** button in the top header bar.
2. The studio generates an anonymized diagnostic report containing recent error logs, hardware configuration details, and engine states.
3. **Privacy Scrubber**: The diagnostic report automatically scrubs usernames, machine names, personal file paths, and private prompt text before creating the report file.
4. Save the diagnostic file to share for support or debugging.

---

### Safety & Content Boundaries

AI Studio Portable is designed for personal, uncensored creative freedom. Generation parameters are not moralized, prompt filters are not imposed on adult creative work, and prompts are never sent to external moderation relays.

**The One Non-Negotiable Limit**:
* The studio contains strict, locally enforced code blocks against producing sexual material involving minors (CSAM), in both conversational chat and image generation.
* Prompts violating this rule are refused locally before reaching the engine.
* Refusals occur entirely on your own machine without network telemetry.

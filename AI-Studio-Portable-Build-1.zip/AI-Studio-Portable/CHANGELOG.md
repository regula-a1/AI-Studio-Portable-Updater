# Version log

Builds are numbered from 1 and count up by one, forever. There are no decimals
and no major or minor versions - Build 7 came after Build 6, and that is the
whole system. The number you are running is shown faintly in the corner of the
studio; click it to read this list.

Every build published adds an entry here first. The entry is what the studio
shows you when you restart after an update, so if it is not written down, you
were not told.

## Build 1 - 2026-09-17

The first release.

- Four modes in one window: text to image, image to image, inpainting, and chat.
- Everything runs on your own machine. No prompt, image or conversation is ever
  sent anywhere - generation and chat happen entirely on your own hardware, and
  the studio works with the network unplugged once it is installed. Three things
  do use the network, all of them visible: turning on web search sends that
  query to Bing or DuckDuckGo, installing a model downloads it from that model's
  own host, and the studio checks once at startup whether a newer build exists.
  You can switch the update check off in config.json.
- One folder holds all of it. The installer puts ComfyUI, llama.cpp, Python and
  the models inside the studio folder rather than anywhere else on your PC, so
  moving it means moving the folder and removing it means deleting the folder.
- Models you already have elsewhere are found and used where they are, and the
  studio only ever reads them.
- Krea 2 Turbo for images, with LoRA support, an upscaler, and a masked editor
  for changing part of an image instead of regenerating it.
- Chat is deliberately disabled in this build. It answers everything with the
  same nonsense phrase on purpose: this build exists to prove the update
  pipeline works from end to end, and the clearest way to see an update land is
  for the before and after to be impossible to confuse. The next build turns
  chat on properly - Qwen3 1.7B, with memory, document reading and optional web
  search.
- Sixteen colour schemes and a light/dark switch.
- A problem report you can read in full before it is saved, which never contains
  your prompts, images, conversations or file paths.
- Updates arrive by themselves: the studio notices a new build, asks before
  downloading anything, and never touches your images, models or settings.
